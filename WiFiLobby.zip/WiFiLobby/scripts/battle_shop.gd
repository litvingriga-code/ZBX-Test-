extends PanelContainer
## Stage84: окно магазина на карте «Титаник». Продаёт турели за деньги профиля (GameState.money).
## Покупка кладёт турель в ячейки «Предметы» боевого инвентаря; ставится она кнопкой «Использовать».

signal closed

const UiGray = preload("res://scripts/ui_gray.gd")
const GOLD := Color(0.86, 0.86, 0.89)   # акцент теперь светло-серый
const TEXT := Color(0.93, 0.93, 0.94)

var balance_label: Label
var owned_label: Label
var message_label: Label
var buy_button: Button


func _ready() -> void:
    visible = false
    mouse_filter = Control.MOUSE_FILTER_STOP
    theme = UiGray.make_theme(22)
    z_index = 40
    anchor_left = 0.5
    anchor_right = 0.5
    anchor_top = 0.5
    anchor_bottom = 0.5
    offset_left = -250.0
    offset_right = 250.0
    offset_top = -190.0
    offset_bottom = 190.0
    var style := StyleBoxFlat.new()
    style.bg_color = UiGray.PANEL
    style.border_color = UiGray.EDGE
    style.set_border_width_all(2)
    style.set_corner_radius_all(8)
    style.set_content_margin_all(14)
    add_theme_stylebox_override("panel", style)

    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 10)
    add_child(root)

    var top := HBoxContainer.new()
    root.add_child(top)
    var heading := _label("МАГАЗИН · ТУРЕЛИ", 22, GOLD)
    heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(heading)
    var close := Button.new()
    close.text = "✕"
    close.custom_minimum_size = Vector2(52, 44)
    close.pressed.connect(close_shop)
    top.add_child(close)

    balance_label = _label("", 17, GOLD)
    root.add_child(balance_label)

    var card := PanelContainer.new()
    var card_style := StyleBoxFlat.new()
    card_style.bg_color = UiGray.RAISED
    card_style.set_corner_radius_all(6)
    card_style.set_content_margin_all(10)
    card.add_theme_stylebox_override("panel", card_style)
    root.add_child(card)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    card.add_child(row)
    var picture := TextureRect.new()
    picture.custom_minimum_size = Vector2(150, 118)
    picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    if ResourceLoader.exists("res://assets/shop/turret.png"):
        picture.texture = load("res://assets/shop/turret.png") as Texture2D
    row.add_child(picture)
    var info := VBoxContainer.new()
    info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(info)
    info.add_child(_label("Автоматическая турель", 19))
    info.add_child(_label("Ставится перед вами и сама стреляет по зомби в радиусе %d м. Урон %d, %d выстрелов в секунду, %d патронов в одной турели." % [
            int(Net.TURRET_RANGE), Net.TURRET_DAMAGE, int(round(1.0 / Net.TURRET_INTERVAL)), Net.TURRET_AMMO], 14))
    info.add_child(_label("Лимит: %d турели на игрока. Использовать — в инвентаре." % Net.TURRET_MAX_PER_PLAYER, 13, UiGray.TEXT_DIM))
    info.add_child(_label("Цена: %s $" % GameState.format_money(GameState.TURRET_PRICE), 20, GOLD))

    owned_label = _label("", 15)
    root.add_child(owned_label)
    buy_button = Button.new()
    buy_button.text = "Купить турель"
    buy_button.custom_minimum_size = Vector2(0, 56)
    buy_button.add_theme_font_size_override("font_size", 20)
    buy_button.pressed.connect(_buy)
    root.add_child(buy_button)
    message_label = _label("", 15, UiGray.TEXT_DIM)
    root.add_child(message_label)
    GameState.changed.connect(_refresh)


func open_shop() -> void:
    message_label.text = ""
    _refresh()
    show()


func close_shop() -> void:
    hide()
    closed.emit()


func _buy() -> void:
    message_label.text = GameState.buy_turret()
    _refresh()


func _refresh() -> void:
    if balance_label == null:
        return
    balance_label.text = "Ваш баланс: %s $" % GameState.format_money(GameState.money)
    owned_label.text = "В инвентаре турелей: %d" % GameState.count_battle_item("turret")
    buy_button.disabled = GameState.money < GameState.TURRET_PRICE
    buy_button.text = "Купить турель — %s $" % GameState.format_money(GameState.TURRET_PRICE) \
            if GameState.money >= GameState.TURRET_PRICE else "Недостаточно денег"


func _label(value: String, size_px: int = 16, color: Color = TEXT) -> Label:
    var label := Label.new()
    label.text = value
    label.add_theme_font_size_override("font_size", size_px)
    label.add_theme_color_override("font_color", color)
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    return label
