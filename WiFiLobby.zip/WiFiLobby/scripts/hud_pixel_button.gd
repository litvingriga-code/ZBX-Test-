extends Button
## Accept touch/click only on visible pixels of the HUD icon.
## Godot calls _has_point for GUI hit testing (including touch).
const ALPHA_THRESHOLD: float = 0.12
var _cached_texture: Texture2D
var _cached_image: Image

func _has_point(point: Vector2) -> bool:
    if not Rect2(Vector2.ZERO, size).has_point(point):
        return false
    if icon == null:
        return false
    if _cached_texture != icon:
        _cached_texture = icon
        _cached_image = icon.get_image()
    if _cached_image == null or _cached_image.is_empty():
        return false
    var texture_size := Vector2(_cached_image.get_width(), _cached_image.get_height())
    if texture_size.x <= 0.0 or texture_size.y <= 0.0:
        return false
    # expand_icon displays the image inside the button preserving its aspect ratio.
    var factor: float = minf(size.x / texture_size.x, size.y / texture_size.y)
    var display_size: Vector2 = texture_size * factor
    var origin: Vector2 = (size - display_size) * 0.5
    var uv: Vector2 = (point - origin) / display_size
    if uv.x < 0.0 or uv.y < 0.0 or uv.x >= 1.0 or uv.y >= 1.0:
        return false
    var px: int = clampi(int(uv.x * texture_size.x), 0, _cached_image.get_width() - 1)
    var py: int = clampi(int(uv.y * texture_size.y), 0, _cached_image.get_height() - 1)
    return _cached_image.get_pixel(px, py).a >= ALPHA_THRESHOLD
