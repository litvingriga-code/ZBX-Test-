extends RefCounted
## Процедурные модели оружия (этап 49: детализированные модели).
## Файл собран генератором из описаний деталей; править можно и руками.
## Все модели смотрят в -Z. Верх мушки/прицела находится на высоте, которая
## совпадает с "ads" из weapons.gd, поэтому в режиме прицеливания линия
## прицеливания проходит через центр камеры.
##
## Детали одного цвета склеены в один меш (см. model_kit.gd), подвижные
## части (магазин, затвор, цевьё, барабан) — отдельные узлы.
##
## build() возвращает словарь с ссылками на подвижные детали:
##   root, mag, mag_rest, mag_drop, slide, slide_rest, slide_back,
##   pump, pump_rest, pump_back, bolt, bolt_rest, bolt_back,
##   cylinder, cylinder_rest, eject (позиция вылета гильзы), flash.

const Kit = preload("res://scripts/model_kit.gd")
const GraphicsFX = preload("res://scripts/graphics_fx.gd")

const STEEL := Color(0.3, 0.32, 0.36)
const DARK := Color(0.13, 0.14, 0.16)
const BLACK := Color(0.07, 0.07, 0.08)
const WOOD := Color(0.4, 0.24, 0.11)
const WOOD_DARK := Color(0.29, 0.17, 0.08)
const BLADE := Color(0.78, 0.8, 0.84)
const BRASS := Color(0.85, 0.66, 0.25)
const GUN := Color(0.17, 0.18, 0.2)
const POLY := Color(0.09, 0.09, 0.1)
const BLUED := Color(0.1, 0.12, 0.16)
const ALU := Color(0.52, 0.54, 0.58)
const RUBBER := Color(0.05, 0.05, 0.05)
const SHELL_RED := Color(0.72, 0.12, 0.1)
const GLASS := Color(0.16, 0.3, 0.55)
const HOLE := Color(0.02, 0.02, 0.025)
const TAN := Color(0.55, 0.47, 0.32)
const OIL_WOOD := Color(0.46, 0.27, 0.12)

## Оружие, на которое можно поставить коллиматор (сам прицел — отдельный предмет).
const COLLIMATOR_KINDS := ["ak47", "m4a1"]


## Вспышка выстрела: скрыта, включается на ~0.05 с из battle.gd.
static func make_flash(parent: Node3D, pos: Vector3) -> Node3D:
    var holder := Node3D.new()
    holder.name = "MuzzleFlash"
    holder.position = pos
    holder.visible = false
    parent.add_child(holder)
    var glow := Kit.glow_material(Color(1.0, 0.82, 0.38))
    var hot := Kit.glow_material(Color(1.0, 0.97, 0.80))
    var core := SphereMesh.new()
    core.radius = 0.045
    core.height = 0.09
    core.radial_segments = 8
    core.rings = 4
    var core_node := MeshInstance3D.new()
    core_node.mesh = core
    core_node.material_override = hot
    holder.add_child(core_node)
    var cone := CylinderMesh.new()
    cone.top_radius = 0.06
    cone.bottom_radius = 0.0
    cone.height = 0.10
    cone.radial_segments = 6
    cone.rings = 1
    var cone_node := MeshInstance3D.new()
    cone_node.mesh = cone
    cone_node.material_override = glow
    cone_node.rotation_degrees = Vector3(-90, 0, 0)
    cone_node.position = Vector3(0, 0, -0.07)
    holder.add_child(cone_node)
    var star := BoxMesh.new()
    star.size = Vector3(0.20, 0.010, 0.05)
    for angle in [0.0, 60.0, 120.0]:
        var ray := MeshInstance3D.new()
        ray.mesh = star
        ray.material_override = glow
        ray.rotation_degrees = Vector3(0, 0, angle)
        ray.position = Vector3(0, 0, -0.01)
        holder.add_child(ray)
    for child in holder.get_children():
        (child as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    return holder


## collimator = true: на модель ставится коллиматор (только для kind из COLLIMATOR_KINDS).
static func build(kind: String, parent: Node3D, for_drop: bool = false, collimator: bool = false) -> Dictionary:
    var root := Node3D.new()
    root.name = "Model_" + kind
    parent.add_child(root)
    var refs: Dictionary = {"root": root}
    refs["collimator"] = collimator and kind in COLLIMATOR_KINDS
    match kind:
        "ak47": _ak47(root, refs)
        "m4a1": _m4a1(root, refs)
        "shotgun": _shotgun(root, refs)
        "svd": _svd(root, refs)
        "pm": _pm(root, refs)
        "revolver": _revolver(root, refs)
        "knife": _knife(root, refs)
        "machete": _machete(root, refs)
        "diamond_sword": _diamond_sword(root, refs)
    _gfx_details(kind, root, refs)
    if for_drop:
        root.rotation_degrees.y = 90.0
        if refs.has("flash"):
            (refs["flash"] as Node3D).free()
            refs.erase("flash")
    return refs


static func _ak47(root: Node3D, refs: Dictionary) -> void:
    var coll: bool = bool(refs.get("collimator", false))
    var k = Kit.new()
    k.box(Vector3(0.06, 0.085, 0.34), Vector3(0, 0, 0), GUN)
    k.box(Vector3(0.05, 0.072, 0.15), Vector3(0, 0.012, -0.24), GUN)
    k.box(Vector3(0.044, 0.026, 0.15), Vector3(0, 0.062, -0.24), STEEL)
    k.cyl_z(0.022, 0.022, 0.06, Vector3(0, 0.04, -0.3), STEEL, 10)
    k.box(Vector3(0.056, 0.024, 0.33), Vector3(0, 0.054, 0), STEEL)
    k.box(Vector3(0.052, 0.016, 0.3), Vector3(0, 0.068, -0.01), STEEL)
    k.box(Vector3(0.058, 0.004, 0.01), Vector3(0, 0.062, -0.12), DARK)
    k.box(Vector3(0.058, 0.004, 0.01), Vector3(0, 0.062, -0.05), DARK)
    k.box(Vector3(0.058, 0.004, 0.01), Vector3(0, 0.062, 0.02), DARK)
    k.box(Vector3(0.058, 0.004, 0.01), Vector3(0, 0.062, 0.09), DARK)
    k.cyl_z(0.01, 0.01, 0.02, Vector3(0, 0.06, 0.175), BLACK, 8)
    k.box(Vector3(0.004, 0.034, 0.1), Vector3(0.031, 0.04, 0.04), BLACK)
    k.box(Vector3(0.007, 0.08, 0.014), Vector3(0.033, -0.004, 0), STEEL)
    k.box(Vector3(0.03, 0.014, 0.024), Vector3(0.045, 0.05, 0.02), STEEL)
    k.cyl_x(0.01, 0.01, 0.024, Vector3(0.06, 0.05, 0.02), BLACK, 8)
    k.box(Vector3(0.052, 0.012, 0.014), Vector3(0, -0.044, -0.045), GUN)
    k.box(Vector3(0.03, 0.03, 0.07), Vector3(0, 0.088, -0.19), STEEL)
    if not coll: k.box(Vector3(0.008, 0.06, 0.012), Vector3(0.011, 0.128, -0.172), BLACK)
    if not coll: k.box(Vector3(0.008, 0.06, 0.012), Vector3(-0.011, 0.128, -0.172), BLACK)
    k.box(Vector3(0.028, 0.01, 0.05), Vector3(0, 0.108, -0.205), DARK, Vector3(-10, 0, 0))
    k.cyl_z(0.015, 0.015, 0.3, Vector3(0, 0.075, -0.52), STEEL, 10, 0.6, 0.4)
    k.cyl_z(0.029, 0.029, 0.29, Vector3(0, 0.062, -0.455), WOOD, 12, 0, 0.85)
    k.box(Vector3(0.06, 0.056, 0.27), Vector3(0, -0.016, -0.45), WOOD_DARK, Vector3(0, 0, 0), 0, 0.85)
    k.box(Vector3(0.062, 0.005, 0.012), Vector3(0, -0.046, -0.34), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.062, 0.005, 0.012), Vector3(0, -0.046, -0.38), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.062, 0.005, 0.012), Vector3(0, -0.046, -0.42), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.062, 0.005, 0.012), Vector3(0, -0.046, -0.46), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.062, 0.005, 0.012), Vector3(0, -0.046, -0.5), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.062, 0.005, 0.012), Vector3(0, -0.046, -0.54), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.064, 0.08, 0.014), Vector3(0, 0.01, -0.315), STEEL)
    k.box(Vector3(0.064, 0.08, 0.014), Vector3(0, 0.01, -0.605), STEEL)
    k.cyl_z(0.0125, 0.0125, 0.52, Vector3(0, 0.04, -0.74), STEEL, 10, 0.7, 0.35)
    k.box(Vector3(0.036, 0.052, 0.05), Vector3(0, 0.06, -0.7), STEEL)
    if not coll: k.box(Vector3(0.007, 0.073, 0.007), Vector3(0, 0.1215, -0.7), BLACK)
    if not coll: k.box(Vector3(0.004, 0.05, 0.026), Vector3(0.015, 0.118, -0.7), STEEL)
    if not coll: k.box(Vector3(0.004, 0.05, 0.026), Vector3(-0.015, 0.118, -0.7), STEEL)
    if not coll: k.box(Vector3(0.034, 0.004, 0.026), Vector3(0, 0.145, -0.7), STEEL)
    k.cyl_z(0.0045, 0.0045, 0.36, Vector3(0, 0.003, -0.8), DARK, 6)
    k.cyl_z(0.018, 0.018, 0.07, Vector3(0, 0.04, -1.04), STEEL, 10)
    k.box(Vector3(0.008, 0.034, 0.04), Vector3(0, 0.04, -1.05), HOLE)
    k.cyl_z(0.0135, 0.0135, 0.03, Vector3(0, 0.04, -1.09), DARK, 8)
    k.box(Vector3(0.018, 0.02, 0.032), Vector3(0, 0.02, -0.7), STEEL)
    k.box(Vector3(0.046, 0.13, 0.06), Vector3(0, -0.118, 0.13), WOOD_DARK, Vector3(-22, 0, 0), 0, 0.8)
    k.box(Vector3(0.04, 0.012, 0.058), Vector3(0, -0.184, 0.152), BLACK, Vector3(-22, 0, 0))
    k.box(Vector3(0.01, 0.008, 0.095), Vector3(0, -0.056, 0.022), STEEL)
    k.box(Vector3(0.01, 0.04, 0.008), Vector3(0, -0.04, -0.026), STEEL)
    k.box(Vector3(0.01, 0.036, 0.008), Vector3(0, -0.04, 0.07), STEEL)
    k.box(Vector3(0.007, 0.036, 0.01), Vector3(0, -0.036, 0.032), STEEL, Vector3(-14, 0, 0))
    k.box(Vector3(0.04, 0.085, 0.12), Vector3(0, 0, 0.205), WOOD, Vector3(0, 0, 0), 0, 0.85)
    k.box(Vector3(0.05, 0.118, 0.26), Vector3(0, -0.02, 0.32), WOOD, Vector3(5, 0, 0), 0, 0.85)
    k.box(Vector3(0.054, 0.134, 0.02), Vector3(0, -0.034, 0.455), BLACK, Vector3(5, 0, 0), 0, 0.9)
    k.box(Vector3(0.052, 0.008, 0.2), Vector3(0, 0.042, 0.315), WOOD_DARK, Vector3(5, 0, 0), 0, 0.9)
    k.cyl_x(0.008, 0.008, 0.012, Vector3(0.027, -0.015, 0.2), STEEL, 8)
    k.commit(root)
    if coll:
        refs["collimator_node"] = add_collimator(root, 0.076, 0.158, -0.06)
    var mag := Kit.group(root, Vector3(0, -0.05, -0.075), "Magazine")
    var k_mag = Kit.new()
    k_mag.box(Vector3(0.044, 0.0416, 0.074), Vector3(0, -0.02, 0), GUN)
    k_mag.box(Vector3(0.048, 0.006, 0.071), Vector3(0, -0.02, 0), BLACK)
    k_mag.box(Vector3(0.044, 0.0416, 0.074), Vector3(0, -0.0599, -0.0021), GUN, Vector3(6, 0, 0))
    k_mag.box(Vector3(0.048, 0.006, 0.071), Vector3(0, -0.0599, -0.0021), BLACK, Vector3(6, 0, 0))
    k_mag.box(Vector3(0.044, 0.0416, 0.074), Vector3(0, -0.0993, -0.0087), GUN, Vector3(13, 0, 0))
    k_mag.box(Vector3(0.048, 0.006, 0.071), Vector3(0, -0.0993, -0.0087), BLACK, Vector3(13, 0, 0))
    k_mag.box(Vector3(0.044, 0.0416, 0.074), Vector3(0, -0.1374, -0.0203), GUN, Vector3(21, 0, 0))
    k_mag.box(Vector3(0.048, 0.006, 0.071), Vector3(0, -0.1374, -0.0203), BLACK, Vector3(21, 0, 0))
    k_mag.box(Vector3(0.044, 0.0416, 0.074), Vector3(0, -0.1734, -0.0375), GUN, Vector3(30, 0, 0))
    k_mag.box(Vector3(0.048, 0.006, 0.071), Vector3(0, -0.1734, -0.0375), BLACK, Vector3(30, 0, 0))
    k_mag.box(Vector3(0.05, 0.014, 0.082), Vector3(0, -0.1947, -0.0475), STEEL, Vector3(30, 0, 0))
    k_mag.commit(mag)
    refs["mag"] = mag
    refs["mag_rest"] = mag.position
    refs["mag_drop"] = Vector3(0.0, -0.28, 0.04)
    refs["mag_drop_rot"] = Vector3(0, 0, 14)
    refs["eject"] = Vector3(0.045, 0.040, 0.040)
    refs["flash"] = make_flash(root, Vector3(0, 0.04, -1.13))


static func _m4a1(root: Node3D, refs: Dictionary) -> void:
    var coll: bool = bool(refs.get("collimator", false))
    var k = Kit.new()
    k.box(Vector3(0.064, 0.062, 0.3), Vector3(0, 0.04, -0.025), GUN)
    k.box(Vector3(0.06, 0.056, 0.04), Vector3(0, 0.04, 0.145), GUN)
    k.box(Vector3(0.06, 0.072, 0.27), Vector3(0, -0.022, 0.015), GUN)
    k.box(Vector3(0.066, 0.018, 0.09), Vector3(0, -0.062, -0.085), GUN)
    k.box(Vector3(0.004, 0.026, 0.075), Vector3(0.033, 0.046, 0.045), BLACK)
    k.cyl_x(0.011, 0.011, 0.02, Vector3(0.037, 0.034, 0.1), STEEL, 8)
    k.box(Vector3(0.03, 0.014, 0.04), Vector3(0, 0.067, 0.168), BLACK)
    k.box(Vector3(0.052, 0.012, 0.022), Vector3(0, 0.067, 0.184), BLACK)
    k.cyl_x(0.008, 0.008, 0.012, Vector3(0.034, -0.04, -0.045), STEEL, 8)
    k.box(Vector3(0.006, 0.024, 0.012), Vector3(-0.034, -0.01, 0.072), STEEL)
    k.box(Vector3(0.004, 0.012, 0.03), Vector3(0.032, 0, 0.085), BLACK)
    k.box(Vector3(0.028, 0.012, 0.5), Vector3(0, 0.077, -0.14), STEEL)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.38), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.345), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.31), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.275), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.24), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.205), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.17), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.135), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.1), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.065), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, -0.03), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, 0.005), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, 0.04), DARK)
    k.box(Vector3(0.032, 0.007, 0.012), Vector3(0, 0.0855, 0.075), DARK)
    k.box(Vector3(0.034, 0.016, 0.04), Vector3(0, 0.097, 0.062), STEEL)
    if not coll: k.box(Vector3(0.008, 0.05, 0.014), Vector3(0.013, 0.127, 0.062), BLACK)
    if not coll: k.box(Vector3(0.008, 0.05, 0.014), Vector3(-0.013, 0.127, 0.062), BLACK)
    if not coll: k.box(Vector3(0.034, 0.01, 0.014), Vector3(0, 0.108, 0.062), BLACK)
    k.cyl_x(0.007, 0.007, 0.016, Vector3(0.022, 0.1, 0.062), STEEL, 8)
    k.cyl_z(0.038, 0.038, 0.36, Vector3(0, 0.012, -0.36), POLY, 14, 0.2, 0.7)
    k.cyl_z(0.04, 0.04, 0.01, Vector3(0, 0.012, -0.205), GUN, 14, 0.4)
    k.cyl_z(0.04, 0.04, 0.01, Vector3(0, 0.012, -0.245), GUN, 14, 0.4)
    k.cyl_z(0.04, 0.04, 0.01, Vector3(0, 0.012, -0.285), GUN, 14, 0.4)
    k.cyl_z(0.04, 0.04, 0.01, Vector3(0, 0.012, -0.325), GUN, 14, 0.4)
    k.cyl_z(0.04, 0.04, 0.01, Vector3(0, 0.012, -0.365), GUN, 14, 0.4)
    k.cyl_z(0.04, 0.04, 0.01, Vector3(0, 0.012, -0.405), GUN, 14, 0.4)
    k.cyl_z(0.04, 0.04, 0.01, Vector3(0, 0.012, -0.445), GUN, 14, 0.4)
    k.cyl_z(0.04, 0.04, 0.01, Vector3(0, 0.012, -0.485), GUN, 14, 0.4)
    k.box(Vector3(0.026, 0.012, 0.36), Vector3(0, 0.056, -0.36), STEEL)
    k.box(Vector3(0.026, 0.012, 0.3), Vector3(0, -0.032, -0.39), STEEL)
    k.box(Vector3(0.01, 0.024, 0.28), Vector3(0.041, 0.012, -0.4), STEEL)
    k.box(Vector3(0.01, 0.024, 0.28), Vector3(-0.041, 0.012, -0.4), STEEL)
    k.box(Vector3(0.028, 0.007, 0.012), Vector3(0, -0.0395, -0.5), DARK)
    k.box(Vector3(0.028, 0.007, 0.012), Vector3(0, -0.0395, -0.465), DARK)
    k.box(Vector3(0.028, 0.007, 0.012), Vector3(0, -0.0395, -0.43), DARK)
    k.box(Vector3(0.028, 0.007, 0.012), Vector3(0, -0.0395, -0.395), DARK)
    k.box(Vector3(0.028, 0.007, 0.012), Vector3(0, -0.0395, -0.36), DARK)
    k.box(Vector3(0.028, 0.007, 0.012), Vector3(0, -0.0395, -0.325), DARK)
    k.box(Vector3(0.03, 0.09, 0.034), Vector3(0, -0.088, -0.4), POLY, Vector3(-8, 0, 0), 0.1, 0.8)
    k.box(Vector3(0.034, 0.02, 0.06), Vector3(0, -0.046, -0.4), STEEL)
    k.cyl_z(0.0115, 0.0115, 0.42, Vector3(0, 0.012, -0.75), STEEL, 10, 0.7, 0.35)
    k.cyl_z(0.022, 0.022, 0.05, Vector3(0, 0.012, -0.675), BLACK, 10)
    if not coll: k.box(Vector3(0.018, 0.092, 0.022), Vector3(0, 0.076, -0.675), BLACK)
    if not coll: k.box(Vector3(0.006, 0.034, 0.006), Vector3(0, 0.135, -0.675), BLACK)
    if not coll: k.box(Vector3(0.032, 0.006, 0.02), Vector3(0, 0.108, -0.675), BLACK)
    k.cyl_z(0.017, 0.019, 0.08, Vector3(0, 0.012, -0.985), BLACK, 10)
    k.box(Vector3(0.042, 0.005, 0.045), Vector3(0, 0.012, -0.99), HOLE)
    k.box(Vector3(0.005, 0.042, 0.045), Vector3(0, 0.012, -0.99), HOLE)
    k.cyl_z(0.02, 0.02, 0.008, Vector3(0, 0.012, -0.95), GUN, 10)
    k.box(Vector3(0.046, 0.13, 0.056), Vector3(0, -0.118, 0.115), POLY, Vector3(-20, 0, 0), 0.1, 0.8)
    k.box(Vector3(0.03, 0.1, 0.012), Vector3(0, -0.112, 0.146), POLY, Vector3(-20, 0, 0), 0.1, 0.8)
    k.box(Vector3(0.04, 0.012, 0.054), Vector3(0, -0.182, 0.138), BLACK, Vector3(-20, 0, 0))
    k.box(Vector3(0.01, 0.008, 0.08), Vector3(0, -0.068, 0), BLACK)
    k.box(Vector3(0.01, 0.038, 0.008), Vector3(0, -0.05, -0.038), BLACK)
    k.box(Vector3(0.01, 0.034, 0.008), Vector3(0, -0.052, 0.045), BLACK)
    k.box(Vector3(0.007, 0.034, 0.01), Vector3(0, -0.048, 0.022), STEEL, Vector3(-14, 0, 0))
    k.cyl_z(0.021, 0.021, 0.17, Vector3(0, 0.005, 0.25), GUN, 10)
    k.box(Vector3(0.048, 0.074, 0.2), Vector3(0, -0.004, 0.345), POLY, Vector3(0, 0, 0), 0.1, 0.8)
    k.box(Vector3(0.044, 0.016, 0.15), Vector3(0, 0.037, 0.35), POLY, Vector3(0, 0, 0), 0.1, 0.8)
    k.box(Vector3(0.054, 0.1, 0.022), Vector3(0, -0.004, 0.452), RUBBER, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.02, 0.016, 0.04), Vector3(0, -0.056, 0.25), STEEL)
    k.cyl_x(0.012, 0.012, 0.012, Vector3(0.028, -0.03, 0.4), STEEL, 8)
    k.commit(root)
    if coll:
        refs["collimator_node"] = add_collimator(root, 0.089, 0.152, -0.04)
    var mag := Kit.group(root, Vector3(0, -0.062, -0.085), "Magazine")
    var k_mag = Kit.new()
    k_mag.box(Vector3(0.04, 0.0416, 0.064), Vector3(0, -0.02, -0.0014), BLACK, Vector3(4, 0, 0))
    k_mag.box(Vector3(0.044, 0.006, 0.0614), Vector3(0, -0.02, -0.0014), POLY, Vector3(4, 0, 0))
    k_mag.box(Vector3(0.04, 0.0416, 0.064), Vector3(0, -0.0598, -0.0049), BLACK, Vector3(6, 0, 0))
    k_mag.box(Vector3(0.044, 0.006, 0.0614), Vector3(0, -0.0598, -0.0049), POLY, Vector3(6, 0, 0))
    k_mag.box(Vector3(0.04, 0.0416, 0.064), Vector3(0, -0.0995, -0.0098), BLACK, Vector3(8, 0, 0))
    k_mag.box(Vector3(0.044, 0.006, 0.0614), Vector3(0, -0.0995, -0.0098), POLY, Vector3(8, 0, 0))
    k_mag.box(Vector3(0.04, 0.0416, 0.064), Vector3(0, -0.139, -0.016), BLACK, Vector3(10, 0, 0))
    k_mag.box(Vector3(0.044, 0.006, 0.0614), Vector3(0, -0.139, -0.016), POLY, Vector3(10, 0, 0))
    k_mag.box(Vector3(0.046, 0.014, 0.072), Vector3(0, -0.1627, -0.0195), STEEL, Vector3(10, 0, 0))
    k_mag.commit(mag)
    refs["mag"] = mag
    refs["mag_rest"] = mag.position
    refs["mag_drop"] = Vector3(0.0, -0.26, 0.04)
    refs["eject"] = Vector3(0.045, 0.046, 0.045)
    refs["flash"] = make_flash(root, Vector3(0, 0.012, -1.03))


static func _shotgun(root: Node3D, refs: Dictionary) -> void:
    var k = Kit.new()
    k.box(Vector3(0.054, 0.12, 0.3), Vector3(0, -0.045, 0.3), WOOD, Vector3(6, 0, 0), 0, 0.8)
    k.box(Vector3(0.05, 0.02, 0.2), Vector3(0, 0.02, 0.3), WOOD_DARK, Vector3(6, 0, 0), 0, 0.85)
    k.box(Vector3(0.058, 0.135, 0.02), Vector3(0, -0.07, 0.455), RUBBER, Vector3(6, 0, 0), 0, 0.9)
    k.box(Vector3(0.048, 0.08, 0.1), Vector3(0, -0.02, 0.15), WOOD, Vector3(0, 0, 0), 0, 0.8)
    k.box(Vector3(0.064, 0.096, 0.27), Vector3(0, 0, 0.02), BLUED, Vector3(0, 0, 0), 0.5, 0.45)
    k.box(Vector3(0.062, 0.016, 0.25), Vector3(0, 0.054, 0.02), BLUED, Vector3(0, 0, 0), 0.5, 0.45)
    k.box(Vector3(0.004, 0.034, 0.09), Vector3(0.033, 0.016, 0.05), HOLE)
    k.box(Vector3(0.004, 0.03, 0.05), Vector3(0.033, -0.04, -0.04), HOLE)
    k.box(Vector3(0.007, 0.012, 0.05), Vector3(0.034, -0.012, -0.075), STEEL)
    k.cyl_x(0.008, 0.008, 0.012, Vector3(-0.034, -0.05, 0.07), BRASS, 8)
    k.box(Vector3(0.016, 0.01, 0.06), Vector3(0, 0.062, 0.08), DARK)
    k.box(Vector3(0.058, 0.078, 0.09), Vector3(0, 0.01, -0.15), BLUED, Vector3(0, 0, 0), 0.5, 0.45)
    k.box(Vector3(0.03, 0.05, 0.09), Vector3(0, -0.002, -0.235), BLUED, Vector3(0, 0, 0), 0.5, 0.45)
    k.cyl_z(0.018, 0.018, 0.74, Vector3(0, 0.034, -0.64), BLUED, 12, 0.6, 0.35)
    k.box(Vector3(0.012, 0.01, 0.74), Vector3(0, 0.056, -0.64), BLACK)
    k.cyl_z(0.022, 0.022, 0.012, Vector3(0, 0.034, -0.275), STEEL)
    k.cyl_z(0.02, 0.02, 0.03, Vector3(0, 0.034, -1), BLUED)
    k.cyl_z(0.0045, 0.0045, 0.012, Vector3(0, 0.062, -0.97), BRASS, 6)
    k.box(Vector3(0.008, 0.04, 0.008), Vector3(0, 0.078, -0.975), BLACK)
    k.sphere(0.009, Vector3(0, 0.099, -0.975), BRASS, Vector3(1, 1, 1), 0.7, 0.3, 8)
    k.box(Vector3(0.026, 0.012, 0.045), Vector3(0, 0.068, 0.095), BLACK)
    k.box(Vector3(0.007, 0.034, 0.012), Vector3(0.011, 0.091, 0.095), BLACK)
    k.box(Vector3(0.007, 0.034, 0.012), Vector3(-0.011, 0.091, 0.095), BLACK)
    k.cyl_z(0.016, 0.016, 0.58, Vector3(0, -0.014, -0.58), BLUED, 10, 0.6, 0.4)
    k.cyl_z(0.02, 0.02, 0.016, Vector3(0, -0.014, -0.865), STEEL, 10)
    k.box(Vector3(0.016, 0.04, 0.02), Vector3(0, 0.01, -0.45), STEEL)
    k.box(Vector3(0.016, 0.04, 0.02), Vector3(0, 0.01, -0.86), STEEL)
    k.box(Vector3(0.048, 0.11, 0.06), Vector3(0, -0.095, 0.06), WOOD_DARK, Vector3(-16, 0, 0), 0, 0.8)
    k.box(Vector3(0.01, 0.008, 0.1), Vector3(0, -0.068, -0.04), STEEL)
    k.box(Vector3(0.01, 0.044, 0.008), Vector3(0, -0.046, -0.09), STEEL)
    k.box(Vector3(0.007, 0.034, 0.01), Vector3(0, -0.044, -0.03), STEEL, Vector3(-14, 0, 0))
    k.cyl_x(0.0095, 0.0095, 0.04, Vector3(-0.0475, 0.045, 0.01), SHELL_RED, 8, 0, 0.5)
    k.cyl_x(0.01, 0.01, 0.01, Vector3(-0.0675, 0.045, 0.01), BRASS, 8, 0.8, 0.3)
    k.cyl_x(0.0095, 0.0095, 0.04, Vector3(-0.0475, 0.045, 0.032), SHELL_RED, 8, 0, 0.5)
    k.cyl_x(0.01, 0.01, 0.01, Vector3(-0.0675, 0.045, 0.032), BRASS, 8, 0.8, 0.3)
    k.cyl_x(0.0095, 0.0095, 0.04, Vector3(-0.0475, 0.045, 0.054), SHELL_RED, 8, 0, 0.5)
    k.cyl_x(0.01, 0.01, 0.01, Vector3(-0.0675, 0.045, 0.054), BRASS, 8, 0.8, 0.3)
    k.cyl_x(0.0095, 0.0095, 0.04, Vector3(-0.0475, 0.045, 0.076), SHELL_RED, 8, 0, 0.5)
    k.cyl_x(0.01, 0.01, 0.01, Vector3(-0.0675, 0.045, 0.076), BRASS, 8, 0.8, 0.3)
    k.box(Vector3(0.008, 0.04, 0.1), Vector3(-0.036, 0.04, 0.03), STEEL)
    k.commit(root)
    var pump := Kit.group(root, Vector3(0, -0.02, -0.5), "Pump")
    var k_pump = Kit.new()
    k_pump.box(Vector3(0.066, 0.06, 0.22), Vector3(0, 0, 0), WOOD_DARK, Vector3(0, 0, 0), 0, 0.8)
    k_pump.box(Vector3(0.068, 0.062, 0.006), Vector3(0, 0, -0.09), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k_pump.box(Vector3(0.068, 0.062, 0.006), Vector3(0, 0, -0.06), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k_pump.box(Vector3(0.068, 0.062, 0.006), Vector3(0, 0, -0.03), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k_pump.box(Vector3(0.068, 0.062, 0.006), Vector3(0, 0, 0), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k_pump.box(Vector3(0.068, 0.062, 0.006), Vector3(0, 0, 0.03), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k_pump.box(Vector3(0.068, 0.062, 0.006), Vector3(0, 0, 0.06), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k_pump.box(Vector3(0.068, 0.062, 0.006), Vector3(0, 0, 0.09), WOOD, Vector3(0, 0, 0), 0, 0.9)
    k_pump.box(Vector3(0.04, 0.02, 0.222), Vector3(0, -0.034, 0), BLACK)
    k_pump.commit(pump)
    refs["pump"] = pump
    refs["pump_rest"] = pump.position
    refs["pump_back"] = pump.position + Vector3(0, 0, 0.13)
    refs["eject"] = Vector3(0.045, 0.020, 0.050)
    refs["flash"] = make_flash(root, Vector3(0, 0.034, -1.12))


static func _svd(root: Node3D, refs: Dictionary) -> void:
    var k = Kit.new()
    k.box(Vector3(0.066, 0.096, 0.33), Vector3(0, 0, 0), GUN)
    k.box(Vector3(0.06, 0.022, 0.32), Vector3(0, 0.058, 0), STEEL)
    k.box(Vector3(0.004, 0.03, 0.09), Vector3(0.034, 0.03, 0.05), HOLE)
    k.box(Vector3(0.03, 0.012, 0.03), Vector3(0.046, 0.045, 0.04), STEEL)
    k.cyl_x(0.009, 0.009, 0.02, Vector3(0.062, 0.045, 0.04), BLACK, 8)
    k.box(Vector3(0.007, 0.07, 0.012), Vector3(0.036, -0.005, -0.01), STEEL)
    k.box(Vector3(0.052, 0.02, 0.15), Vector3(0, 0.078, -0.04), BLACK)
    k.box(Vector3(0.03, 0.028, 0.03), Vector3(0, 0.098, 0.04), DARK)
    k.box(Vector3(0.03, 0.028, 0.03), Vector3(0, 0.098, -0.1), DARK)
    k.cyl_z(0.024, 0.024, 0.29, Vector3(0, 0.152, -0.02), BLACK, 14, 0.4)
    k.cyl_z(0.036, 0.024, 0.075, Vector3(0, 0.152, -0.205), BLACK, 14, 0.4)
    k.cyl_z(0.031, 0.031, 0.006, Vector3(0, 0.152, -0.246), GLASS, 14, 0.9, 0.1)
    k.cyl_z(0.024, 0.032, 0.04, Vector3(0, 0.152, 0.145), BLACK, 14, 0.4)
    k.cyl_z(0.026, 0.026, 0.02, Vector3(0, 0.152, 0.17), RUBBER, 14, 0, 0.9)
    k.cyl_y(0.012, 0.012, 0.03, Vector3(0, 0.188, -0.02), STEEL, 10)
    k.cyl_y(0.014, 0.014, 0.012, Vector3(0, 0.205, -0.02), BLACK, 10)
    k.cyl_x(0.012, 0.012, 0.03, Vector3(0.036, 0.152, -0.02), STEEL, 10)
    k.cyl_x(0.014, 0.014, 0.01, Vector3(0.052, 0.152, -0.02), BLACK, 10)
    k.box(Vector3(0.044, 0.06, 0.12), Vector3(0, 0.02, 0.215), WOOD, Vector3(0, 0, 0), 0, 0.8)
    k.box(Vector3(0.044, 0.034, 0.2), Vector3(0, 0.04, 0.35), WOOD, Vector3(3, 0, 0), 0, 0.8)
    k.box(Vector3(0.046, 0.022, 0.14), Vector3(0, 0.068, 0.34), WOOD_DARK, Vector3(3, 0, 0), 0, 0.85)
    k.box(Vector3(0.044, 0.034, 0.2), Vector3(0, -0.075, 0.35), WOOD, Vector3(6, 0, 0), 0, 0.8)
    k.box(Vector3(0.044, 0.12, 0.04), Vector3(0, -0.018, 0.255), WOOD, Vector3(0, 0, 0), 0, 0.8)
    k.box(Vector3(0.044, 0.15, 0.036), Vector3(0, -0.018, 0.442), WOOD, Vector3(4, 0, 0), 0, 0.8)
    k.box(Vector3(0.052, 0.16, 0.022), Vector3(0, -0.02, 0.466), RUBBER, Vector3(4, 0, 0), 0, 0.9)
    k.box(Vector3(0.052, 0.08, 0.1), Vector3(0, 0.006, -0.215), GUN)
    k.box(Vector3(0.06, 0.07, 0.38), Vector3(0, -0.005, -0.45), WOOD_DARK, Vector3(0, 0, 0), 0, 0.8)
    k.cyl_z(0.027, 0.027, 0.3, Vector3(0, 0.06, -0.47), WOOD, 12, 0, 0.85)
    k.box(Vector3(0.05, 0.004, 0.012), Vector3(0, 0.093, -0.35), WOOD_DARK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.05, 0.004, 0.012), Vector3(0, 0.093, -0.39), WOOD_DARK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.05, 0.004, 0.012), Vector3(0, 0.093, -0.43), WOOD_DARK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.05, 0.004, 0.012), Vector3(0, 0.093, -0.47), WOOD_DARK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.05, 0.004, 0.012), Vector3(0, 0.093, -0.51), WOOD_DARK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.05, 0.004, 0.012), Vector3(0, 0.093, -0.55), WOOD_DARK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.05, 0.004, 0.012), Vector3(0, 0.093, -0.59), WOOD_DARK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.064, 0.08, 0.014), Vector3(0, 0.01, -0.26), STEEL)
    k.box(Vector3(0.064, 0.08, 0.014), Vector3(0, 0.01, -0.64), STEEL)
    k.cyl_z(0.0135, 0.0135, 0.66, Vector3(0, 0.03, -0.95), STEEL, 10, 0.7, 0.35)
    k.box(Vector3(0.034, 0.05, 0.05), Vector3(0, 0.045, -0.76), STEEL)
    k.box(Vector3(0.008, 0.04, 0.012), Vector3(0, 0.09, -0.76), BLACK)
    k.cyl_z(0.02, 0.02, 0.115, Vector3(0, 0.03, -1.275), BLACK, 10)
    k.box(Vector3(0.044, 0.006, 0.014), Vector3(0, 0.03, -1.24), HOLE)
    k.box(Vector3(0.044, 0.006, 0.014), Vector3(0, 0.03, -1.272), HOLE)
    k.box(Vector3(0.044, 0.006, 0.014), Vector3(0, 0.03, -1.304), HOLE)
    k.box(Vector3(0.006, 0.044, 0.014), Vector3(0, 0.03, -1.28), HOLE)
    k.box(Vector3(0.018, 0.02, 0.032), Vector3(0, 0.01, -0.8), STEEL)
    k.box(Vector3(0.046, 0.13, 0.056), Vector3(0, -0.112, 0.132), WOOD_DARK, Vector3(-22, 0, 0), 0, 0.8)
    k.box(Vector3(0.04, 0.01, 0.054), Vector3(0, -0.178, 0.158), BLACK, Vector3(-22, 0, 0))
    k.box(Vector3(0.01, 0.008, 0.095), Vector3(0, -0.056, 0.022), STEEL)
    k.box(Vector3(0.01, 0.04, 0.008), Vector3(0, -0.04, -0.026), STEEL)
    k.box(Vector3(0.007, 0.036, 0.01), Vector3(0, -0.036, 0.032), STEEL, Vector3(-14, 0, 0))
    k.box(Vector3(0.012, 0.012, 0.06), Vector3(0, 0.004, -0.62), DARK)
    k.commit(root)
    var mag := Kit.group(root, Vector3(0, -0.05, -0.1), "Magazine")
    var k_mag = Kit.new()
    k_mag.box(Vector3(0.04, 0.0374, 0.066), Vector3(0, -0.018, -0.0006), GUN, Vector3(2, 0, 0))
    k_mag.box(Vector3(0.044, 0.006, 0.0634), Vector3(0, -0.018, -0.0006), BLACK, Vector3(2, 0, 0))
    k_mag.box(Vector3(0.04, 0.0374, 0.066), Vector3(0, -0.0539, -0.0025), GUN, Vector3(4, 0, 0))
    k_mag.box(Vector3(0.044, 0.006, 0.0634), Vector3(0, -0.0539, -0.0025), BLACK, Vector3(4, 0, 0))
    k_mag.box(Vector3(0.04, 0.0374, 0.066), Vector3(0, -0.0898, -0.0056), GUN, Vector3(6, 0, 0))
    k_mag.box(Vector3(0.044, 0.006, 0.0634), Vector3(0, -0.0898, -0.0056), BLACK, Vector3(6, 0, 0))
    k_mag.box(Vector3(0.04, 0.0374, 0.066), Vector3(0, -0.1255, -0.01), GUN, Vector3(8, 0, 0))
    k_mag.box(Vector3(0.044, 0.006, 0.0634), Vector3(0, -0.1255, -0.01), BLACK, Vector3(8, 0, 0))
    k_mag.box(Vector3(0.046, 0.014, 0.074), Vector3(0, -0.1473, -0.0125), STEEL, Vector3(8, 0, 0))
    k_mag.commit(mag)
    var bolt := Kit.group(root, Vector3(0.045, 0.04, 0.02), "Bolt")
    var k_bolt = Kit.new()
    k_bolt.box(Vector3(0.02, 0.016, 0.04), Vector3(0.01, 0, 0), STEEL)
    k_bolt.commit(bolt)
    refs["mag"] = mag
    refs["mag_rest"] = mag.position
    refs["mag_drop"] = Vector3(0.0, -0.26, -0.02)
    refs["eject"] = Vector3(0.05, 0.03, 0.04)
    refs["bolt"] = bolt
    refs["bolt_rest"] = bolt.position
    refs["bolt_back"] = bolt.position + Vector3(0, 0, 0.07)
    refs["flash"] = make_flash(root, Vector3(0, 0.03, -1.36))


static func _pm(root: Node3D, refs: Dictionary) -> void:
    var k = Kit.new()
    k.box(Vector3(0.034, 0.03, 0.19), Vector3(0, 0.047, -0.02), BLUED, Vector3(0, 0, 0), 0.5, 0.45)
    k.cyl_z(0.007, 0.007, 0.04, Vector3(0, 0.058, -0.15), STEEL, 8)
    k.box(Vector3(0.036, 0.072, 0.08), Vector3(0, 0.02, 0.06), BLUED, Vector3(0, 0, 0), 0.5, 0.45)
    k.box(Vector3(0.038, 0.122, 0.062), Vector3(0, -0.02, 0.066), POLY, Vector3(-14, 0, 0), 0, 0.8)
    k.box(Vector3(0.04, 0.1, 0.02), Vector3(0, -0.018, 0.034), BLACK, Vector3(-14, 0, 0), 0, 0.8)
    k.box(Vector3(0.004, 0.11, 0.05), Vector3(0.019, -0.02, 0.068), BLACK, Vector3(-14, 0, 0), 0, 0.9)
    k.box(Vector3(0.004, 0.11, 0.05), Vector3(-0.019, -0.02, 0.068), BLACK, Vector3(-14, 0, 0), 0, 0.9)
    k.box(Vector3(0.04, 0.01, 0.06), Vector3(0, -0.083, 0.094), STEEL, Vector3(-14, 0, 0))
    k.cyl_x(0.006, 0.006, 0.04, Vector3(0, -0.072, 0.092), STEEL, 8)
    k.box(Vector3(0.01, 0.05, 0.01), Vector3(0, 0.02, -0.065), DARK)
    k.box(Vector3(0.01, 0.01, 0.06), Vector3(0, -0.004, -0.04), DARK)
    k.box(Vector3(0.007, 0.03, 0.01), Vector3(0, 0.012, -0.02), STEEL, Vector3(-14, 0, 0))
    k.box(Vector3(0.01, 0.018, 0.018), Vector3(0, 0.066, 0.1), STEEL, Vector3(-20, 0, 0))
    k.box(Vector3(0.006, 0.014, 0.016), Vector3(-0.021, 0.06, 0.06), STEEL)
    k.commit(root)
    var slide := Kit.group(root, Vector3(0, 0.087, -0.03), "Slide")
    var k_slide = Kit.new()
    k_slide.box(Vector3(0.036, 0.046, 0.22), Vector3(0, 0, 0), BLUED, Vector3(0, 0, 0), 0.55, 0.4)
    k_slide.box(Vector3(0.03, 0.01, 0.2), Vector3(0, 0.027, 0), BLUED, Vector3(0, 0, 0), 0.55, 0.4)
    k_slide.box(Vector3(0.03, 0.01, 0.012), Vector3(0, 0.032, 0.095), BLACK)
    k_slide.box(Vector3(0.01, 0.012, 0.012), Vector3(0, 0.033, -0.1), BLACK)
    k_slide.box(Vector3(0.04, 0.044, 0.005), Vector3(0, 0, 0.06), DARK)
    k_slide.box(Vector3(0.04, 0.044, 0.005), Vector3(0, 0, 0.068), DARK)
    k_slide.box(Vector3(0.04, 0.044, 0.005), Vector3(0, 0, 0.076), DARK)
    k_slide.box(Vector3(0.04, 0.044, 0.005), Vector3(0, 0, 0.084), DARK)
    k_slide.box(Vector3(0.04, 0.044, 0.005), Vector3(0, 0, 0.092), DARK)
    k_slide.box(Vector3(0.04, 0.044, 0.005), Vector3(0, 0, 0.1), DARK)
    k_slide.box(Vector3(0.003, 0.024, 0.05), Vector3(0.0185, 0.004, -0.02), HOLE)
    k_slide.box(Vector3(0.036, 0.04, 0.012), Vector3(0, -0.002, -0.114), DARK)
    k_slide.commit(slide)
    var mag := Kit.group(root, Vector3(0, -0.03, 0.07), "Magazine")
    var k_mag = Kit.new()
    k_mag.box(Vector3(0.028, 0.095, 0.048), Vector3(0, 0, 0), DARK, Vector3(-14, 0, 0))
    k_mag.box(Vector3(0.034, 0.01, 0.056), Vector3(0, -0.052, 0.013), STEEL, Vector3(-14, 0, 0))
    k_mag.commit(mag)
    refs["slide"] = slide
    refs["slide_rest"] = slide.position
    refs["slide_back"] = slide.position + Vector3(0, 0, 0.055)
    refs["mag"] = mag
    refs["mag_rest"] = mag.position
    refs["mag_drop"] = Vector3(0.0, -0.20, 0.05)
    refs["eject"] = Vector3(0.025, 0.09, 0.0)
    refs["flash"] = make_flash(root, Vector3(0, 0.087, -0.16))


static func _revolver(root: Node3D, refs: Dictionary) -> void:
    var k = Kit.new()
    k.box(Vector3(0.04, 0.075, 0.15), Vector3(0, 0.075, 0), STEEL, Vector3(0, 0, 0), 0.6, 0.35)
    k.box(Vector3(0.042, 0.034, 0.06), Vector3(0, 0.04, 0.06), STEEL, Vector3(0, 0, 0), 0.6, 0.35)
    k.box(Vector3(0.028, 0.012, 0.012), Vector3(0, 0.119, 0.05), BLACK)
    k.box(Vector3(0.022, 0.012, 0.03), Vector3(0, 0.112, 0.048), STEEL)
    k.box(Vector3(0.03, 0.026, 0.27), Vector3(0, 0.101, -0.27), STEEL, Vector3(0, 0, 0), 0.6, 0.35)
    k.box(Vector3(0.016, 0.01, 0.27), Vector3(0, 0.12, -0.27), BLACK)
    k.box(Vector3(0.018, 0.006, 0.012), Vector3(0, 0.126, -0.17), BLACK)
    k.box(Vector3(0.018, 0.006, 0.012), Vector3(0, 0.126, -0.21), BLACK)
    k.box(Vector3(0.018, 0.006, 0.012), Vector3(0, 0.126, -0.25), BLACK)
    k.box(Vector3(0.018, 0.006, 0.012), Vector3(0, 0.126, -0.29), BLACK)
    k.box(Vector3(0.018, 0.006, 0.012), Vector3(0, 0.126, -0.33), BLACK)
    k.box(Vector3(0.018, 0.006, 0.012), Vector3(0, 0.126, -0.37), BLACK)
    k.box(Vector3(0.032, 0.04, 0.05), Vector3(0, 0.08, -0.2), STEEL)
    k.box(Vector3(0.026, 0.04, 0.23), Vector3(0, 0.062, -0.255), STEEL, Vector3(0, 0, 0), 0.6, 0.35)
    k.cyl_z(0.02, 0.02, 0.02, Vector3(0, 0.101, -0.425), BLACK, 10)
    k.box(Vector3(0.012, 0.014, 0.012), Vector3(0, 0.1185, -0.42), BLACK)
    k.cyl_z(0.007, 0.007, 0.18, Vector3(0, 0.046, -0.25), STEEL, 6)
    k.cyl_z(0.011, 0.011, 0.012, Vector3(0, 0.046, -0.347), BLACK, 8)
    k.box(Vector3(0.012, 0.04, 0.022), Vector3(0, 0.128, 0.085), BLACK, Vector3(28, 0, 0))
    k.box(Vector3(0.012, 0.018, 0.026), Vector3(0, 0.15, 0.096), STEEL, Vector3(28, 0, 0))
    k.box(Vector3(0.008, 0.03, 0.01), Vector3(0, 0.04, 0), STEEL, Vector3(-14, 0, 0))
    k.box(Vector3(0.01, 0.044, 0.01), Vector3(0, 0.02, -0.05), STEEL)
    k.box(Vector3(0.01, 0.01, 0.09), Vector3(0, 0, -0.005), STEEL)
    k.box(Vector3(0.01, 0.04, 0.01), Vector3(0, 0.02, 0.078), STEEL)
    k.box(Vector3(0.042, 0.14, 0.07), Vector3(0, -0.03, 0.095), WOOD, Vector3(-18, 0, 0), 0, 0.7)
    k.box(Vector3(0.046, 0.03, 0.076), Vector3(0, -0.092, 0.118), WOOD_DARK, Vector3(-18, 0, 0), 0, 0.7)
    k.box(Vector3(0.004, 0.1, 0.05), Vector3(0.0215, -0.03, 0.095), WOOD_DARK, Vector3(-18, 0, 0), 0, 0.9)
    k.box(Vector3(0.004, 0.1, 0.05), Vector3(-0.0215, -0.03, 0.095), WOOD_DARK, Vector3(-18, 0, 0), 0, 0.9)
    k.cyl_x(0.007, 0.007, 0.044, Vector3(0, -0.095, 0.12), STEEL, 8)
    k.commit(root)
    var cylinder := Kit.group(root, Vector3(0, 0.08, -0.1), "Cylinder")
    var k_cylinder = Kit.new()
    k_cylinder.cyl_z(0.039, 0.039, 0.092, Vector3(0, 0, 0), STEEL, 12, 0.6, 0.35)
    k_cylinder.cyl_z(0.042, 0.042, 0.01, Vector3(0, 0, 0.04), BLACK)
    k_cylinder.cyl_z(0.04, 0.04, 0.006, Vector3(0, 0, -0.04), BLACK)
    k_cylinder.cyl_z(0.0085, 0.0085, 0.096, Vector3(0.026, 0, 0), HOLE, 8)
    k_cylinder.cyl_z(0.0075, 0.0075, 0.008, Vector3(0.026, 0, -0.04), BRASS, 8, 0.8, 0.3)
    k_cylinder.box(Vector3(0.01, 0.01, 0.06), Vector3(0.0338, 0.0195, 0), BLACK, Vector3(0, 0, 30))
    k_cylinder.cyl_z(0.0085, 0.0085, 0.096, Vector3(0.013, 0.0225, 0), HOLE, 8)
    k_cylinder.cyl_z(0.0075, 0.0075, 0.008, Vector3(0.013, 0.0225, -0.04), BRASS, 8, 0.8, 0.3)
    k_cylinder.box(Vector3(0.01, 0.01, 0.06), Vector3(0, 0.039, 0), BLACK, Vector3(0, 0, 90))
    k_cylinder.cyl_z(0.0085, 0.0085, 0.096, Vector3(-0.013, 0.0225, 0), HOLE, 8)
    k_cylinder.cyl_z(0.0075, 0.0075, 0.008, Vector3(-0.013, 0.0225, -0.04), BRASS, 8, 0.8, 0.3)
    k_cylinder.box(Vector3(0.01, 0.01, 0.06), Vector3(-0.0338, 0.0195, 0), BLACK, Vector3(0, 0, 150))
    k_cylinder.cyl_z(0.0085, 0.0085, 0.096, Vector3(-0.026, 0, 0), HOLE, 8)
    k_cylinder.cyl_z(0.0075, 0.0075, 0.008, Vector3(-0.026, 0, -0.04), BRASS, 8, 0.8, 0.3)
    k_cylinder.box(Vector3(0.01, 0.01, 0.06), Vector3(-0.0338, -0.0195, 0), BLACK, Vector3(0, 0, 210))
    k_cylinder.cyl_z(0.0085, 0.0085, 0.096, Vector3(-0.013, -0.0225, 0), HOLE, 8)
    k_cylinder.cyl_z(0.0075, 0.0075, 0.008, Vector3(-0.013, -0.0225, -0.04), BRASS, 8, 0.8, 0.3)
    k_cylinder.box(Vector3(0.01, 0.01, 0.06), Vector3(0, -0.039, 0), BLACK, Vector3(0, 0, 270))
    k_cylinder.cyl_z(0.0085, 0.0085, 0.096, Vector3(0.013, -0.0225, 0), HOLE, 8)
    k_cylinder.cyl_z(0.0075, 0.0075, 0.008, Vector3(0.013, -0.0225, -0.04), BRASS, 8, 0.8, 0.3)
    k_cylinder.box(Vector3(0.01, 0.01, 0.06), Vector3(0.0338, -0.0195, 0), BLACK, Vector3(0, 0, 330))
    k_cylinder.commit(cylinder)
    refs["cylinder"] = cylinder
    refs["cylinder_rest"] = cylinder.position
    refs["eject"] = Vector3(0.0, 0.08, -0.10)
    refs["flash"] = make_flash(root, Vector3(0, 0.1, -0.46))


static func _knife(root: Node3D, refs: Dictionary) -> void:
    var k = Kit.new()
    k.cyl_z(0.0165, 0.0165, 0.13, Vector3(0, 0, 0), WOOD_DARK, 10, 0, 0.8)
    k.cyl_z(0.0185, 0.0185, 0.008, Vector3(0, 0, -0.05), BLACK, 10, 0, 0.8)
    k.cyl_z(0.0185, 0.0185, 0.008, Vector3(0, 0, -0.0335), BLACK, 10, 0, 0.8)
    k.cyl_z(0.0185, 0.0185, 0.008, Vector3(0, 0, -0.017), BLACK, 10, 0, 0.8)
    k.cyl_z(0.0185, 0.0185, 0.008, Vector3(0, 0, -0.0005), BLACK, 10, 0, 0.8)
    k.cyl_z(0.0185, 0.0185, 0.008, Vector3(0, 0, 0.016), BLACK, 10, 0, 0.8)
    k.cyl_z(0.0185, 0.0185, 0.008, Vector3(0, 0, 0.0325), BLACK, 10, 0, 0.8)
    k.cyl_z(0.0185, 0.0185, 0.008, Vector3(0, 0, 0.049), BLACK, 10, 0, 0.8)
    k.cyl_z(0.024, 0.02, 0.024, Vector3(0, 0, 0.078), STEEL, 10, 0.7, 0.3)
    k.cyl_z(0.01, 0.01, 0.012, Vector3(0, 0, 0.096), DARK, 8)
    k.box(Vector3(0.06, 0.016, 0.014), Vector3(0, 0, -0.072), STEEL, Vector3(0, 0, 0), 0.7, 0.3)
    k.box(Vector3(0.016, 0.052, 0.012), Vector3(0, 0, -0.072), STEEL, Vector3(0, 0, 0), 0.7, 0.3)
    k.box(Vector3(0.008, 0.044, 0.19), Vector3(0, 0.004, -0.175), BLADE, Vector3(0, 0, 0), 0.9, 0.2)
    k.box(Vector3(0.008, 0.032, 0.06), Vector3(0, -0.004, -0.296), BLADE, Vector3(-14, 0, 0), 0.9, 0.2)
    k.box(Vector3(0.008, 0.016, 0.04), Vector3(0, -0.012, -0.326), BLADE, Vector3(-26, 0, 0), 0.9, 0.2)
    k.box(Vector3(0.0095, 0.006, 0.21), Vector3(0, 0.016, -0.205), ALU, Vector3(0, 0, 0), 0.9, 0.25)
    k.box(Vector3(0.0095, 0.004, 0.12), Vector3(0, 0.004, -0.15), DARK, Vector3(0, 0, 0), 0.9, 0.3)
    k.box(Vector3(0.01, 0.003, 0.15), Vector3(0, -0.016, -0.17), ALU, Vector3(0, 0, 0), 0.9, 0.2)
    k.box(Vector3(0.007, 0.012, 0.06), Vector3(0, 0.027, -0.15), BLADE, Vector3(0, 0, 0), 0.9, 0.2)
    k.commit(root)
    root.rotation_degrees = Vector3(-8, -12, -12)
    refs["base_rotation"] = root.rotation_degrees


static func _machete(root: Node3D, refs: Dictionary) -> void:
    var k = Kit.new()
    k.box(Vector3(0.03, 0.04, 0.13), Vector3(0, 0, 0), RUBBER, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.034, 0.044, 0.01), Vector3(0, 0, -0.04), BLACK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.034, 0.044, 0.01), Vector3(0, 0, -0.018), BLACK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.034, 0.044, 0.01), Vector3(0, 0, 0.004), BLACK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.034, 0.044, 0.01), Vector3(0, 0, 0.026), BLACK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.034, 0.044, 0.01), Vector3(0, 0, 0.048), BLACK, Vector3(0, 0, 0), 0, 0.9)
    k.box(Vector3(0.034, 0.05, 0.014), Vector3(0, 0, 0.068), BLACK)
    k.cyl_x(0.007, 0.007, 0.036, Vector3(0, 0.012, 0.05), HOLE, 8)
    k.cyl_x(0.0045, 0.0045, 0.038, Vector3(0, 0, -0.03), STEEL, 6, 0.8, 0.3)
    k.cyl_x(0.0045, 0.0045, 0.038, Vector3(0, 0, 0.01), STEEL, 6, 0.8, 0.3)
    k.cyl_x(0.0045, 0.0045, 0.038, Vector3(0, 0, 0.05), STEEL, 6, 0.8, 0.3)
    k.box(Vector3(0.016, 0.06, 0.014), Vector3(0, 0.006, -0.072), STEEL, Vector3(0, 0, 0), 0.7, 0.3)
    k.box(Vector3(0.007, 0.06, 0.12), Vector3(0, 0.01, -0.14), BLADE, Vector3(0, 0, 0), 0.9, 0.25)
    k.box(Vector3(0.007, 0.074, 0.2), Vector3(0, 0.008, -0.3), BLADE, Vector3(0, 0, 0), 0.9, 0.25)
    k.box(Vector3(0.007, 0.08, 0.1), Vector3(0, 0.006, -0.45), BLADE, Vector3(0, 0, 0), 0.9, 0.25)
    k.box(Vector3(0.007, 0.06, 0.08), Vector3(0, -0.002, -0.54), BLADE, Vector3(0, 0, 0), 0.9, 0.25)
    k.box(Vector3(0.007, 0.04, 0.06), Vector3(0, -0.014, -0.585), BLADE, Vector3(-18, 0, 0), 0.9, 0.25)
    k.box(Vector3(0.007, 0.02, 0.044), Vector3(0, -0.026, -0.616), BLADE, Vector3(-32, 0, 0), 0.9, 0.25)
    k.box(Vector3(0.01, 0.006, 0.48), Vector3(0, 0.048, -0.34), DARK, Vector3(0, 0, 0), 0.8, 0.4)
    k.box(Vector3(0.0085, 0.004, 0.44), Vector3(0, -0.026, -0.33), ALU, Vector3(0, 0, 0), 0.9, 0.2)
    k.box(Vector3(0.0085, 0.004, 0.3), Vector3(0, 0.02, -0.32), ALU, Vector3(0, 0, 0), 0.9, 0.3)
    k.commit(root)
    root.rotation_degrees = Vector3(-8, -12, -12)
    refs["base_rotation"] = root.rotation_degrees


## Полый цилиндр вдоль оси Z (труба с отверстием): внешняя и внутренняя стенки и торцы.
## Двусторонний материал, поэтому порядок обхода вершин не важен.
static func _tube_mesh(r_out: float, r_in: float, length: float, segs: int = 24) -> ArrayMesh:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var h := length * 0.5
    for i in segs:
        var a0 := TAU * float(i) / float(segs)
        var a1 := TAU * float(i + 1) / float(segs)
        var c0 := cos(a0)
        var s0 := sin(a0)
        var c1 := cos(a1)
        var s1 := sin(a1)
        for ring in [r_out, r_in]:
            var p0 := Vector3(c0 * ring, s0 * ring, -h)
            var p1 := Vector3(c1 * ring, s1 * ring, -h)
            var p2 := Vector3(c1 * ring, s1 * ring, h)
            var p3 := Vector3(c0 * ring, s0 * ring, h)
            _tri(st, p0, p1, p2, 0)
            _tri(st, p0, p2, p3, 0)
        for z in [-h, h]:
            var o0 := Vector3(c0 * r_out, s0 * r_out, z)
            var o1 := Vector3(c1 * r_out, s1 * r_out, z)
            var n0 := Vector3(c0 * r_in, s0 * r_in, z)
            var n1 := Vector3(c1 * r_in, s1 * r_in, z)
            _tri(st, o0, o1, n1, -1)
            _tri(st, o0, n1, n0, -1)
    st.generate_normals()
    return st.commit()


## smooth: 0 = сглаженные стенки трубы, -1 = плоские торцы.
static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, smooth: int) -> void:
    st.set_smooth_group(smooth)
    st.add_vertex(a)
    st.add_vertex(b)
    st.add_vertex(c)


static func _two_sided(tint: Color, metal: float, rough: float) -> StandardMaterial3D:
    var mat := Kit.material(tint, metal, rough).duplicate() as StandardMaterial3D
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    return mat


## Коллиматорный прицел (красная точка) — отдельный предмет-обвес. Круглая труба с
## линзой, на стойке с зажимом на планку/крышку ствольной коробки.
## base_y — верх крепления на оружии, window_y — высота центра трубы (совпадает с линией
## прицеливания "ads" из weapons.gd: ads.y + window_y = 0, поэтому в режиме прицеливания
## центр трубы точно в центре экрана), z — положение вдоль оружия.
## Красная точка рисуется не моделью, а на экране (collimator_reticle.gd), только при
## прицеливании. Возвращает узел "Collimator".
static func add_collimator(root: Node3D, base_y: float, window_y: float, z: float) -> Node3D:
    var node := Kit.group(root, Vector3(0, 0, z), "Collimator")
    var k = Kit.new()
    var r_out := 0.0255
    var r_in := 0.0215
    var body_mat := _two_sided(Color(0.085, 0.09, 0.10), 0.55, 0.42)
    var lip_mat := _two_sided(Color(0.14, 0.145, 0.16), 0.6, 0.38)
    var center := Vector3(0, window_y, 0)
    # корпус-труба, окуляр сзади (+Z) и объектив спереди (-Z) шире
    k.add_mesh(_tube_mesh(r_out, r_in, 0.070, 24), Transform3D(Basis.IDENTITY, center), body_mat)
    k.add_mesh(_tube_mesh(0.0285, r_in, 0.012, 24), Transform3D(Basis.IDENTITY, center + Vector3(0, 0, 0.041)), lip_mat)
    k.add_mesh(_tube_mesh(0.0300, r_in, 0.016, 24), Transform3D(Basis.IDENTITY, center + Vector3(0, 0, -0.043)), lip_mat)
    # стойка и зажим
    var tube_bottom := window_y - r_out
    var post_h := maxf(tube_bottom + 0.004 - (base_y + 0.010), 0.006)
    k.box(Vector3(0.026, post_h, 0.05), Vector3(0, base_y + 0.010 + post_h * 0.5, 0.0), BLACK, Vector3.ZERO, 0.5, 0.5)
    k.box(Vector3(0.052, 0.010, 0.078), Vector3(0, base_y + 0.005, 0.0), BLACK, Vector3.ZERO, 0.5, 0.5)
    k.box(Vector3(0.056, 0.006, 0.012), Vector3(0, base_y + 0.003, 0.034), DARK)
    k.box(Vector3(0.056, 0.006, 0.012), Vector3(0, base_y + 0.003, -0.034), DARK)
    k.cyl_x(0.0045, 0.0045, 0.062, Vector3(0, base_y + 0.012, 0.024), STEEL, 8, 0.7, 0.35)
    k.cyl_x(0.0045, 0.0045, 0.062, Vector3(0, base_y + 0.012, -0.024), STEEL, 8, 0.7, 0.35)
    k.box(Vector3(0.006, 0.016, 0.03), Vector3(0.032, base_y + 0.014, 0.0), STEEL, Vector3(0, 0, 0), 0.7, 0.35)
    # барабаны юстировки сверху и сбоку, кнопка яркости
    k.cyl_y(0.0065, 0.0065, 0.012, Vector3(0, window_y + r_out + 0.004, 0.010), lip_mat.albedo_color, 10)
    k.cyl_x(0.0065, 0.0065, 0.012, Vector3(r_out + 0.004, window_y, 0.010), lip_mat.albedo_color, 10)
    k.box(Vector3(0.010, 0.006, 0.012), Vector3(-r_out - 0.001, window_y - 0.006, -0.018), Color(0.7, 0.12, 0.1), Vector3.ZERO, 0.0, 0.6)
    # линза: почти прозрачная, с лёгким голубым отливом
    k.cyl_z(r_in, r_in, 0.0012, center + Vector3(0, 0, -0.030), Color(0.45, 0.65, 1.0, 0.13), 24, 0.0, 0.05)
    k.commit(node)
    return node

## Гильза для эффекта выброса (создаётся и удаляется в battle.gd).
static func make_casing(scale_factor: float, tint: Color = BRASS) -> MeshInstance3D:
    var casing := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = 0.0075 * scale_factor
    mesh.bottom_radius = 0.0095 * scale_factor
    mesh.height = 0.038 * scale_factor
    mesh.radial_segments = 6
    mesh.rings = 1
    casing.mesh = mesh
    casing.material_override = Kit.material(tint, 0.8, 0.35)
    return casing


static func _diamond_sword(root: Node3D, refs: Dictionary) -> void:
    # One-handed first-person sword grip: right-hand side of screen, tip up.
    # The user's original CSG sword scene remains unchanged.
    var scene: PackedScene = load("res://assets/models/creator_sword.tscn")
    if scene == null:
        return
    var sword := scene.instantiate() as Node3D
    sword.name = "CreatorGreatsword"
    root.add_child(sword)
    # +Y is the blade direction. Keep blade on the right side, leaning upward.
    # Stage107: меч держится остриём ВПЕРЁД (вдаль), гарда горизонтально, плоскость клинка смотрит вверх.
    sword.rotation_degrees = Vector3(-65.2, -7.6, 0)
    sword.scale = Vector3.ONE * 0.36
    sword.position = Vector3(0.384, -0.295, -0.232)
    root.rotation_degrees = Vector3(-8, 0, -9)
    refs["base_rotation"] = root.rotation_degrees

    # Stage104: правильный хват. Все размеры в координатах меча (+Y — вдоль клинка, рукоять
    # на y от -0.5 до 0.29, сечение рукояти примерно 0.33 x 0.23). Кулак замыкается вокруг
    # рукояти кольцом: тыл ладони со стороны камеры (+Z), четыре пальца друг над другом
    # спереди (-Z), боковые блоки смыкают кольцо, большой палец лежит сверху на пальцах.
    # Предплечье уходит от тыла кисти вниз, к себе и вправо — за край экрана.
    var glove := StandardMaterial3D.new()
    glove.albedo_color = Color(0.13, 0.12, 0.13, 1)
    var glove_light := StandardMaterial3D.new()
    glove_light.albedo_color = Color(0.20, 0.19, 0.20, 1)
    var sleeve := StandardMaterial3D.new()
    sleeve.albedo_color = Color(0.20, 0.24, 0.30, 1)

    var grip := Node3D.new()
    grip.name = "RightHandGrip"
    sword.add_child(grip)
    var hand_y := -0.10   # центр кулака на рукояти (выше — открытая часть рукояти до гарды)
    grip.position = Vector3(0, hand_y, 0)

    # Тыл ладони (ближе к камере).
    var back := MeshInstance3D.new()
    back.name = "BackOfHand"
    var back_mesh := BoxMesh.new()
    back_mesh.size = Vector3(0.46, 0.40, 0.13)
    back.mesh = back_mesh
    back.material_override = glove
    back.position = Vector3(0, 0, 0.17)
    grip.add_child(back)

    # Боковые блоки (основание указательного пальца и край мизинца) замыкают кольцо.
    for side in [-1.0, 1.0]:
        var edge := MeshInstance3D.new()
        edge.name = "HandEdge"
        var edge_mesh := BoxMesh.new()
        edge_mesh.size = Vector3(0.08, 0.38, 0.36)
        edge.mesh = edge_mesh
        edge.material_override = glove
        edge.position = Vector3(side * 0.21, 0, 0.0)
        grip.add_child(edge)

    # Четыре пальца: лежат поперёк рукояти спереди, один над другим вдоль неё.
    for i in range(4):
        var finger := MeshInstance3D.new()
        finger.name = "Finger%d" % i
        var finger_mesh := CapsuleMesh.new()
        finger_mesh.radius = 0.052
        finger_mesh.height = 0.46
        finger.mesh = finger_mesh
        finger.material_override = glove_light if i % 2 == 0 else glove
        finger.position = Vector3(0, (1.5 - float(i)) * 0.092, -0.165)
        finger.rotation_degrees = Vector3(0, 0, 90)
        grip.add_child(finger)

    # Большой палец: сверху на пальцах, наискосок к гарде.
    var thumb := MeshInstance3D.new()
    thumb.name = "Thumb"
    var thumb_mesh := CapsuleMesh.new()
    thumb_mesh.radius = 0.058
    thumb_mesh.height = 0.30
    thumb.mesh = thumb_mesh
    thumb.material_override = glove_light
    thumb.position = Vector3(0.04, 0.215, -0.20)
    thumb.rotation_degrees = Vector3(0, 0, 72)
    grip.add_child(thumb)

    # Манжета и предплечье: от тыла кисти вниз, к камере и вправо.
    var arm_dir := Vector3(0.45, -0.882, -0.139).normalized()   # в координатах меча: к камере, вниз и вправо за край экрана
    var arm_rot := Basis(Quaternion(Vector3.UP, arm_dir))
    var cuff := MeshInstance3D.new()
    cuff.name = "Cuff"
    var cuff_mesh := CylinderMesh.new()
    cuff_mesh.top_radius = 0.125
    cuff_mesh.bottom_radius = 0.115
    cuff_mesh.height = 0.12
    cuff.mesh = cuff_mesh
    cuff.material_override = glove
    cuff.transform = Transform3D(arm_rot, Vector3(0, 0, 0.20) + arm_dir * 0.10)
    grip.add_child(cuff)
    var forearm := MeshInstance3D.new()
    forearm.name = "RightForearm"
    var forearm_mesh := CylinderMesh.new()
    forearm_mesh.top_radius = 0.17
    forearm_mesh.bottom_radius = 0.125
    forearm_mesh.height = 1.6
    forearm.mesh = forearm_mesh
    forearm.material_override = sleeve
    forearm.transform = Transform3D(arm_rot, Vector3(0, 0, 0.20) + arm_dir * 0.92)
    grip.add_child(forearm)
    refs["custom_sword"] = sword
    refs["sword_grip_hand"] = grip
    # Stage102: огонь на клинке (пламя, угольки, свет, свечение).
    SwordFire.attach(sword)


# ---------------------------------------------------------------- Stage129: доп. детали
## Ступень 1 (a) — средняя и высокая графика; ступень 2 (b) — только высокая.
## Детали лежат в узлах GfxDetail1/GfxDetail2 (см. graphics_fx.gd), на низкой графике скрыты.

static func _gfx_details(kind: String, root: Node3D, _refs: Dictionary) -> void:
    var a = Kit.new()
    var b = Kit.new()
    match kind:
        "ak47": _d_ak47(a, b)
        "m4a1": _d_m4a1(a, b)
        "shotgun": _d_shotgun(a, b)
        "svd": _d_svd(a, b)
        "pm": _d_pm(a, b)
        "revolver": _d_revolver(a, b)
        "knife": _d_knife(a, b)
        "machete": _d_machete(a, b)
        _:
            return
    a.commit(GraphicsFX.detail_group(root, 1, "GfxDetail1"))
    b.commit(GraphicsFX.detail_group(root, 2, "GfxDetail2"))


## Кольцо (антабка) в плоскости YZ, ось вдоль X.
static func _ring_x(kit, pos: Vector3, r_out: float, r_in: float, thick: float, tint: Color) -> void:
    var mesh := _tube_mesh(r_out, r_in, thick, 12)
    kit.add_mesh(mesh, Transform3D(Basis.from_euler(Vector3(0.0, PI * 0.5, 0.0)), pos), Kit.material(tint, 0.7, 0.35))


static func _glow_part(kit, size: Vector3, pos: Vector3, tint: Color) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    kit.add_mesh(mesh, Transform3D(Basis.IDENTITY, pos), Kit.glow_material(tint))


## Точка на наклонённой детали: центр + локальное смещение, повёрнутое так же, как деталь.
static func _rot_pos(center: Vector3, rot_deg: Vector3, local: Vector3) -> Vector3:
    return center + Basis.from_euler(rot_deg * (PI / 180.0)) * local


## Насечки на рукоятке/ложе: тонкие полоски поверх наклонённой детали.
static func _grip_lines(kit, center: Vector3, rot_deg: Vector3, width: float, depth: float, span: float, count: int, tint: Color, rough: float = 0.9) -> void:
    for i in range(count):
        var dy := -span * 0.5 + span * float(i) / float(maxi(count - 1, 1))
        kit.box(Vector3(width, 0.004, depth), _rot_pos(center, rot_deg, Vector3(0.0, dy, 0.0)), tint, rot_deg, 0.0, rough)


static func _d_ak47(a, b) -> void:
    _ring_x(a, Vector3(0, -0.008, -0.7), 0.017, 0.012, 0.006, STEEL)             # передняя антабка
    _ring_x(a, Vector3(0, -0.092, 0.405), 0.017, 0.012, 0.006, STEEL)            # задняя антабка
    a.cyl_z(0.005, 0.005, 0.03, Vector3(0.027, 0.045, 0.01), BRASS, 8, 0.8, 0.3)  # гильза в окне
    for i in range(5):                                                            # заклёпки ствольной коробки
        for side in [-1.0, 1.0]:
            b.cyl_x(0.0045, 0.0045, 0.006, Vector3(side * 0.0325, -0.02, -0.12 + float(i) * 0.06), STEEL, 8, 0.6, 0.4)
    _grip_lines(b, Vector3(0, -0.02, 0.32), Vector3(5, 0, 0), 0.053, 0.2, 0.07, 3, WOOD_DARK)    # прожилки приклада
    _grip_lines(b, Vector3(0, -0.016, -0.45), Vector3(0, 0, 0), 0.063, 0.22, 0.044, 3, WOOD)     # прожилки цевья
    _grip_lines(b, Vector3(0, -0.118, 0.13), Vector3(-22, 0, 0), 0.049, 0.05, 0.08, 5, BLACK)    # насечка рукоятки
    b.cyl_z(0.0138, 0.0138, 0.006, Vector3(0, 0.04, -0.985), DARK, 10)             # резьба дульного тормоза
    b.cyl_z(0.0138, 0.0138, 0.006, Vector3(0, 0.04, -0.997), DARK, 10)
    b.box(Vector3(0.012, 0.02, 0.03), Vector3(0, 0.018, -0.99), STEEL)             # штык-нож — упор


static func _d_m4a1(a, b) -> void:
    _ring_x(a, Vector3(0, -0.035, 0.465), 0.017, 0.012, 0.006, STEEL)            # антабка на трубе приклада
    _ring_x(a, Vector3(0, -0.032, -0.49), 0.017, 0.012, 0.006, STEEL)            # антабка на цевье
    a.box(Vector3(0.03, 0.03, 0.08), Vector3(0.063, 0.012, -0.45), BLACK, Vector3(0, 0, 0), 0.4, 0.5)    # тактический фонарь
    _glow_part(a, Vector3(0.02, 0.02, 0.004), Vector3(0.063, 0.012, -0.492), Color(1.0, 0.97, 0.8))
    for i in range(4):                                                            # зубцы пламегасителя
        var ang := float(i) * PI * 0.5
        b.box(Vector3(0.006, 0.012, 0.03), Vector3(cos(ang) * 0.02, 0.012 + sin(ang) * 0.02, -1.03), BLACK, Vector3(0, 0, float(i) * 90.0))
    b.cyl_z(0.0205, 0.0205, 0.006, Vector3(0, 0.012, -1.0), DARK, 10)             # кольцо на дульном устройстве
    _grip_lines(b, Vector3(0, -0.118, 0.115), Vector3(-20, 0, 0), 0.049, 0.05, 0.08, 5, BLACK)   # насечка рукоятки
    b.box(Vector3(0.008, 0.02, 0.025), Vector3(0.033, 0.06, 0.07), STEEL)          # отражатель гильз
    b.box(Vector3(0.05, 0.01, 0.002), Vector3(0, -0.004, 0.4635), Color(0.02, 0.02, 0.02))      # накладка приклада


static func _d_shotgun(a, b) -> void:
    _ring_x(a, Vector3(0, -0.04, -0.865), 0.017, 0.012, 0.006, STEEL)            # антабка на трубе магазина
    for i in range(5):                                                            # рифление затылка приклада
        a.box(Vector3(0.06, 0.004, 0.004), Vector3(0, -0.02 - float(i) * 0.025, 0.468), BLACK)
    b.box(Vector3(0.03, 0.05, 0.012), Vector3(0, 0.01, -0.65), STEEL)             # хомут ствола и трубы
    b.cyl_z(0.0205, 0.0205, 0.01, Vector3(0, 0.034, -0.64), STEEL, 10)
    b.box(Vector3(0.0662, 0.003, 0.2), Vector3(0, 0.03, 0.02), BLACK)            # гравировка ствольной коробки
    b.box(Vector3(0.0662, 0.003, 0.2), Vector3(0, -0.03, 0.02), BLACK)
    _grip_lines(b, Vector3(0, -0.045, 0.3), Vector3(6, 0, 0), 0.057, 0.24, 0.07, 3, WOOD_DARK)   # прожилки приклада


static func _d_svd(a, b) -> void:
    _ring_x(a, Vector3(0, -0.048, -0.6), 0.017, 0.012, 0.006, STEEL)             # антабка
    _glow_part(a, Vector3(0.012, 0.012, 0.002), Vector3(-0.012, 0.162, -0.249), Color(0.7, 0.85, 1.0))   # блик на линзе
    b.box(Vector3(0.05, 0.012, 0.12), Vector3(0, 0.088, 0.34), Color(0.2, 0.14, 0.08), Vector3(3, 0, 0), 0.0, 0.9)   # щёчка
    b.cyl_z(0.0145, 0.0145, 0.006, Vector3(0, 0.03, -1.21), DARK, 10)             # резьба под пламегаситель
    b.cyl_z(0.0145, 0.0145, 0.006, Vector3(0, 0.03, -1.2), DARK, 10)
    _grip_lines(b, Vector3(0, -0.005, -0.45), Vector3(0, 0, 0), 0.063, 0.3, 0.05, 3, WOOD)       # прожилки цевья
    _grip_lines(b, Vector3(0, -0.112, 0.132), Vector3(-22, 0, 0), 0.049, 0.05, 0.08, 5, BLACK)   # насечка рукоятки


static func _d_pm(a, b) -> void:
    _ring_x(a, Vector3(0, -0.1, 0.094), 0.012, 0.008, 0.004, STEEL)              # кольцо под шнур
    a.box(Vector3(0.007, 0.014, 0.02), Vector3(-0.0215, 0.075, 0.05), STEEL)      # предохранитель
    _grip_lines(b, Vector3(0, -0.02, 0.066), Vector3(-14, 0, 0), 0.041, 0.056, 0.08, 5, DARK)   # насечка рукоятки
    _glow_part(b, Vector3(0.004, 0.004, 0.003), Vector3(0, 0.048, -0.067), Color(0.9, 1.0, 0.9))   # точка на мушке


static func _d_revolver(a, b) -> void:
    a.cyl_z(0.012, 0.012, 0.008, Vector3(0, 0.046, -0.3), BLACK, 8)               # хомут шомпола
    _ring_x(a, Vector3(0, -0.108, 0.125), 0.012, 0.008, 0.004, STEEL)            # кольцо под шнур
    for side in [-1.0, 1.0]:
        b.cyl_x(0.006, 0.006, 0.006, Vector3(side * 0.0245, -0.03, 0.095), BRASS, 8, 0.8, 0.3)   # винты рукоятки
    b.box(Vector3(0.033, 0.003, 0.2), Vector3(0, 0.108, -0.27), BLACK)           # гравировка на стволе
    b.box(Vector3(0.033, 0.003, 0.2), Vector3(0, 0.094, -0.27), BLACK)


static func _d_knife(a, b) -> void:
    a.box(Vector3(0.0095, 0.006, 0.15), Vector3(0, 0.012, -0.18), DARK)           # кровосток на клинке
    _ring_x(a, Vector3(0, 0, 0.108), 0.012, 0.008, 0.004, STEEL)                 # отверстие под шнур
    b.box(Vector3(0.0035, 0.003, 0.18), Vector3(0, -0.0185, -0.175), Color(0.95, 0.96, 1.0), Vector3.ZERO, 0.9, 0.15)   # блик на лезвии
    b.cyl_z(0.0105, 0.0105, 0.004, Vector3(0, 0, 0.066), BRASS, 8, 0.8, 0.3)      # латунное кольцо рукояти


static func _d_machete(a, b) -> void:
    _ring_x(a, Vector3(0, 0, 0.082), 0.016, 0.011, 0.005, STEEL)                 # темляк
    a.box(Vector3(0.0072, 0.004, 0.3), Vector3(0, 0.034, -0.3), DARK)            # ребро жёсткости
    b.box(Vector3(0.004, 0.003, 0.4), Vector3(0, -0.0295, -0.3), Color(0.95, 0.96, 1.0), Vector3.ZERO, 0.9, 0.15)   # блик на лезвии
    var rng := RandomNumberGenerator.new()
    rng.seed = 313
    for i in range(7):                                                            # пятна ржавчины
        b.box(Vector3(0.0075, rng.randf_range(0.006, 0.014), rng.randf_range(0.012, 0.03)),
            Vector3(0, rng.randf_range(-0.02, 0.04), rng.randf_range(-0.5, -0.15)), Color(0.35, 0.2, 0.1), Vector3.ZERO, 0.3, 0.9)
