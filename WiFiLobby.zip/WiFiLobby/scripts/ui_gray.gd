extends RefCounted
## Единая серая тема интерфейса (лобби, пауза, настройки, HUD, магазин, инвентарь).
## Мобильное управление (кнопки-иконки и джойстик) этим файлом НЕ затрагивается.
##
## Использование в любом скрипте:
##   const UiGray = preload("res://scripts/ui_gray.gd")
##   control.theme = UiGray.make_theme()

# ---------- Палитра (только оттенки серого) ----------
const BG_DEEP := Color(0.055, 0.055, 0.060, 0.97)    # затемнение под окнами
const PANEL := Color(0.125, 0.125, 0.135, 0.97)      # фон окон
const PANEL_SOFT := Color(0.09, 0.09, 0.10, 0.80)    # полупрозрачные плашки HUD
const RAISED := Color(0.175, 0.175, 0.185, 1.0)      # карточки, слоты
const BTN := Color(0.215, 0.215, 0.230, 0.98)
const BTN_HOVER := Color(0.295, 0.295, 0.315, 1.0)
const BTN_PRESSED := Color(0.45, 0.45, 0.48, 1.0)
const BTN_DISABLED := Color(0.14, 0.14, 0.15, 0.90)
const EDGE := Color(0.42, 0.42, 0.45, 1.0)           # рамки окон
const EDGE_SOFT := Color(0.30, 0.30, 0.32, 1.0)      # рамки слотов и кнопок
const EDGE_STRONG := Color(0.78, 0.78, 0.81, 1.0)    # выбранный элемент
const TEXT := Color(0.93, 0.93, 0.94)
const TEXT_DIM := Color(0.68, 0.68, 0.71)
const TEXT_MUTE := Color(0.50, 0.50, 0.53)
const TEXT_ON_LIGHT := Color(0.08, 0.08, 0.09)
const ACCENT := Color(0.86, 0.86, 0.89)              # главный «акцент» — светло-серый
const OUTLINE := Color(0, 0, 0, 0.9)                 # обводка текста поверх мира
const BAR_FILL := Color(0.82, 0.82, 0.85)
const BAR_FILL_LOW := Color(0.55, 0.55, 0.58)        # полоска при низком значении
const BAR_BG := Color(0.07, 0.07, 0.08, 0.88)

const RADIUS := 8
const RADIUS_PANEL := 12


static func box(bg: Color, radius: int = RADIUS, edge: Color = EDGE_SOFT, border_w: int = 1, margin: int = 10) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.set_corner_radius_all(radius)
    s.border_color = edge
    s.set_border_width_all(border_w)
    s.set_content_margin_all(margin)
    return s


## Серая плашка для надписей поверх игры (голос, уведомления и т.п.).
static func hud_plate(margin: int = 8) -> StyleBoxFlat:
    return box(PANEL_SOFT, RADIUS, EDGE_SOFT, 1, margin)


## Пара стилей для ProgressBar (фон, заливка).
static func bar_background() -> StyleBoxFlat:
    return box(BAR_BG, 5, EDGE, 2, 0)


static func bar_fill(color: Color = BAR_FILL) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = color
    s.set_corner_radius_all(4)
    return s


static func circle_icon(diameter: int, color: Color, ring: Color = Color(0.1, 0.1, 0.11)) -> ImageTexture:
    var img := Image.create(diameter, diameter, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    var c := (diameter - 1) * 0.5
    var r := diameter * 0.5 - 1.0
    for y in range(diameter):
        for x in range(diameter):
            var d := Vector2(x - c, y - c).length()
            if d <= r + 0.5:
                var a := clampf(r + 0.5 - d, 0.0, 1.0)
                var col := ring if d > r - 3.0 else color
                img.set_pixel(x, y, Color(col.r, col.g, col.b, a))
    return ImageTexture.create_from_image(img)


static func make_theme(font_size: int = 22) -> Theme:
    var t := Theme.new()
    t.default_font_size = font_size

    # --- Текст ---
    t.set_color("font_color", "Label", TEXT)
    t.set_stylebox("normal", "Label", StyleBoxEmpty.new())
    for c in ["font_color", "font_focus_color"]:
        t.set_color(c, "Button", TEXT)
    t.set_color("font_hover_color", "Button", Color.WHITE)
    t.set_color("font_hover_pressed_color", "Button", Color.WHITE)
    t.set_color("font_pressed_color", "Button", Color.WHITE)
    t.set_color("font_disabled_color", "Button", TEXT_MUTE)

    # --- Кнопки ---
    t.set_stylebox("normal", "Button", box(BTN))
    t.set_stylebox("hover", "Button", box(BTN_HOVER, RADIUS, EDGE))
    t.set_stylebox("pressed", "Button", box(BTN_PRESSED, RADIUS, EDGE_STRONG))
    t.set_stylebox("hover_pressed", "Button", box(BTN_PRESSED, RADIUS, EDGE_STRONG))
    t.set_stylebox("disabled", "Button", box(BTN_DISABLED, RADIUS, Color(0.22, 0.22, 0.24)))
    t.set_stylebox("focus", "Button", StyleBoxEmpty.new())

    # --- Окна ---
    t.set_stylebox("panel", "PanelContainer", box(PANEL, RADIUS_PANEL, EDGE, 2, 18))
    t.set_stylebox("panel", "Panel", box(PANEL, RADIUS_PANEL, EDGE, 2, 10))
    t.set_stylebox("panel", "PopupPanel", box(PANEL, RADIUS_PANEL, EDGE, 2, 12))
    t.set_stylebox("panel", "PopupMenu", box(PANEL, RADIUS, EDGE, 1, 6))
    t.set_stylebox("panel", "AcceptDialog", box(PANEL, RADIUS_PANEL, EDGE, 2, 14))
    t.set_stylebox("embedded_border", "Window", box(PANEL, RADIUS_PANEL, EDGE, 2, 12))
    t.set_stylebox("embedded_unfocused_border", "Window", box(PANEL, RADIUS_PANEL, EDGE_SOFT, 2, 12))
    t.set_color("title_color", "Window", TEXT)

    # --- Поле ввода ---
    t.set_color("font_color", "LineEdit", TEXT)
    t.set_color("font_placeholder_color", "LineEdit", TEXT_MUTE)
    t.set_color("caret_color", "LineEdit", ACCENT)
    t.set_color("selection_color", "LineEdit", Color(0.5, 0.5, 0.55, 0.6))
    t.set_stylebox("normal", "LineEdit", box(Color(0.06, 0.06, 0.07, 0.85), RADIUS, EDGE_SOFT, 1, 8))
    t.set_stylebox("focus", "LineEdit", box(Color(0.07, 0.07, 0.08, 0.95), RADIUS, EDGE_STRONG, 2, 8))
    t.set_stylebox("read_only", "LineEdit", box(Color(0.09, 0.09, 0.10, 0.85), RADIUS, EDGE_SOFT, 1, 8))

    # --- Галочки ---
    for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
        t.set_color(c, "CheckBox", TEXT)
        t.set_color(c, "CheckButton", TEXT)
    t.set_stylebox("normal", "CheckBox", StyleBoxEmpty.new())
    t.set_stylebox("hover", "CheckBox", StyleBoxEmpty.new())
    t.set_stylebox("pressed", "CheckBox", StyleBoxEmpty.new())
    t.set_stylebox("focus", "CheckBox", StyleBoxEmpty.new())

    # --- Ползунки ---
    var track := box(Color(0.07, 0.07, 0.08, 0.95), 4, EDGE_SOFT, 1, 0)
    track.content_margin_top = 4
    track.content_margin_bottom = 4
    var filled := box(Color(0.62, 0.62, 0.66, 1.0), 4, EDGE_SOFT, 1, 0)
    filled.content_margin_top = 4
    filled.content_margin_bottom = 4
    var filled_hi := box(BAR_FILL, 4, EDGE_STRONG, 1, 0)
    filled_hi.content_margin_top = 4
    filled_hi.content_margin_bottom = 4
    t.set_stylebox("slider", "HSlider", track)
    t.set_stylebox("grabber_area", "HSlider", filled)
    t.set_stylebox("grabber_area_highlight", "HSlider", filled_hi)
    var knob := circle_icon(28, ACCENT)
    var knob_hi := circle_icon(28, Color.WHITE)
    var knob_off := circle_icon(28, TEXT_MUTE)
    t.set_icon("grabber", "HSlider", knob)
    t.set_icon("grabber_highlight", "HSlider", knob_hi)
    t.set_icon("grabber_disabled", "HSlider", knob_off)

    # --- Полоски (HP и т.п.) ---
    t.set_stylebox("background", "ProgressBar", bar_background())
    t.set_stylebox("fill", "ProgressBar", bar_fill())
    t.set_color("font_color", "ProgressBar", Color.WHITE)
    t.set_color("font_outline_color", "ProgressBar", Color(0, 0, 0, 0.95))
    t.set_constant("outline_size", "ProgressBar", 4)

    # --- Прокрутка ---
    for kind in ["VScrollBar", "HScrollBar"]:
        t.set_stylebox("scroll", kind, box(Color(0.07, 0.07, 0.08, 0.7), 4, Color(0, 0, 0, 0), 0, 0))
        t.set_stylebox("grabber", kind, box(Color(0.42, 0.42, 0.45), 4, Color(0, 0, 0, 0), 0, 0))
        t.set_stylebox("grabber_highlight", kind, box(Color(0.58, 0.58, 0.62), 4, Color(0, 0, 0, 0), 0, 0))
        t.set_stylebox("grabber_pressed", kind, box(Color(0.75, 0.75, 0.78), 4, Color(0, 0, 0, 0), 0, 0))

    # --- Списки ---
    t.set_stylebox("panel", "ItemList", box(Color(0.07, 0.07, 0.08, 0.92), RADIUS, EDGE_SOFT, 1, 6))
    t.set_stylebox("focus", "ItemList", StyleBoxEmpty.new())
    t.set_stylebox("hovered", "ItemList", box(Color(0.20, 0.20, 0.22, 0.9), 6, Color(0, 0, 0, 0), 0, 4))
    t.set_stylebox("selected", "ItemList", box(Color(0.34, 0.34, 0.37, 1.0), 6, EDGE_STRONG, 1, 4))
    t.set_stylebox("selected_focus", "ItemList", box(Color(0.34, 0.34, 0.37, 1.0), 6, EDGE_STRONG, 1, 4))
    t.set_stylebox("cursor", "ItemList", StyleBoxEmpty.new())
    t.set_stylebox("cursor_unfocused", "ItemList", StyleBoxEmpty.new())
    t.set_color("font_color", "ItemList", TEXT_DIM)
    t.set_color("font_hovered_color", "ItemList", Color.WHITE)
    t.set_color("font_selected_color", "ItemList", Color.WHITE)

    # --- Разделители ---
    var line := StyleBoxLine.new()
    line.color = EDGE_SOFT
    line.thickness = 1
    t.set_stylebox("separator", "HSeparator", line)
    return t
