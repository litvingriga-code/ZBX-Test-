extends Control
## Сцена лобби: 3D-платформа с low-poly игроками, ники снизу, деньги сверху.
## Состав и позиции берутся из Net.roster. Свайп/мышь по пустому месту
## поворачивает вашего персонажа.

const PlayerModel = preload("res://scripts/low_poly_player.gd")

var viewport: SubViewport
var world: Node3D
var floor_node: MeshInstance3D
var camera: Camera3D
var models: Dictionary = {}   # peer_id -> модель
var model_skins: Dictionary = {}   # peer_id -> номер скина, с которым собрана модель
var tags: Dictionary = {}     # peer_id -> {"nick": Label, "money": Label, "role": Label}
var time: float = 0.0


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP

    var grad := Gradient.new()
    grad.set_color(0, Color(0.20, 0.20, 0.22))
    grad.set_color(1, Color(0.05, 0.05, 0.06))
    var tex := GradientTexture2D.new()
    tex.gradient = grad
    tex.fill_from = Vector2(0, 0)
    tex.fill_to = Vector2(0, 1)
    tex.width = 4
    tex.height = 256
    var bg := TextureRect.new()
    bg.texture = tex
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_SCALE
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var container := SubViewportContainer.new()
    container.stretch = true
    container.mouse_filter = Control.MOUSE_FILTER_IGNORE
    container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(container)
    viewport = SubViewport.new()
    viewport.transparent_bg = true
    viewport.msaa_3d = Viewport.MSAA_4X
    container.add_child(viewport)
    _build_world()


func _build_world() -> void:
    world = Node3D.new()
    viewport.add_child(world)

    var env := Environment.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.78, 0.78, 0.80)
    env.ambient_light_energy = 0.65
    var we := WorldEnvironment.new()
    we.environment = env
    world.add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-35, 20, 0)
    sun.light_energy = 1.1
    world.add_child(sun)

    # низкополигональная круглая платформа
    var floor_mesh := CylinderMesh.new()
    floor_mesh.top_radius = 6.0
    floor_mesh.bottom_radius = 6.0
    floor_mesh.height = 0.1
    floor_mesh.radial_segments = 10
    floor_mesh.rings = 1
    var floor_mat := StandardMaterial3D.new()
    floor_mat.albedo_color = Color(0.22, 0.22, 0.24)
    floor_mat.roughness = 1.0
    floor_mesh.material = floor_mat
    floor_node = MeshInstance3D.new()
    floor_node.mesh = floor_mesh
    floor_node.position = Vector3(0, -0.05, 0)
    world.add_child(floor_node)
    floor_node.visible = true

    camera = Camera3D.new()
    camera.fov = 40.0
    camera.position = Vector3(0, 1.35, 5.4)
    camera.rotation_degrees = Vector3(-4, 0, 0)
    world.add_child(camera)
    camera.current = true


func _gui_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
        Net.add_my_yaw(event.relative.x * 0.012)


func _process(delta: float) -> void:
    time += delta
    var roster: Dictionary = Net.roster
    for id in roster.keys():
        if not models.has(id):
            _add_model(int(id), roster[id])
    for id in models.keys():
        if not roster.has(id):
            _remove_model(id)
    var count: int = roster.size()
    var my_id: int = Net.my_id()
    for id in models.keys():
        var e: Dictionary = roster[id]
        if int(model_skins.get(id, 0)) != int(e.get("skin", 0)):
            _recolor_model(int(id), e)   # игрок выбрал другой скин — пересобираем модель
        var m = models[id]
        var target_x: float = float(e.get("x", 0.0))
        var cur_x: float = m.position.x
        var nx: float = lerpf(cur_x, target_x, clampf(delta * 14.0, 0.0, 1.0))
        var vel: float = (nx - cur_x) / maxf(delta, 0.0001)
        var walking: bool = absf(vel) > 0.4
        var yaw_goal: float = float(e.get("yaw", 0.0))
        if int(id) == my_id and Net.role == "client":
            yaw_goal = Net.my_yaw   # свой поворот показываем сразу, Host подтвердит
        if walking:
            yaw_goal = PI * 0.5 if vel > 0.0 else -PI * 0.5
        m.rotation.y = lerp_angle(m.rotation.y, yaw_goal, clampf(delta * 10.0, 0.0, 1.0))
        m.position.x = nx
        # Stage82: в руках оружие из слота 1 (автомат), иначе пистолет из слота 2.
        var hand_id: String = GameState.get_hand_weapon() if int(id) == my_id else str(e.get("hand", ""))
        m.set_weapon(hand_id)
        m.animate(time, walking, delta)
        _update_tags(int(id), e, nx, count, int(id) == my_id)


func _new_model(id: int, skin: int) -> Node3D:
    var m = PlayerModel.new()
    var base := Color(0.20, 0.45, 0.85) if id == 1 else Color(0.90, 0.55, 0.15)
    m.setup(GameState.skin_color(skin, base))
    return m


## Заменяет модель игрока на модель нового цвета, сохраняя место и поворот.
func _recolor_model(id: int, data: Dictionary) -> void:
    var skin := GameState.clamp_skin(int(data.get("skin", 0)))
    var old: Node3D = models[id]
    var fresh: Node3D = _new_model(id, skin)
    fresh.position = old.position
    fresh.rotation = old.rotation
    world.add_child(fresh)
    old.queue_free()
    models[id] = fresh
    model_skins[id] = skin


func _add_model(id: int, data: Dictionary) -> void:
    var skin := GameState.clamp_skin(int(data.get("skin", 0)))
    var m = _new_model(id, skin)
    m.position.x = float(data.get("x", 0.0))
    world.add_child(m)
    models[id] = m
    model_skins[id] = skin
    tags[id] = {
        "money": _make_label(30, Color(0.90, 0.90, 0.92)),
        "nick": _make_label(28, Color(1, 1, 1)),
        "role": _make_label(16, Color(0.62, 0.62, 0.66)),
    }


func _remove_model(id) -> void:
    if models.has(id):
        (models[id] as Node).queue_free()
        models.erase(id)
        model_skins.erase(id)
    if tags.has(id):
        var t: Dictionary = tags[id]
        for key in t.keys():
            (t[key] as Node).queue_free()
        tags.erase(id)


func _update_tags(id: int, e: Dictionary, x: float, count: int, is_me: bool) -> void:
    var t: Dictionary = tags[id]
    var money_l: Label = t["money"]
    var nick_l: Label = t["nick"]
    var role_l: Label = t["role"]
    money_l.text = GameState.format_money(int(e.get("money", 0))) + " $"
    nick_l.text = str(e.get("nick", ""))
    nick_l.add_theme_color_override("font_color", Color(1, 1, 1) if is_me else Color(0.74, 0.74, 0.78))
    role_l.visible = count > 1
    role_l.text = "Host" if id == 1 else "Client"
    var head: Vector2 = camera.unproject_position(Vector3(x, 2.2, 0.0))
    var foot: Vector2 = camera.unproject_position(Vector3(x, 0.0, 0.0))
    _put(money_l, head, false)
    _put(nick_l, foot + Vector2(0, 8), true)
    _put(role_l, foot + Vector2(0, 8 + nick_l.get_minimum_size().y), true)


func _put(l: Label, p: Vector2, below: bool) -> void:
    var s: Vector2 = l.get_minimum_size()
    l.size = s
    l.position = Vector2(p.x - s.x * 0.5, p.y if below else p.y - s.y)


func _make_label(font_size: int, color: Color) -> Label:
    var l := Label.new()
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    l.add_theme_constant_override("outline_size", 6)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(l)
    return l


func set_floor_visible(enabled: bool) -> void:
    if floor_node != null:
        floor_node.visible = enabled
