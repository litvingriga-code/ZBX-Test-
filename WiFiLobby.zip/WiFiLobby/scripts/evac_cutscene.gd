extends Node3D
## Stage83: эвакуация вертолётом в режиме «Волны зомби».
## Когда счётчик раунда доходит до 00:00, на точку появления («Титаник», носовая площадка)
## прилетает вертолёт, садится, забирает игроков и улетает. Всё строится кодом, ассеты не нужны.
## Stage87: сцена полностью локальная и личная — её запускает battle.gd (_start_evac), когда игрок коснулся
## точки появления; в вертолёт садится только он. По окончании (done = true) battle.gd вызывает _end_evac().
##
## Хронология (t — секунды с начала, f = t - CUT_AT — «время полёта»):
##   t 0..1     затемнение, управление отключено, издалека слышен вертолёт
##   t 1        смена кадра: игроки на площадке, вертолёт на подлёте
##   f 0..5.2   подлёт к площадке со стороны носа, прожектор
##   f 5.2..7.6 снижение и посадка
##   f 7.6..11  двери открыты, игроки бегут и садятся
##   f 11..15.5 взлёт и уход в ночь; последние ~1.5 с — затемнение

const Kit = preload("res://scripts/model_kit.gd")
const TitanicMap = preload("res://scripts/titanic_map.gd")

const TOTAL := 16.5            # длительность личной сцены (Stage87: играется только у того, кто коснулся точки)
const CUT_AT := 1.0
const FLY_START := Vector3(-34.0, 30.0, -150.0)
const HOVER_Y := 12.0
const PAD_TOP := 0.22          # толщина площадки над палубой
const BOARD_SPEED := 3.4

var t := 0.0
var fade := 0.0                # 0..1 — чёрный экран
var letterbox := 0.0           # 0..1 — чёрные полосы «кино»
var cam_active := false        # камерой управляет сцена
var done := false

var camera: Camera3D
var pad := Vector3.ZERO
var passengers: Array = []

var heli: Node3D
var body: Node3D
var main_rotor: Node3D
var tail_rotor: Node3D
var door_l: Node3D
var door_r: Node3D
var cabin_light: OmniLight3D
var strobe: MeshInstance3D
var audio: AudioStreamPlayer3D
var _look := Vector3.ZERO
var _cut_done := false


## cam — камера боя; actors/tags — модели живых игроков и их ярлыки (Label3D).
func setup(cam: Camera3D, actors: Array, tags: Array) -> void:
    camera = cam
    pad = Vector3(TitanicMap.SPAWN_CENTER.x, TitanicMap.GROUND_Y, TitanicMap.SPAWN_CENTER.z)
    _build_heli()
    heli.position = FLY_START
    heli.visible = false
    for i in range(actors.size()):
        var side := -1.0 if i % 2 == 0 else 1.0
        var row := floori(i * 0.5)
        passengers.append({
            "node": actors[i],
            "tag": tags[i],
            "side": side,
            "slot": pad + Vector3(side * 3.4, 0.0, -2.0 + 2.6 * float(row)),
            "start": 7.9 + 0.3 * float(i),
            "boarded": false,
        })
    audio = AudioStreamPlayer3D.new()
    audio.stream = _make_rotor_loop()
    audio.unit_size = 30.0
    audio.volume_db = 5.0
    audio.max_distance = 0.0
    heli.add_child(audio)
    audio.play()


func step(delta: float) -> void:
    if done:
        return
    t += delta
    var f := t - CUT_AT
    if t < CUT_AT:
        fade = smoothstep(0.0, CUT_AT, t)
    elif t < CUT_AT + 0.3:
        fade = 1.0
    elif t < CUT_AT + 1.3:
        fade = 1.0 - smoothstep(CUT_AT + 0.3, CUT_AT + 1.3, t)
    else:
        fade = 0.0
    if t > TOTAL - 1.5:
        fade = maxf(fade, smoothstep(TOTAL - 1.5, TOTAL - 0.1, t))
    letterbox = smoothstep(0.3, 1.5, t)
    if t >= CUT_AT and not _cut_done:
        _do_cut()
    if _cut_done:
        _update_heli(f, delta)
        _update_passengers(f, delta)
        _update_camera(f, delta)
    if t >= TOTAL:
        done = true
        if audio != null:
            audio.stop()


# ------------------------------------------------------------------ кадры

func _do_cut() -> void:
    _cut_done = true
    cam_active = true
    heli.visible = true
    camera.fov = 62.0
    _look = heli.position
    for p in passengers:
        var node: Node3D = p["node"]
        var slot: Vector3 = p["slot"]
        node.visible = true
        node.position = slot
        node.rotation.y = atan2(pad.x - slot.x, pad.z - slot.z)
        if node.has_method("set_weapon"):
            node.call("set_weapon", "", false)
        if node.has_method("set_crouching"):
            node.call("set_crouching", false, 1.0)
        if node.has_method("set_downed"):
            node.call("set_downed", false, 1.0)
        if node.has_method("auto_animate"):
            node.call("auto_animate", 0.0)   # сбросить «прошлую позицию», иначе будет рывок
        var tag: Node3D = p["tag"]
        if tag != null:
            tag.visible = false


func _update_heli(f: float, delta: float) -> void:
    var land := Vector3(pad.x, pad.y + PAD_TOP, pad.z)
    var hover := Vector3(pad.x, HOVER_Y, pad.z)
    var lift := Vector3(pad.x, 9.5, pad.z)
    var away := Vector3(-110.0, 45.0, 55.0)
    var approach_yaw := atan2(hover.x - FLY_START.x, hover.z - FLY_START.z)
    var away_yaw := atan2(away.x, away.z)
    var pos := land
    var yaw := 0.0
    var pitch := 0.0
    var roll := 0.0
    var sway := 0.0
    if f < 5.2:
        var u := clampf(f / 5.2, 0.0, 1.0)
        var e := 1.0 - pow(1.0 - u, 3.0)
        pos = FLY_START.lerp(hover, e)
        yaw = approach_yaw
        pitch = 0.22 * (1.0 - u) * (1.0 - u)
        roll = -0.12 * (1.0 - u)
        sway = u
    elif f < 7.6:
        var u2 := smoothstep(0.0, 1.0, (f - 5.2) / 2.4)
        pos = hover.lerp(land, u2)
        yaw = lerp_angle(approach_yaw, 0.0, smoothstep(0.0, 1.0, (f - 5.2) / 1.8))
        pitch = -0.05 * sin(u2 * PI)
        sway = 1.0 - u2
    elif f < 11.0:
        pos = land
    else:
        var up := smoothstep(11.0, 13.2, f)
        pos = land.lerp(lift, up)
        var run := clampf((f - 12.0) / 3.5, 0.0, 1.0)
        var s := pow(run, 2.2)
        pos += away * s
        var turn := smoothstep(0.0, 1.0, (f - 12.0) / 2.0)
        yaw = lerp_angle(0.0, away_yaw, turn)
        pitch = 0.30 * clampf((f - 12.4) / 1.5, 0.0, 1.0)
        roll = 0.22 * sin(turn * PI)
        sway = clampf((f - 11.2) / 1.5, 0.0, 1.0) * (1.0 - s)
    pos += Vector3(sin(f * 1.3) * 0.25, sin(f * 1.9) * 0.12, cos(f * 1.1) * 0.25) * sway
    heli.position = pos
    heli.rotation = Vector3(0.0, yaw, 0.0)
    body.rotation = Vector3(pitch, 0.0, roll)
    main_rotor.rotation.y += delta * 26.0
    tail_rotor.rotation.x += delta * 42.0
    # Двери открываются после посадки и закрываются перед взлётом.
    var open := smoothstep(7.6, 8.5, f) - smoothstep(10.8, 11.6, f)
    door_l.position.z = 0.5 - open * 1.0
    door_r.position.z = 0.5 - open * 1.0
    cabin_light.light_energy = 1.6 * open
    cabin_light.visible = open > 0.02
    strobe.visible = fmod(t, 1.1) < 0.12


func _update_passengers(f: float, delta: float) -> void:
    for p in passengers:
        var node: Node3D = p["node"]
        if bool(p["boarded"]):
            continue
        if f >= float(p["start"]):
            var door: Vector3 = heli.to_global(Vector3(float(p["side"]) * 1.55, 0.0, 0.5))
            door.y = node.position.y
            var to := door - node.position
            to.y = 0.0
            var dist := to.length()
            if dist < 0.35:
                node.visible = false
                p["boarded"] = true
                continue
            node.position += to / dist * minf(dist, BOARD_SPEED * delta)
            node.rotation.y = lerp_angle(node.rotation.y, atan2(to.x, to.z), clampf(delta * 12.0, 0.0, 1.0))
        if node.has_method("auto_animate"):
            node.call("auto_animate", delta)


func _update_camera(f: float, delta: float) -> void:
    # План 1: из-за площадки смотрим на подлёт. План 2: облёт вокруг посадки. План 3: отъезд за взлётом.
    # Stage103: камера всегда со стороны носа (перед площадкой), а не над кормой — там мостик и рубка.
    var pos_a := pad + Vector3(9.0, 2.5, -16.0)
    var a := 0.55 + 0.11 * maxf(f - 5.0, 0.0)
    var pull := smoothstep(10.0, 13.5, f)
    var radius := lerpf(15.0, 24.0, pull)
    var height := lerpf(3.4, 8.5, pull)
    var pos_b := pad + Vector3(sin(a) * radius, height, -cos(a) * radius)
    var pos := pos_a.lerp(pos_b, smoothstep(4.0, 6.0, f))
    pos.z = clampf(pos.z, TitanicMap.BOW_Z + 10.0, pad.z + 5.0)   # не заходим в здания (мостик начинается с z = -118)
    var hw := TitanicMap.half_width(pos.z)
    pos.x = clampf(pos.x, -hw + 0.8, hw - 0.8)
    var heli_look := heli.position + Vector3(0.0, 1.5, 0.0)
    var pad_look := pad + Vector3(0.0, 2.2, 0.0)
    var target := heli_look.lerp(pad_look, smoothstep(4.0, 6.0, f))
    target = target.lerp(heli_look, smoothstep(10.8, 12.8, f))
    _look = _look.lerp(target, clampf(delta * 5.0, 0.0, 1.0))
    camera.look_at_from_position(pos, _look, Vector3.UP)
    camera.fov = lerpf(62.0, 44.0, smoothstep(11.0, 15.0, f))


# ------------------------------------------------------------------ модель вертолёта

func _build_heli() -> void:
    heli = Node3D.new()
    heli.name = "EvacHelicopter"
    add_child(heli)
    body = Node3D.new()
    body.name = "Body"
    heli.add_child(body)

    var hull := Color(0.86, 0.24, 0.10)
    var white := Color(0.92, 0.92, 0.95)
    var dark := Color(0.10, 0.11, 0.13)
    var glass := Color(0.20, 0.42, 0.58, 0.6)

    var kit := Kit.new()
    # Фюзеляж, брюхо, моторный горб, хвостовая балка, оперение.
    kit.sphere(1.0, Vector3(0, 1.5, 0.6), hull, Vector3(1.25, 1.2, 2.3), 0.2, 0.5, 16)
    kit.sphere(1.0, Vector3(0, 1.2, 0.6), white, Vector3(1.22, 1.0, 2.25), 0.2, 0.5, 16)
    kit.box(Vector3(1.5, 0.7, 2.2), Vector3(0, 2.75, 0.1), dark, Vector3.ZERO, 0.4, 0.6)
    kit.cyl_z(0.16, 0.42, 6.2, Vector3(0, 1.85, -4.4), hull, 10, 0.2, 0.6)
    kit.cyl_z(0.22, 0.30, 1.0, Vector3(0, 1.85, -2.6), white, 10, 0.2, 0.6)
    kit.box(Vector3(0.12, 1.7, 1.2), Vector3(0, 2.6, -7.0), hull, Vector3.ZERO, 0.2, 0.6)
    kit.box(Vector3(2.2, 0.1, 0.7), Vector3(0, 1.95, -6.8), hull, Vector3.ZERO, 0.2, 0.6)
    kit.sphere(1.0, Vector3(0, 1.75, 2.1), glass, Vector3(1.05, 0.8, 0.9), 0.6, 0.1, 12)
    kit.cyl_y(0.14, 0.14, 0.7, Vector3(0, 3.4, 0.1), dark, 8, 0.5, 0.5)
    # Лыжи и стойки.
    for sx in [-1.0, 1.0]:
        kit.cyl_z(0.07, 0.07, 4.4, Vector3(sx * 1.2, 0.1, 0.4), dark, 8, 0.5, 0.5)
        kit.box(Vector3(0.07, 0.55, 0.07), Vector3(sx * 1.15, 0.4, 1.4), dark)
        kit.box(Vector3(0.07, 0.55, 0.07), Vector3(sx * 1.15, 0.4, -0.6), dark)
    # Светящиеся детали: проём двери, габаритные огни, прожектор.
    for sx in [-1.0, 1.0]:
        _glow(kit, Vector3(0.04, 1.05, 1.5), Vector3(sx * 1.268, 1.5, 0.5), Color(1.0, 0.82, 0.45))
    _glow_sphere(kit, 0.09, Vector3(-1.2, 1.2, 1.2), Color(1.0, 0.1, 0.1))
    _glow_sphere(kit, 0.09, Vector3(1.2, 1.2, 1.2), Color(0.1, 1.0, 0.2))
    _glow_sphere(kit, 0.08, Vector3(0, 2.35, -7.15), Color(1.0, 1.0, 1.0))
    _glow_sphere(kit, 0.18, Vector3(0, 0.55, 2.4), Color(1.0, 0.98, 0.8))
    kit.commit(body)

    # Двери-створки: сдвигаются назад вдоль борта.
    for sx in [-1.0, 1.0]:
        var door := Node3D.new()
        door.name = "DoorL" if sx < 0.0 else "DoorR"
        door.position = Vector3(sx * 1.29, 1.5, 0.5)
        body.add_child(door)
        var dk := Kit.new()
        dk.box(Vector3(0.06, 1.05, 1.5), Vector3.ZERO, Color(0.22, 0.24, 0.27), Vector3.ZERO, 0.3, 0.6)
        dk.commit(door)
        if sx < 0.0:
            door_l = door
        else:
            door_r = door

    # Несущий винт.
    main_rotor = Node3D.new()
    main_rotor.name = "MainRotor"
    main_rotor.position = Vector3(0, 3.8, 0.1)
    body.add_child(main_rotor)
    var rk := Kit.new()
    rk.box(Vector3(10.6, 0.05, 0.42), Vector3.ZERO, dark, Vector3.ZERO, 0.3, 0.6)
    rk.box(Vector3(0.42, 0.05, 10.6), Vector3.ZERO, dark, Vector3.ZERO, 0.3, 0.6)
    rk.commit(main_rotor)
    var blur := MeshInstance3D.new()
    var disc := CylinderMesh.new()
    disc.top_radius = 5.3
    disc.bottom_radius = 5.3
    disc.height = 0.01
    disc.radial_segments = 24
    blur.mesh = disc
    var blur_mat := StandardMaterial3D.new()
    blur_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    blur_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    blur_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    blur_mat.albedo_color = Color(0.7, 0.75, 0.8, 0.10)
    blur.material_override = blur_mat
    body.add_child(blur)
    blur.position = Vector3(0, 3.8, 0.1)

    # Хвостовой винт.
    tail_rotor = Node3D.new()
    tail_rotor.name = "TailRotor"
    tail_rotor.position = Vector3(0.22, 2.55, -7.35)
    body.add_child(tail_rotor)
    var tk := Kit.new()
    tk.box(Vector3(0.06, 1.5, 0.14), Vector3.ZERO, dark, Vector3.ZERO, 0.3, 0.6)
    tk.box(Vector3(0.06, 0.14, 1.5), Vector3.ZERO, dark, Vector3.ZERO, 0.3, 0.6)
    tk.commit(tail_rotor)

    # Мигалка сверху.
    strobe = MeshInstance3D.new()
    var strobe_mesh := SphereMesh.new()
    strobe_mesh.radius = 0.13
    strobe_mesh.height = 0.26
    strobe.mesh = strobe_mesh
    strobe.material_override = Kit.glow_material(Color(1, 1, 1))
    strobe.position = Vector3(0, 3.2, -0.9)
    body.add_child(strobe)

    # Прожектор и видимый луч.
    var spot := SpotLight3D.new()
    spot.name = "Searchlight"
    spot.position = Vector3(0, 0.5, 2.4)
    spot.rotation_degrees = Vector3(-110.0, 0.0, 0.0)
    spot.spot_range = 48.0
    spot.spot_angle = 24.0
    spot.light_energy = 9.0
    spot.light_color = Color(1.0, 0.97, 0.85)
    spot.shadow_enabled = false
    body.add_child(spot)
    var beam := MeshInstance3D.new()
    var cone := CylinderMesh.new()
    cone.top_radius = 0.08
    cone.bottom_radius = 3.6
    cone.height = 16.0
    cone.radial_segments = 16
    beam.mesh = cone
    var beam_mat := StandardMaterial3D.new()
    beam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    beam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    beam_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    beam_mat.albedo_color = Color(1.0, 0.97, 0.8, 0.07)
    beam.material_override = beam_mat
    beam.position = Vector3(0, -7.02, 5.14)
    beam.rotation_degrees = Vector3(-20.0, 0.0, 0.0)
    body.add_child(beam)

    # Свет в салоне — включается при открытых дверях.
    cabin_light = OmniLight3D.new()
    cabin_light.position = Vector3(0, 1.6, 0.5)
    cabin_light.omni_range = 6.0
    cabin_light.light_color = Color(1.0, 0.85, 0.55)
    cabin_light.light_energy = 0.0
    cabin_light.shadow_enabled = false
    body.add_child(cabin_light)


func _glow(kit: Object, size: Vector3, pos: Vector3, tint: Color) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    kit.add_mesh(mesh, Transform3D(Basis.IDENTITY, pos), Kit.glow_material(tint))


func _glow_sphere(kit: Object, radius: float, pos: Vector3, tint: Color) -> void:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 8
    mesh.rings = 4
    kit.add_mesh(mesh, Transform3D(Basis.IDENTITY, pos), Kit.glow_material(tint))


# ------------------------------------------------------------------ звук

## Зацикленный стук лопастей (12 ударов в секунду) + низкий гул двигателя. Целое число периодов — шва нет.
func _make_rotor_loop() -> AudioStreamWAV:
    var rate := 22050
    var n := rate
    var data := PackedByteArray()
    data.resize(n * 2)
    var rng := RandomNumberGenerator.new()
    rng.seed = 83
    var low := 0.0
    for i in range(n):
        var time := float(i) / float(rate)
        var phase := fmod(time * 12.0, 1.0)
        var env := exp(-phase * 7.0)
        low += (rng.randf_range(-1.0, 1.0) - low) * 0.12
        var v := low * env * 1.7
        v += sin(TAU * 60.0 * time) * 0.16
        v += sin(TAU * 120.0 * time) * 0.07 * (0.6 + 0.4 * env)
        data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 30000.0))
    var stream := AudioStreamWAV.new()
    stream.format = AudioStreamWAV.FORMAT_16_BITS
    stream.mix_rate = rate
    stream.stereo = false
    stream.data = data
    stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
    stream.loop_begin = 0
    stream.loop_end = n
    return stream
