extends RefCounted
## Stage103: БОЛЬШАЯ карта «Титаник» с проходимыми внутренними помещениями.
## Корабль 360 x 48 м: нос, площадка появления, мостик с рубкой и ШТУРВАЛОМ, шесть
## палубных надстроек (каюты, коридоры, салон с лестницей, столовая, каюты экипажа),
## шлюпки, краны, упавшая труба. Зомби вылезают из ВЕНТИЛЯЦИОННЫХ ЛЮКОВ (vent_points()).
## Всё строится кодом (без внешних ассетов). Одни и те же данные использует:
##   - build()            — визуал (только в бою);
##   - obstacles()        — столкновения игрока, навигация зомби, блокировка выстрелов;
##   - build_navigation() — сетка A* для хоста (физика не нужна);
##   - player_spawns() / zombie_spawn_points() — точки появления.
## Оси: нос = -Z, корма = +Z. Палуба на y = 0, карта поднята на GROUND_Y.
## ВАЖНО для навигации: все стены лежат на чётных координатах (линиях ячеек сетки 2 м),
## двери шириной 3 м, у стен запас для зомби 0.4 м (поле "g").

const Kit = preload("res://scripts/model_kit.gd")

const BOW_Z := -180.0
const STERN_Z := 180.0
const HALF_W := 24.0
const WATER_Y := -9.0
const PLAYER_RADIUS := 0.45
const GROUND_Y := 1.0

# Сетка навигации зомби (ячейка 2 м, вся палуба).
const NAV_CELL := 2.0
const NAV_LEFT := -26.0
const NAV_TOP := -184.0
const NAV_COLS := 27
const NAV_ROWS := 185

const SPAWN_CENTER := Vector3(0.0, 0.0, -128.0)

# Магазин турелей рядом с площадкой появления.
const SHOP_SPOTS := [Vector2(-12.0, -128.0)]
const SHOP_USE_RADIUS := 3.4

# Stage122: ящики стоячие, ступени, вода
const STEP_UP := 0.3                 # на столько выше ступни можно «влезть» на край ящика
const WATER_TOUCH_Y := -7.6          # мировая высота ступни, при которой игрок коснулся воды (вода на y = -8)
const SHIP_SPEED := 9.0              # м/с, корабль идёт вперёд (к -Z); вода и айсберги уходят назад

const WALL_T := 0.3
const WALL_H := 3.4
const DOOR_HALF := 1.5
const BUCKET := 12.0

static var _obstacles: Array = []
static var _buckets: Dictionary = {}
static var _doors: Array = []
static var _windows: Array = []
static var _floors: Array = []
static var _lamps: Array = []
static var _labels: Array = []
static var _vents: Array = []
static var _buildings: Array = []
static var _cur_b := -1
static var _layout_ready := false
# Stage123: ледяные блоки айсбергов (в системе их «державы»): {berg, rect, h}; _ice_dz — текущий снос айсберга по Z
static var _ice: Array = []
static var _ice_dz: Array = [0.0, 0.0]


## Полуширина палубы на координате z (нос сужается, корма скруглена).
static func half_width(z: float) -> float:
    if z < -130.0:
        var t := clampf((z - BOW_Z) / 50.0, 0.0, 1.0)
        return HALF_W * pow(t, 0.65)
    if z > 150.0:
        return HALF_W * (1.0 - 0.28 * clampf((z - 150.0) / 30.0, 0.0, 1.0))
    return HALF_W


# ------------------------------------------------------------------ генерация данных

static func _add(list: Array, cx: float, cz: float, w: float, d: float, h: float, kind: String, style: String = "") -> void:
    var grow := 0.9
    if kind == "wall":
        grow = 0.4
    elif kind == "furn" or kind == "cowl":
        grow = 0.3
    var stand := kind == "crate" or style == "crate"   # на ящиках можно стоять
    list.append({"rect": Rect2(cx - w * 0.5, cz - d * 0.5, w, d), "h": h, "kind": kind, "style": style, "cx": cx, "cz": cz, "w": w, "d": d, "g": grow, "b": _cur_b, "stand": stand})


static func _furn(list: Array, cx: float, cz: float, w: float, d: float, h: float, style: String) -> void:
    _add(list, cx, cz, w, d, h, "furn", style)


## Штабель ящиков со ступенями: основной блок высотой 0.9 * levels и «лесенка» из ящиков с одной стороны
## (каждая ступень на 0.9 м ниже предыдущей — это ниже высоты прыжка, поэтому на штабель можно запрыгнуть).
## side — куда смотрят ступени: Vector2(1, 0) = +X, (-1, 0) = -X, (0, 1) = +Z, (0, -1) = -Z.
static func _crate_stack(list: Array, cx: float, cz: float, w: float, d: float, levels: int, side: Vector2) -> void:
    _add(list, cx, cz, w, d, 0.9 * float(levels), "crate")
    for k in range(1, levels):
        var ext := 1.1 * float(levels - k)
        var h := 0.9 * float(k)
        if absf(side.x) > 0.5:
            _add(list, cx + side.x * (w * 0.5 + ext * 0.5), cz, ext, d, h, "crate")
        else:
            _add(list, cx, cz + side.y * (d * 0.5 + ext * 0.5), w, ext, h, "crate")


## Стена вдоль X на глубине zc от x0 до x1; doors — центры дверей (проёмы шириной 3 м).
static func _wall_x(list: Array, zc: float, x0: float, x1: float, doors: Array, style: String) -> void:
    var cursor := x0 - WALL_T * 0.5
    var sorted := doors.duplicate()
    sorted.sort()
    for raw in sorted:
        var dx: float = raw
        var a := dx - DOOR_HALF
        if a > cursor:
            _add(list, (cursor + a) * 0.5, zc, a - cursor, WALL_T, WALL_H, "wall", style)
        cursor = dx + DOOR_HALF
        _doors.append({"x": dx, "z": zc, "axis": "x", "b": _cur_b})
    var tail := x1 + WALL_T * 0.5
    if tail > cursor:
        _add(list, (cursor + tail) * 0.5, zc, tail - cursor, WALL_T, WALL_H, "wall", style)


## Стена вдоль Z на x = xc от z0 до z1.
static func _wall_z(list: Array, xc: float, z0: float, z1: float, doors: Array, style: String) -> void:
    var cursor := z0 - WALL_T * 0.5
    var sorted := doors.duplicate()
    sorted.sort()
    for raw in sorted:
        var dz: float = raw
        var a := dz - DOOR_HALF
        if a > cursor:
            _add(list, xc, (cursor + a) * 0.5, WALL_T, a - cursor, WALL_H, "wall", style)
        cursor = dz + DOOR_HALF
        _doors.append({"x": xc, "z": dz, "axis": "z", "b": _cur_b})
    var tail := z1 + WALL_T * 0.5
    if tail > cursor:
        _add(list, xc, (cursor + tail) * 0.5, WALL_T, tail - cursor, WALL_H, "wall", style)


static func _floor(x0: float, z0: float, x1: float, z1: float, tint: Color) -> void:
    _floors.append({"r": Rect2(x0, z0, x1 - x0, z1 - z0), "c": tint, "b": _cur_b})


static func _lamp(x: float, z: float) -> void:
    _lamps.append({"x": x, "z": z, "b": _cur_b})


static func _window(axis: String, fixed: float, pos: float, length: float) -> void:
    _windows.append({"axis": axis, "f": fixed, "p": pos, "l": length, "b": _cur_b})


static func _vent(x: float, z: float) -> void:
    _vents.append(Vector2(x, z))


static func _label(text: String, x: float, y: float, z: float) -> void:
    _labels.append({"t": text, "x": x, "y": y, "z": z})


static func _ensure_layout() -> void:
    if _layout_ready:
        return
    _layout_ready = true
    var list: Array = []
    _doors.clear()
    _windows.clear()
    _floors.clear()
    _lamps.clear()
    _labels.clear()
    _vents.clear()
    _buildings.clear()
    _cur_b = -1
    _bridge(list)
    _cabin_block(list, "КАЮТЫ 1 КЛАССА", -80.0, -44.0, {"funnel": "normal", "rooms": ["lounge", "bath", "stairs"]})
    _cabin_block(list, "ПАРАДНАЯ ЛЕСТНИЦА И САЛОН", -40.0, -4.0, {"hall": true, "hall_kind": "grand", "funnel": "normal", "dome": true})
    _cabin_block(list, "КАЮТЫ 2 КЛАССА", 12.0, 48.0, {"funnel": "broken", "rooms": ["bath", "lounge", "storage"]})
    _cabin_block(list, "СТОЛОВАЯ", 64.0, 100.0, {"hall": true, "hall_kind": "dining", "funnel": "normal"})
    _cabin_block(list, "КАЮТЫ ЭКИПАЖА", 108.0, 138.0, {"crew": true, "rooms": ["mess", "bath", "storage"]})
    _cur_b = -1
    _outdoor(list)
    _obstacles = list
    _index_obstacles()
    _make_ice_data()


static func _index_obstacles() -> void:
    _buckets.clear()
    for i in range(_obstacles.size()):
        var rect: Rect2 = (_obstacles[i] as Dictionary)["rect"]
        var k0 := floori((rect.position.y - 1.6) / BUCKET)
        var k1 := floori((rect.end.y + 1.6) / BUCKET)
        for k in range(k0, k1 + 1):
            if not _buckets.has(k):
                _buckets[k] = []
            (_buckets[k] as Array).append(i)


static func _bucket(z: float) -> Array:
    return _buckets.get(floori(z / BUCKET), [])


## Все твёрдые объекты (прямоугольники в плоскости XZ): стены, мебель, шлюпки, ящики...
static func obstacles() -> Array:
    _ensure_layout()
    return _obstacles


# ---- мостик: рубка со штурвалом, капитанская, радиорубка, холл, каюты офицеров

static func _bridge(list: Array) -> void:
    _cur_b = _buildings.size()
    _buildings.append({"name": "МОСТИК", "x0": -14.0, "x1": 14.0, "z0": -118.0, "z1": -84.0, "hall": false, "funnel": "", "dome": false, "kind": "bridge"})
    var ext_doors := [-112.0, -100.0, -92.0]
    _wall_z(list, -14.0, -118.0, -84.0, ext_doors, "ext")
    _wall_z(list, 14.0, -118.0, -84.0, ext_doors, "ext")
    _wall_x(list, -118.0, -14.0, 14.0, [], "ext")
    _wall_x(list, -84.0, -14.0, 14.0, [], "ext")
    _wall_x(list, -106.0, -14.0, 14.0, [-10.0, 0.0, 10.0], "int")
    _wall_z(list, -6.0, -106.0, -94.0, [-100.0], "int")
    _wall_z(list, 6.0, -106.0, -94.0, [-100.0], "int")
    _wall_x(list, -94.0, -14.0, 14.0, [-10.0, 0.0, 10.0], "int")
    _wall_x(list, -90.0, -14.0, 14.0, [-11.0, -4.0, 4.0, 11.0], "int")
    for x in [-8.0, 0.0, 8.0]:
        _wall_z(list, x, -90.0, -84.0, [], "int")
    # Рубка (штурвал стоит в центре, у передней стены — приборы).
    _floor(-14.0, -118.0, 14.0, -106.0, Color(0.30, 0.20, 0.12))
    _add(list, 0.0, -115.0, 0.9, 0.9, 1.2, "helm")
    _furn(list, -3.0, -115.0, 0.8, 0.8, 1.3, "compass")
    _furn(list, 4.0, -115.0, 0.6, 0.6, 1.3, "telegraph")
    _furn(list, -4.0, -115.0, 0.6, 0.6, 1.3, "telegraph")
    _furn(list, -10.0, -114.5, 3.6, 1.6, 1.0, "chart")
    _furn(list, 9.0, -116.8, 4.0, 0.8, 1.1, "console")
    _furn(list, -9.0, -116.8, 4.0, 0.8, 1.1, "console")
    _window("x", -118.0, -9.0, 6.0)
    _window("x", -118.0, 0.0, 6.0)
    _window("x", -118.0, 9.0, 6.0)
    _window("z", -14.0, -108.0, 2.0)
    _window("z", 14.0, -108.0, 2.0)
    _window("z", -14.0, -116.0, 2.0)
    _window("z", 14.0, -116.0, 2.0)
    _lamp(-6.0, -112.0)
    _lamp(6.0, -112.0)
    _lamp(0.0, -108.0)
    _vent(10.0, -110.0)
    _label("РУБКА — ШТУРВАЛ", 0.0, 2.9, -112.0)
    # Капитанская каюта (запад) и радиорубка (восток).
    _floor(-14.0, -106.0, -6.0, -94.0, Color(0.38, 0.25, 0.14))
    _floor(6.0, -106.0, 14.0, -94.0, Color(0.20, 0.24, 0.28))
    _floor(-6.0, -106.0, 6.0, -94.0, Color(0.45, 0.10, 0.10))
    _furn(list, -12.6, -102.0, 2.2, 1.0, 0.7, "bed")
    _furn(list, -12.6, -97.0, 1.2, 2.4, 0.8, "table")
    _furn(list, -9.0, -105.4, 3.0, 0.6, 2.0, "wardrobe")
    _furn(list, 9.0, -105.2, 4.0, 0.8, 1.1, "console")
    _furn(list, 12.6, -98.0, 1.2, 3.0, 1.1, "console")
    _window("z", -14.0, -100.0, 1.6)
    _window("z", 14.0, -100.0, 1.6)
    _lamp(-10.0, -100.0)
    _lamp(10.0, -100.0)
    _lamp(0.0, -100.0)
    _vent(0.0, -98.0)
    _label("КАПИТАНСКАЯ КАЮТА", -10.0, 2.9, -100.0)
    _label("РАДИОРУБКА", 10.0, 2.9, -100.0)
    # Коридор и каюты офицеров.
    _floor(-14.0, -94.0, 14.0, -90.0, Color(0.45, 0.10, 0.10))
    _lamp(-8.0, -92.0)
    _lamp(0.0, -92.0)
    _lamp(8.0, -92.0)
    _vent(-6.0, -92.0)
    for cx in [-11.0, -4.0, 4.0, 11.0]:
        _floor(cx - 3.0, -90.0, cx + 3.0, -84.0, Color(0.38, 0.25, 0.14))
        _lamp(cx, -87.0)
    _furn(list, -12.6, -86.6, 2.0, 1.0, 0.7, "bed")
    _furn(list, -2.0, -86.6, 2.0, 1.0, 0.7, "bed")
    _furn(list, 6.0, -86.6, 2.0, 1.0, 0.7, "bed")
    _furn(list, 12.6, -86.6, 2.0, 1.0, 0.7, "bed")
    _label("КАЮТЫ ОФИЦЕРОВ", 0.0, 2.9, -92.0)


# ---- палубная надстройка: каюты по бокам, коридоры, центральные комнаты или большой зал

static func _cabin_block(list: Array, label: String, z0: float, z1: float, opts: Dictionary) -> void:
    _cur_b = _buildings.size()
    var hall: bool = opts.get("hall", false)
    var crew: bool = opts.get("crew", false)
    var funnel: String = opts.get("funnel", "")
    var rooms: Array = opts.get("rooms", ["lounge", "bath", "stairs"])
    _buildings.append({"name": label, "x0": -14.0, "x1": 14.0, "z0": z0, "z1": z1, "hall": hall, "funnel": funnel, "dome": bool(opts.get("dome", false)), "kind": "deckhouse"})
    var length := z1 - z0
    var count := int(round(length / 6.0))
    var cab_z: Array = []
    for k in range(count):
        cab_z.append(z0 + 3.0 + 6.0 * float(k))
    var ext_doors: Array = [cab_z[1], cab_z[count - 2]]
    _wall_z(list, -14.0, z0, z1, ext_doors, "ext")
    _wall_z(list, 14.0, z0, z1, ext_doors, "ext")
    var end_doors: Array = [-6.0, 0.0, 6.0]
    if hall:
        end_doors = [-4.0, 4.0]
    _wall_x(list, z0, -14.0, 14.0, end_doors, "ext")
    _wall_x(list, z1, -14.0, 14.0, end_doors, "ext")
    var cabin_wood := Color(0.38, 0.25, 0.14)
    if crew:
        cabin_wood = Color(0.28, 0.28, 0.30)
    for side in [-1.0, 1.0]:
        var s: float = side
        var xa := minf(8.0 * s, 14.0 * s)
        var xb := maxf(8.0 * s, 14.0 * s)
        for k in range(1, count):
            _wall_x(list, z0 + 6.0 * float(k), xa, xb, [], "int")
        _wall_z(list, 8.0 * s, z0, z1, cab_z, "int")
        for k in range(count):
            var zc: float = cab_z[k]
            _floor(xa, zc - 3.0, xb, zc + 3.0, cabin_wood)
            _furnish_cabin(list, s, zc, crew)
            if not ext_doors.has(zc):
                _window("z", 14.0 * s, zc, 1.8)
            _lamp(11.0 * s, zc)
    if not hall:
        var third := length / 3.0
        var room_mid: Array = [z0 + third * 0.5, z0 + third * 1.5, z0 + third * 2.5]
        for side in [-1.0, 1.0]:
            var s2: float = side
            _wall_z(list, 4.0 * s2, z0, z1, room_mid, "int")
            _floor(minf(4.0 * s2, 8.0 * s2), z0, maxf(4.0 * s2, 8.0 * s2), z1, Color(0.45, 0.10, 0.10))
            for k in range(count):
                _lamp(6.0 * s2, cab_z[k])
        _wall_x(list, z0 + third, -4.0, 4.0, [], "int")
        _wall_x(list, z0 + 2.0 * third, -4.0, 4.0, [], "int")
        for i in range(3):
            _furnish_room(list, str(rooms[i]), z0 + third * float(i), z0 + third * float(i + 1))
        _vent(6.0, z0 + 12.0)
        _vent(-6.0, z0 + 24.0)
    else:
        _floor(-8.0, z0, 8.0, z1, Color(0.42, 0.08, 0.10))
        if str(opts.get("hall_kind", "")) == "grand":
            for k in range(1, count):
                _furn(list, -4.0, z0 + 6.0 * float(k), 0.8, 0.8, WALL_H, "column")
                _furn(list, 4.0, z0 + 6.0 * float(k), 0.8, 0.8, WALL_H, "column")
            for i in range(5):
                _furn(list, 0.0, z0 + 3.0 + float(i), 6.0, 1.0, 0.3 * float(i + 1), "step")
            _label("ПАРАДНАЯ ЛЕСТНИЦА", 0.0, 3.0, z0 + 14.0)
        else:
            for row in [-2.0, 2.0]:
                for t in range(3):
                    _furn(list, row, z0 + 6.0 + 12.0 * float(t), 1.6, 8.0, 0.8, "dining")
            _label("ПЕРВАЯ СТОЛОВАЯ", 0.0, 3.0, z0 + 18.0)
        for k in range(count):
            _lamp(0.0, cab_z[k])
            _lamp(-6.0, cab_z[k])
            _lamp(6.0, cab_z[k])
        _vent(0.0, z0 + 18.0)
        _vent(6.0, z0 + 30.0)
        _vent(-6.0, z0 + 6.0)
    _label(label, 0.0, 3.2, z0 - 1.5)


static func _furnish_cabin(list: Array, s: float, zc: float, crew: bool) -> void:
    if crew:
        _furn(list, s * 12.5, zc - 1.6, 2.4, 1.1, 1.8, "bunk")
        _furn(list, s * 12.5, zc + 1.6, 2.4, 1.1, 1.8, "bunk")
    else:
        _furn(list, s * 12.75, zc - 1.6, 2.2, 1.0, 0.7, "bed")
        _furn(list, s * 13.55, zc + 1.7, 0.6, 1.2, 2.0, "wardrobe")
        _floor(minf(s * 9.5, s * 11.5), zc - 1.0, maxf(s * 9.5, s * 11.5), zc + 1.0, Color(0.50, 0.14, 0.12))


static func _furnish_room(list: Array, kind: String, za: float, zb: float) -> void:
    var zm := (za + zb) * 0.5
    match kind:
        "lounge":
            _floor(-4.0, za, 4.0, zb, Color(0.18, 0.26, 0.42))
            _furn(list, -3.0, zm, 0.9, 4.0, 0.9, "sofa")
            _furn(list, 3.0, zm, 0.9, 4.0, 0.9, "sofa")
            _furn(list, 0.0, zm, 1.8, 1.8, 0.7, "table")
            _lamp(0.0, zm)
        "bath":
            _floor(-4.0, za, 4.0, zb, Color(0.80, 0.82, 0.82))
            _furn(list, -3.4, za + 2.0, 1.2, 1.2, 1.0, "sink")
            _furn(list, 3.4, za + 2.0, 1.2, 1.2, 1.0, "sink")
            _furn(list, -3.4, zb - 2.0, 1.2, 1.2, 1.0, "sink")
            _furn(list, 3.4, zb - 2.0, 1.2, 1.2, 1.0, "sink")
            _lamp(0.0, zm)
        "stairs":
            _floor(-4.0, za, 4.0, zb, Color(0.25, 0.16, 0.10))
            for i in range(5):
                _furn(list, -2.0, za + 2.0 + float(i), 3.0, 1.0, 0.3 * float(i + 1), "step")
            _lamp(0.0, zm)
        "storage":
            _floor(-4.0, za, 4.0, zb, Color(0.22, 0.22, 0.22))
            _furn(list, -2.5, za + 2.5, 2.0, 2.0, 0.9, "crate")
            _furn(list, 2.5, zb - 2.5, 2.0, 2.0, 0.9, "crate")
            _furn(list, 2.8, za + 2.0, 1.4, 1.4, 0.9, "crate")
            _lamp(0.0, zm)
        _:
            _floor(-4.0, za, 4.0, zb, Color(0.30, 0.26, 0.20))
            _furn(list, -2.6, zm - 1.5, 2.4, 1.2, 0.8, "table")
            _furn(list, 2.6, zm + 1.5, 2.4, 1.2, 0.8, "table")
            _lamp(0.0, zm)


# ---- открытая палуба: нос, корма, шлюпки, ящики, краны, магазин, люки

static func _outdoor(list: Array) -> void:
    for z in [-100.0, -62.0, -22.0, 4.0, 30.0, 56.0, 82.0, 123.0]:
        _add(list, -21.0, z, 2.4, 7.0, 2.4, "boat")
        _add(list, 21.0, z, 2.4, 7.0, 2.4, "boat")
    # Нос: лебёдка, мачта, ящики.
    _add(list, 0.0, -170.0, 3.0, 3.0, 2.0, "winch")
    _add(list, 0.0, -160.0, 2.0, 2.0, 26.0, "mast")
    _crate_stack(list, -6.0, -164.0, 3.0, 3.0, 2, Vector2(1, 0))
    _crate_stack(list, 8.0, -152.0, 3.0, 3.0, 2, Vector2(-1, 0))
    _crate_stack(list, -10.0, -150.0, 3.0, 3.0, 2, Vector2(1, 0))
    _crate_stack(list, 12.0, -142.0, 3.0, 3.0, 2, Vector2(-1, 0))
    # Лёд, упавший на палубу при ударе об айсберг (правый борт).
    _add(list, 10.0, -2.0, 3.2, 3.2, 2.4, "ice")
    _add(list, 7.0, 4.0, 2.4, 2.4, 1.5, "ice")
    # Дворики между надстройками.
    _crate_stack(list, -9.0, 2.0, 3.0, 3.0, 2, Vector2(-1, 0))
    _crate_stack(list, -12.0, 8.0, 3.0, 3.0, 2, Vector2(1, 0))
    _add(list, 0.0, 56.0, 18.0, 5.0, 5.0, "fallen_funnel")
    # Корма: штабели грузов и краны.
    _crate_stack(list, -8.0, 150.0, 4.0, 4.0, 3, Vector2(1, 0))
    _crate_stack(list, 7.0, 146.0, 4.0, 4.0, 3, Vector2(-1, 0))
    _crate_stack(list, -2.0, 158.0, 6.0, 3.0, 2, Vector2(0, 1))
    _crate_stack(list, -12.0, 168.0, 4.0, 6.0, 3, Vector2(0, 1))
    _crate_stack(list, 10.0, 168.0, 5.0, 4.0, 3, Vector2(-1, 0))
    _crate_stack(list, 0.0, 172.0, 3.0, 3.0, 3, Vector2(-1, 0))
    _add(list, -14.0, 156.0, 2.0, 2.0, 14.0, "crane")
    _add(list, 14.0, 160.0, 2.0, 2.0, 14.0, "crane")
    for spot in SHOP_SPOTS:
        _add(list, spot.x, spot.y, 1.9, 3.5, 2.8, "shop")
    # Раструбы вентиляторов (декор около люков).
    for p in [Vector2(-13.0, -146.0), Vector2(13.0, -146.0), Vector2(-13.0, -4.0), Vector2(13.0, 10.0), Vector2(-14.0, 62.0), Vector2(14.0, 52.0), Vector2(-13.0, 104.0), Vector2(13.0, 144.0)]:
        _add(list, p.x, p.y, 0.8, 0.8, 1.8, "cowl")
    # Вентиляционные люки на открытой палубе.
    for p in [Vector2(-10.0, -158.0), Vector2(10.0, -158.0), Vector2(0.0, -146.0), Vector2(-16.0, -138.0), Vector2(16.0, -138.0),
            Vector2(-16.0, -100.0), Vector2(16.0, -100.0), Vector2(0.0, -82.0),
            Vector2(-16.0, -62.0), Vector2(16.0, -62.0), Vector2(0.0, -42.0),
            Vector2(-16.0, -22.0), Vector2(16.0, -22.0), Vector2(-6.0, 0.0), Vector2(6.0, 8.0),
            Vector2(-16.0, 30.0), Vector2(16.0, 30.0), Vector2(-12.0, 52.0), Vector2(12.0, 62.0),
            Vector2(-16.0, 82.0), Vector2(16.0, 82.0), Vector2(0.0, 104.0),
            Vector2(-16.0, 124.0), Vector2(16.0, 124.0), Vector2(0.0, 142.0),
            Vector2(-8.0, 146.0), Vector2(8.0, 154.0), Vector2(-8.0, 164.0), Vector2(6.0, 164.0)]:
        _vent(p.x, p.y)


# ------------------------------------------------------------------ публичные данные

## Точки появления игроков: площадка на носовой палубе.
static func player_spawns() -> Array:
    var points: Array = []
    for offset in [Vector2(-3.5, -3.0), Vector2(3.5, -3.0), Vector2(-3.5, 3.0), Vector2(3.5, 3.0), Vector2(0.0, -5.5), Vector2(0.0, 5.5)]:
        points.append(Vector3(SPAWN_CENTER.x + offset.x, 1.0, SPAWN_CENTER.z + offset.y))
    return points


static func player_spawn(index: int) -> Vector3:
    var points := player_spawns()
    return points[index % points.size()]


## Вентиляционные люки (центры, x/z).
static func vent_points() -> Array:
    _ensure_layout()
    return _vents


## Люки, из которых вылезают зомби (вентиляция), на уровне земли боя.
static func zombie_spawn_points() -> Array:
    var points: Array = []
    for raw in vent_points():
        var v: Vector2 = raw
        points.append(Vector3(v.x, GROUND_Y, v.y))
    return points


## Точки у прилавков магазинов.
static func shop_points() -> Array:
    var points: Array = []
    for spot in SHOP_SPOTS:
        var fx := -signf(spot.x)
        points.append(Vector3(spot.x + fx * 1.7, GROUND_Y, spot.y))
    return points


static func nearest_shop(pos: Vector3) -> int:
    var best := -1
    var best_d := SHOP_USE_RADIUS * SHOP_USE_RADIUS
    var points := shop_points()
    for i in range(points.size()):
        var p: Vector3 = points[i]
        var dx := p.x - pos.x
        var dz := p.z - pos.z
        var d := dx * dx + dz * dz
        if d <= best_d:
            best_d = d
            best = i
    return best


# ------------------------------------------------------------------ лучи, коллизии, навигация

static func _slab_hit(ob: Dictionary, a: Vector3, d: Vector3) -> float:
    var shrink := 0.12
    if str(ob["kind"]) == "wall":
        shrink = 0.05
    var rect: Rect2 = (ob["rect"] as Rect2).grow(-shrink)
    var lo := Vector3(rect.position.x, GROUND_Y, rect.position.y)
    var hi := Vector3(rect.end.x, GROUND_Y + float(ob["h"]), rect.end.y)
    var t_min := 0.0
    var t_max := 1.0
    for axis in range(3):
        var origin := a[axis]
        var dir := d[axis]
        if absf(dir) < 0.00001:
            if origin < lo[axis] or origin > hi[axis]:
                return -1.0
        else:
            var t1 := (lo[axis] - origin) / dir
            var t2 := (hi[axis] - origin) / dir
            t_min = maxf(t_min, minf(t1, t2))
            t_max = minf(t_max, maxf(t1, t2))
            if t_min > t_max:
                return -1.0
    return t_min


static func _segment_candidates(a: Vector3, b: Vector3) -> Array:
    var k0 := floori(minf(a.z, b.z) / BUCKET)
    var k1 := floori(maxf(a.z, b.z) / BUCKET)
    if k0 == k1:
        return _buckets.get(k0, [])
    var out: Array = []
    for k in range(k0, k1 + 1):
        out.append_array(_buckets.get(k, []))
    return out


## Пересекает ли отрезок a→b стену, мебель или постройку.
static func segment_blocked(a: Vector3, b: Vector3) -> bool:
    _ensure_layout()
    var d := b - a
    var min_x := minf(a.x, b.x) - 0.2
    var max_x := maxf(a.x, b.x) + 0.2
    for idx in _segment_candidates(a, b):
        var ob: Dictionary = _obstacles[int(idx)]
        var rect: Rect2 = ob["rect"]
        if rect.end.x < min_x or rect.position.x > max_x:
            continue
        if _slab_hit(ob, a, d) >= 0.0:
            return true
    return false


## Расстояние от origin вдоль dir до первой преграды (или max_dist). Стены держат пули.
static func ray_distance(origin: Vector3, dir: Vector3, max_dist: float) -> float:
    _ensure_layout()
    var d := dir.normalized() * max_dist
    var end := origin + d
    var min_x := minf(origin.x, end.x) - 0.2
    var max_x := maxf(origin.x, end.x) + 0.2
    var best_t := 2.0
    for idx in _segment_candidates(origin, end):
        var ob: Dictionary = _obstacles[int(idx)]
        var rect: Rect2 = ob["rect"]
        if rect.end.x < min_x or rect.position.x > max_x:
            continue
        var t := _slab_hit(ob, origin, d)
        if t >= 0.0 and t < best_t:
            best_t = t
    if best_t > 1.0:
        return max_dist
    return maxf(best_t * max_dist, 0.0)


static func nav_cell_free(x: float, z: float) -> bool:
    if z < BOW_Z + 4.0 or z > STERN_Z - 3.0:
        return false
    if absf(x) > half_width(z) - 1.6:
        return false
    _ensure_layout()
    var p := Vector2(x, z)
    for idx in _bucket(z):
        var ob: Dictionary = _obstacles[int(idx)]
        var rect: Rect2 = ob["rect"]
        if rect.grow(float(ob["g"])).has_point(p):
            return false
    return true


## Сетка A* для зомби. Возвращает {"grid": AStarGrid2D, "heights": Dictionary}.
static func build_navigation() -> Dictionary:
    _ensure_layout()
    var grid := AStarGrid2D.new()
    grid.region = Rect2i(0, 0, NAV_COLS, NAV_ROWS)
    grid.cell_size = Vector2.ONE
    grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
    grid.update()
    var heights := {}
    for cx in range(NAV_COLS):
        for cz in range(NAV_ROWS):
            var point := Vector2i(cx, cz)
            var wx := NAV_LEFT + float(cx) * NAV_CELL
            var wz := NAV_TOP + float(cz) * NAV_CELL
            if nav_cell_free(wx, wz):
                heights[point] = GROUND_Y
            else:
                grid.set_point_solid(point)
    return {"grid": grid, "heights": heights}


## Над палубой ли точка (x, z): внутри контура корабля.
static func on_deck(x: float, z: float) -> bool:
    return z > BOW_Z and z < STERN_Z and absf(x) <= half_width(z)


## Высота пола под игроком (мировая y): верх ящика, палуба или -1000 над водой.
## Верх ящика считается полом, если ступня не ниже его верха больше чем на STEP_UP.
static func floor_height(x: float, z: float, feet_y: float) -> float:
    _ensure_layout()
    var best := -1000.0
    if on_deck(x, z) and feet_y >= GROUND_Y - 0.5:
        best = GROUND_Y
    var p := Vector2(x, z)
    for idx in _bucket(z):
        var ob: Dictionary = _obstacles[int(idx)]
        if not bool(ob["stand"]):
            continue
        var rect: Rect2 = ob["rect"]
        if not rect.grow(0.2).has_point(p):
            continue
        var top := GROUND_Y + float(ob["h"])
        if feet_y >= top - STEP_UP and top > best:
            best = top
    best = maxf(best, _ice_floor(x, z, feet_y))
    return best


## Игрок коснулся воды (ступня ниже поверхности).
static func touches_water(pos: Vector3) -> bool:
    return pos.y <= WATER_TOUCH_Y


## Выталкивает игрока из стен, мебели и построек. Верх ящиков не выталкивает (на них стоят).
## Невидимой стены у борта больше нет: можно выйти за ограждение и упасть в воду.
static func resolve_player(pos: Vector3) -> Vector3:
    _ensure_layout()
    var p := Vector2(pos.x, pos.z)
    for idx in _bucket(p.y):
        var ob: Dictionary = _obstacles[int(idx)]
        var rect: Rect2 = ob["rect"]
        if bool(ob["stand"]) and pos.y >= GROUND_Y + float(ob["h"]) - STEP_UP:
            continue   # игрок стоит выше верха ящика
        var nearest := Vector2(clampf(p.x, rect.position.x, rect.end.x), clampf(p.y, rect.position.y, rect.end.y))
        var delta := p - nearest
        var dist := delta.length()
        if dist >= PLAYER_RADIUS:
            continue
        if dist > 0.0001:
            p += delta / dist * (PLAYER_RADIUS - dist)
        else:
            var to_left := p.x - rect.position.x
            var to_right := rect.end.x - p.x
            var to_top := p.y - rect.position.y
            var to_bottom := rect.end.y - p.y
            var best := minf(minf(to_left, to_right), minf(to_top, to_bottom))
            if best == to_left:
                p.x = rect.position.x - PLAYER_RADIUS
            elif best == to_right:
                p.x = rect.end.x + PLAYER_RADIUS
            elif best == to_top:
                p.y = rect.position.y - PLAYER_RADIUS
            else:
                p.y = rect.end.y + PLAYER_RADIUS
    # Stage123: айсберги — твёрдые, пока ступня ниже верха блока.
    for blk in _ice:
        var ir: Rect2 = blk["rect"]
        ir.position.y += float(_ice_dz[int(blk["berg"])])
        if pos.y >= GROUND_Y + float(blk["h"]) - STEP_UP:
            continue
        var inearest := Vector2(clampf(p.x, ir.position.x, ir.end.x), clampf(p.y, ir.position.y, ir.end.y))
        var idelta := p - inearest
        var idist := idelta.length()
        if idist >= PLAYER_RADIUS:
            continue
        if idist > 0.0001:
            p += idelta / idist * (PLAYER_RADIUS - idist)
        else:
            p.x = ir.position.x - PLAYER_RADIUS if p.x < ir.get_center().x else ir.end.x + PLAYER_RADIUS
    return Vector3(p.x, pos.y, p.y)


## Вентиляционный люк рядом с pos открывается (клиентская анимация при появлении зомби).
static func open_vent(root: Node3D, pos: Vector3) -> void:
    if root == null:
        return
    var holder := root.get_node_or_null("Vents")
    if holder == null:
        return
    var best: Node3D = null
    var best_d := 6.25
    for child in holder.get_children():
        var node := child as Node3D
        if node == null:
            continue
        var d := Vector2(node.position.x - pos.x, node.position.z - pos.z).length_squared()
        if d < best_d:
            best_d = d
            best = node
    if best == null:
        return
    var hinge := best.get_node_or_null("Hinge") as Node3D
    if hinge == null:
        return
    if best.has_meta("tween"):
        var old = best.get_meta("tween")
        if old is Tween and (old as Tween).is_valid():
            (old as Tween).kill()
    var tween := hinge.create_tween()
    best.set_meta("tween", tween)
    tween.tween_property(hinge, "rotation:x", -1.75, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tween.tween_interval(2.2)
    tween.tween_property(hinge, "rotation:x", 0.0, 0.5)


# ------------------------------------------------------------------ построение сцены

static func build(world: Node3D) -> Node3D:
    _ensure_layout()
    var root := Node3D.new()
    root.name = "TitanicMap"
    root.position.y = GROUND_Y
    world.add_child(root)
    _build_environment(root, world)
    _build_water(root)
    _build_hull(root)
    _build_rails(root)
    _build_structures(root)
    _build_labels(root)
    _build_deck_props(root)
    _build_vents(root)
    _build_spawn_markers(root)
    _build_helm(root)
    _build_shops(root)
    _build_iceberg(root)
    return root


static func _glow_box(kit: Object, size: Vector3, pos: Vector3, tint: Color) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    kit.add_mesh(mesh, Transform3D(Basis.IDENTITY, pos), Kit.glow_material(tint))


static func _add_instance(root: Node3D, mesh: Mesh, label: String) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.name = label
    instance.mesh = mesh
    root.add_child(instance)
    return instance


static func _build_environment(root: Node3D, world: Node3D) -> void:
    var sky_material := ProceduralSkyMaterial.new()
    sky_material.sky_top_color = Color(0.015, 0.03, 0.08)
    sky_material.sky_horizon_color = Color(0.09, 0.13, 0.21)
    sky_material.ground_horizon_color = Color(0.09, 0.13, 0.21)
    sky_material.ground_bottom_color = Color(0.03, 0.05, 0.09)
    var sky := Sky.new()
    sky.sky_material = sky_material
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.40, 0.46, 0.64)
    env.ambient_light_energy = 1.1   # чуть светлее, чтобы были видны каюты внутри
    env.fog_enabled = true
    env.fog_light_color = Color(0.09, 0.13, 0.2)
    env.fog_density = 0.011
    env.fog_sky_affect = 0.0
    var world_env := WorldEnvironment.new()
    world_env.name = "NightEnvironment"
    world_env.environment = env
    root.add_child(world_env)

    var moon_dir := Vector3(-300.0, 210.0, -520.0)
    var sun := world.get_node_or_null("Sun") as DirectionalLight3D
    if sun != null:
        sun.basis = Basis.looking_at(-moon_dir.normalized(), Vector3.UP)
        sun.light_color = Color(0.62, 0.72, 1.0)
        sun.light_energy = 0.75
        sun.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY
    var moon_material := StandardMaterial3D.new()
    moon_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    moon_material.albedo_color = Color(0.93, 0.95, 1.0)
    moon_material.disable_fog = true
    var moon_mesh := SphereMesh.new()
    moon_mesh.radius = 16.0
    moon_mesh.height = 32.0
    moon_mesh.radial_segments = 16
    moon_mesh.rings = 8
    var moon := _add_instance(root, moon_mesh, "Moon")
    moon.material_override = moon_material
    moon.position = moon_dir.normalized() * 1800.0
    moon.scale = Vector3.ONE * 4.0

    var star_mesh := BoxMesh.new()
    star_mesh.size = Vector3(5.0, 5.0, 5.0)
    var star_material := StandardMaterial3D.new()
    star_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    star_material.albedo_color = Color(1, 1, 1)
    star_material.disable_fog = true
    star_mesh.material = star_material
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    multi.mesh = star_mesh
    multi.instance_count = 260
    var rng := RandomNumberGenerator.new()
    rng.seed = 8080
    for i in range(multi.instance_count):
        var dir := Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(0.12, 1.0), rng.randf_range(-1.0, 1.0)).normalized()
        multi.set_instance_transform(i, Transform3D(Basis.IDENTITY, dir * 2500.0))
    var stars := MultiMeshInstance3D.new()
    stars.name = "Stars"
    stars.multimesh = multi
    root.add_child(stars)


static func _build_water(root: Node3D) -> void:
    var plane := PlaneMesh.new()
    plane.size = Vector2(2400.0, 2400.0)
    var water := _add_instance(root, plane, "Water")
    water.position = Vector3(0.0, WATER_Y, 0.0)
    # Stage122: корабль идёт вперёд (к -Z), поэтому узор воды и пена скользят назад вдоль борта (к +Z).
    var shader := Shader.new()
    shader.code = """shader_type spatial;
uniform vec3 deep_color : source_color = vec3(0.015, 0.06, 0.11);
uniform vec3 foam_color : source_color = vec3(0.62, 0.74, 0.84);
uniform float speed = 9.0;
varying vec3 wpos;
void vertex() {
    wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
float hull_half(float z) {
    if (z < -130.0) {
        return 24.0 * pow(clamp((z + 180.0) / 50.0, 0.0, 1.0), 0.65);
    }
    if (z > 150.0) {
        return 24.0 * (1.0 - 0.28 * clamp((z - 150.0) / 30.0, 0.0, 1.0));
    }
    return 24.0;
}
void fragment() {
    vec2 q = vec2(wpos.x, wpos.z - TIME * speed);
    float a = sin(q.x * 0.55 + sin(q.y * 0.11) * 2.2) * sin(q.y * 0.42 + q.x * 0.17);
    float b = sin(q.x * 1.3 - q.y * 0.23) * sin(q.y * 0.9 + sin(q.x * 0.4) * 1.5);
    float ripple = smoothstep(0.55, 1.0, a * 0.6 + b * 0.4);
    float away = abs(wpos.x) - hull_half(wpos.z);
    float near_hull = (1.0 - smoothstep(0.0, 9.0, away)) * step(-0.5, away);
    float streak = smoothstep(0.1, 0.9, sin(q.y * 0.9 + wpos.x * 0.35) * 0.5 + 0.5);
    float foam = clamp(ripple * 0.22 + near_hull * (0.30 + 0.55 * streak), 0.0, 0.95);
    ALBEDO = mix(deep_color, foam_color, foam);
    ROUGHNESS = mix(0.22, 0.7, foam);
    METALLIC = mix(0.55, 0.0, foam);
}
"""
    var material := ShaderMaterial.new()
    material.shader = shader
    material.set_shader_parameter("speed", SHIP_SPEED)
    water.material_override = material
    var tween := water.create_tween().set_loops()
    tween.tween_property(water, "position:y", WATER_Y + 0.35, 2.6).set_trans(Tween.TRANS_SINE)
    tween.tween_property(water, "position:y", WATER_Y - 0.1, 2.6).set_trans(Tween.TRANS_SINE)


# ------------------------------------------------------------------ Stage123: айсберги с коллизией
# Два «ступенчатых» айсберга (слева и справа от корабля) проплывают мимо назад со скоростью корабля.
# Нижняя ступень ниже верха ящика у борта: можно запрыгнуть с палубы, подняться по ступеням (шаг 0.9 м) и стоять.
# Стоящего на льду игрока айсберг несёт назад (on_ice), поэтому надо вовремя спрыгнуть обратно на корабль.
const ICE_BERGS := [
    {"side": 1.0, "start_z": 0.0},      # правый борт, проходит у середины корабля сразу
    {"side": -1.0, "start_z": -260.0}]  # левый борт, подходит позже

static func _ice_tiers() -> Array:
    # [x_от_борта_внутр, x_до, z_от, z_до, h]  (x для правого борта; для левого зеркально)
    return [[27.0, 45.0, -37.0, -3.0, 0.6],
        [31.0, 49.0, -33.0, -7.0, 1.5],
        [35.0, 53.0, -29.0, -11.0, 2.4],
        [39.0, 56.0, -26.0, -14.0, 3.3],
        [43.0, 58.0, -24.0, -16.0, 4.2],
        [47.0, 56.0, -22.0, -18.0, 9.0]]


static func _make_ice_data() -> void:
    _ice.clear()
    for b in range(ICE_BERGS.size()):
        var side: float = ICE_BERGS[b]["side"]
        for t in _ice_tiers():
            var x0: float = t[0]
            var x1: float = t[1]
            var rx0 := minf(x0 * side, x1 * side)
            var rx1 := maxf(x0 * side, x1 * side)
            _ice.append({"berg": b, "rect": Rect2(rx0, float(t[2]), rx1 - rx0, float(t[3]) - float(t[2])), "h": float(t[4])})


static func _ice_floor(x: float, z: float, feet_y: float) -> float:
    var best := -1000.0
    for blk in _ice:
        var r: Rect2 = blk["rect"]
        r.position.y += float(_ice_dz[int(blk["berg"])])
        if not r.grow(0.2).has_point(Vector2(x, z)):
            continue
        var top := GROUND_Y + float(blk["h"])
        if feet_y >= top - STEP_UP and top > best:
            best = top
    return best


## Стоит ли игрок на айсберге (тогда его несёт назад вместе с ним).
static func on_ice(pos: Vector3) -> bool:
    _ensure_layout()
    var top := _ice_floor(pos.x, pos.z, pos.y)
    return top > -500.0 and pos.y <= top + 0.03


static func _set_ice_z(v: float, holder: Node3D, index: int) -> void:
    holder.position.z = v
    _ice_dz[index] = v


static func _restart_drift(holder: Node3D, index: int) -> void:
    _set_ice_z(-520.0, holder, index)
    _drift(holder, index)


# Айсберг плывёт назад (к +Z) со скоростью корабля, у кормы исчезает и снова появляется далеко впереди.
static func _drift(holder: Node3D, index: int) -> void:
    var tween := holder.create_tween()
    var from_z := holder.position.z
    tween.tween_method(_set_ice_z.bind(holder, index), from_z, 520.0, maxf((520.0 - from_z) / SHIP_SPEED, 0.1))
    tween.tween_callback(_restart_drift.bind(holder, index))


## Брызги при падении в воду: столб капель, расходящееся кольцо и пена. pos — на поверхности воды (в системе карты).
static func splash(root: Node3D, pos: Vector3) -> void:
    if root == null or not is_instance_valid(root):
        return
    var holder := Node3D.new()
    holder.name = "Splash"
    holder.position = pos
    root.add_child(holder)
    var drops := CPUParticles3D.new()
    drops.amount = 70
    drops.lifetime = 1.3
    drops.one_shot = true
    drops.explosiveness = 0.95
    drops.direction = Vector3.UP
    drops.spread = 40.0
    drops.initial_velocity_min = 5.0
    drops.initial_velocity_max = 10.0
    drops.gravity = Vector3(0.0, -16.0, 0.0)
    drops.scale_amount_min = 0.5
    drops.scale_amount_max = 1.3
    var drop_mesh := SphereMesh.new()
    drop_mesh.radius = 0.16
    drop_mesh.height = 0.32
    drop_mesh.radial_segments = 6
    drop_mesh.rings = 3
    var drop_material := StandardMaterial3D.new()
    drop_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    drop_material.albedo_color = Color(0.82, 0.92, 1.0, 0.9)
    drop_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    drop_mesh.material = drop_material
    drops.mesh = drop_mesh
    holder.add_child(drops)
    drops.emitting = true
    var foam := CPUParticles3D.new()
    foam.amount = 40
    foam.lifetime = 1.8
    foam.one_shot = true
    foam.explosiveness = 1.0
    foam.direction = Vector3.UP
    foam.spread = 88.0
    foam.initial_velocity_min = 2.0
    foam.initial_velocity_max = 4.5
    foam.gravity = Vector3(0.0, -3.0, 0.0)
    foam.scale_amount_min = 1.2
    foam.scale_amount_max = 2.6
    var foam_mesh := SphereMesh.new()
    foam_mesh.radius = 0.2
    foam_mesh.height = 0.2
    foam_mesh.radial_segments = 6
    foam_mesh.rings = 2
    var foam_material := StandardMaterial3D.new()
    foam_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    foam_material.albedo_color = Color(0.7, 0.84, 0.95, 0.65)
    foam_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    foam_mesh.material = foam_material
    foam.mesh = foam_mesh
    holder.add_child(foam)
    foam.emitting = true
    var ring := MeshInstance3D.new()
    var torus := TorusMesh.new()
    torus.inner_radius = 0.8
    torus.outer_radius = 1.0
    ring.mesh = torus
    ring.scale = Vector3(0.4, 0.06, 0.4)
    var ring_material := StandardMaterial3D.new()
    ring_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    ring_material.albedo_color = Color(0.85, 0.94, 1.0, 0.85)
    ring_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    ring.material_override = ring_material
    holder.add_child(ring)
    var tween := holder.create_tween()
    tween.set_parallel(true)
    tween.tween_property(ring, "scale", Vector3(5.5, 0.06, 5.5), 1.1).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tween.tween_property(ring_material, "albedo_color:a", 0.0, 1.1)
    tween.chain().tween_interval(1.0)
    tween.chain().tween_callback(holder.queue_free)


static func _vertex(st: SurfaceTool, p: Vector3, n: Vector3, uv: Vector2) -> void:
    st.set_normal(n)
    st.set_uv(uv)
    st.add_vertex(p)


static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, n: Vector3, uva: Vector2 = Vector2.ZERO, uvb: Vector2 = Vector2.ZERO, uvc: Vector2 = Vector2.ZERO) -> void:
    var face := (b - a).cross(c - a)
    if face.dot(n) > 0.0:
        _vertex(st, a, n, uva)
        _vertex(st, c, n, uvc)
        _vertex(st, b, n, uvb)
    else:
        _vertex(st, a, n, uva)
        _vertex(st, b, n, uvb)
        _vertex(st, c, n, uvc)


static func _deck_texture() -> ImageTexture:
    var image := Image.create(32, 32, false, Image.FORMAT_RGBA8)
    for x in range(32):
        var plank := x / 8
        var tone := 0.80 + 0.10 * float((plank * 37 + 11) % 5) / 4.0
        for y in range(32):
            var shade := tone
            if x % 8 == 0:
                shade = tone * 0.45
            elif (y + plank * 9) % 32 == 0:
                shade = tone * 0.6
            image.set_pixel(x, y, Color(0.50 * shade, 0.37 * shade, 0.23 * shade, 1.0))
    image.generate_mipmaps()
    return ImageTexture.create_from_image(image)


static func _build_hull(root: Node3D) -> void:
    var deck := SurfaceTool.new()
    deck.begin(Mesh.PRIMITIVE_TRIANGLES)
    var hull_black := SurfaceTool.new()
    hull_black.begin(Mesh.PRIMITIVE_TRIANGLES)
    var hull_red := SurfaceTool.new()
    hull_red.begin(Mesh.PRIMITIVE_TRIANGLES)
    var z := BOW_Z
    var step := 2.0
    while z < STERN_Z - 0.01:
        var z1 := z + step
        var w0 := half_width(z)
        var w1 := half_width(z1)
        var l0 := Vector3(-w0, 0.0, z)
        var r0 := Vector3(w0, 0.0, z)
        var l1 := Vector3(-w1, 0.0, z1)
        var r1 := Vector3(w1, 0.0, z1)
        var up := Vector3.UP
        _tri(deck, l0, r0, r1, up, Vector2(-w0 / 3.0, z / 3.0), Vector2(w0 / 3.0, z / 3.0), Vector2(w1 / 3.0, z1 / 3.0))
        _tri(deck, l0, r1, l1, up, Vector2(-w0 / 3.0, z / 3.0), Vector2(w1 / 3.0, z1 / 3.0), Vector2(-w1 / 3.0, z1 / 3.0))
        for side in [-1.0, 1.0]:
            var a0 := Vector3(side * w0, 0.0, z)
            var a1 := Vector3(side * w1, 0.0, z1)
            var b0 := Vector3(side * w0 * 0.9, -4.0, z)
            var b1 := Vector3(side * w1 * 0.9, -4.0, z1)
            var c0 := Vector3(side * w0 * 0.7, -10.0, z)
            var c1 := Vector3(side * w1 * 0.7, -10.0, z1)
            var n1 := Vector3(side, 0.15, 0.0).normalized()
            var n2 := Vector3(side, -0.2, 0.0).normalized()
            _tri(hull_black, a0, a1, b1, n1)
            _tri(hull_black, a0, b1, b0, n1)
            _tri(hull_red, b0, b1, c1, n2)
            _tri(hull_red, b0, c1, c0, n2)
        z = z1
    var sw := half_width(STERN_Z)
    _tri(hull_black, Vector3(-sw, 0, STERN_Z), Vector3(sw, 0, STERN_Z), Vector3(sw * 0.9, -4, STERN_Z), Vector3(0, 0, 1))
    _tri(hull_black, Vector3(-sw, 0, STERN_Z), Vector3(sw * 0.9, -4, STERN_Z), Vector3(-sw * 0.9, -4, STERN_Z), Vector3(0, 0, 1))
    _tri(hull_red, Vector3(-sw * 0.9, -4, STERN_Z), Vector3(sw * 0.9, -4, STERN_Z), Vector3(sw * 0.7, -10, STERN_Z), Vector3(0, 0, 1))
    _tri(hull_red, Vector3(-sw * 0.9, -4, STERN_Z), Vector3(sw * 0.7, -10, STERN_Z), Vector3(-sw * 0.7, -10, STERN_Z), Vector3(0, 0, 1))

    var deck_material := StandardMaterial3D.new()
    deck_material.albedo_texture = _deck_texture()
    deck_material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    deck_material.roughness = 0.9
    deck_material.cull_mode = BaseMaterial3D.CULL_DISABLED
    deck.set_material(deck_material)
    var black_material := StandardMaterial3D.new()
    black_material.albedo_color = Color(0.04, 0.04, 0.05)
    black_material.roughness = 0.5
    black_material.cull_mode = BaseMaterial3D.CULL_DISABLED
    hull_black.set_material(black_material)
    var red_material := StandardMaterial3D.new()
    red_material.albedo_color = Color(0.35, 0.05, 0.04)
    red_material.roughness = 0.6
    red_material.cull_mode = BaseMaterial3D.CULL_DISABLED
    hull_red.set_material(red_material)
    var mesh := ArrayMesh.new()
    deck.commit(mesh)
    hull_black.commit(mesh)
    hull_red.commit(mesh)
    _add_instance(root, mesh, "ShipHull")

    var flood := BoxMesh.new()
    flood.size = Vector3(12.0, 0.12, 14.0)
    var flood_instance := _add_instance(root, flood, "BowFlood")
    flood_instance.position = Vector3(0.0, 0.07, -170.0)
    var flood_material := StandardMaterial3D.new()
    flood_material.albedo_color = Color(0.05, 0.15, 0.25, 0.55)
    flood_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    flood_material.metallic = 0.4
    flood_material.roughness = 0.2
    flood_instance.material_override = flood_material


static func _build_rails(root: Node3D) -> void:
    var kit := Kit.new()
    var rail := Color(0.88, 0.88, 0.84)
    var z := BOW_Z
    var index := 0
    while z < STERN_Z - 0.01:
        var step := 4.0
        if z < -128.0 or z > 147.9:
            step = 2.0
        var z1 := z + step
        for side in [-1.0, 1.0]:
            var inset := 0.25
            var a := Vector2(side * (half_width(z) - inset), z)
            var b := Vector2(side * (half_width(z1) - inset), z1)
            var delta := b - a
            var length := delta.length()
            if length < 0.05:
                continue
            var mid := (a + b) * 0.5
            var yaw := rad_to_deg(atan2(delta.x, delta.y))
            kit.box(Vector3(0.07, 0.07, length + 0.04), Vector3(mid.x, 1.1, mid.y), rail, Vector3(0, yaw, 0), 0.2, 0.6)
            kit.box(Vector3(0.05, 0.05, length + 0.04), Vector3(mid.x, 0.6, mid.y), rail, Vector3(0, yaw, 0), 0.2, 0.6)
            kit.box(Vector3(0.09, 1.1, 0.09), Vector3(a.x, 0.55, a.y), rail, Vector3.ZERO, 0.2, 0.6)
        z = z1
        index += 1
    var sw := half_width(STERN_Z) - 0.25
    kit.box(Vector3(sw * 2.0, 0.07, 0.07), Vector3(0, 1.1, STERN_Z - 0.25), rail)
    kit.box(Vector3(sw * 2.0, 0.05, 0.05), Vector3(0, 0.6, STERN_Z - 0.25), rail)
    var holder := Node3D.new()
    holder.name = "Rails"
    root.add_child(holder)
    kit.commit(holder)


static func _smoke(root: Node3D, pos: Vector3, fire: bool) -> void:
    var particles := CPUParticles3D.new()
    particles.name = "FireGlow" if fire else "Smoke"
    particles.position = pos
    particles.amount = 10 if fire else 14
    particles.lifetime = 2.0 if fire else 6.0
    particles.direction = Vector3.UP
    particles.spread = 18.0
    particles.gravity = Vector3(0.3, 0.4, 3.2)   # дым сносит назад: корабль идёт вперёд
    particles.initial_velocity_min = 1.5
    particles.initial_velocity_max = 3.0
    particles.scale_amount_min = 0.7
    particles.scale_amount_max = 1.8 if fire else 3.2
    var mesh := SphereMesh.new()
    mesh.radius = 0.6
    mesh.height = 1.2
    mesh.radial_segments = 6
    mesh.rings = 3
    var material := StandardMaterial3D.new()
    if fire:
        material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        material.albedo_color = Color(1.0, 0.45, 0.1, 0.8)
    else:
        material.albedo_color = Color(0.12, 0.12, 0.13, 0.55)
    material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mesh.material = material
    particles.mesh = mesh
    root.add_child(particles)


# Каждая надстройка и открытая палуба — отдельная сетка (работает отсечение по камере).
static func _build_structures(root: Node3D) -> void:
    var kits := {}
    for ob in obstacles():
        var o: Dictionary = ob
        var key: int = o["b"]
        if not kits.has(key):
            kits[key] = Kit.new()
        _draw_obstacle(kits[key], root, o)
    for i in range(_buildings.size()):
        if not kits.has(i):
            kits[i] = Kit.new()
        _draw_shell(kits[i], root, i)
    for key in kits.keys():
        var holder := Node3D.new()
        holder.name = "Outdoor" if int(key) < 0 else "Building_%d" % int(key)
        root.add_child(holder)
        (kits[key] as Object).call("commit", holder)
    # Тёплый свет в рубке.
    for p in [Vector3(0.0, 3.0, -112.0), Vector3(-9.0, 3.0, -112.0), Vector3(9.0, 3.0, -112.0)]:
        var lamp := OmniLight3D.new()
        lamp.position = p
        lamp.omni_range = 11.0
        lamp.light_energy = 0.9
        lamp.light_color = Color(1.0, 0.8, 0.5)
        lamp.shadow_enabled = false
        root.add_child(lamp)


static func _draw_obstacle(kit: Object, root: Node3D, ob: Dictionary) -> void:
    var kind: String = ob["kind"]
    var style: String = ob["style"]
    var cx: float = ob["cx"]
    var cz: float = ob["cz"]
    var w: float = ob["w"]
    var d: float = ob["d"]
    var h: float = ob["h"]
    var black := Color(0.05, 0.05, 0.06)
    match kind:
        "wall":
            var tint := Color(0.80, 0.80, 0.76) if style == "ext" else Color(0.68, 0.54, 0.38)
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), tint, Vector3.ZERO, 0.1, 0.85)
            # плинтус
            kit.box(Vector3(w + 0.04, 0.18, d + 0.04), Vector3(cx, 0.09, cz), Color(0.22, 0.15, 0.09))
        "furn":
            _draw_furn(kit, style, cx, cz, w, d, h)
        "cowl":
            kit.cyl_y(0.28, 0.28, 1.3, Vector3(cx, 0.65, cz), Color(0.80, 0.25, 0.12), 8, 0.2, 0.7)
            kit.cyl_y(0.65, 0.3, 0.9, Vector3(cx, 1.5, cz), Color(0.12, 0.12, 0.13), 10, 0.2, 0.7, Vector3(65, 0, 0))
        "boat":
            var side := signf(cx)
            kit.capsule(1.05, 7.0, Vector3(cx, 1.45, cz), Color(0.93, 0.92, 0.88), Vector3(90, 0, 0), 0.0, 0.8)
            kit.box(Vector3(1.4, 0.15, 5.4), Vector3(cx, 2.2, cz), Color(0.45, 0.30, 0.16))
            kit.box(Vector3(0.12, 1.2, 0.12), Vector3(cx - side * 0.3, 0.6, cz - 2.0), black)
            kit.box(Vector3(0.12, 1.2, 0.12), Vector3(cx - side * 0.3, 0.6, cz + 2.0), black)
        "crate":
            var tint2 := Color(0.42, 0.28, 0.15).lerp(Color(0.30, 0.34, 0.22), fposmod(cx * 0.37 + cz * 0.11, 1.0))
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), tint2, Vector3.ZERO, 0.0, 0.9)
            kit.box(Vector3(w + 0.08, 0.18, d + 0.08), Vector3(cx, h * 0.25, cz), Color(0.18, 0.12, 0.07))
            kit.box(Vector3(w + 0.08, 0.18, d + 0.08), Vector3(cx, h * 0.75, cz), Color(0.18, 0.12, 0.07))
        "ice":
            kit.cyl_y(w * 0.6, 0.15, h * 1.4, Vector3(cx, h * 0.55, cz), Color(0.78, 0.92, 1.0), 5, 0.1, 0.25, Vector3(6, cx * 37.0, 4))
        "winch":
            kit.cyl_y(1.3, 1.3, 1.4, Vector3(cx, 0.9, cz), Color(0.2, 0.22, 0.24), 10)
            kit.box(Vector3(2.8, 0.8, 2.8), Vector3(cx, 0.4, cz), Color(0.15, 0.16, 0.18))
        "mast":
            kit.cyl_y(0.5, 0.3, 26.0, Vector3(cx, 13.0, cz), Color(0.35, 0.28, 0.2), 8)
            kit.box(Vector3(8.0, 0.3, 0.3), Vector3(cx, 21.0, cz), Color(0.35, 0.28, 0.2))
            kit.cyl_y(1.0, 1.0, 1.2, Vector3(cx, 17.0, cz), Color(0.3, 0.22, 0.14), 10)
        "crane":
            kit.cyl_y(0.5, 0.4, 14.0, Vector3(cx, 7.0, cz), Color(0.25, 0.28, 0.3), 8)
            kit.box(Vector3(0.35, 0.35, 12.0), Vector3(cx, 13.4, cz + 4.5), Color(0.25, 0.28, 0.3), Vector3(-12, 0, 0))
            kit.box(Vector3(0.05, 8.0, 0.05), Vector3(cx, 9.4, cz + 10.0), black)
        "fallen_funnel":
            var buff := Color(0.84, 0.52, 0.14)
            kit.cyl_x(2.6, 3.0, w, Vector3(cx, 2.6, cz), buff, 14, 0.2, 0.7)
            kit.cyl_x(2.62, 2.62, 2.4, Vector3(cx - w * 0.5 + 1.2, 2.6, cz), black, 14, 0.2, 0.7)
            _glow_box(kit, Vector3(0.05, 4.4, 4.4), Vector3(cx + w * 0.5 + 0.02, 2.6, cz), Color(1.0, 0.45, 0.1))
        _:
            pass   # "helm" и "shop" строятся отдельно


static func _draw_furn(kit: Object, style: String, cx: float, cz: float, w: float, d: float, h: float) -> void:
    var out := signf(cx)   # в какую сторону «наружу» (к борту)
    match style:
        "bed":
            kit.box(Vector3(w, 0.35, d), Vector3(cx, 0.3, cz), Color(0.40, 0.26, 0.14), Vector3.ZERO, 0.0, 0.8)
            kit.box(Vector3(w - 0.1, 0.22, d - 0.1), Vector3(cx, 0.55, cz), Color(0.88, 0.88, 0.84), Vector3.ZERO, 0.0, 0.9)
            kit.box(Vector3(0.5, 0.12, d - 0.2), Vector3(cx + out * (w * 0.5 - 0.35), 0.72, cz), Color(0.95, 0.95, 0.92), Vector3.ZERO, 0.0, 0.9)
            kit.box(Vector3(w * 0.55, 0.06, d - 0.08), Vector3(cx - out * 0.3, 0.68, cz), Color(0.35, 0.12, 0.12), Vector3.ZERO, 0.0, 0.9)
        "bunk":
            for level in range(2):
                var y := 0.4 + 0.8 * float(level)
                kit.box(Vector3(w, 0.1, d), Vector3(cx, y, cz), Color(0.35, 0.36, 0.38), Vector3.ZERO, 0.5, 0.5)
                kit.box(Vector3(w - 0.1, 0.14, d - 0.1), Vector3(cx, y + 0.12, cz), Color(0.45, 0.50, 0.40), Vector3.ZERO, 0.0, 0.9)
            for corner in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
                kit.box(Vector3(0.06, h, 0.06), Vector3(cx + corner.x * (w * 0.5 - 0.03), h * 0.5, cz + corner.y * (d * 0.5 - 0.03)), Color(0.35, 0.36, 0.38), Vector3.ZERO, 0.5, 0.5)
        "wardrobe":
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), Color(0.32, 0.20, 0.11), Vector3.ZERO, 0.0, 0.8)
            kit.box(Vector3(w + 0.03, h - 0.3, 0.04), Vector3(cx, h * 0.5, cz), Color(0.18, 0.11, 0.06))
        "sofa":
            kit.box(Vector3(w, 0.5, d), Vector3(cx, 0.25, cz), Color(0.45, 0.12, 0.14), Vector3.ZERO, 0.0, 0.9)
            kit.box(Vector3(0.25, 0.6, d), Vector3(cx + out * (w * 0.5 - 0.12), 0.75, cz), Color(0.40, 0.10, 0.12), Vector3.ZERO, 0.0, 0.9)
        "table", "dining":
            kit.box(Vector3(w, 0.08, d), Vector3(cx, h - 0.04, cz), Color(0.45, 0.30, 0.16), Vector3.ZERO, 0.1, 0.7)
            if style == "dining":
                kit.box(Vector3(w - 0.2, 0.02, d - 0.2), Vector3(cx, h + 0.01, cz), Color(0.92, 0.92, 0.90))
                var n := int(d / 2.0)
                for i in range(n):
                    var lz := cz - d * 0.5 + 1.0 + 2.0 * float(i)
                    kit.box(Vector3(0.18, 0.2, 0.18), Vector3(cx, h + 0.12, lz), Color(1.0, 0.8, 0.45))
            else:
                kit.cyl_y(0.12, 0.12, h, Vector3(cx, h * 0.5, cz), Color(0.3, 0.2, 0.1), 6)
            for corner in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
                kit.box(Vector3(0.08, h, 0.08), Vector3(cx + corner.x * (w * 0.5 - 0.1), h * 0.5, cz + corner.y * (d * 0.5 - 0.1)), Color(0.3, 0.2, 0.1))
        "sink":
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), Color(0.88, 0.90, 0.92), Vector3.ZERO, 0.2, 0.4)
            kit.box(Vector3(0.1, 0.25, 0.1), Vector3(cx, h + 0.12, cz), Color(0.7, 0.7, 0.72), Vector3.ZERO, 0.8, 0.3)
        "step":
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), Color(0.55, 0.40, 0.25), Vector3.ZERO, 0.0, 0.7)
            kit.box(Vector3(w, 0.06, d + 0.02), Vector3(cx, h + 0.01, cz), Color(0.45, 0.08, 0.10))
        "column":
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), Color(0.82, 0.80, 0.72), Vector3.ZERO, 0.1, 0.7)
            kit.box(Vector3(w + 0.3, 0.3, d + 0.3), Vector3(cx, 0.15, cz), Color(0.60, 0.50, 0.30))
            kit.box(Vector3(w + 0.3, 0.3, d + 0.3), Vector3(cx, h - 0.15, cz), Color(0.60, 0.50, 0.30))
        "compass":
            kit.cyl_y(0.4, 0.3, h, Vector3(cx, h * 0.5, cz), Color(0.40, 0.28, 0.14), 8)
            kit.sphere(0.25, Vector3(cx, h + 0.1, cz), Color(0.8, 0.65, 0.25), Vector3(1, 0.7, 1), 0.7, 0.3, 8)
            _glow_box(kit, Vector3(0.2, 0.03, 0.2), Vector3(cx, h + 0.3, cz), Color(1.0, 0.8, 0.4))
        "telegraph":
            kit.cyl_y(0.22, 0.18, h, Vector3(cx, h * 0.5, cz), Color(0.75, 0.55, 0.2), 8, 0.7, 0.3)
            kit.cyl_z(0.3, 0.3, 0.12, Vector3(cx, h + 0.2, cz), Color(0.9, 0.85, 0.7), 12)
            kit.box(Vector3(0.05, 0.4, 0.05), Vector3(cx, h + 0.35, cz), Color(0.7, 0.1, 0.1))
        "chart":
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), Color(0.35, 0.23, 0.12), Vector3.ZERO, 0.0, 0.8)
            kit.box(Vector3(w - 0.3, 0.03, d - 0.3), Vector3(cx, h + 0.02, cz), Color(0.88, 0.82, 0.62))
            _glow_box(kit, Vector3(0.3, 0.3, 0.3), Vector3(cx + 1.0, h + 0.2, cz), Color(1.0, 0.75, 0.35))
        "console":
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), Color(0.14, 0.15, 0.17), Vector3.ZERO, 0.4, 0.5)
            var knobs := int(w / 0.6)
            for i in range(knobs):
                var tint := Color(0.3, 0.9, 0.4) if i % 3 != 0 else Color(1.0, 0.4, 0.2)
                _glow_box(kit, Vector3(0.15, 0.04, 0.15), Vector3(cx - w * 0.5 + 0.4 + 0.6 * float(i), h + 0.03, cz), tint)
        "crate":
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), Color(0.42, 0.28, 0.15), Vector3.ZERO, 0.0, 0.9)
            kit.box(Vector3(w + 0.06, 0.16, d + 0.06), Vector3(cx, h * 0.5, cz), Color(0.18, 0.12, 0.07))
        _:
            kit.box(Vector3(w, h, d), Vector3(cx, h * 0.5, cz), Color(0.35, 0.35, 0.38))


# Крыша, окна, полы, лампы, дверные рамы, трубы и купол одной надстройки.
static func _draw_shell(kit: Object, root: Node3D, idx: int) -> void:
    var bld: Dictionary = _buildings[idx]
    var x0: float = bld["x0"]
    var x1: float = bld["x1"]
    var z0: float = bld["z0"]
    var z1: float = bld["z1"]
    var cx := (x0 + x1) * 0.5
    var cz := (z0 + z1) * 0.5
    var roof := Color(0.30, 0.24, 0.18)
    var lit := Color(1.0, 0.78, 0.38)
    var dim := Color(0.05, 0.07, 0.1)
    kit.box(Vector3(x1 - x0 + 0.6, 0.3, z1 - z0 + 0.6), Vector3(cx, WALL_H + 0.15, cz), roof, Vector3.ZERO, 0.1, 0.9)
    for f in _floors:
        var fl: Dictionary = f
        if int(fl["b"]) != idx:
            continue
        var r: Rect2 = fl["r"]
        kit.box(Vector3(r.size.x, 0.04, r.size.y), Vector3(r.position.x + r.size.x * 0.5, 0.03, r.position.y + r.size.y * 0.5), fl["c"], Vector3.ZERO, 0.0, 0.9)
    for l in _lamps:
        var lp: Dictionary = l
        if int(lp["b"]) != idx:
            continue
        _glow_box(kit, Vector3(1.0, 0.05, 0.4), Vector3(float(lp["x"]), WALL_H - 0.05, float(lp["z"])), Color(1.0, 0.9, 0.65))
    var brass := Color(0.55, 0.40, 0.18)
    for dd in _doors:
        var dr: Dictionary = dd
        if int(dr["b"]) != idx:
            continue
        var dx: float = dr["x"]
        var dz: float = dr["z"]
        if str(dr["axis"]) == "x":
            kit.box(Vector3(2.0 * DOOR_HALF, 0.6, WALL_T + 0.04), Vector3(dx, WALL_H - 0.3, dz), Color(0.80, 0.80, 0.76), Vector3.ZERO, 0.1, 0.85)
            kit.box(Vector3(0.12, 2.8, WALL_T + 0.08), Vector3(dx - DOOR_HALF + 0.06, 1.4, dz), brass, Vector3.ZERO, 0.5, 0.4)
            kit.box(Vector3(0.12, 2.8, WALL_T + 0.08), Vector3(dx + DOOR_HALF - 0.06, 1.4, dz), brass, Vector3.ZERO, 0.5, 0.4)
        else:
            kit.box(Vector3(WALL_T + 0.04, 0.6, 2.0 * DOOR_HALF), Vector3(dx, WALL_H - 0.3, dz), Color(0.80, 0.80, 0.76), Vector3.ZERO, 0.1, 0.85)
            kit.box(Vector3(WALL_T + 0.08, 2.8, 0.12), Vector3(dx, 1.4, dz - DOOR_HALF + 0.06), brass, Vector3.ZERO, 0.5, 0.4)
            kit.box(Vector3(WALL_T + 0.08, 2.8, 0.12), Vector3(dx, 1.4, dz + DOOR_HALF - 0.06), brass, Vector3.ZERO, 0.5, 0.4)
    var win_i := 0
    for wv in _windows:
        var wd: Dictionary = wv
        if int(wd["b"]) != idx:
            continue
        win_i += 1
        var tint := lit if (win_i % 4) != 0 else dim
        var fixed: float = wd["f"]
        var pos: float = wd["p"]
        var length: float = wd["l"]
        var off := 0.17
        if str(wd["axis"]) == "z":
            _glow_box(kit, Vector3(0.05, 0.9, length), Vector3(fixed + off, 1.9, pos), tint)
            _glow_box(kit, Vector3(0.05, 0.9, length), Vector3(fixed - off, 1.9, pos), tint)
        else:
            _glow_box(kit, Vector3(length, 0.9, 0.05), Vector3(pos, 1.9, fixed + off), tint)
            _glow_box(kit, Vector3(length, 0.9, 0.05), Vector3(pos, 1.9, fixed - off), tint)
    # Крыша: трубы, дымовая струя, купол, надстройка мостика.
    var buff := Color(0.84, 0.52, 0.14)
    var black := Color(0.05, 0.05, 0.06)
    var funnel: String = bld["funnel"]
    if funnel == "normal":
        kit.cyl_y(4.4, 3.9, 16.0, Vector3(cx, WALL_H + 8.3, cz), buff, 14, 0.2, 0.7)
        kit.cyl_y(3.95, 3.8, 3.0, Vector3(cx, WALL_H + 15.6, cz), black, 14, 0.2, 0.7)
        kit.box(Vector3(0.12, 14.0, 0.12), Vector3(cx + 4.0, WALL_H + 8.0, cz + 0.3), black)
        _smoke(root, Vector3(cx, WALL_H + 17.5, cz), false)
    elif funnel == "broken":
        kit.cyl_y(4.4, 3.9, 4.0, Vector3(cx, WALL_H + 2.2, cz), black, 10, 0.2, 0.9)
        _glow_box(kit, Vector3(5.6, 0.1, 5.6), Vector3(cx, WALL_H + 4.25, cz), Color(1.0, 0.4, 0.08))
        _smoke(root, Vector3(cx, WALL_H + 4.6, cz), true)
        _smoke(root, Vector3(cx, WALL_H + 5.0, cz), false)
    if bool(bld["dome"]):
        kit.sphere(5.5, Vector3(cx, WALL_H + 0.3, cz), Color(0.45, 0.75, 0.9, 0.45), Vector3(1.0, 0.55, 1.0), 0.3, 0.1, 16)
        kit.sphere(4.4, Vector3(cx, WALL_H + 0.4, cz), Color(1.0, 0.8, 0.45), Vector3(1.0, 0.5, 1.0), 0.0, 0.8, 10)
    if str(bld["kind"]) == "bridge":
        var top := WALL_H + 0.3
        kit.box(Vector3(18.0, 2.8, 8.0), Vector3(cx, top + 1.4, -110.0), Color(0.80, 0.80, 0.76), Vector3.ZERO, 0.1, 0.8)
        kit.box(Vector3(18.6, 0.3, 8.6), Vector3(cx, top + 2.95, -110.0), roof)
        _glow_box(kit, Vector3(15.0, 0.9, 0.06), Vector3(cx, top + 1.7, -114.03), lit)
        kit.box(Vector3(34.0, 0.25, 1.4), Vector3(cx, 2.4, -112.0), roof)   # крылья мостика


static func _build_labels(root: Node3D) -> void:
    for l in _labels:
        var lb: Dictionary = l
        var label := Label3D.new()
        label.text = str(lb["t"])
        label.position = Vector3(float(lb["x"]), float(lb["y"]), float(lb["z"]))
        label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        label.font_size = 36
        label.pixel_size = 0.0085
        label.outline_size = 6
        label.modulate = Color(1.0, 0.92, 0.7)
        root.add_child(label)


static func _build_deck_props(root: Node3D) -> void:
    var kit := Kit.new()
    var rng := RandomNumberGenerator.new()
    rng.seed = 1912
    for i in range(70):
        var z := rng.randf_range(-165.0, 170.0)
        var side := -1.0 if rng.randf() < 0.5 else 1.0
        var x := side * (half_width(z) - 1.0)
        if i % 3 == 0:
            kit.cyl_y(0.4, 0.4, 0.1, Vector3(x - side * 0.1, 0.85, z), Color(0.95, 0.35, 0.1), 10, 0.0, 0.8, Vector3(0, 0, 90))
        else:
            kit.cyl_y(0.05, 0.05, 2.4, Vector3(x - side * 0.6, 1.2, z), Color(0.12, 0.12, 0.14), 5)
            _glow_box(kit, Vector3(0.28, 0.28, 0.28), Vector3(x - side * 0.6, 2.5, z), Color(1.0, 0.82, 0.45))
    for i in range(60):
        var pz := rng.randf_range(-170.0, 170.0)
        var px := rng.randf_range(-22.0, 22.0)
        if not nav_cell_free(px, pz):
            continue
        if i % 2 == 0:
            kit.box(Vector3(0.7, 0.4, 0.45), Vector3(px, 0.2, pz), Color(0.35, 0.22, 0.12), Vector3(0, rng.randf_range(0, 180), 0))
        else:
            kit.box(Vector3(1.4, 0.12, 0.3), Vector3(px, 0.08, pz), Color(0.4, 0.3, 0.2), Vector3(0, rng.randf_range(0, 180), rng.randf_range(-8, 8)))
    var holder := Node3D.new()
    holder.name = "DeckProps"
    root.add_child(holder)
    kit.commit(holder)


# Вентиляционные люки: решётка на петле открывается, когда из люка лезет зомби (open_vent).
static func _build_vents(root: Node3D) -> void:
    var holder := Node3D.new()
    holder.name = "Vents"
    root.add_child(holder)
    for i in range(_vents.size()):
        var p: Vector2 = _vents[i]
        var vent := Node3D.new()
        vent.name = "Vent_%d" % i
        vent.position = Vector3(p.x, 0.0, p.y)
        holder.add_child(vent)
        var kit := Kit.new()
        kit.box(Vector3(2.5, 0.12, 2.5), Vector3(0, 0.06, 0), Color(0.18, 0.19, 0.18), Vector3.ZERO, 0.5, 0.6)
        kit.box(Vector3(2.1, 0.05, 2.1), Vector3(0, 0.145, 0), Color(0.01, 0.02, 0.01))
        _glow_box(kit, Vector3(1.8, 0.02, 1.8), Vector3(0, 0.17, 0), Color(0.25, 0.85, 0.2))
        for corner in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
            kit.box(Vector3(0.14, 0.08, 0.14), Vector3(corner.x * 1.12, 0.14, corner.y * 1.12), Color(0.45, 0.42, 0.38), Vector3.ZERO, 0.6, 0.4)
        kit.commit(vent)
        var hinge := Node3D.new()
        hinge.name = "Hinge"
        hinge.position = Vector3(0.0, 0.22, -1.0)
        vent.add_child(hinge)
        var lid := Kit.new()
        for j in range(6):
            lid.box(Vector3(2.1, 0.06, 0.16), Vector3(0, 0, 0.12 + 0.35 * float(j)), Color(0.14, 0.15, 0.16), Vector3.ZERO, 0.6, 0.5)
        lid.box(Vector3(0.12, 0.06, 2.0), Vector3(-1.0, 0, 1.0), Color(0.14, 0.15, 0.16), Vector3.ZERO, 0.6, 0.5)
        lid.box(Vector3(0.12, 0.06, 2.0), Vector3(1.0, 0, 1.0), Color(0.14, 0.15, 0.16), Vector3.ZERO, 0.6, 0.5)
        lid.commit(hinge)


# Площадка появления игроков (она же площадка вертолёта).
static func _build_spawn_markers(root: Node3D) -> void:
    var kit := Kit.new()
    var c := SPAWN_CENTER
    kit.cyl_y(4.2, 4.2, 0.14, Vector3(c.x, 0.07, c.z), Color(0.12, 0.14, 0.16), 24, 0.5, 0.5)
    kit.cyl_y(3.9, 3.9, 0.05, Vector3(c.x, 0.165, c.z), Color(0.2, 0.7, 1.0), 24)
    kit.cyl_y(3.5, 3.5, 0.06, Vector3(c.x, 0.19, c.z), Color(0.1, 0.12, 0.14), 24, 0.5, 0.5)
    for corner in [Vector2(-3.8, -3.8), Vector2(3.8, -3.8), Vector2(-3.8, 3.8), Vector2(3.8, 3.8)]:
        kit.box(Vector3(0.25, 1.6, 0.25), Vector3(c.x + corner.x, 0.8, c.z + corner.y), Color(0.15, 0.17, 0.2))
        _glow_box(kit, Vector3(0.35, 0.2, 0.35), Vector3(c.x + corner.x, 1.7, c.z + corner.y), Color(0.3, 0.85, 1.0))
    var holder := Node3D.new()
    holder.name = "SpawnMarkers"
    root.add_child(holder)
    kit.commit(holder)
    var label := Label3D.new()
    label.name = "SpawnLabel"
    label.text = "ТОЧКА ПОЯВЛЕНИЯ"
    label.position = Vector3(c.x, 3.3, c.z)
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.font_size = 48
    label.pixel_size = 0.012
    label.outline_size = 8
    label.modulate = Color(0.55, 0.9, 1.0)
    root.add_child(label)


# ШТУРВАЛ в рубке: деревянное колесо с рукоятками на пьедестале, медленно «рыскает».
static func _build_helm(root: Node3D) -> void:
    var helm := Node3D.new()
    helm.name = "Helm"
    helm.position = Vector3(0.0, 0.0, -115.0)
    root.add_child(helm)
    var base := Kit.new()
    base.cyl_y(0.55, 0.42, 1.0, Vector3(0, 0.5, 0), Color(0.28, 0.17, 0.09), 12, 0.1, 0.7)
    base.box(Vector3(0.55, 0.35, 0.55), Vector3(0, 1.18, 0), Color(0.55, 0.40, 0.18), Vector3.ZERO, 0.6, 0.4)
    base.cyl_z(0.09, 0.09, 0.5, Vector3(0, 1.6, 0), Color(0.75, 0.55, 0.2), 8, 0.7, 0.3)
    base.commit(helm)
    var wheel := Node3D.new()
    wheel.name = "Wheel"
    wheel.position = Vector3(0.0, 1.6, 0.0)
    helm.add_child(wheel)
    var kit := Kit.new()
    var wood := Color(0.45, 0.27, 0.11)
    var radius := 0.8
    var segments := 20
    for i in range(segments):
        var a := TAU * float(i) / float(segments)
        kit.box(Vector3(0.3, 0.1, 0.1), Vector3(cos(a) * radius, sin(a) * radius, 0.0), wood, Vector3(0, 0, rad_to_deg(a) + 90.0), 0.1, 0.6)
    for i in range(4):
        kit.box(Vector3(2.0 * (radius + 0.28), 0.07, 0.07), Vector3.ZERO, wood, Vector3(0, 0, 45.0 * float(i)), 0.1, 0.6)
    for i in range(8):
        var a2 := TAU * float(i) / 8.0
        kit.box(Vector3(0.12, 0.12, 0.14), Vector3(cos(a2) * (radius + 0.3), sin(a2) * (radius + 0.3), 0.0), Color(0.75, 0.55, 0.2), Vector3(0, 0, rad_to_deg(a2)), 0.6, 0.4)
    kit.cyl_z(0.16, 0.16, 0.16, Vector3.ZERO, Color(0.75, 0.55, 0.2), 10, 0.7, 0.3)
    kit.commit(wheel)
    var tween := wheel.create_tween().set_loops()
    tween.tween_property(wheel, "rotation:z", 0.55, 3.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tween.tween_property(wheel, "rotation:z", -0.55, 6.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tween.tween_property(wheel, "rotation:z", 0.0, 3.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


static func _build_shops(root: Node3D) -> void:
    var turret_script = load("res://scripts/turret_model.gd")
    for spot in SHOP_SPOTS:
        var fx := -signf(spot.x)
        var holder := Node3D.new()
        holder.name = "Shop_%d_%d" % [int(spot.x), int(spot.y)]
        holder.position = Vector3(spot.x, 0.0, spot.y)
        root.add_child(holder)
        var kit := Kit.new()
        var steel := Color(0.16, 0.18, 0.21)
        var wood := Color(0.42, 0.28, 0.16)
        kit.box(Vector3(1.9, 0.08, 3.5), Vector3(0, 0.04, 0), Color(0.10, 0.11, 0.12), Vector3.ZERO, 0.4, 0.7)
        kit.box(Vector3(1.0, 1.1, 3.2), Vector3(fx * 0.45, 0.6, 0), steel, Vector3.ZERO, 0.5, 0.5)
        kit.box(Vector3(1.25, 0.07, 3.4), Vector3(fx * 0.5, 1.18, 0), wood, Vector3.ZERO, 0.1, 0.7)
        kit.box(Vector3(0.12, 2.5, 3.4), Vector3(-fx * 0.85, 1.3, 0), steel, Vector3.ZERO, 0.5, 0.5)
        kit.box(Vector3(1.7, 2.5, 0.1), Vector3(0, 1.3, 1.7), steel, Vector3.ZERO, 0.5, 0.5)
        kit.box(Vector3(1.7, 2.5, 0.1), Vector3(0, 1.3, -1.7), steel, Vector3.ZERO, 0.5, 0.5)
        for shelf_y in [1.6, 2.0]:
            kit.box(Vector3(0.32, 0.06, 3.0), Vector3(-fx * 0.62, shelf_y, 0), wood, Vector3.ZERO, 0.1, 0.7)
        for k in range(5):
            kit.box(Vector3(0.18, 0.22, 0.4), Vector3(-fx * 0.62, 1.74 + 0.4 * float(k % 2), -1.2 + 0.6 * float(k)), Color(0.30, 0.36, 0.22), Vector3.ZERO, 0.2, 0.7)
        for k in range(5):
            var stripe := Color(0.82, 0.15, 0.12) if k % 2 == 0 else Color(0.92, 0.92, 0.90)
            kit.box(Vector3(2.4, 0.08, 0.74), Vector3(fx * 0.1, 2.6, -1.48 + 0.74 * float(k)), stripe, Vector3.ZERO, 0.0, 0.8)
        for pz in [-1.65, 1.65]:
            kit.cyl_y(0.06, 0.06, 2.6, Vector3(fx * 0.95, 1.3, pz), Color(0.75, 0.75, 0.78), 8, 0.6, 0.4)
        var sign_mesh := BoxMesh.new()
        sign_mesh.size = Vector3(0.12, 0.6, 2.8)
        kit.add_mesh(sign_mesh, Transform3D(Basis.IDENTITY, Vector3(fx * 1.05, 3.05, 0)), Kit.glow_material(Color(0.05, 0.28, 0.35)))
        _glow_box(kit, Vector3(1.5, 0.03, 3.6), Vector3(fx * 1.75, 0.09, 0), Color(0.2, 0.8, 1.0))
        kit.commit(holder)
        var display: Node3D = turret_script.build_static(holder, 0.5)
        display.position = Vector3(fx * 0.5, 1.22, 0)
        display.rotation.y = fx * PI * 0.5
        var label := Label3D.new()
        label.name = "ShopLabel"
        label.text = "МАГАЗИН\nТУРЕЛЬ — 50.000 $"
        label.position = Vector3(fx * 1.14, 3.05, 0)
        label.rotation_degrees = Vector3(0, 90.0 * fx, 0)
        label.font_size = 40
        label.pixel_size = 0.0085
        label.outline_size = 8
        label.modulate = Color(0.6, 0.95, 1.0)
        holder.add_child(label)
        var lamp := OmniLight3D.new()
        lamp.position = Vector3(fx * 1.2, 2.3, 0)
        lamp.omni_range = 8.0
        lamp.light_energy = 1.4
        lamp.light_color = Color(1.0, 0.85, 0.6)
        lamp.shadow_enabled = false
        holder.add_child(lamp)


# Айсберги: ступенчатые ледяные блоки (та же геометрия, что и коллизия _ice_tiers), уходят под воду.
static func _build_iceberg(root: Node3D) -> void:
    for b in range(ICE_BERGS.size()):
        var side: float = ICE_BERGS[b]["side"]
        var kit := Kit.new()
        var tiers := _ice_tiers()
        for k in range(tiers.size()):
            var t: Array = tiers[k]
            var x0: float = minf(float(t[0]) * side, float(t[1]) * side)
            var x1: float = maxf(float(t[0]) * side, float(t[1]) * side)
            var z0: float = t[2]
            var z1: float = t[3]
            var h: float = t[4]
            var tint := Color(0.62, 0.80, 0.94).lerp(Color(0.86, 0.95, 1.0), float(k) / float(tiers.size() - 1))
            var depth := h + 12.0
            kit.box(Vector3(x1 - x0, depth, z1 - z0), Vector3((x0 + x1) * 0.5, h - depth * 0.5, (z0 + z1) * 0.5), tint, Vector3.ZERO, 0.1, 0.3)
            kit.box(Vector3(x1 - x0 + 0.04, 0.08, z1 - z0 + 0.04), Vector3((x0 + x1) * 0.5, h + 0.02, (z0 + z1) * 0.5), Color(0.95, 0.98, 1.0), Vector3.ZERO, 0.0, 0.8)
        var holder := Node3D.new()
        holder.name = "Iceberg_%d" % b
        holder.position.z = float(ICE_BERGS[b]["start_z"])
        root.add_child(holder)
        kit.commit(holder)
        _ice_dz[b] = holder.position.z
        _drift(holder, b)
