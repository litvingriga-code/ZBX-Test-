extends Node3D
## Deterministic 200x200 m test arena; only used in Survival.
const MAP_SIZE := 200.0

func _ready() -> void:
    if Net.game_mode != Net.MODE_SURVIVAL:
        return
    var floor_mesh := get_node_or_null("Floor") as MeshInstance3D
    if floor_mesh != null:
        var mesh := BoxMesh.new()
        mesh.size = Vector3(MAP_SIZE, 0.2, MAP_SIZE)
        floor_mesh.mesh = mesh
        var grass := StandardMaterial3D.new()
        grass.albedo_color = Color(0.31, 0.43, 0.28)
        floor_mesh.material_override = grass
    var floor_collision := get_node_or_null("GroundCollision/CollisionShape3D") as CollisionShape3D
    if floor_collision != null:
        var shape := BoxShape3D.new()
        shape.size = Vector3(MAP_SIZE, 0.2, MAP_SIZE)
        floor_collision.shape = shape
    var rng := RandomNumberGenerator.new()
    rng.seed = 2002026
    for i in range(65):
        var p := Vector3(rng.randf_range(-94, 94), 0, rng.randf_range(-94, 94))
        if Vector2(p.x, p.z).length() < 12.0:
            continue
        if i % 3 == 0:
            _make_tree(p, rng)
        elif i % 3 == 1:
            _make_block(p, rng)
        else:
            _make_rock(p, rng)

func _solid_box(pos: Vector3, size: Vector3, color: Color, label_name: String) -> void:
    var body := StaticBody3D.new()
    body.name = label_name
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    mesh.material_override = material
    body.add_child(mesh)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    add_child(body)

func _make_block(p: Vector3, rng: RandomNumberGenerator) -> void:
    var size := Vector3(rng.randf_range(1.8, 5.0), rng.randf_range(1.2, 3.6), rng.randf_range(1.8, 5.0))
    _solid_box(p + Vector3.UP * size.y * 0.5, size, Color(0.42, 0.43, 0.41), "ConcreteBlock")

func _make_tree(p: Vector3, rng: RandomNumberGenerator) -> void:
    var height := rng.randf_range(4.5, 8.5)
    _solid_box(p + Vector3.UP * height * 0.33, Vector3(0.65, height * 0.66, 0.65), Color(0.32, 0.20, 0.11), "TreeTrunk")
    var leaves := MeshInstance3D.new()
    leaves.name = "TreeCrown"
    leaves.position = p + Vector3.UP * height * 0.78
    var mesh := SphereMesh.new()
    mesh.radius = height * 0.26
    mesh.height = height * 0.52
    leaves.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.13 + rng.randf_range(0, 0.09), 0.32 + rng.randf_range(0, 0.15), 0.13)
    leaves.material_override = mat
    add_child(leaves)

func _make_rock(p: Vector3, rng: RandomNumberGenerator) -> void:
    var size := Vector3(rng.randf_range(1.0, 3.0), rng.randf_range(0.8, 2.0), rng.randf_range(1.0, 2.8))
    _solid_box(p + Vector3.UP * size.y * 0.5, size, Color(0.37, 0.38, 0.35), "Rock")
