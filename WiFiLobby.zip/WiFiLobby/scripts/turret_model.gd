extends Node3D
## Stage84: модель автоматической турели. Строится кодом из примитивов (ModelKit).
## Голова вращается вокруг Y (yaw) и X (pitch), стволы смотрят в +Z головы.
## aim(yaw, pitch, delta) — плавный поворот; flash() — вспышка выстрела.

const Kit = preload("res://scripts/model_kit.gd")

const HEAD_HEIGHT := 1.05
const MUZZLE_OFFSET := Vector3(0.0, 0.0, 1.05)

var head: Node3D
var flash_node: MeshInstance3D
var flash_light: OmniLight3D
var led: MeshInstance3D
var _flash_left := 0.0
var _yaw := 0.0
var _pitch := 0.0
var _spin := 0.0
var barrels: Node3D


func _init() -> void:
    name = "Turret"
    _build()


## Статичная копия (для витрины магазина и предмета на земле): без света.
static func build_static(parent: Node3D, scale_factor: float = 1.0) -> Node3D:
    var model: Node3D = (load("res://scripts/turret_model.gd") as GDScript).new()
    model.scale = Vector3.ONE * scale_factor
    parent.add_child(model)
    model.call("hide_light")
    return model


func hide_light() -> void:
    flash_light.visible = false


func _build() -> void:
    var steel := Color(0.28, 0.31, 0.36)
    var dark := Color(0.09, 0.10, 0.12)
    var light := Color(0.50, 0.54, 0.60)
    var olive := Color(0.30, 0.36, 0.22)
    var orange := Color(0.92, 0.48, 0.14)

    var base := Kit.new()
    # Три опоры-треноги, плита и стойка.
    base.cyl_y(0.55, 0.55, 0.08, Vector3(0, 0.04, 0), dark, 12, 0.5, 0.6)
    for i in range(3):
        var a := TAU / 3.0 * float(i)
        var leg_pos := Vector3(sin(a) * 0.38, 0.30, cos(a) * 0.38)
        base.box(Vector3(0.09, 0.62, 0.09), leg_pos, steel, Vector3(cos(a) * 28.0, 0.0, -sin(a) * 28.0), 0.5, 0.5)
        base.box(Vector3(0.20, 0.05, 0.20), Vector3(sin(a) * 0.52, 0.03, cos(a) * 0.52), dark)
    base.cyl_y(0.11, 0.14, 0.60, Vector3(0, 0.70, 0), steel, 10, 0.5, 0.5)
    base.cyl_y(0.20, 0.20, 0.08, Vector3(0, 0.98, 0), dark, 12, 0.5, 0.5)
    base.commit(self)

    head = Node3D.new()
    head.name = "Head"
    head.position = Vector3(0, HEAD_HEIGHT, 0)
    add_child(head)
    var hk := Kit.new()
    # Корпус, бронекожух, коробка с лентой, датчик.
    hk.box(Vector3(0.46, 0.34, 0.62), Vector3(0, 0.12, 0.0), steel, Vector3.ZERO, 0.5, 0.45)
    hk.box(Vector3(0.50, 0.08, 0.50), Vector3(0, 0.33, -0.02), light, Vector3.ZERO, 0.5, 0.45)
    hk.box(Vector3(0.20, 0.28, 0.30), Vector3(-0.33, 0.04, -0.06), olive, Vector3.ZERO, 0.2, 0.7)
    hk.box(Vector3(0.20, 0.16, 0.16), Vector3(0.0, 0.22, 0.34), dark)
    hk.box(Vector3(0.10, 0.10, 0.36), Vector3(0.24, 0.32, 0.10), orange, Vector3.ZERO, 0.2, 0.6)
    hk.sphere(0.09, Vector3(0.0, 0.43, -0.06), dark, Vector3.ONE, 0.5, 0.3, 10)
    hk.commit(head)

    # Блок стволов вращается вдоль оси стрельбы, когда турель ведёт огонь.
    barrels = Node3D.new()
    barrels.name = "Barrels"
    barrels.position = Vector3(0, 0.12, 0.28)
    head.add_child(barrels)
    var bk := Kit.new()
    for i in range(3):
        var ang := TAU / 3.0 * float(i)
        bk.cyl_z(0.035, 0.035, 0.80, Vector3(cos(ang) * 0.08, sin(ang) * 0.08, 0.36), dark, 8, 0.7, 0.35)
    bk.cyl_z(0.12, 0.12, 0.10, Vector3(0, 0, 0.10), steel, 10, 0.6, 0.4)
    bk.cyl_z(0.10, 0.10, 0.06, Vector3(0, 0, 0.74), steel, 10, 0.6, 0.4)
    bk.commit(barrels)

    # Светодиод состояния и вспышка выстрела.
    led = MeshInstance3D.new()
    var led_mesh := SphereMesh.new()
    led_mesh.radius = 0.035
    led_mesh.height = 0.07
    led_mesh.radial_segments = 8
    led_mesh.rings = 4
    led.mesh = led_mesh
    led.material_override = Kit.glow_material(Color(0.2, 0.9, 1.0))
    led.position = Vector3(0.0, 0.43, 0.10)
    head.add_child(led)

    flash_node = MeshInstance3D.new()
    var flash_mesh := SphereMesh.new()
    flash_mesh.radius = 0.16
    flash_mesh.height = 0.32
    flash_mesh.radial_segments = 8
    flash_mesh.rings = 4
    flash_node.mesh = flash_mesh
    flash_node.material_override = Kit.glow_material(Color(1.0, 0.85, 0.35))
    flash_node.position = Vector3(0, 0.12, 0.28) + MUZZLE_OFFSET - Vector3(0, 0, 0.16)
    flash_node.scale = Vector3(1.0, 1.0, 1.8)
    flash_node.visible = false
    head.add_child(flash_node)

    flash_light = OmniLight3D.new()
    flash_light.position = flash_node.position
    flash_light.omni_range = 7.0
    flash_light.light_energy = 0.0
    flash_light.light_color = Color(1.0, 0.8, 0.4)
    flash_light.shadow_enabled = false
    flash_light.visible = false     # выключенный свет не считается шейдером (важно для телефонов)
    head.add_child(flash_light)


## Мировая позиция дульного среза (для трассера).
func muzzle_global() -> Vector3:
    return head.to_global(Vector3(0, 0.12, 0.28) + MUZZLE_OFFSET)


func flash() -> void:
    _flash_left = 0.07
    flash_node.visible = true
    flash_light.visible = true
    flash_light.light_energy = 2.2


func aim(yaw: float, pitch: float, delta: float, firing: bool) -> void:
    _yaw = lerp_angle(_yaw, yaw, clampf(delta * 16.0, 0.0, 1.0))
    _pitch = lerpf(_pitch, pitch, clampf(delta * 16.0, 0.0, 1.0))
    head.rotation = Vector3(-_pitch, _yaw, 0.0)
    _spin = fmod(_spin + delta * (22.0 if firing else 0.0), TAU)
    barrels.rotation.z = _spin
    if _flash_left > 0.0:
        _flash_left -= delta
        if _flash_left <= 0.0:
            flash_node.visible = false
            flash_light.visible = false
            flash_light.light_energy = 0.0


func set_active(on: bool) -> void:
    led.material_override = Kit.glow_material(Color(0.2, 0.9, 1.0) if on else Color(0.9, 0.2, 0.2))
