extends RefCounted
## Единая таблица оружия. Используется боем (battle.gd), хостом (net.gd),
## магазином и инвентарём. Чтобы добавить оружие: запись здесь + запись в
## GameState.ITEMS/SHOP + модель в weapon_models.gd.

const NONE := ""

## Максимальная скорость бега в единицах CS2 (units/s). Без оружия — как с ножом (250).
## Умножается на SPEED_UNIT в battle.gd (1 unit = 0.0254 м).
const DEFAULT_SPEED := 250.0

# slot: 0 основное, 1 пистолет, 2 нож (совпадает с ячейками снаряжения).
# kind: имя построителя модели в weapon_models.gd.
# reload_style: mag | pistol | revolver | shell | none
const DEFS := {
    "ak47": {
        "name": "АК-47", "slot": 0, "kind": "ak47", "speed": 215, "ammo": "ammo_762",
        "mag": 30, "damage": 18, "rate": 0.12, "auto": true, "pellets": 1,
        "spread": 0.35, "spread_gain": 0.28, "range": 90.0,
        "reload": 3.0, "reload_style": "mag",
        "recoil": 0.72, "recoil_ads": 0.45, "kick_back": 0.065,
        "fov_ads": 64.0, "scope": false, "collimator": true,
        "rest": Vector3(0.42, -0.40, -0.78), "ads": Vector3(0.0, -0.158, -0.53),
        "muzzle": Vector3(0, 0.04, -1.13),
        "sound_fire": "res://assets/audio/ak47_fire.wav",
        "sound_reload": "res://assets/audio/m4a1_reload.wav",
        "tracer": Color(1.0, 0.78, 0.18),
    },
    "m4a1": {
        "name": "M4A1", "slot": 0, "kind": "m4a1", "speed": 225, "ammo": "ammo_556",
        "mag": 30, "damage": 16, "rate": 0.085, "auto": true, "pellets": 1,
        "spread": 0.25, "spread_gain": 0.20, "range": 95.0,
        "reload": 2.4, "reload_style": "mag",
        "recoil": 0.50, "recoil_ads": 0.30, "kick_back": 0.045,
        "fov_ads": 62.0, "scope": false, "collimator": true,
        "rest": Vector3(0.40, -0.36, -0.72), "ads": Vector3(0.0, -0.152, -0.50),
        "muzzle": Vector3(0, 0.012, -1.03),
        "sound_fire": "res://assets/audio/m4a1_fire.wav",
        "sound_reload": "res://assets/audio/m4a1_reload.wav",
        "tracer": Color(1.0, 0.86, 0.35),
    },
    "shotgun": {
        "name": "Дробовик МР-133", "slot": 0, "kind": "shotgun", "speed": 220, "ammo": "ammo_12",
        "mag": 6, "damage": 9, "rate": 0.85, "auto": false, "pellets": 8,
        "spread": 2.6, "spread_gain": 0.0, "range": 38.0,
        "reload": 0.55, "reload_style": "shell",
        "recoil": 2.6, "recoil_ads": 1.8, "kick_back": 0.14,
        "fov_ads": 68.0, "scope": false,
        "rest": Vector3(0.40, -0.36, -0.72), "ads": Vector3(0.0, -0.108, -0.50),
        "muzzle": Vector3(0, 0.034, -1.12),
        "sound_fire": "res://assets/audio/shotgun_fire.wav",
        "sound_reload": "res://assets/audio/shotgun_shell.wav",
        "sound_pump": "res://assets/audio/shotgun_pump.wav",
        "tracer": Color(1.0, 0.7, 0.25),
    },
    "svd": {
        "name": "СВД", "slot": 0, "kind": "svd", "speed": 215, "speed_scoped": 120, "ammo": "ammo_762",
        "mag": 10, "damage": 70, "rate": 0.95, "auto": false, "pellets": 1,
        "spread": 0.45, "spread_gain": 0.0, "range": 160.0,
        "reload": 3.2, "reload_style": "mag",
        "recoil": 3.2, "recoil_ads": 2.2, "kick_back": 0.12,
        "fov_ads": 22.0, "scope": true,
        "rest": Vector3(0.40, -0.38, -0.74), "ads": Vector3(0.0, -0.152, -0.50),
        "muzzle": Vector3(0, 0.03, -1.36),
        "sound_fire": "res://assets/audio/svd_fire.wav",
        "sound_reload": "res://assets/audio/m4a1_reload.wav",
        "sound_bolt": "res://assets/audio/bolt.wav",
        "tracer": Color(1.0, 0.95, 0.6),
    },
    "pm": {
        "name": "Пистолет ПМ", "slot": 1, "kind": "pm", "speed": 240, "ammo": "ammo_9mm",
        "mag": 12, "damage": 14, "rate": 0.2, "auto": false, "pellets": 1,
        "spread": 0.5, "spread_gain": 0.5, "range": 55.0,
        "reload": 1.9, "reload_style": "pistol",
        "recoil": 1.0, "recoil_ads": 0.7, "kick_back": 0.07,
        "fov_ads": 68.0, "scope": false,
        "rest": Vector3(0.30, -0.27, -0.55), "ads": Vector3(0.0, -0.125, -0.42),
        "muzzle": Vector3(0, 0.087, -0.16),
        "sound_fire": "res://assets/audio/pm_fire.wav",
        "sound_reload": "res://assets/audio/pistol_reload.wav",
        "tracer": Color(1.0, 0.82, 0.3),
    },
    "revolver": {
        "name": "Револьвер .44", "slot": 1, "kind": "revolver", "speed": 230, "ammo": "ammo_44",
        "mag": 6, "damage": 46, "rate": 0.55, "auto": false, "pellets": 1,
        "spread": 0.4, "spread_gain": 0.8, "range": 70.0,
        "reload": 2.8, "reload_style": "revolver",
        "recoil": 2.4, "recoil_ads": 1.7, "kick_back": 0.13,
        "fov_ads": 66.0, "scope": false,
        "rest": Vector3(0.30, -0.27, -0.55), "ads": Vector3(0.0, -0.126, -0.42),
        "muzzle": Vector3(0, 0.10, -0.46),
        "sound_fire": "res://assets/audio/revolver_fire.wav",
        "sound_reload": "res://assets/audio/revolver_reload.wav",
        "tracer": Color(1.0, 0.7, 0.2),
    },
    "knife": {
        "name": "Боевой нож", "slot": 2, "kind": "knife", "speed": 250, "ammo": "",
        "mag": 0, "damage": 30, "rate": 0.5, "auto": false, "pellets": 1,
        "spread": 0.0, "spread_gain": 0.0, "range": 2.3,
        "reload": 0.0, "reload_style": "none",
        "recoil": 0.0, "recoil_ads": 0.0, "kick_back": 0.0,
        "fov_ads": 75.0, "scope": false, "melee": true,
        "rest": Vector3(0.34, -0.30, -0.62), "ads": Vector3(0.34, -0.30, -0.62),
        "muzzle": Vector3.ZERO,
        "sound_fire": "res://assets/audio/knife_swing.wav",
        "sound_hit": "res://assets/audio/knife_hit.wav",
        "tracer": Color.WHITE,
    },
    "diamond_sword": {
        "name": "Алмазный меч CREATOR", "slot": 2, "kind": "diamond_sword", "speed": 250, "ammo": "",
        "mag": 0, "damage": 95, "rate": 0.75, "auto": false, "pellets": 1,
        "spread": 0.0, "spread_gain": 0.0, "range": 3.5,
        "reload": 0.0, "reload_style": "none",
        "recoil": 0.0, "recoil_ads": 0.0, "kick_back": 0.0,
        "fov_ads": 75.0, "scope": false, "melee": true,
        "rest": Vector3(0.17, -0.37, -0.85), "ads": Vector3(0.17, -0.37, -0.85),
        "muzzle": Vector3.ZERO,
        "sound_fire": "res://assets/audio/knife_swing.wav",
        "sound_hit": "res://assets/audio/knife_hit.wav",
        "tracer": Color(0.15, 0.75, 1.0),
    },
    "machete": {
        "name": "Мачете", "slot": 2, "kind": "machete", "speed": 250, "ammo": "",
        "mag": 0, "damage": 48, "rate": 0.85, "auto": false, "pellets": 1,
        "spread": 0.0, "spread_gain": 0.0, "range": 2.7,
        "reload": 0.0, "reload_style": "none",
        "recoil": 0.0, "recoil_ads": 0.0, "kick_back": 0.0,
        "fov_ads": 75.0, "scope": false, "melee": true,
        "rest": Vector3(0.36, -0.32, -0.64), "ads": Vector3(0.36, -0.32, -0.64),
        "muzzle": Vector3.ZERO,
        "sound_fire": "res://assets/audio/knife_swing.wav",
        "sound_hit": "res://assets/audio/knife_hit.wav",
        "tracer": Color.WHITE,
    },
}

## Как оружие держит модель игрока (вид от третьего лица, low_poly_player.gd).
## r — точка хвата основной руки, l — точка хвата второй руки (в координатах модели оружия,
## ось -Z = ствол; l отсутствует -> вторая рука свободна). scale — размер в руках модели
## (оружие для вида от первого лица крупнее реального), cls: rifle | pistol | melee.
const GRIPS := {
    "ak47": {"cls": "rifle", "scale": 0.52, "r": Vector3(0, -0.10, 0.125), "l": Vector3(0, -0.035, -0.36)},
    "m4a1": {"cls": "rifle", "scale": 0.52, "r": Vector3(0, -0.10, 0.11), "l": Vector3(0, -0.03, -0.34)},
    "shotgun": {"cls": "rifle", "scale": 0.50, "r": Vector3(0, -0.08, 0.06), "l": Vector3(0, -0.05, -0.48)},
    "svd": {"cls": "rifle", "scale": 0.46, "r": Vector3(0, -0.09, 0.13), "l": Vector3(0, -0.035, -0.40)},
    "pm": {"cls": "pistol", "scale": 1.0, "r": Vector3(0, -0.015, 0.07), "l": Vector3(-0.012, -0.07, 0.06)},
    "revolver": {"cls": "pistol", "scale": 1.0, "r": Vector3(0, -0.03, 0.095), "l": Vector3(-0.012, -0.075, 0.10)},
    "knife": {"cls": "melee", "scale": 0.85, "r": Vector3(0, 0, 0.0)},
    "diamond_sword": {"cls": "melee", "scale": 0.85, "r": Vector3(0.38, -0.31, -0.20)},   # Stage105/107: рукоять меча (кисть модели игрока)
    "machete": {"cls": "melee", "scale": 0.85, "r": Vector3(0, 0, 0.0)},
}

## Типы патронов: id предмета -> подпись для интерфейса.
const AMMO_NAMES := {
    "ammo_762": "7.62", "ammo_556": "5.56", "ammo_9mm": "9 мм",
    "ammo_12": "12 к.", "ammo_44": ".44",
}


static func has(id: String) -> bool:
    return DEFS.has(id)


static func get_def(id: String) -> Dictionary:
    return DEFS.get(id, {})


static func is_melee(id: String) -> bool:
    return bool(DEFS.get(id, {}).get("melee", false))


## Скорость бега (units/s) для оружия; scoped=true — в оптическом прицеле.
static func run_speed(id: String, scoped: bool = false) -> float:
    var def: Dictionary = DEFS.get(id, {})
    if def.is_empty():
        return DEFAULT_SPEED
    if scoped and def.has("speed_scoped"):
        return float(def["speed_scoped"])
    return float(def.get("speed", DEFAULT_SPEED))


## Можно ли поставить на это оружие коллиматор (сам прицел — отдельный предмет "collimator").
static func has_collimator(id: String) -> bool:
    return bool(DEFS.get(id, {}).get("collimator", false))
