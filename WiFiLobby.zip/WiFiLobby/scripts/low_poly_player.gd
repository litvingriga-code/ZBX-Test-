extends Node3D
## Модель игрока в стиле PUBG Mobile (этап 49): шлем с очками, разгрузка с плитами и
## подсумками, рюкзак 3 уровня, наколенники, перчатки, ботинки. Все детали собираются
## кодом из примитивов (без внешних ассетов), см. model_kit.gd.
## Лицом к камере при rotation.y = 0 (лицо смотрит в +Z). Цвет команды = цвет куртки,
## жилет, шлем и рюкзак — его более тёмные оттенки.
##
## API (совместим с прежней версией): setup(jacket), set_crouching(value, delta),
## animate(t, walking, delta). Новое: auto_animate(delta) — сама определяет ходьбу по
## смещению модели (для боя, где позиции приходят по сети).

const Kit = preload("res://scripts/model_kit.gd")
const Weapons = preload("res://scripts/weapons.gd")
const WeaponModels = preload("res://scripts/weapon_models.gd")
const GraphicsFX = preload("res://scripts/graphics_fx.gd")
const HIP_Y := 0.9375            # высота таза в стойке
const THIGH := 0.45
const SHIN := 0.40
const ANKLE_Y := 0.0875          # высота оси голеностопа над землёй
const CROUCH_HIP := 1.25         # сгиб бедра в приседе (рад)
const CROUCH_KNEE := 2.55        # сгиб колена в приседе (рад)
const ARM_SCALE := 1.12          # руки чуть длиннее, чтобы дотягиваться до оружия
const ARM_L1 := 0.30 * ARM_SCALE # плечо
const ARM_L2 := 0.30 * ARM_SCALE # предплечье до центра кисти
const WALK_REF_SPEED := 3.4      # м/с: при такой скорости шаг на полную амплитуду
const RUN_START := 3.9           # м/с: с этой скорости начинается бег
const RUN_FULL := 5.4            # м/с: полный бег
const GROUND_Y := 1.0            # высота модели на земле (позиции боя)

var _root: Node3D
var _upper: Node3D
var _left_hip: Node3D
var _right_hip: Node3D
var _left_knee: Node3D
var _right_knee: Node3D
var _left_ankle: Node3D
var _right_ankle: Node3D
var _left_shoulder: Node3D
var _right_shoulder: Node3D
var _left_elbow: Node3D
var _right_elbow: Node3D
var _crouch_alpha := 0.0
var _downed_alpha := 0.0          # 0..1: нокаут — на коленях, ползёт на руках
var _walk_blend := 0.0
var _clock := 0.0
var _speed := 0.0
var _last_pos := Vector3.ZERO
var _has_last := false
var _hit_body: StaticBody3D
var _blob: MeshInstance3D           # «фальшивая» тень под ногами (скрывается, когда есть настоящие тени)
var _camera_hidden := false         # тело видно только солнцу (для тени своего игрока), камере — нет
var _hit_shape: CollisionShape3D
var _head: Node3D
var _aim_pivot: Node3D            # плечевая ось: наклон оружия вверх/вниз
var _holder: Node3D               # узел оружия (повёрнут на PI: ствол смотрит вперёд)
var _weapon_id := ""
var _weapon_attach := false
var _weapon_refs: Dictionary = {}
var _weapon_cls := "rifle"
var _grip_r := Vector3.ZERO
var _grip_l := Vector3.ZERO
var _has_grip_l := false
var _aiming := false
var _pitch := 0.0
var _pitch_s := 0.0
var _aim_blend := 0.0
var _hold_blend := 0.0
var _run_blend := 0.0
var _air_blend := 0.0
var _phase := 0.0
var _dir_sign := 1.0
var _move_fwd := 0.0
var _vy := 0.0
var _kick := 0.0
var _swing := 0.0
var _reload_t := 0.0              # 1 -> 0: чужая перезарядка (оружие опускается)
var _reload_dur := 2.0
var _flash_t := 0.0
var _fa_l := 0.0                  # плечо/локоть в свободной анимации (без оружия)
var _fa_r := 0.0
var _fe_l := -0.3
var _fe_r := -0.3
var _flinch := 0.0               # 1 -> 0: реакция на попадание (отшатывание)
var _flinch_side := 1.0
var _land := 0.0                 # 1 -> 0: амортизация после приземления
var _was_air := false


func setup(jacket: Color) -> void:
    var shirt := jacket
    var vest := jacket.darkened(0.55)
    var vest_dark := jacket.darkened(0.68)
    var helmet := jacket.darkened(0.35)
    var pack := jacket.darkened(0.5)
    var pack_lid := jacket.darkened(0.4)
    var skin := Color(0.88, 0.70, 0.56)
    var pants := Color(0.25, 0.26, 0.22)
    var pants_dark := Color(0.17, 0.18, 0.15)
    var boots := Color(0.12, 0.10, 0.08)
    var sole := Color(0.04, 0.04, 0.04)
    var glove := Color(0.12, 0.12, 0.13)
    var strap := Color(0.06, 0.06, 0.07)
    var metal := Color(0.38, 0.38, 0.42)
    var lens := Color(0.20, 0.38, 0.62)
    var hair_dark := Color(0.12, 0.08, 0.06)
    var eye := Color(0.05, 0.04, 0.04)
    var lips := Color(0.62, 0.35, 0.32)
    _root = Node3D.new()
    add_child(_root)
    var upper := Kit.group(_root, Vector3(0, 0.9375, 0), "Upper")
    var k_upper = Kit.new()
    k_upper.box(Vector3(0.38, 0.17, 0.24), Vector3(0, 0.0325, 0), pants)
    k_upper.box(Vector3(0.4, 0.05, 0.26), Vector3(0, 0.1075, 0), strap)
    k_upper.box(Vector3(0.07, 0.04, 0.012), Vector3(0, 0.1075, 0.133), metal, Vector3(0, 0, 0), 0.7, 0.35)
    k_upper.box(Vector3(0.085, 0.1, 0.06), Vector3(-0.16, 0.0825, 0.145), vest_dark)
    k_upper.box(Vector3(0.09, 0.025, 0.065), Vector3(-0.16, 0.1375, 0.145), vest)
    k_upper.box(Vector3(0.085, 0.1, 0.06), Vector3(0.16, 0.0825, 0.145), vest_dark)
    k_upper.box(Vector3(0.09, 0.025, 0.065), Vector3(0.16, 0.1375, 0.145), vest)
    k_upper.box(Vector3(0.07, 0.13, 0.15), Vector3(0.26, 0.0625, -0.02), vest_dark)
    k_upper.box(Vector3(0.075, 0.03, 0.155), Vector3(0.26, 0.1375, -0.02), vest)
    k_upper.box(Vector3(0.36, 0.22, 0.23), Vector3(0, 0.2225, 0), shirt)
    k_upper.box(Vector3(0.44, 0.3, 0.25), Vector3(0, 0.4425, 0), shirt)
    k_upper.cyl_y(0.05, 0.056, 0.1, Vector3(0, 0.6425, 0), skin)
    k_upper.cyl_y(0.066, 0.074, 0.075, Vector3(0, 0.6275, 0), vest_dark, 10)
    k_upper.box(Vector3(0.38, 0.36, 0.07), Vector3(0, 0.3825, 0.15), vest)
    k_upper.box(Vector3(0.3, 0.26, 0.012), Vector3(0, 0.4125, 0.19), vest_dark)
    k_upper.box(Vector3(0.05, 0.05, 0.014), Vector3(-0.1, 0.5025, 0.194), strap)
    k_upper.box(Vector3(0.38, 0.38, 0.06), Vector3(0, 0.3825, -0.145), vest)
    k_upper.box(Vector3(0.465, 0.2, 0.27), Vector3(0, 0.1825, 0), vest)
    k_upper.box(Vector3(0.09, 0.035, 0.29), Vector3(-0.145, 0.5975, 0), vest)
    k_upper.box(Vector3(0.092, 0.04, 0.05), Vector3(-0.145, 0.5825, 0.155), vest_dark)
    k_upper.box(Vector3(0.09, 0.035, 0.29), Vector3(0.145, 0.5975, 0), vest)
    k_upper.box(Vector3(0.092, 0.04, 0.05), Vector3(0.145, 0.5825, 0.155), vest_dark)
    k_upper.box(Vector3(0.095, 0.125, 0.05), Vector3(-0.115, 0.2125, 0.205), vest_dark)
    k_upper.box(Vector3(0.1, 0.035, 0.056), Vector3(-0.115, 0.2775, 0.205), vest)
    k_upper.box(Vector3(0.016, 0.026, 0.012), Vector3(-0.115, 0.2775, 0.236), metal, Vector3(0, 0, 0), 0.7, 0.35)
    k_upper.box(Vector3(0.095, 0.125, 0.05), Vector3(0, 0.2125, 0.205), vest_dark)
    k_upper.box(Vector3(0.1, 0.035, 0.056), Vector3(0, 0.2775, 0.205), vest)
    k_upper.box(Vector3(0.016, 0.026, 0.012), Vector3(0, 0.2775, 0.236), metal, Vector3(0, 0, 0), 0.7, 0.35)
    k_upper.box(Vector3(0.095, 0.125, 0.05), Vector3(0.115, 0.2125, 0.205), vest_dark)
    k_upper.box(Vector3(0.1, 0.035, 0.056), Vector3(0.115, 0.2775, 0.205), vest)
    k_upper.box(Vector3(0.016, 0.026, 0.012), Vector3(0.115, 0.2775, 0.236), metal, Vector3(0, 0, 0), 0.7, 0.35)
    k_upper.box(Vector3(0.07, 0.11, 0.045), Vector3(-0.21, 0.4025, 0.12), strap)
    k_upper.cyl_y(0.006, 0.006, 0.14, Vector3(-0.215, 0.5225, 0.12), strap, 6)
    k_upper.box(Vector3(0.34, 0.46, 0.2), Vector3(0, 0.3625, -0.265), pack)
    k_upper.box(Vector3(0.32, 0.1, 0.22), Vector3(0, 0.6325, -0.265), pack_lid)
    k_upper.box(Vector3(0.3, 0.12, 0.16), Vector3(0, 0.0825, -0.25), pack)
    k_upper.box(Vector3(0.085, 0.3, 0.14), Vector3(-0.22, 0.2825, -0.255), pack_lid)
    k_upper.box(Vector3(0.03, 0.3, 0.012), Vector3(-0.09, 0.4025, -0.372), strap)
    k_upper.box(Vector3(0.085, 0.3, 0.14), Vector3(0.22, 0.2825, -0.255), pack_lid)
    k_upper.box(Vector3(0.03, 0.3, 0.012), Vector3(0.09, 0.4025, -0.372), strap)
    k_upper.box(Vector3(0.3, 0.03, 0.012), Vector3(0, 0.5625, -0.375), strap)
    k_upper.cyl_x(0.062, 0.062, 0.34, Vector3(0, 0.0075, -0.3), pack_lid, 10)
    k_upper.box(Vector3(0.02, 0.07, 0.02), Vector3(0, 0.1625, -0.375), metal, Vector3(0, 0, 0), 0.7, 0.35)
    var k_head = Kit.new()
    k_head.sphere(0.118, Vector3(0, 0.7975, 0.01), skin, Vector3(0.92, 1.08, 1), 0, 0.8, 14)
    k_head.box(Vector3(0.1, 0.06, 0.08), Vector3(0, 0.7275, 0.045), skin)
    k_head.sphere(0.028, Vector3(-0.11, 0.7975, 0), skin, Vector3(0.6, 1, 0.8), 0, 0.8, 8)
    k_head.box(Vector3(0.032, 0.012, 0.014), Vector3(-0.046, 0.8175, 0.116), eye)
    k_head.box(Vector3(0.044, 0.008, 0.014), Vector3(-0.046, 0.8425, 0.118), hair_dark)
    k_head.box(Vector3(0.01, 0.08, 0.012), Vector3(-0.095, 0.7475, 0.07), strap, Vector3(0, 0, -8))
    k_head.sphere(0.028, Vector3(0.11, 0.7975, 0), skin, Vector3(0.6, 1, 0.8), 0, 0.8, 8)
    k_head.box(Vector3(0.032, 0.012, 0.014), Vector3(0.046, 0.8175, 0.116), eye)
    k_head.box(Vector3(0.044, 0.008, 0.014), Vector3(0.046, 0.8425, 0.118), hair_dark)
    k_head.box(Vector3(0.01, 0.08, 0.012), Vector3(0.095, 0.7475, 0.07), strap, Vector3(0, 0, 8))
    k_head.box(Vector3(0.026, 0.04, 0.03), Vector3(0, 0.7905, 0.124), skin)
    k_head.box(Vector3(0.046, 0.008, 0.014), Vector3(0, 0.7525, 0.112), lips)
    k_head.box(Vector3(0.085, 0.01, 0.014), Vector3(0, 0.7075, 0.09), strap)
    k_head.sphere(0.14, Vector3(0, 0.8945, -0.022), helmet, Vector3(1.04, 0.82, 1.14), 0.1, 0.75, 16)
    k_head.box(Vector3(0.03, 0.085, 0.13), Vector3(0.12, 0.8175, -0.01), helmet)
    k_head.box(Vector3(0.03, 0.085, 0.13), Vector3(-0.12, 0.8175, -0.01), helmet)
    k_head.box(Vector3(0.2, 0.065, 0.045), Vector3(0, 0.7925, -0.13), helmet)
    k_head.box(Vector3(0.215, 0.04, 0.035), Vector3(0, 0.9525, 0.112), strap)
    k_head.box(Vector3(0.085, 0.045, 0.02), Vector3(-0.054, 0.9525, 0.135), lens, Vector3(0, 0, 0), 0.6, 0.15)
    k_head.box(Vector3(0.092, 0.052, 0.012), Vector3(-0.054, 0.9525, 0.127), strap)
    k_head.box(Vector3(0.085, 0.045, 0.02), Vector3(0.054, 0.9525, 0.135), lens, Vector3(0, 0, 0), 0.6, 0.15)
    k_head.box(Vector3(0.092, 0.052, 0.012), Vector3(0.054, 0.9525, 0.127), strap)
    k_head.box(Vector3(0.05, 0.06, 0.05), Vector3(0, 0.9775, 0.08), metal, Vector3(0, 0, 0), 0.6, 0.4)
    var head_pivot := Kit.group(upper, Vector3(0, 0.68, 0), "Head")
    var head_mesh := Kit.group(head_pivot, Vector3(0, -0.68, 0), "HeadMesh")
    k_head.commit(head_mesh)
    k_upper.commit(upper)
    var shoulderL := Kit.group(upper, Vector3(-0.285, 0.5525, 0), "ShoulderL")
    var k_shoulderL = Kit.new()
    k_shoulderL.sphere(0.085, Vector3(0, 0, 0), shirt, Vector3(1, 1, 1), 0, 0.9)
    k_shoulderL.box(Vector3(0.1, 0.045, 0.11), Vector3(0, 0.07, 0), vest_dark)
    k_shoulderL.cyl_y(0.056, 0.068, 0.3, Vector3(0, -0.15, 0), shirt, 10)
    k_shoulderL.commit(shoulderL)
    var elbowL := Kit.group(shoulderL, Vector3(0, -0.3, 0), "ElbowL")
    var k_elbowL = Kit.new()
    k_elbowL.sphere(0.058, Vector3(0, 0, 0), shirt, Vector3(1, 1, 1), 0, 0.9, 10)
    k_elbowL.box(Vector3(0.09, 0.07, 0.04), Vector3(0, 0, -0.055), pants_dark)
    k_elbowL.cyl_y(0.046, 0.058, 0.25, Vector3(0, -0.13, 0), shirt, 10)
    k_elbowL.cyl_y(0.05, 0.05, 0.03, Vector3(0, -0.245, 0), strap, 10)
    k_elbowL.box(Vector3(0.085, 0.095, 0.105), Vector3(0, -0.3, 0.01), glove)
    k_elbowL.box(Vector3(0.08, 0.045, 0.095), Vector3(0, -0.365, 0.03), glove)
    k_elbowL.box(Vector3(0.024, 0.055, 0.035), Vector3(0.048, -0.3, 0.05), glove, Vector3(-20, 0, 0))
    k_elbowL.box(Vector3(0.08, 0.012, 0.09), Vector3(0, -0.28, 0.012), metal)
    k_elbowL.commit(elbowL)
    var shoulderR := Kit.group(upper, Vector3(0.285, 0.5525, 0), "ShoulderR")
    var k_shoulderR = Kit.new()
    k_shoulderR.sphere(0.085, Vector3(0, 0, 0), shirt, Vector3(1, 1, 1), 0, 0.9)
    k_shoulderR.box(Vector3(0.1, 0.045, 0.11), Vector3(0, 0.07, 0), vest_dark)
    k_shoulderR.cyl_y(0.056, 0.068, 0.3, Vector3(0, -0.15, 0), shirt, 10)
    k_shoulderR.commit(shoulderR)
    var elbowR := Kit.group(shoulderR, Vector3(0, -0.3, 0), "ElbowR")
    var k_elbowR = Kit.new()
    k_elbowR.sphere(0.058, Vector3(0, 0, 0), shirt, Vector3(1, 1, 1), 0, 0.9, 10)
    k_elbowR.box(Vector3(0.09, 0.07, 0.04), Vector3(0, 0, -0.055), pants_dark)
    k_elbowR.cyl_y(0.046, 0.058, 0.25, Vector3(0, -0.13, 0), shirt, 10)
    k_elbowR.cyl_y(0.05, 0.05, 0.03, Vector3(0, -0.245, 0), strap, 10)
    k_elbowR.box(Vector3(0.085, 0.095, 0.105), Vector3(0, -0.3, 0.01), glove)
    k_elbowR.box(Vector3(0.08, 0.045, 0.095), Vector3(0, -0.365, 0.03), glove)
    k_elbowR.box(Vector3(0.024, 0.055, 0.035), Vector3(-0.048, -0.3, 0.05), glove, Vector3(-20, 0, 0))
    k_elbowR.box(Vector3(0.08, 0.012, 0.09), Vector3(0, -0.28, 0.012), metal)
    k_elbowR.commit(elbowR)
    var hipL := Kit.group(_root, Vector3(-0.105, 0.9375, 0), "HipL")
    var k_hipL = Kit.new()
    k_hipL.sphere(0.1, Vector3(0, 0, 0), pants, Vector3(1, 1, 1), 0, 0.9, 10)
    k_hipL.cyl_y(0.078, 0.102, 0.45, Vector3(0, -0.225, 0), pants)
    k_hipL.box(Vector3(0.045, 0.16, 0.13), Vector3(-0.095, -0.22, 0.015), pants_dark)
    k_hipL.box(Vector3(0.05, 0.03, 0.135), Vector3(-0.095, -0.15, 0.015), pants)
    k_hipL.commit(hipL)
    var kneeL := Kit.group(hipL, Vector3(0, -0.45, 0), "KneeL")
    var k_kneeL = Kit.new()
    k_kneeL.sphere(0.078, Vector3(0, 0, 0), pants, Vector3(1, 1, 1), 0, 0.9, 10)
    k_kneeL.box(Vector3(0.125, 0.12, 0.05), Vector3(0, 0, 0.078), strap)
    k_kneeL.box(Vector3(0.1, 0.09, 0.02), Vector3(0, 0, 0.1), pants_dark)
    k_kneeL.cyl_y(0.064, 0.08, 0.4, Vector3(0, -0.2, 0), pants)
    k_kneeL.commit(kneeL)
    var ankleL := Kit.group(kneeL, Vector3(0, -0.4, 0), "AnkleL")
    var k_ankleL = Kit.new()
    k_ankleL.cyl_y(0.066, 0.074, 0.12, Vector3(0, 0.03, 0), boots, 10)
    k_ankleL.cyl_y(0.07, 0.07, 0.02, Vector3(0, 0.085, 0), strap, 10)
    k_ankleL.box(Vector3(0.115, 0.07, 0.245), Vector3(0, -0.04, 0.05), boots)
    k_ankleL.sphere(0.058, Vector3(0, -0.045, 0.175), boots, Vector3(1, 0.75, 1), 0, 0.8, 10)
    k_ankleL.box(Vector3(0.126, 0.026, 0.285), Vector3(0, -0.075, 0.055), sole, Vector3(0, 0, 0), 0, 0.95)
    k_ankleL.box(Vector3(0.06, 0.012, 0.05), Vector3(0, -0.052, 0.04), strap)
    k_ankleL.commit(ankleL)
    var hipR := Kit.group(_root, Vector3(0.105, 0.9375, 0), "HipR")
    var k_hipR = Kit.new()
    k_hipR.sphere(0.1, Vector3(0, 0, 0), pants, Vector3(1, 1, 1), 0, 0.9, 10)
    k_hipR.cyl_y(0.078, 0.102, 0.45, Vector3(0, -0.225, 0), pants)
    k_hipR.box(Vector3(0.045, 0.16, 0.13), Vector3(0.095, -0.22, 0.015), pants_dark)
    k_hipR.box(Vector3(0.05, 0.03, 0.135), Vector3(0.095, -0.15, 0.015), pants)
    k_hipR.commit(hipR)
    var kneeR := Kit.group(hipR, Vector3(0, -0.45, 0), "KneeR")
    var k_kneeR = Kit.new()
    k_kneeR.sphere(0.078, Vector3(0, 0, 0), pants, Vector3(1, 1, 1), 0, 0.9, 10)
    k_kneeR.box(Vector3(0.125, 0.12, 0.05), Vector3(0, 0, 0.078), strap)
    k_kneeR.box(Vector3(0.1, 0.09, 0.02), Vector3(0, 0, 0.1), pants_dark)
    k_kneeR.cyl_y(0.064, 0.08, 0.4, Vector3(0, -0.2, 0), pants)
    k_kneeR.commit(kneeR)
    var ankleR := Kit.group(kneeR, Vector3(0, -0.4, 0), "AnkleR")
    var k_ankleR = Kit.new()
    k_ankleR.cyl_y(0.066, 0.074, 0.12, Vector3(0, 0.03, 0), boots, 10)
    k_ankleR.cyl_y(0.07, 0.07, 0.02, Vector3(0, 0.085, 0), strap, 10)
    k_ankleR.box(Vector3(0.115, 0.07, 0.245), Vector3(0, -0.04, 0.05), boots)
    k_ankleR.sphere(0.058, Vector3(0, -0.045, 0.175), boots, Vector3(1, 0.75, 1), 0, 0.8, 10)
    k_ankleR.box(Vector3(0.126, 0.026, 0.285), Vector3(0, -0.075, 0.055), sole, Vector3(0, 0, 0), 0, 0.95)
    k_ankleR.box(Vector3(0.06, 0.012, 0.05), Vector3(0, -0.052, 0.04), strap)
    k_ankleR.commit(ankleR)
    _upper = upper
    _left_shoulder = shoulderL
    _right_shoulder = shoulderR
    _left_elbow = elbowL
    _right_elbow = elbowR
    _left_hip = hipL
    _right_hip = hipR
    _left_knee = kneeL
    _right_knee = kneeR
    _left_ankle = ankleL
    _right_ankle = ankleR
    _head = head_pivot
    _left_shoulder.scale = Vector3.ONE * ARM_SCALE
    _right_shoulder.scale = Vector3.ONE * ARM_SCALE
    _add_gfx_details(jacket)
    _aim_pivot = Kit.group(upper, Vector3(0, 0.5525, 0), "AimPivot")
    _holder = Kit.group(_aim_pivot, Vector3.ZERO, "WeaponHolder")
    _holder.rotation.y = PI
    _holder.visible = false
    # Капсула попаданий повторяет позу приседа.
    _hit_body = StaticBody3D.new()
    _hit_body.collision_layer = 2
    _hit_body.collision_mask = 0
    add_child(_hit_body)
    _hit_shape = CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.32
    capsule.height = 1.90
    _hit_shape.shape = capsule
    _hit_shape.position.y = 0.95
    _hit_body.add_child(_hit_shape)
    # мягкая тень под ногами
    var disc := CylinderMesh.new()
    disc.top_radius = 0.55
    disc.bottom_radius = 0.55
    disc.height = 0.01
    disc.radial_segments = 12
    disc.rings = 1
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0, 0, 0, 0.35)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    disc.material = mat
    var blob := MeshInstance3D.new()
    blob.mesh = disc
    blob.position = Vector3(0.0, 0.012, 0.0)
    blob.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(blob)
    _blob = blob
    animate(0.0, false, 0.0)


## Тело только для солнца: камера его не видит (слой 2), но тень на землю оно отбрасывает.
## Так игрок видит собственную тень, не видя собственной модели изнутри.
func hide_from_camera(value: bool) -> void:
    if _camera_hidden == value:
        return
    _camera_hidden = value
    _apply_layers(self, GraphicsFX.SHADOW_PROXY_LAYER if value else 1)


func _apply_layers(node: Node, mask: int) -> void:
    var item := node as VisualInstance3D
    if item != null:
        item.layers = mask
    for child in node.get_children():
        _apply_layers(child, mask)


## Настоящие тени от солнца включены — чёрное «пятно» под ногами больше не нужно.
func set_real_shadows(value: bool) -> void:
    if _blob != null:
        _blob.visible = not value


func _glow_box(kit, size: Vector3, pos: Vector3, tint: Color) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    kit.add_mesh(mesh, Transform3D(Basis.IDENTITY, pos), Kit.glow_material(tint))


## Stage129: дополнительные мелкие детали. Ступень 1 видна на средней и высокой графике,
## ступень 2 — только на высокой (на низкой скрыто всё). См. graphics_fx.gd::detail_group.
func _add_gfx_details(jacket: Color) -> void:
    var vest := jacket.darkened(0.55)
    var vest_dark := jacket.darkened(0.68)
    var pack_lid := jacket.darkened(0.4)
    var pants_dark := Color(0.17, 0.18, 0.15)
    var boots := Color(0.12, 0.10, 0.08)
    var strap := Color(0.06, 0.06, 0.07)
    var metal := Color(0.38, 0.38, 0.42)
    var olive := Color(0.22, 0.27, 0.16)
    var tan := Color(0.55, 0.47, 0.32)
    var black := Color(0.03, 0.03, 0.035)
    var head_mesh := _head.get_node("HeadMesh") as Node3D
    # ---------------------------------------------------------- ступень 1 (средняя + высокая)
    var t1_body := GraphicsFX.detail_group(_upper, 1, "GfxBody1")
    var k1 = Kit.new()
    k1.box(Vector3(0.07, 0.03, 0.006), Vector3(0.1, 0.5, 0.1985), Color(0.9, 0.75, 0.2))      # нашивка на груди
    k1.box(Vector3(0.045, 0.085, 0.035), Vector3(-0.17, 0.43, 0.2), strap)                     # рация
    k1.cyl_y(0.004, 0.003, 0.16, Vector3(-0.17, 0.57, 0.2), strap, 6)                           # антенна
    k1.cyl_y(0.048, 0.048, 0.16, Vector3(0.27, 0.2, -0.12), olive, 12, 0.1, 0.8)               # фляга
    k1.cyl_y(0.02, 0.02, 0.03, Vector3(0.27, 0.29, -0.12), strap, 8)                            # крышка фляги
    k1.commit(t1_body)
    var t1_head := GraphicsFX.detail_group(head_mesh, 1, "GfxHead1")
    var kh1 = Kit.new()
    kh1.box(Vector3(0.1, 0.05, 0.04), Vector3(0, 0.88, -0.165), jacket.darkened(0.45))         # противовес шлема
    kh1.box(Vector3(0.012, 0.03, 0.12), Vector3(0.147, 0.89, 0.0), metal, Vector3(0, 0, 0), 0.6, 0.4)   # боковые рейки
    kh1.box(Vector3(0.012, 0.03, 0.12), Vector3(-0.147, 0.89, 0.0), metal, Vector3(0, 0, 0), 0.6, 0.4)
    kh1.commit(t1_head)
    for side in [-1.0, 1.0]:
        var elbow: Node3D = _left_elbow if side < 0.0 else _right_elbow
        var t1_arm := GraphicsFX.detail_group(elbow, 1, "GfxArm1")
        var ka1 = Kit.new()
        ka1.cyl_y(0.053, 0.053, 0.026, Vector3(0, -0.2, 0), strap, 10)                         # ремешок часов
        _glow_box(ka1, Vector3(0.008, 0.03, 0.03), Vector3(side * 0.056, -0.2, 0.0), Color(0.45, 1.0, 0.65))
        ka1.commit(t1_arm)
        var ankle: Node3D = _left_ankle if side < 0.0 else _right_ankle
        var t1_boot := GraphicsFX.detail_group(ankle, 1, "GfxBoot1")
        var kb1 = Kit.new()
        for i in range(4):                                                                      # шнуровка
            kb1.box(Vector3(0.07, 0.005, 0.012), Vector3(0, -0.0025, float(i) * 0.035), Color(0.7, 0.68, 0.6))
        kb1.commit(t1_boot)
    var t1_leg := GraphicsFX.detail_group(_right_hip, 1, "GfxLeg1")
    var kl1 = Kit.new()
    kl1.box(Vector3(0.04, 0.14, 0.065), Vector3(0.105, -0.2, 0.105), strap)                    # кобура на бедре
    kl1.box(Vector3(0.024, 0.05, 0.045), Vector3(0.105, -0.115, 0.115), Color(0.08, 0.08, 0.09))
    kl1.box(Vector3(0.044, 0.012, 0.07), Vector3(0.105, -0.14, 0.105), pants_dark)
    kl1.commit(t1_leg)
    # ---------------------------------------------------------- ступень 2 (только высокая)
    var t2_body := GraphicsFX.detail_group(_upper, 2, "GfxBody2")
    var k2 = Kit.new()
    for row in range(4):                                                                        # ряды MOLLE на плите
        k2.box(Vector3(0.28, 0.01, 0.004), Vector3(0, 0.3 + float(row) * 0.05, 0.1985), strap)
    for side in [-1.0, 1.0]:
        k2.box(Vector3(0.03, 0.012, 0.035), Vector3(side * 0.145, 0.62, 0.0), metal, Vector3(0, 0, 0), 0.7, 0.35)   # пряжки лямок
        k2.box(Vector3(0.05, 0.13, 0.1), Vector3(side * 0.2, 0.46, -0.31), pack_lid)           # боковые карманы рюкзака
    k2.sphere(0.03, Vector3(0.12, 0.44, 0.215), olive, Vector3(1, 1.2, 1), 0.2, 0.7, 10)       # граната
    k2.box(Vector3(0.012, 0.05, 0.008), Vector3(0.125, 0.47, 0.238), metal)
    k2.cyl_x(0.012, 0.012, 0.004, Vector3(0.14, 0.495, 0.225), metal, 8)
    k2.cyl_x(0.052, 0.052, 0.3, Vector3(0, 0.735, -0.27), tan, 12, 0.0, 0.9)                   # скатка на рюкзаке
    for roll_x in [-0.09, 0.09]:
        k2.cyl_x(0.055, 0.055, 0.014, Vector3(roll_x, 0.735, -0.27), strap, 12)
    _glow_box(k2, Vector3(0.012, 0.09, 0.012), Vector3(0.13, 0.3, -0.381), Color(0.45, 1.0, 0.4))   # химсвет
    k2.cyl_y(0.07, 0.07, 0.026, Vector3(0, 0.665, 0), vest_dark, 12)                           # воротник
    k2.commit(t2_body)
    var t2_head := GraphicsFX.detail_group(head_mesh, 2, "GfxHead2")
    var kh2 = Kit.new()
    for ear in [-1.0, 1.0]:                                                                     # гарнитура
        kh2.cyl_x(0.042, 0.042, 0.03, Vector3(ear * 0.135, 0.795, 0.0), strap, 12)
    kh2.box(Vector3(0.005, 0.005, 0.1), Vector3(-0.1, 0.752, 0.075), strap, Vector3(0, 28, 0))   # микрофон
    kh2.sphere(0.012, Vector3(-0.068, 0.742, 0.118), strap, Vector3.ONE, 0.2, 0.6, 8)
    _glow_box(kh2, Vector3(0.02, 0.006, 0.003), Vector3(-0.074, 0.962, 0.1465), Color(0.7, 0.9, 1.0))   # блики очков
    _glow_box(kh2, Vector3(0.02, 0.006, 0.003), Vector3(0.034, 0.962, 0.1465), Color(0.7, 0.9, 1.0))
    var rng := RandomNumberGenerator.new()
    rng.seed = 4242
    var center := Vector3(0, 0.8945, -0.022)
    var radii := Vector3(0.14 * 1.04, 0.14 * 0.82, 0.14 * 1.14)
    var camo := [Color(0.18, 0.22, 0.12), Color(0.28, 0.24, 0.14), Color(0.12, 0.14, 0.10)]
    for i in range(7):                                                                          # камуфляжные нашлёпки на шлеме
        var theta := rng.randf() * TAU
        var phi := rng.randf_range(0.15, 1.0)
        var unit := Vector3(sin(phi) * cos(theta), cos(phi), sin(phi) * sin(theta))
        var spot := center + unit * radii * 1.01
        var normal := (unit / radii).normalized()
        var patch := BoxMesh.new()
        patch.size = Vector3(0.05, 0.008, 0.04)
        kh2.add_mesh(patch, Transform3D(Basis(Quaternion(Vector3.UP, normal)), spot), Kit.material(camo[i % 3], 0.0, 0.9))
    kh2.commit(t2_head)
    for side in [-1.0, 1.0]:
        var shoulder: Node3D = _left_shoulder if side < 0.0 else _right_shoulder
        var t2_sh := GraphicsFX.detail_group(shoulder, 2, "GfxArm2a")
        var ks2 = Kit.new()
        ks2.cyl_y(0.07, 0.07, 0.04, Vector3(0, -0.12, 0), jacket.lightened(0.3), 10)           # нарукавная повязка
        ks2.commit(t2_sh)
        var elbow2: Node3D = _left_elbow if side < 0.0 else _right_elbow
        var t2_arm := GraphicsFX.detail_group(elbow2, 2, "GfxArm2b")
        var ke2 = Kit.new()
        for i in range(4):                                                                      # костяшки перчатки
            ke2.box(Vector3(0.014, 0.016, 0.012), Vector3(-0.027 + float(i) * 0.018, -0.268, 0.066), Color(0.22, 0.22, 0.25))
        for finger_x in [-0.02, 0.0, 0.02]:                                                     # промежутки между пальцами
            ke2.box(Vector3(0.004, 0.048, 0.1), Vector3(finger_x, -0.365, 0.03), strap)
        ke2.commit(t2_arm)
        var hip: Node3D = _left_hip if side < 0.0 else _right_hip
        var t2_hip := GraphicsFX.detail_group(hip, 2, "GfxLeg2a")
        var kp2 = Kit.new()
        kp2.cyl_x(0.008, 0.008, 0.006, Vector3(side * 0.1205, -0.15, 0.015), metal, 8, 0.7, 0.35)   # пуговицы карманов
        kp2.commit(t2_hip)
        var knee: Node3D = _left_knee if side < 0.0 else _right_knee
        var t2_knee := GraphicsFX.detail_group(knee, 2, "GfxLeg2b")
        var kk2 = Kit.new()
        kk2.box(Vector3(0.13, 0.012, 0.054), Vector3(0, 0.062, 0.078), strap)                  # края наколенников
        kk2.box(Vector3(0.13, 0.012, 0.054), Vector3(0, -0.062, 0.078), strap)
        kk2.commit(t2_knee)
        var ankle2: Node3D = _left_ankle if side < 0.0 else _right_ankle
        var t2_boot := GraphicsFX.detail_group(ankle2, 2, "GfxBoot2")
        var kb2 = Kit.new()
        for i in range(6):                                                                      # протектор по бокам подошвы
            kb2.box(Vector3(0.131, 0.012, 0.012), Vector3(0, -0.075, -0.06 + float(i) * 0.05), black)
        kb2.box(Vector3(0.012, 0.07, 0.02), Vector3(side * 0.072, 0.03, 0.0), metal, Vector3(0, 0, 0), 0.7, 0.35)   # молния
        kb2.box(Vector3(0.1, 0.05, 0.04), Vector3(0, -0.04, -0.07), boots.darkened(0.3))       # задник ботинка
        kb2.commit(t2_boot)


func set_crouching(value: bool, delta: float) -> void:
    _crouch_alpha = move_toward(_crouch_alpha, 1.0 if value else 0.0, delta * 4.5)
    var capsule: CapsuleShape3D = _hit_shape.shape
    capsule.height = lerpf(1.90, 1.28, _crouch_alpha)
    _hit_shape.position.y = capsule.height * 0.5


## Нокаут: игрок стоит на коленях, опирается на руки и может ползти.
func set_downed(value: bool, delta: float) -> void:
    _downed_alpha = move_toward(_downed_alpha, 1.0 if value else 0.0, delta * 3.0)


## Оружие в руках модели ("" = пусто). Модель оружия строится из тех же деталей, что и
## оружие от первого лица (включая коллиматор на автоматах).
func set_weapon(id: String, collimator: bool = false) -> void:
    if _holder == null:
        return
    collimator = collimator and Weapons.has_collimator(id)
    if id == _weapon_id and collimator == _weapon_attach:
        return
    _weapon_id = id
    _weapon_attach = collimator
    for child in _holder.get_children():
        child.free()
    _weapon_refs = {}
    if id == "" or not Weapons.has(id):
        _weapon_id = ""
        _holder.visible = false
        return
    var def: Dictionary = Weapons.get_def(id)
    var kind := str(def["kind"])
    _weapon_refs = WeaponModels.build(kind, _holder, false, collimator)
    # Stage105: у модели игрока своя кисть — отдельная перчатка меча (для вида от первого лица) не нужна.
    var fp_hand := _holder.find_child("RightHandGrip", true, false)
    if fp_hand != null:
        fp_hand.get_parent().remove_child(fp_hand)
        fp_hand.free()
    var grips: Dictionary = Weapons.GRIPS.get(kind, {})
    _weapon_cls = str(grips.get("cls", "rifle"))
    _grip_r = grips.get("r", Vector3.ZERO)
    _has_grip_l = grips.has("l")
    _grip_l = grips.get("l", Vector3.ZERO)
    _holder.scale = Vector3.ONE * float(grips.get("scale", 0.6))
    _holder.visible = true
    _flash_t = 0.0
    var flash = _weapon_refs.get("flash")
    if flash != null:
        (flash as Node3D).visible = false
    if _camera_hidden:
        _apply_layers(_holder, GraphicsFX.SHADOW_PROXY_LAYER)


## Куда смотрит игрок: pitch > 0 — вверх (как у камеры), aiming — прицеливание.
func set_aim_state(aiming: bool, pitch: float) -> void:
    _aiming = aiming
    _pitch = clampf(pitch, -1.3, 1.3)


## Выстрел/удар: отдача оружия, вспышка, взмах ножа.
func play_attack() -> void:
    if _weapon_id == "":
        return
    if _weapon_cls == "melee":
        _swing = 1.0
        return
    _kick = 1.0
    _flash_t = 0.05
    var flash = _weapon_refs.get("flash")
    if flash != null:
        (flash as Node3D).visible = true


## Реакция на попадание: корпус дёргается назад, голова откидывается, руки подбрасывает.
func hit_react() -> void:
    _flinch = 1.0
    _flinch_side = -_flinch_side


## Перезарядка (приходит по сети): оружие опускается и наклоняется на время duration.
func play_reload(duration: float) -> void:
    if _weapon_id == "" or _weapon_cls == "melee":
        return
    _reload_dur = maxf(duration, 0.4)
    _reload_t = 1.0


## Дуло оружия в мировых координатах (для трассеров и звука); без оружия — уровень груди.
func muzzle_global() -> Vector3:
    var flash = _weapon_refs.get("flash")
    if flash != null and is_instance_valid(flash):
        return (flash as Node3D).global_position
    return global_position + Vector3(0, 1.4, 0)


## Окно выброса гильз в мировых координатах (Vector3.INF — если у оружия его нет).
func eject_global() -> Vector3:
    if _holder == null or not _weapon_refs.has("eject"):
        return Vector3.INF
    return _holder.to_global(_weapon_refs["eject"] as Vector3)


## Для боя: скорость, направление и прыжок определяются по смещению модели между кадрами.
func auto_animate(delta: float) -> void:
    var speed := 0.0
    var fwd := _move_fwd
    var moving := false
    if _has_last and delta > 0.0:
        var moved := position - _last_pos
        _vy = lerpf(_vy, moved.y / delta, clampf(delta * 12.0, 0.0, 1.0))
        moved.y = 0.0
        speed = moved.length() / delta
        if moved.length() > 0.0005:
            moving = true
            var face := global_transform.basis.z
            face.y = 0.0
            face = face.normalized()
            fwd = moved.normalized().dot(face)
    _last_pos = position
    _has_last = true
    _speed = lerpf(_speed, speed, clampf(delta * 9.0, 0.0, 1.0))
    if moving:
        _move_fwd = lerpf(_move_fwd, fwd, clampf(delta * 8.0, 0.0, 1.0))
    _dir_sign = move_toward(_dir_sign, -1.0 if _move_fwd < -0.35 else 1.0, delta * 10.0)
    var airborne := position.y > GROUND_Y + 0.08
    _pose(delta, _speed, airborne)


## Для лобби (прежний вызов): walking = шаг со скоростью ~3 м/с.
func animate(_t: float, walking: bool, delta: float) -> void:
    _pose(delta, 3.2 if walking else 0.0, false)


## Единая поза: ходьба, бег, присед (и шаг в приседе), прыжок, оружие, голова.
func _pose(delta: float, speed: float, airborne: bool) -> void:
    if _upper == null:
        return
    var k: float = 1.0 if delta <= 0.0 else clampf(delta * 14.0, 0.0, 1.0)
    _clock += delta
    var c: float = _crouch_alpha
    var amt: float = clampf(speed / WALK_REF_SPEED, 0.0, 1.0)
    var run_target := 0.0
    if c < 0.5 and not airborne:
        run_target = clampf((speed - RUN_START) / (RUN_FULL - RUN_START), 0.0, 1.0)
    _run_blend = move_toward(_run_blend, run_target, delta * 5.0)
    _air_blend = move_toward(_air_blend, 1.0 if airborne else 0.0, delta * 8.0)
    if _was_air and not airborne:
        _land = clampf(absf(_vy) / 5.0, 0.35, 1.0)
    _was_air = airborne
    _land = move_toward(_land, 0.0, delta * 4.5)
    _flinch = move_toward(_flinch, 0.0, delta * 3.5)
    var r: float = _run_blend
    var air: float = _air_blend
    var ground: float = 1.0 - air
    _phase += delta * clampf(speed * 1.7, 4.0, 11.0)
    var ph: float = _phase
    var sgn: float = _dir_sign
    var sw: float = sin(ph) * sgn
    var cw: float = cos(ph) * sgn
    # --- ноги
    var amp: float = lerpf(0.62, 1.0, r) * amt * (1.0 - 0.45 * c) * ground
    var amp_cr: float = 0.5 * amt * ground
    var knee_amp: float = lerpf(0.55, 1.45, r)
    var hip_l_g: float = -amp * sw
    var hip_r_g: float = amp * sw
    var knee_l_g: float = 0.10 * amt + knee_amp * maxf(0.0, cw) * amt * ground
    var knee_r_g: float = 0.10 * amt + knee_amp * maxf(0.0, -cw) * amt * ground
    var hip_l_c: float = -CROUCH_HIP - amp_cr * sw
    var hip_r_c: float = -CROUCH_HIP + amp_cr * sw
    var knee_l_c: float = CROUCH_KNEE + 0.35 * maxf(0.0, cw) * amt * ground
    var knee_r_c: float = CROUCH_KNEE + 0.35 * maxf(0.0, -cw) * amt * ground
    var hip_l: float = lerpf(lerpf(hip_l_g, hip_l_c, c), -0.6, air)
    var hip_r: float = lerpf(lerpf(hip_r_g, hip_r_c, c), -0.1, air)
    var knee_l: float = lerpf(lerpf(knee_l_g, knee_l_c, c), 0.9, air)
    var knee_r: float = lerpf(lerpf(knee_r_g, knee_r_c, c), 1.2, air)
    # --- нокаут: колени на земле, голени назад; при ползке ноги поочерёдно подтягиваются
    var dn: float = _downed_alpha
    var crawl: float = clampf(speed / 1.2, 0.0, 1.0)
    if dn > 0.0:
        hip_l = lerpf(hip_l, -0.12 - 0.30 * sw * crawl, dn)
        hip_r = lerpf(hip_r, -0.12 + 0.30 * sw * crawl, dn)
        knee_l = lerpf(knee_l, 1.75, dn)
        knee_r = lerpf(knee_r, 1.75, dn)
    if _land > 0.0:
        hip_l -= _land * 0.30
        hip_r -= _land * 0.30
        knee_l += _land * 0.60
        knee_r += _land * 0.60
    _left_hip.rotation.x = lerpf(_left_hip.rotation.x, hip_l, k)
    _right_hip.rotation.x = lerpf(_right_hip.rotation.x, hip_r, k)
    _left_knee.rotation.x = lerpf(_left_knee.rotation.x, knee_l, k)
    _right_knee.rotation.x = lerpf(_right_knee.rotation.x, knee_r, k)
    # стопа остаётся параллельной земле
    _left_ankle.rotation.x = -(_left_hip.rotation.x + _left_knee.rotation.x) * 0.85
    _right_ankle.rotation.x = -(_right_hip.rotation.x + _right_knee.rotation.x) * 0.85
    # таз опускается ровно настолько, чтобы опорная нога стояла на земле (в прыжке — не опускается)
    var reach_l: float = THIGH * cos(_left_hip.rotation.x) + SHIN * cos(_left_hip.rotation.x + _left_knee.rotation.x)
    var reach_r: float = THIGH * cos(_right_hip.rotation.x) + SHIN * cos(_right_hip.rotation.x + _right_knee.rotation.x)
    var hip_y: float = ANKLE_Y + maxf(reach_l, reach_r)
    hip_y += sin(_clock * 2.0) * 0.004 * (1.0 - amt)
    hip_y = lerpf(hip_y, ANKLE_Y + THIGH + SHIN - 0.05, air)
    _left_hip.position.y = hip_y
    _right_hip.position.y = hip_y
    _upper.position.y = hip_y
    # --- корпус: наклон вперёд (присед, бег), скрутка при шаге; с оружием корпус не скручивается
    _hold_blend = move_toward(_hold_blend, 1.0 if _weapon_id != "" else 0.0, delta * 6.0)
    var lean: float = 0.24 * c + 0.05 * amt + 0.20 * r
    lean = lerpf(lean, 0.75, dn)
    lean += _land * 0.22 - _flinch * 0.22
    var twist: float = sin(ph) * sgn * (0.09 + 0.08 * r) * amt * (1.0 - _hold_blend) * ground
    _upper.rotation.x = lerpf(_upper.rotation.x, lean, k)
    _upper.rotation.y = lerpf(_upper.rotation.y, twist + _flinch * _flinch_side * 0.18, k)
    # боковой крен на шаге/беге, лёгкое дыхание в покое, дрожь при попадании
    var roll: float = sin(ph) * sgn * (0.025 + 0.04 * r) * amt * ground * (1.0 - 0.8 * _hold_blend) + _flinch * _flinch_side * 0.10
    _upper.rotation.z = lerpf(_upper.rotation.z, roll, k)
    var breath: float = 1.0 + sin(_clock * 1.9) * 0.010 * (1.0 - amt)
    _upper.scale = Vector3(1.0, breath, 1.0)
    # --- голова смотрит туда же, куда игрок (угол приходит по сети)
    _pitch_s = lerpf(_pitch_s, _pitch, k)
    _head.rotation.x = lerpf(_head.rotation.x, -clampf(_pitch_s, -0.9, 0.9) * 0.75 - _upper.rotation.x * 0.5 + _flinch * 0.45, k)
    _head.rotation.z = lerpf(_head.rotation.z, -_upper.rotation.z * 0.8 + sin(_clock * 0.7) * 0.015 * (1.0 - amt), k)
    # --- свободные руки (когда оружия нет): встречный мах, на бегу — согнуты и «качают»
    var arm: float = sin(ph) * sgn * lerpf(0.55, 0.95, r) * amt * (1.0 - 0.45 * c) * ground
    var idle: float = sin(_clock * 1.6) * 0.03 * (1.0 - amt)
    var arm_l_t: float = lerpf(arm, -0.55, c) * ground - 0.45 * air + idle - _flinch * 0.5
    var arm_r_t: float = lerpf(-arm, -0.55, c) * ground - 0.45 * air - idle - _flinch * 0.5
    var base_bend: float = lerpf(-0.30, -1.35, r)
    var bend_l_t: float = lerpf(base_bend - 0.35 * maxf(0.0, -sw) * amt, -1.0, c)
    var bend_r_t: float = lerpf(base_bend - 0.35 * maxf(0.0, sw) * amt, -1.0, c)
    if dn > 0.0:
        # руки тянутся вперёд и вниз к земле, при ползке работают поочерёдно
        arm_l_t = lerpf(arm_l_t, -0.9 + 0.45 * sw * crawl, dn)
        arm_r_t = lerpf(arm_r_t, -0.9 - 0.45 * sw * crawl, dn)
        bend_l_t = lerpf(bend_l_t, -0.35, dn)
        bend_r_t = lerpf(bend_r_t, -0.35, dn)
    _fa_l = lerpf(_fa_l, arm_l_t, k)
    _fa_r = lerpf(_fa_r, arm_r_t, k)
    _fe_l = lerpf(_fe_l, bend_l_t, k)
    _fe_r = lerpf(_fe_r, bend_r_t, k)
    _update_weapon(delta, k, r)


## Оружие в руках: поза «у бедра» / «у плеча» (прицеливание), низкая стойка на бегу,
## руки тянутся к хватам оружия (IK по двум костям). Без оружия — свободные руки.
func _update_weapon(delta: float, k: float, run: float) -> void:
    var has_weapon := _weapon_id != ""
    _aim_blend = move_toward(_aim_blend, 1.0 if (_aiming and has_weapon and _weapon_cls != "melee") else 0.0, delta * 7.0)
    _kick = move_toward(_kick, 0.0, delta * 9.0)
    _swing = move_toward(_swing, 0.0, delta / 0.35)
    _reload_t = move_toward(_reload_t, 0.0, delta / _reload_dur)
    if _flash_t > 0.0:
        _flash_t -= delta
        if _flash_t <= 0.0:
            var flash = _weapon_refs.get("flash")
            if flash != null:
                (flash as Node3D).visible = false
    if _hold_blend <= 0.001 and not has_weapon:
        _apply_free_arms()
        return
    var hip := Vector3(-0.20, -0.15, 0.30)
    var ads := hip
    match _weapon_cls:
        "rifle":
            hip = Vector3(-0.04, -0.05, 0.38)
            ads = Vector3(-0.03, 0.15, 0.38)
        "pistol":
            hip = Vector3(-0.08, -0.04, 0.32)
            ads = Vector3(-0.03, 0.13, 0.40)
    var low: float = run * (1.0 - _aim_blend)
    var pos: Vector3 = hip.lerp(ads, _aim_blend) + Vector3(0.0, -0.05, -0.05) * low
    pos.z -= _kick * 0.05
    var aim_pitch: float = _pitch_s if _weapon_cls != "melee" else 0.0
    var rot_x: float = -aim_pitch + 0.5 * low - _upper.rotation.x - _kick * 0.12
    if _swing > 0.0:
        var p: float = 1.0 - _swing
        rot_x += lerpf(-1.0, 0.9, p) * sin(p * PI)
        pos.z += 0.12 * sin(p * PI)
    if _reload_t > 0.0:
        var rp: float = 1.0 - _reload_t
        var wave: float = sin(clampf(rp * 1.15, 0.0, 1.0) * PI)
        rot_x += 0.55 * wave
        pos.y -= 0.12 * wave
        pos.x += 0.05 * wave
    _aim_pivot.rotation.x = rot_x
    _holder.position = pos
    # руки к хватам
    var hand_r: Vector3 = _upper.to_local(_holder.to_global(_grip_r))
    _solve_arm(_left_shoulder, _left_elbow, hand_r, Vector3(-0.7, -1.0, -0.4), _hold_blend, _fa_l, _fe_l)
    if _has_grip_l:
        var hand_l: Vector3 = _upper.to_local(_holder.to_global(_grip_l))
        _solve_arm(_right_shoulder, _right_elbow, hand_l, Vector3(0.7, -1.0, -0.4), _hold_blend, _fa_r, _fe_r)
    else:
        _set_shoulder(_right_shoulder, Quaternion(Basis.from_euler(Vector3(_fa_r, 0.0, 0.0))))
        _right_elbow.rotation.x = _fe_r


## Поворот плеча без потери масштаба руки.
func _set_shoulder(node: Node3D, q: Quaternion) -> void:
    node.basis = Basis(q).scaled(Vector3.ONE * ARM_SCALE)


func _apply_free_arms() -> void:
    _set_shoulder(_left_shoulder, Quaternion(Basis.from_euler(Vector3(_fa_l, 0.0, 0.0))))
    _set_shoulder(_right_shoulder, Quaternion(Basis.from_euler(Vector3(_fa_r, 0.0, 0.0))))
    _left_elbow.rotation.x = _fe_l
    _right_elbow.rotation.x = _fe_r


## Рука из двух костей тянется к точке target (пространство корпуса). pole — в какую
## сторону смотрит локоть. blend: 0 = свободная поза (free_sh/free_el), 1 = рука на цели.
func _solve_arm(shoulder: Node3D, elbow: Node3D, target: Vector3, pole: Vector3, blend: float, free_sh: float, free_el: float) -> void:
    var to_target := target - shoulder.position
    var raw_dist := to_target.length()
    var dist := clampf(raw_dist, 0.08, ARM_L1 + ARM_L2 - 0.004)
    var dir := to_target / raw_dist if raw_dist > 0.0001 else Vector3(0, 0, 1)
    var n := dir.cross(pole)
    if n.length() < 0.001:
        n = dir.cross(Vector3.DOWN)
    if n.length() < 0.001:
        n = Vector3.RIGHT
    n = n.normalized()
    var cos_a := (ARM_L1 * ARM_L1 + dist * dist - ARM_L2 * ARM_L2) / (2.0 * ARM_L1 * dist)
    var a := acos(clampf(cos_a, -1.0, 1.0))
    var u := dir.rotated(n, a)                      # направление плеча
    var elbow_pos := shoulder.position + u * ARM_L1
    var hand_pos := shoulder.position + dir * dist
    var f := (hand_pos - elbow_pos).normalized()    # направление предплечья
    var bx := n
    var by := -u
    var bz := bx.cross(by).normalized()
    var ik_basis := Basis(bx, by, bz)
    var q_free := Quaternion(Basis.from_euler(Vector3(free_sh, 0.0, 0.0)))
    _set_shoulder(shoulder, q_free.slerp(ik_basis.get_rotation_quaternion(), blend))
    # локоть гнётся вокруг оси X плеча: предплечье в покое смотрит по -Y
    var f_local := ik_basis.inverse() * f
    var theta := atan2(-f_local.z, -f_local.y)
    elbow.rotation.x = lerpf(free_el, theta, blend)
