class_name SwordFire
extends Node3D
## Stage102: настоящий огонь для меча CREATOR.
## - языки пламени вдоль клинка и на острие (CPUParticles3D, работает в режиме GL Compatibility);
## - искры/угольки, которые отлетают в мир и остаются позади при движении меча;
## - огненный шлейф при ударе (burst) — вместо прежних 15 «шариков» на твинах;
## - мерцающий тёплый свет и пульсирующее свечение клинка;
## - огненный взрыв на зомби (spawn_burst).
## Качество берётся из SwordFire.quality (1 низкая, 2 средняя, 3 высокая) — его выставляет battle.gd.

static var quality: int = 3
static var _tex: Texture2D = null
static var _flame_mesh: QuadMesh = null
static var _flame_mat: StandardMaterial3D = null

var _light: OmniLight3D
var _blade_mat: StandardMaterial3D
var _swing: CPUParticles3D
var _swing_left := 0.0
var _time := randf() * 10.0

# ------------------------------------------------------------------ общие ресурсы

static func _texture() -> Texture2D:
    if _tex == null:
        var g := Gradient.new()
        g.offsets = PackedFloat32Array([0.0, 0.40, 1.0])
        g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.5), Color(1, 1, 1, 0)])
        var t := GradientTexture2D.new()
        t.gradient = g
        t.fill = GradientTexture2D.FILL_RADIAL
        t.fill_from = Vector2(0.5, 0.5)
        t.fill_to = Vector2(1.0, 0.5)
        t.width = 64
        t.height = 64
        _tex = t
    return _tex

static func _mesh() -> QuadMesh:
    if _flame_mesh == null:
        _flame_mat = StandardMaterial3D.new()
        _flame_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _flame_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _flame_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
        _flame_mat.vertex_color_use_as_albedo = true
        _flame_mat.albedo_texture = _texture()
        _flame_mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
        _flame_mat.billboard_keep_scale = true
        _flame_mat.particles_anim_h_frames = 1
        _flame_mat.particles_anim_v_frames = 1
        _flame_mat.particles_anim_loop = false
        _flame_mesh = QuadMesh.new()
        _flame_mesh.size = Vector2(1, 1)
        _flame_mesh.material = _flame_mat
    return _flame_mesh

static func _ramp(kind: int) -> Gradient:
    var g := Gradient.new()
    if kind == 1:      # угольки: жёлтый -> оранжевый -> гаснут
        g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
        g.colors = PackedColorArray([Color(1.0, 0.95, 0.55, 1.0), Color(1.0, 0.45, 0.08, 0.9), Color(0.5, 0.08, 0.0, 0.0)])
    else:              # пламя: белое-жёлтое ядро -> оранжевый -> красный -> дым
        g.offsets = PackedFloat32Array([0.0, 0.22, 0.6, 1.0])
        g.colors = PackedColorArray([Color(1.0, 0.92, 0.55, 0.85), Color(1.0, 0.55, 0.1, 0.75), Color(0.85, 0.16, 0.02, 0.4), Color(0.18, 0.02, 0.0, 0.0)])
    return g

static func _curve(start: float, peak: float) -> Curve:
    var c := Curve.new()
    c.add_point(Vector2(0.0, start))
    c.add_point(Vector2(0.25, peak))
    c.add_point(Vector2(1.0, 0.05))
    return c

static func _emitter(parent: Node, name_: String, count: int, life: float, size_min: float, size_max: float, kind: int = 0) -> CPUParticles3D:
    var p := CPUParticles3D.new()
    p.name = name_
    p.amount = maxi(2, count)
    p.lifetime = life
    p.mesh = _mesh()
    p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    p.direction = Vector3(0, 1, 0)
    p.spread = 20.0
    p.gravity = Vector3.ZERO
    p.scale_amount_min = size_min
    p.scale_amount_max = size_max
    p.scale_amount_curve = _curve(0.5, 1.0)
    p.color_ramp = _ramp(kind)
    p.angle_min = 0.0
    p.angle_max = 360.0
    p.randomness = 0.6
    p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(p)
    return p

static func _amount_scale() -> float:
    return 0.5 if quality <= 1 else (0.75 if quality == 2 else 1.0)

# ------------------------------------------------------------------ меч

## Повесить огонь на модель меча (корень сцены creator_sword; +Y — вдоль клинка, остриё около y = 3.0).
static func attach(sword: Node3D) -> SwordFire:
    var fire := SwordFire.new()
    fire.name = "SwordFire"
    sword.add_child(fire)
    return fire

func _ready() -> void:
    var q := _amount_scale()
    # 1) основное пламя вдоль клинка (двигается вместе с мечом)
    var body := _emitter(self, "Flames", int(34.0 * q), 0.55, 0.50, 0.95)
    body.local_coords = true
    body.position = Vector3(0, 1.75, 0)
    body.emission_box_extents = Vector3(0.17, 1.2, 0.07)
    body.initial_velocity_min = 0.5
    body.initial_velocity_max = 1.1
    # 2) языки пламени на острие
    var tip := _emitter(self, "TipFlames", int(14.0 * q), 0.6, 0.55, 0.95)
    tip.local_coords = true
    tip.position = Vector3(0, 3.1, 0)
    tip.emission_box_extents = Vector3(0.1, 0.08, 0.06)
    tip.initial_velocity_min = 0.9
    tip.initial_velocity_max = 1.7
    tip.spread = 14.0
    # 3) угольки остаются в мире позади меча
    var embers := _emitter(self, "Embers", int(14.0 * q), 1.3, 0.05, 0.11, 1)
    embers.local_coords = false
    embers.position = Vector3(0, 1.8, 0)
    embers.emission_box_extents = Vector3(0.2, 1.2, 0.1)
    embers.initial_velocity_min = 0.5
    embers.initial_velocity_max = 1.4
    embers.spread = 70.0
    embers.gravity = Vector3(0, 0.6, 0)
    # 4) огненный шлейф при ударе (включается из battle.gd через swing_burst)
    _swing = _emitter(self, "SwingTrail", int(46.0 * q), 0.42, 0.45, 0.8)
    _swing.local_coords = false
    _swing.position = Vector3(0, 1.9, 0)
    _swing.emission_box_extents = Vector3(0.12, 1.15, 0.06)
    _swing.initial_velocity_min = 0.2
    _swing.initial_velocity_max = 0.7
    _swing.spread = 35.0
    _swing.emitting = false
    # 5) тёплый свет (на низкой графике отключён)
    if quality >= 2:
        _light = OmniLight3D.new()
        _light.name = "FireLight"
        _light.light_color = Color(1.0, 0.5, 0.16)
        _light.light_energy = 1.4
        _light.omni_range = 3.0
        _light.shadow_enabled = false
        _light.position = Vector3(0, 1.8, 0.4)
        add_child(_light)
    # 6) клинок светится изнутри
    var parent_node := get_parent()
    if parent_node != null:
        var blade := parent_node.find_child("mesh2", true, false) as CSGShape3D
        if blade != null and blade.get("material") is StandardMaterial3D:
            _blade_mat = (blade.get("material") as StandardMaterial3D).duplicate() as StandardMaterial3D
            _blade_mat.emission_enabled = true
            _blade_mat.emission = Color(1.0, 0.42, 0.08)
            _blade_mat.emission_energy_multiplier = 1.4
            blade.set("material", _blade_mat)

func _process(delta: float) -> void:
    _time += delta
    var flicker := 0.78 + 0.22 * sin(_time * 23.0) * sin(_time * 7.3 + 1.1) + randf_range(-0.08, 0.08)
    if _light != null:
        _light.light_energy = 1.5 * flicker
    if _blade_mat != null:
        _blade_mat.emission_energy_multiplier = 1.2 + 0.9 * flicker
    if _swing_left > 0.0:
        _swing_left -= delta
        if _swing_left <= 0.0:
            _swing.emitting = false

## Удар мечом: на короткое время клинок оставляет в воздухе огненный след.
func swing_burst(duration: float = 0.38) -> void:
    if _swing == null:
        return
    _swing_left = duration
    _swing.emitting = true
    if _light != null:
        _light.light_energy = 2.6

# ------------------------------------------------------------------ огонь на зомби

## Огненный взрыв в точке (в мире). Сам удаляется по окончании.
static func spawn_burst(parent: Node3D, pos: Vector3) -> void:
    if parent == null or not is_instance_valid(parent):
        return
    var q := _amount_scale()
    var holder := Node3D.new()
    holder.position = pos
    parent.add_child(holder)
    var flames := _emitter(holder, "BurstFlames", int(30.0 * q), 1.2, 0.5, 1.0)
    flames.local_coords = false
    flames.one_shot = true
    flames.explosiveness = 0.35
    flames.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    flames.emission_sphere_radius = 0.35
    flames.initial_velocity_min = 0.6
    flames.initial_velocity_max = 1.8
    flames.spread = 35.0
    flames.gravity = Vector3(0, 1.2, 0)
    flames.emitting = true
    var sparks := _emitter(holder, "BurstSparks", int(16.0 * q), 1.4, 0.05, 0.1, 1)
    sparks.local_coords = false
    sparks.one_shot = true
    sparks.explosiveness = 0.7
    sparks.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    sparks.emission_sphere_radius = 0.3
    sparks.initial_velocity_min = 1.5
    sparks.initial_velocity_max = 3.2
    sparks.spread = 80.0
    sparks.gravity = Vector3(0, 1.0, 0)
    sparks.emitting = true
    if holder.is_inside_tree():
        holder.get_tree().create_timer(1.8).timeout.connect(holder.queue_free)
