extends Node3D
## Stage129: графика высокого уровня — тени, солнце, погода (дождь / туман / гроза со звуками),
## а также «ступени детализации» моделей игрока и оружия.
##
## Уровни (число из battle.gd::_gfx_level): 1 низкая, 2 средняя, 3 высокая.
##   Низкая : ничего из этого не добавляется (ни теней, ни солнца, ни погоды, ни лишних деталей).
##   Средняя: РОВНО ПОЛОВИНА высокой — тени ближе и мельче (2 каскада, 70 м, атлас 2048),
##            солнце без шейдера неба (цветной фон + диск солнца), погода вполовину слабее
##            (в 2 раза меньше капель/тумана, без всплесков и без видимой молнии),
##            у моделей игрока и оружия показана половина «мелких деталей».
##   Высокая: тени 4 каскада до 140 м (атлас 4096), небо с солнцем + блик, фильтр кино-тонов,
##            полная погода, молния, всплески луж, мокрая земля, все детали моделей.
##
## Детали моделей: узлы из detail_group() лежат в группе "gfx_detail" и имеют meta "gfx_tier"
## (1 = видны на средней и высокой, 2 = только на высокой).
##
## Погода включается кнопкой в настройках паузы и работает только на средней/высокой графике.
## Звуки (дождь, ветер, гром) создаются кодом — внешних файлов не нужно.

const SETTINGS_PATH := "user://battle_settings.cfg"
const WEATHER_NAMES := ["Выкл", "Дождь", "Туман", "Гроза"]
const W_NONE := 0
const W_RAIN := 1
const W_FOG := 2
const W_STORM := 3
## Слой, на котором лежит «тело-тень» своего игрока: камера его не видит, а солнце — видит.
const SHADOW_PROXY_LAYER := 2

static var detail_tier: int = -1      # -1 = ещё не прочитано из настроек; 0 нет, 1 половина, 2 все
static var _sound_cache: Dictionary = {}

# ------------------------------------------------------------------ уровни и детали (static)

static func quality_to_level(quality: int) -> int:
    if quality > 0:
        return quality
    if not OS.has_feature("mobile"):
        return 3
    var win := DisplayServer.window_get_size()
    return 1 if mini(win.x, win.y) >= 1200 else 2


## Ступень детализации моделей: 0 / 1 / 2. Читает сохранённые настройки при первом обращении
## (чтобы лобби тоже учитывало выбранную графику).
static func tier() -> int:
    if detail_tier < 0:
        var cfg := ConfigFile.new()
        var quality := 0
        if cfg.load(SETTINGS_PATH) == OK:
            quality = clampi(int(cfg.get_value("general", "graphics", 0)), 0, 3)
        detail_tier = clampi(quality_to_level(quality) - 1, 0, 2)
    return detail_tier


static func set_level(level: int) -> void:
    var new_tier := clampi(level - 1, 0, 2)
    if new_tier == detail_tier:
        return
    detail_tier = new_tier
    refresh_details()


static func refresh_details() -> void:
    var loop := Engine.get_main_loop()
    if not (loop is SceneTree):
        return
    for node in (loop as SceneTree).get_nodes_in_group("gfx_detail"):
        var item := node as Node3D
        if item != null:
            item.visible = tier() >= int(item.get_meta("gfx_tier", 1))


## Узел для «мелких деталей»: виден только если ступень графики >= min_tier.
static func detail_group(parent: Node3D, min_tier: int, label: String) -> Node3D:
    var node := Node3D.new()
    node.name = label
    node.set_meta("gfx_tier", min_tier)
    node.add_to_group("gfx_detail")
    node.visible = tier() >= min_tier
    parent.add_child(node)
    return node


# ------------------------------------------------------------------ состояние

var level := 1
var effect := 1.0                 # 1.0 на высокой, 0.5 на средней
var weather_target := W_NONE
var weather_cur := W_NONE
var intensity := 0.0              # плавное включение/выключение погоды 0..1
var feet_y := 0.0                 # высота земли под игроком (ставит battle.gd)

var world: Node3D
var viewport: SubViewport
var camera: Camera3D
var sun: DirectionalLight3D
var env_node: WorldEnvironment
var env: Environment
var own_env := false              # дневное окружение создали мы (не «Титаник»)
var ground_flat := true           # плоская земля: можно рисовать всплески луж
var base: Dictionary = {}
var base_fog_enabled := true
var sun_base_energy := 1.0
var sun_base_color := Color.WHITE
var orig_sun: Dictionary = {}
var orig_transparent := true
var sky_mat: ProceduralSkyMaterial
var sky: Sky

var sun_disc: MeshInstance3D
var sun_halo: MeshInstance3D
var glare: TextureRect
var flash_rect: ColorRect
var rain: CPUParticles3D
var splash: CPUParticles3D
var mist: CPUParticles3D
var rain_mat: StandardMaterial3D
var mist_mat: StandardMaterial3D
var bolt: Node3D
var bolt_mat: StandardMaterial3D
var rain_player: AudioStreamPlayer
var wind_player: AudioStreamPlayer
var thunder_players: Array[AudioStreamPlayer] = []
var floor_mesh: MeshInstance3D
var floor_mat: StandardMaterial3D
var floor_base_color := Color.WHITE
var floor_base_rough := 1.0

var flash := 0.0
var _flash_events: Array = []
var _flash_clock := 99.0
var _strike_in := 6.0
var _thunder_queue: Array = []
var _thunder_flip := 0
var _rain_amount := -1
var _was_active := true
var _mist_amount := -1
var _wind_dir_x := 0.12


func _ready() -> void:
    set_process(true)


## Один раз при создании: запоминает исходные значения мира, чтобы вернуть их на низкой графике.
func setup(p_world: Node3D, p_viewport: SubViewport, p_camera: Camera3D, night_env: WorldEnvironment, flat_ground: bool) -> void:
    name = "GraphicsFX"
    world = p_world
    viewport = p_viewport
    camera = p_camera
    ground_flat = flat_ground
    orig_transparent = viewport.transparent_bg
    sun = world.get_node_or_null("Sun") as DirectionalLight3D
    if sun != null:
        orig_sun = {
            "energy": sun.light_energy,
            "color": sun.light_color,
            "shadow": sun.shadow_enabled,
            "xform": sun.transform,
            "sky_mode": sun.sky_mode,
        }
        sun_base_energy = sun.light_energy
        sun_base_color = sun.light_color
    if night_env != null and night_env.environment != null:
        env_node = night_env
        env = night_env.environment
        own_env = false
        base = {
            "fog_density": env.fog_density,
            "fog_color": env.fog_light_color,
            "ambient": env.ambient_light_energy,
        }
    else:
        env_node = WorldEnvironment.new()
        env_node.name = "DayEnvironment"
        world.add_child(env_node)
        own_env = true
    _build_sky_objects()
    _build_overlays()
    _build_weather_nodes()
    _build_audio()
    _find_floor()


## Применяет уровень графики и выбранную погоду. Безопасно вызывать сколько угодно раз.
func apply(p_level: int, p_weather: int) -> void:
    level = clampi(p_level, 1, 3)
    effect = 1.0 if level >= 3 else 0.5
    weather_target = p_weather if level >= 2 else W_NONE
    _apply_shadows()
    if own_env:
        _apply_day_environment()
    elif env != null:
        base_fog_enabled = env.fog_enabled
    _apply_sun_base()
    _apply_wet_floor(0.0)
    var sky_visible := own_env and level >= 2
    if sun_disc != null:
        sun_disc.visible = sky_visible
        sun_halo.visible = sky_visible
    if glare != null and not sky_visible:
        glare.visible = false
    if level < 2:
        # Низкая: гасим погоду мгновенно.
        weather_cur = W_NONE
        intensity = 0.0
        _flash_events.clear()
        flash = 0.0
        _stop_weather_nodes()
    _rain_amount = -1
    _mist_amount = -1
    _was_active = true


# ------------------------------------------------------------------ тени и солнце

func _apply_shadows() -> void:
    if sun == null:
        return
    if level >= 2:
        sun.shadow_enabled = true
        sun.shadow_bias = 0.04
        sun.shadow_normal_bias = 1.2
        sun.shadow_blur = 1.2 if level >= 3 else 1.0
        if level >= 3:
            sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
            sun.directional_shadow_max_distance = 140.0
            sun.directional_shadow_blend_splits = true
            RenderingServer.directional_shadow_atlas_set_size(4096, true)
            RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM)
        else:
            sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
            sun.directional_shadow_max_distance = 70.0
            sun.directional_shadow_blend_splits = false
            RenderingServer.directional_shadow_atlas_set_size(2048, true)
            RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_LOW)
    else:
        sun.shadow_enabled = bool(orig_sun.get("shadow", false))


func real_shadows() -> bool:
    return level >= 2 and sun != null


## Яркое солнце днём (режимы с дневной картой); на «Титанике» остаётся лунный свет как был.
func _apply_sun_base() -> void:
    if sun == null:
        return
    if own_env and level >= 2:
        sun.light_color = Color(1.0, 0.94, 0.82)
        sun_base_color = sun.light_color
        sun_base_energy = 1.25 if level >= 3 else 1.1
        sun.light_energy = sun_base_energy
        sun.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_AND_SKY
        # Солнце ниже к горизонту — длиннее и заметнее тени.
        sun.rotation_degrees = Vector3(-38.0, 35.0, 0.0)
    else:
        sun.light_color = orig_sun.get("color", Color.WHITE)
        sun.light_energy = float(orig_sun.get("energy", 1.0))
        sun_base_color = sun.light_color
        sun_base_energy = sun.light_energy
        if own_env:
            sun.transform = orig_sun.get("xform", sun.transform)
            sun.sky_mode = orig_sun.get("sky_mode", DirectionalLight3D.SKY_MODE_LIGHT_AND_SKY)


func _apply_day_environment() -> void:
    if level < 2:
        # Низкая: как было до обновления — мир без своего окружения.
        env_node.environment = null
        viewport.transparent_bg = orig_transparent
        return
    if env == null:
        env = Environment.new()
        sky_mat = ProceduralSkyMaterial.new()
        sky = Sky.new()
        sky.sky_material = sky_mat
    viewport.transparent_bg = false
    var day_top := Color(0.22, 0.42, 0.82)
    var day_hor := Color(0.64, 0.77, 0.92)
    var day_gnd := Color(0.55, 0.6, 0.55)
    sky_mat.sky_top_color = day_top
    sky_mat.sky_horizon_color = day_hor
    sky_mat.ground_horizon_color = day_hor
    sky_mat.ground_bottom_color = day_gnd
    sky_mat.sun_angle_max = 1.0
    sky_mat.sun_curve = 0.05
    var fog_color := Color(0.74, 0.82, 0.92)
    env.fog_enabled = true
    env.fog_light_color = fog_color
    env.fog_sky_affect = 0.0
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.tonemap_exposure = 1.0
    var amb := 1.0
    var fog_density := 0.0016
    var bg_color := day_hor
    if level >= 3:
        env.background_mode = Environment.BG_SKY
        env.sky = sky
        env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
        env.ambient_light_energy = amb
        env.fog_density = fog_density
        env.fog_sun_scatter = 0.25
        env.glow_enabled = true
        env.glow_intensity = 0.6
        env.glow_bloom = 0.04
        env.adjustment_enabled = true
        env.adjustment_saturation = 1.12
        env.adjustment_contrast = 1.06
    else:
        # Половина: без шейдера неба и без пост-обработки.
        amb = 0.85
        fog_density = 0.0008
        bg_color = Color(0.5, 0.68, 0.9)
        env.background_mode = Environment.BG_COLOR
        env.background_color = bg_color
        env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
        env.ambient_light_color = Color(0.62, 0.68, 0.8)
        env.ambient_light_energy = amb
        env.fog_density = fog_density
        env.fog_sun_scatter = 0.0
        env.glow_enabled = false
        env.adjustment_enabled = false
    env_node.environment = env
    base_fog_enabled = true
    base = {
        "fog_density": fog_density,
        "fog_color": fog_color,
        "ambient": amb,
        "sky_top": day_top,
        "sky_hor": day_hor,
        "sky_gnd": day_gnd,
        "bg": bg_color,
    }


func _build_sky_objects() -> void:
    var disc_mat := StandardMaterial3D.new()
    disc_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    disc_mat.albedo_color = Color(1.0, 0.97, 0.85)
    disc_mat.disable_fog = true
    var disc_mesh := SphereMesh.new()
    disc_mesh.radius = 38.0
    disc_mesh.height = 76.0
    disc_mesh.radial_segments = 16
    disc_mesh.rings = 8
    sun_disc = MeshInstance3D.new()
    sun_disc.name = "SunDisc"
    sun_disc.mesh = disc_mesh
    sun_disc.material_override = disc_mat
    sun_disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    sun_disc.visible = false
    add_child(sun_disc)
    var halo_mat := StandardMaterial3D.new()
    halo_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    halo_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    halo_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    halo_mat.albedo_color = Color(1.0, 0.86, 0.55, 0.16)
    halo_mat.disable_fog = true
    var halo_mesh := SphereMesh.new()
    halo_mesh.radius = 120.0
    halo_mesh.height = 240.0
    halo_mesh.radial_segments = 16
    halo_mesh.rings = 8
    sun_halo = MeshInstance3D.new()
    sun_halo.name = "SunHalo"
    sun_halo.mesh = halo_mesh
    sun_halo.material_override = halo_mat
    sun_halo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    sun_halo.visible = false
    add_child(sun_halo)


func _build_overlays() -> void:
    # Блик солнца на экране (когда смотришь на солнце) и вспышка молнии — рисуются поверх 3D.
    var gradient := Gradient.new()
    gradient.offsets = PackedFloat32Array([0.0, 0.12, 0.45, 1.0])
    gradient.colors = PackedColorArray([
        Color(1.0, 0.96, 0.82, 0.85),
        Color(1.0, 0.9, 0.65, 0.4),
        Color(1.0, 0.85, 0.55, 0.1),
        Color(1.0, 0.8, 0.5, 0.0),
    ])
    var tex := GradientTexture2D.new()
    tex.gradient = gradient
    tex.fill = GradientTexture2D.FILL_RADIAL
    tex.fill_from = Vector2(0.5, 0.5)
    tex.fill_to = Vector2(1.0, 0.5)
    tex.width = 256
    tex.height = 256
    glare = TextureRect.new()
    glare.name = "SunGlare"
    glare.texture = tex
    glare.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    glare.stretch_mode = TextureRect.STRETCH_SCALE
    glare.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var add_mat := CanvasItemMaterial.new()
    add_mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
    glare.material = add_mat
    glare.visible = false
    viewport.add_child(glare)
    flash_rect = ColorRect.new()
    flash_rect.name = "LightningFlash"
    flash_rect.color = Color(0.82, 0.88, 1.0, 0.0)
    flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    flash_rect.visible = false
    viewport.add_child(flash_rect)


# ------------------------------------------------------------------ погода: узлы

func _soft_texture(ring: bool) -> GradientTexture2D:
    var gradient := Gradient.new()
    if ring:
        gradient.offsets = PackedFloat32Array([0.0, 0.5, 0.75, 0.9, 1.0])
        gradient.colors = PackedColorArray([
            Color(1, 1, 1, 0.0), Color(1, 1, 1, 0.0), Color(1, 1, 1, 0.9), Color(1, 1, 1, 0.0), Color(1, 1, 1, 0.0),
        ])
    else:
        gradient.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
        gradient.colors = PackedColorArray([Color(1, 1, 1, 0.8), Color(1, 1, 1, 0.3), Color(1, 1, 1, 0.0)])
    var tex := GradientTexture2D.new()
    tex.gradient = gradient
    tex.fill = GradientTexture2D.FILL_RADIAL
    tex.fill_from = Vector2(0.5, 0.5)
    tex.fill_to = Vector2(1.0, 0.5)
    tex.width = 64
    tex.height = 64
    return tex


func _build_weather_nodes() -> void:
    # Капли дождя: тонкие вытянутые «чёрточки», летят вдоль скорости.
    rain_mat = StandardMaterial3D.new()
    rain_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    rain_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    rain_mat.albedo_color = Color(0.72, 0.8, 0.95, 0.0)
    var drop := BoxMesh.new()
    drop.size = Vector3(0.012, 0.55, 0.012)
    drop.material = rain_mat
    rain = CPUParticles3D.new()
    rain.name = "Rain"
    rain.emitting = false
    rain.amount = 700
    rain.lifetime = 0.55
    rain.local_coords = false
    rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    rain.emission_box_extents = Vector3(13.0, 0.2, 13.0)
    rain.direction = Vector3(0.12, -1.0, 0.04)
    rain.spread = 2.0
    rain.initial_velocity_min = 23.0
    rain.initial_velocity_max = 27.0
    rain.gravity = Vector3.ZERO
    rain.particle_flag_align_y = true
    rain.mesh = drop
    rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(rain)
    # Круги от капель на земле (только высокая графика и ровная земля).
    var ring_mat := StandardMaterial3D.new()
    ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    ring_mat.vertex_color_use_as_albedo = true
    ring_mat.albedo_texture = _soft_texture(true)
    ring_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    var plane := PlaneMesh.new()
    plane.size = Vector2(0.4, 0.4)
    plane.material = ring_mat
    var ramp := Gradient.new()
    ramp.offsets = PackedFloat32Array([0.0, 1.0])
    ramp.colors = PackedColorArray([Color(0.85, 0.9, 1.0, 0.7), Color(0.85, 0.9, 1.0, 0.0)])
    var grow := Curve.new()
    grow.add_point(Vector2(0.0, 0.25))
    grow.add_point(Vector2(1.0, 1.0))
    splash = CPUParticles3D.new()
    splash.name = "Splashes"
    splash.emitting = false
    splash.amount = 240
    splash.lifetime = 0.4
    splash.local_coords = false
    splash.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    splash.emission_box_extents = Vector3(9.0, 0.01, 9.0)
    splash.direction = Vector3.UP
    splash.spread = 0.0
    splash.initial_velocity_min = 0.0
    splash.initial_velocity_max = 0.0
    splash.gravity = Vector3.ZERO
    splash.scale_amount_curve = grow
    splash.color_ramp = ramp
    splash.mesh = plane
    splash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(splash)
    # Дымка тумана: большие мягкие облачка у земли.
    mist_mat = StandardMaterial3D.new()
    mist_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mist_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mist_mat.albedo_texture = _soft_texture(false)
    mist_mat.albedo_color = Color(0.82, 0.86, 0.9, 0.0)
    mist_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mist_mat.billboard_keep_scale = true
    mist_mat.vertex_color_use_as_albedo = true
    var puff := QuadMesh.new()
    puff.size = Vector2(7.0, 4.0)
    puff.material = mist_mat
    var mist_ramp := Gradient.new()
    mist_ramp.offsets = PackedFloat32Array([0.0, 0.3, 0.7, 1.0])
    mist_ramp.colors = PackedColorArray([
        Color(1, 1, 1, 0.0), Color(1, 1, 1, 0.22), Color(1, 1, 1, 0.22), Color(1, 1, 1, 0.0),
    ])
    mist = CPUParticles3D.new()
    mist.name = "Mist"
    mist.emitting = false
    mist.amount = 36
    mist.lifetime = 9.0
    mist.preprocess = 9.0
    mist.local_coords = false
    mist.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    mist.emission_box_extents = Vector3(22.0, 1.0, 22.0)
    mist.direction = Vector3(1.0, 0.0, 0.3)
    mist.spread = 25.0
    mist.initial_velocity_min = 0.3
    mist.initial_velocity_max = 0.8
    mist.gravity = Vector3.ZERO
    mist.scale_amount_min = 0.8
    mist.scale_amount_max = 1.6
    mist.color_ramp = mist_ramp
    mist.mesh = puff
    mist.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mist)
    bolt_mat = StandardMaterial3D.new()
    bolt_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    bolt_mat.albedo_color = Color(0.9, 0.94, 1.0)
    bolt_mat.disable_fog = true
    bolt = Node3D.new()
    bolt.name = "LightningBolt"
    bolt.visible = false
    add_child(bolt)


func _build_audio() -> void:
    rain_player = AudioStreamPlayer.new()
    rain_player.name = "RainSound"
    rain_player.volume_db = -80.0
    add_child(rain_player)
    wind_player = AudioStreamPlayer.new()
    wind_player.name = "WindSound"
    wind_player.volume_db = -80.0
    add_child(wind_player)
    for i in range(2):
        var player := AudioStreamPlayer.new()
        player.name = "Thunder%d" % i
        add_child(player)
        thunder_players.append(player)


func _stop_weather_nodes() -> void:
    if rain != null:
        rain.emitting = false
        splash.emitting = false
        mist.emitting = false
    if bolt != null:
        bolt.visible = false
    if rain_player != null:
        rain_player.stop()
        wind_player.stop()
    _thunder_queue.clear()
    if flash_rect != null:
        flash_rect.visible = false


func _find_floor() -> void:
    floor_mesh = world.get_node_or_null("Floor") as MeshInstance3D
    if floor_mesh == null or not floor_mesh.visible:
        floor_mesh = null
        return
    var mat := floor_mesh.material_override as StandardMaterial3D
    if mat == null:
        return
    floor_mat = mat
    floor_base_color = mat.albedo_color
    floor_base_rough = mat.roughness


func _apply_wet_floor(wet: float) -> void:
    if floor_mat == null:
        return
    floor_mat.albedo_color = floor_base_color.darkened(0.35 * wet)
    floor_mat.roughness = lerpf(floor_base_rough, 0.38, wet)


# ------------------------------------------------------------------ профили погоды

func _profile(weather: int) -> Dictionary:
    match weather:
        W_RAIN:
            return {"fog": 0.012, "tint": 0.7, "fog_col": Color(0.42, 0.46, 0.52), "sun": 0.4, "amb": 0.8,
                    "sky": Color(0.30, 0.33, 0.38), "sky_k": 0.55, "rain": 1.0, "wind": 0.12,
                    "rain_db": -15.0, "wind_db": -34.0, "wet": 0.8}
        W_FOG:
            return {"fog": 0.032, "tint": 1.0, "fog_col": Color(0.68, 0.72, 0.76), "sun": 0.55, "amb": 0.95,
                    "sky": Color(0.64, 0.68, 0.72), "sky_k": 0.5, "rain": 0.0, "wind": 0.04,
                    "rain_db": -80.0, "wind_db": -26.0, "wet": 0.0}
        W_STORM:
            return {"fog": 0.016, "tint": 0.7, "fog_col": Color(0.2, 0.22, 0.28), "sun": 0.22, "amb": 0.6,
                    "sky": Color(0.12, 0.13, 0.17), "sky_k": 0.85, "rain": 1.6, "wind": 0.4,
                    "rain_db": -9.0, "wind_db": -22.0, "wet": 1.0}
    return {"fog": 0.0, "tint": 0.0, "fog_col": Color.WHITE, "sun": 1.0, "amb": 1.0,
            "sky": Color.WHITE, "sky_k": 0.0, "rain": 0.0, "wind": 0.0,
            "rain_db": -80.0, "wind_db": -80.0, "wet": 0.0}


# ------------------------------------------------------------------ кадр

func _process(delta: float) -> void:
    if camera == null or not is_instance_valid(camera):
        return
    # Плавная смена погоды: старая гаснет, потом включается новая.
    if weather_cur != weather_target:
        intensity = move_toward(intensity, 0.0, delta / 2.0)
        if intensity <= 0.001:
            weather_cur = weather_target
            _rain_amount = -1
            _mist_amount = -1
    elif weather_cur != W_NONE:
        intensity = move_toward(intensity, 1.0, delta / 3.0)
    var cam_pos := camera.global_position
    _update_sky(cam_pos)
    if level < 2:
        return
    # Когда погоды нет, ничего не пересчитываем (экономим кадры на телефоне).
    var active := weather_cur != W_NONE or weather_cur != weather_target or flash > 0.0 or not _thunder_queue.is_empty()
    if not active and not _was_active:
        return
    _was_active = active
    var profile := _profile(weather_cur)
    _update_particles(cam_pos, profile)
    _update_lightning(delta, cam_pos)
    _update_env(profile)
    _update_audio(profile, delta)


func _update_sky(cam_pos: Vector3) -> void:
    if not own_env or level < 2 or sun == null:
        return
    var to_sun := sun.global_transform.basis.z.normalized()
    var k := intensity * effect
    sun_disc.global_position = cam_pos + to_sun * 1500.0
    sun_halo.global_position = cam_pos + to_sun * 1500.0
    var visible_sun := k < 0.7
    sun_disc.visible = visible_sun
    sun_halo.visible = visible_sun
    # Блик на экране: сильнее, когда смотришь прямо на солнце.
    var forward := -camera.global_transform.basis.z
    var facing := forward.dot(to_sun)
    if visible_sun and facing > 0.2 and level >= 2:
        var screen := viewport.get_visible_rect().size
        var point := camera.unproject_position(cam_pos + to_sun * 100.0)
        var side := screen.y * (1.5 if level >= 3 else 1.0)
        glare.size = Vector2(side, side)
        glare.position = point - glare.size * 0.5
        glare.modulate.a = clampf((facing - 0.2) / 0.8, 0.0, 1.0) * (0.55 if level >= 3 else 0.3) * (1.0 - k)
        glare.visible = true
    else:
        glare.visible = false


func _update_particles(cam_pos: Vector3, profile: Dictionary) -> void:
    var raining := float(profile["rain"]) > 0.0 and intensity > 0.02
    var misty := weather_cur == W_FOG and intensity > 0.02
    if raining:
        var amount := int(round((1500.0 if level >= 3 else 750.0) * float(profile["rain"])))
        amount = maxi(amount, 100)
        if amount != _rain_amount:
            _rain_amount = amount
            rain.amount = amount
            _wind_dir_x = float(profile["wind"])
            rain.direction = Vector3(_wind_dir_x, -1.0, 0.04)
        rain_mat.albedo_color = Color(0.72, 0.8, 0.95, 0.36 * intensity)
        rain.global_position = cam_pos + Vector3(0.0, 11.0, 0.0)
    rain.emitting = raining
    var splashing := raining and level >= 3 and ground_flat
    splash.emitting = splashing
    if splashing:
        splash.global_position = Vector3(cam_pos.x, feet_y + 0.04, cam_pos.z)
    if misty:
        var puffs := 36 if level >= 3 else 18
        if puffs != _mist_amount:
            _mist_amount = puffs
            mist.amount = puffs
        mist_mat.albedo_color = Color(0.82, 0.86, 0.9, intensity)
        mist.global_position = Vector3(cam_pos.x, feet_y + 1.4, cam_pos.z)
    mist.emitting = misty


func _update_env(profile: Dictionary) -> void:
    var k := intensity * effect
    var wet := float(profile["wet"]) * intensity * effect
    _apply_wet_floor(wet)
    if sun != null:
        sun.light_energy = sun_base_energy * lerpf(1.0, float(profile["sun"]), k) + flash * 2.5
        sun.light_color = sun_base_color.lerp(Color(0.8, 0.88, 1.0), clampf(flash, 0.0, 1.0))
    if env == null or base.is_empty():
        return
    var fog_base := float(base["fog_density"])
    var fog_goal := maxf(fog_base, float(profile["fog"]))
    env.fog_density = lerpf(fog_base, fog_goal, k)
    var fog_goal_color: Color = profile["fog_col"]
    if not own_env:
        fog_goal_color = fog_goal_color * 0.3   # ночью туман не должен светиться
        fog_goal_color.a = 1.0
    var base_fog_color: Color = base["fog_color"]
    env.fog_light_color = base_fog_color.lerp(fog_goal_color, clampf(k * float(profile["tint"]), 0.0, 1.0))
    env.fog_enabled = base_fog_enabled or k > 0.01
    env.ambient_light_energy = float(base["ambient"]) * lerpf(1.0, float(profile["amb"]), k) + flash * 1.2
    if own_env:
        var sky_goal: Color = profile["sky"]
        var sky_k := clampf(k * float(profile["sky_k"]), 0.0, 1.0)
        if level >= 3 and sky_mat != null:
            sky_mat.sky_top_color = (base["sky_top"] as Color).lerp(sky_goal, sky_k)
            sky_mat.sky_horizon_color = (base["sky_hor"] as Color).lerp(sky_goal, sky_k)
            sky_mat.ground_horizon_color = sky_mat.sky_horizon_color
            sky_mat.ground_bottom_color = (base["sky_gnd"] as Color).lerp(sky_goal, sky_k)
        else:
            env.background_color = (base["bg"] as Color).lerp(sky_goal, sky_k)
    if flash_rect != null:
        var screen := viewport.get_visible_rect().size
        flash_rect.position = Vector2.ZERO
        flash_rect.size = screen
        flash_rect.color = Color(0.82, 0.88, 1.0, clampf(flash, 0.0, 1.0) * 0.45 * effect)
        flash_rect.visible = flash > 0.01


func _update_audio(profile: Dictionary, delta: float) -> void:
    var quiet := 0.0 if level >= 3 else -4.0
    var rain_db := float(profile["rain_db"])
    var wind_db := float(profile["wind_db"])
    var want_rain := rain_db > -60.0 and intensity > 0.01
    var want_wind := wind_db > -60.0 and intensity > 0.01
    if want_rain:
        if not rain_player.playing:
            rain_player.stream = _sound("rain")
            rain_player.play()
        rain_player.volume_db = rain_db + quiet + linear_to_db(clampf(intensity, 0.001, 1.0))
    elif rain_player.playing:
        rain_player.stop()
    if want_wind:
        if not wind_player.playing:
            wind_player.stream = _sound("wind")
            wind_player.play()
        wind_player.volume_db = wind_db + quiet + linear_to_db(clampf(intensity, 0.001, 1.0))
    elif wind_player.playing:
        wind_player.stop()
    # Очередь грома: звук приходит позже вспышки (звук медленнее света).
    var index := 0
    while index < _thunder_queue.size():
        var entry: Array = _thunder_queue[index]
        entry[0] = float(entry[0]) - delta
        if float(entry[0]) <= 0.0:
            _play_thunder(float(entry[1]) + quiet)
            _thunder_queue.remove_at(index)
        else:
            index += 1


func _play_thunder(db: float) -> void:
    if thunder_players.is_empty():
        return
    _thunder_flip = (_thunder_flip + 1) % thunder_players.size()
    var player := thunder_players[_thunder_flip]
    player.stream = _sound("thunder1" if randf() < 0.5 else "thunder2")
    player.volume_db = db
    player.pitch_scale = randf_range(0.85, 1.1)
    player.play()


# ------------------------------------------------------------------ гроза

func _update_lightning(delta: float, cam_pos: Vector3) -> void:
    if weather_cur == W_STORM and intensity > 0.6 and weather_target == W_STORM:
        _strike_in -= delta
        if _strike_in <= 0.0:
            _strike(cam_pos)
            _strike_in = randf_range(5.0, 13.0)
    else:
        _strike_in = maxf(_strike_in, 3.0)
    # Огибающая вспышки: несколько быстрых импульсов, как у настоящей молнии.
    _flash_clock += delta
    var level_now := 0.0
    for event in _flash_events:
        var start := float(event[0])
        if _flash_clock >= start:
            level_now = maxf(level_now, float(event[1]) * exp(-(_flash_clock - start) * 9.0))
    flash = clampf(level_now, 0.0, 1.0)
    if bolt != null:
        bolt.visible = _flash_clock < 0.42 and bolt.get_child_count() > 0
    if _flash_clock > 2.0:
        _flash_events.clear()


func _strike(cam_pos: Vector3) -> void:
    var distance := randf_range(160.0, 900.0)
    var angle := randf() * TAU
    _flash_events = [[0.0, 0.65], [0.13, 1.0], [0.32, 0.5]]
    _flash_clock = 0.0
    if level >= 3:
        _build_bolt(cam_pos, distance, angle)
    var delay := clampf(distance / 340.0, 0.35, 3.2)
    var db := lerpf(-1.0, -13.0, clampf((distance - 160.0) / 740.0, 0.0, 1.0))
    _thunder_queue.append([delay, db])


func _build_bolt(cam_pos: Vector3, distance: float, angle: float) -> void:
    for child in bolt.get_children():
        child.queue_free()
    var thick := clampf(distance * 0.004, 0.6, 3.6)
    var ground := Vector3(cam_pos.x + cos(angle) * distance, feet_y, cam_pos.z + sin(angle) * distance)
    var top := ground + Vector3(randf_range(-40.0, 40.0), 330.0, randf_range(-40.0, 40.0))
    var points: Array[Vector3] = [top]
    var steps := 9
    for i in range(1, steps):
        var t := float(i) / float(steps)
        var p := top.lerp(ground, t)
        p += Vector3(randf_range(-14.0, 14.0), 0.0, randf_range(-14.0, 14.0))
        points.append(p)
    points.append(ground)
    for i in range(points.size() - 1):
        _bolt_segment(points[i], points[i + 1], thick)
    # Одна боковая ветка.
    var from_index := randi_range(2, 5)
    var branch_end: Vector3 = points[from_index] + Vector3(randf_range(-90.0, 90.0), -randf_range(60.0, 120.0), randf_range(-90.0, 90.0))
    _bolt_segment(points[from_index], branch_end, thick * 0.55)


func _bolt_segment(a: Vector3, b: Vector3, thick: float) -> void:
    var length := a.distance_to(b)
    if length < 0.01:
        return
    var segment := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(thick, thick, length)
    segment.mesh = box
    segment.material_override = bolt_mat
    segment.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    bolt.add_child(segment)
    segment.position = (a + b) * 0.5
    segment.basis = Basis.looking_at((b - a).normalized(), Vector3.RIGHT)


# ------------------------------------------------------------------ звуки (генерация кодом)

static func _sound(kind: String) -> AudioStreamWAV:
    if _sound_cache.has(kind):
        return _sound_cache[kind]
    var stream: AudioStreamWAV = null
    match kind:
        "rain":
            stream = _make_rain_loop()
        "wind":
            stream = _make_wind_loop()
        "thunder1":
            stream = _make_thunder(1)
        "thunder2":
            stream = _make_thunder(2)
    _sound_cache[kind] = stream
    return stream


static func _pcm_stream(samples: PackedFloat32Array, rate: int, looped: bool, peak: float) -> AudioStreamWAV:
    var top := 0.0001
    for value in samples:
        top = maxf(top, absf(value))
    var gain := peak / top
    var bytes := PackedByteArray()
    bytes.resize(samples.size() * 2)
    for i in range(samples.size()):
        bytes.encode_s16(i * 2, int(clampf(samples[i] * gain, -1.0, 1.0) * 32000.0))
    var stream := AudioStreamWAV.new()
    stream.format = AudioStreamWAV.FORMAT_16_BITS
    stream.mix_rate = rate
    stream.stereo = false
    stream.data = bytes
    if looped:
        stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
        stream.loop_begin = 0
        stream.loop_end = samples.size()
    return stream


## Бесшовная петля: берём чуть больше шума и подмешиваем «хвост» в начало.
static func _looped(raw: PackedFloat32Array, count: int, fade: int) -> PackedFloat32Array:
    var out := PackedFloat32Array()
    out.resize(count)
    for i in range(count):
        if i < fade:
            out[i] = lerpf(raw[count + i], raw[i], float(i) / float(fade))
        else:
            out[i] = raw[i]
    return out


static func _make_rain_loop() -> AudioStreamWAV:
    var rate := 22050
    var count := rate * 3
    var fade := 1500
    var rng := RandomNumberGenerator.new()
    rng.seed = 7741
    var raw := PackedFloat32Array()
    raw.resize(count + fade)
    var lp := 0.0
    var lp2 := 0.0
    for i in range(count + fade):
        var n := rng.randf() * 2.0 - 1.0
        lp += (n - lp) * 0.55
        lp2 += (lp - lp2) * 0.12
        var v := (lp - lp2) * 0.9                 # шипение без низких частот
        if rng.randf() < 0.004:                   # редкие удары капель
            v += (rng.randf() * 2.0 - 1.0) * 0.8
        raw[i] = v
    return _pcm_stream(_looped(raw, count, fade), rate, true, 0.6)


static func _make_wind_loop() -> AudioStreamWAV:
    var rate := 11025
    var count := rate * 4
    var fade := 1200
    var rng := RandomNumberGenerator.new()
    rng.seed = 5150
    var raw := PackedFloat32Array()
    raw.resize(count + fade)
    var lp := 0.0
    var lp2 := 0.0
    for i in range(count + fade):
        var n := rng.randf() * 2.0 - 1.0
        lp += (n - lp) * 0.03
        lp2 += (lp - lp2) * 0.05
        var swell := 0.65 + 0.35 * sin(TAU * float(i) / float(count) * 2.0)
        raw[i] = lp2 * swell
    return _pcm_stream(_looped(raw, count, fade), rate, true, 0.55)


static func _make_thunder(variant: int) -> AudioStreamWAV:
    var rate := 16000
    var seconds := 5.0 if variant == 1 else 4.0
    var count := int(float(rate) * seconds)
    var rng := RandomNumberGenerator.new()
    rng.seed = 900 + variant
    var out := PackedFloat32Array()
    out.resize(count)
    var lp1 := 0.0
    var lp2 := 0.0
    var lp3 := 0.0
    var ph1 := rng.randf() * TAU
    var ph2 := rng.randf() * TAU
    var decay_rate := 0.55 if variant == 1 else 0.75
    for i in range(count):
        var t := float(i) / float(rate)
        var n := rng.randf() * 2.0 - 1.0
        lp1 += (n - lp1) * 0.08
        lp2 += (lp1 - lp2) * 0.06
        lp3 += (lp2 - lp3) * 0.05
        var attack := 1.0 - exp(-t * 14.0)
        var decay := exp(-t * decay_rate)
        var roll := 0.65 + 0.35 * sin(t * 9.0 + ph1) * sin(t * 3.1 + ph2)
        var rumble := lp3 * 14.0 * attack * decay * roll
        var crack := n * exp(-t * 22.0) * 0.8                     # резкий треск в начале
        var echo := lp2 * 6.0 * exp(-(t - 1.4) * (t - 1.4) * 2.5) * 0.6   # второй раскат
        out[i] = rumble + crack + echo
    return _pcm_stream(out, rate, false, 0.92)
