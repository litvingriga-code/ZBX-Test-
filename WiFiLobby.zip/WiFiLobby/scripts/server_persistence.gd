extends Node
## Host-only snapshots. Does NOT keep Godot/ENet running while paused.
const DIRECTORY := "user://server_saves"
const SAVE_FILE := DIRECTORY + "/host_snapshot.json"
const INTERVAL := 60.0
var elapsed: float = 0.0

func _process(delta: float) -> void:
    if Net.role != "host":
        elapsed = 0.0
        return
    elapsed += delta
    if elapsed >= INTERVAL:
        elapsed = 0.0
        save_snapshot()

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
        if Net.role == "host":
            save_snapshot()

func _encode(value: Variant) -> String:
    return Marshalls.raw_to_base64(var_to_bytes(value))

func _decode(value: String) -> Variant:
    return bytes_to_var(Marshalls.base64_to_raw(value))

func save_snapshot() -> bool:
    if Net.role != "host":
        return false
    var err := DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(DIRECTORY))
    if err != OK:
        return false
    var state := {
        "roster": Net.roster.duplicate(true),
        "world_items": Net.world_items.duplicate(true),
        "battle_positions": Net.battle_positions.duplicate(true),
        "battle_yaws": Net.battle_yaws.duplicate(true),
        "battle_crouches": Net.battle_crouches.duplicate(true),
        "battle_health": Net.battle_health.duplicate(true),
        "battle_active": Net.battle_active,
        "host_nickname": GameState.nickname,
        "host_money": GameState.money,
        "host_inventory": GameState.inventory.duplicate(true),
        "host_equipment": GameState.equipment.duplicate(true),
        "host_battle_active": GameState.battle_active,
        "host_battle_inventory": GameState.battle_inventory.duplicate(true),
        "host_battle_equipment": GameState.battle_equipment.duplicate(true)
    }
    var envelope := {
        "schema": 2,
        "saved_unix": Time.get_unix_time_from_system(),
        "state_base64": _encode(state)
    }
    var temp := SAVE_FILE + ".tmp"
    var file := FileAccess.open(temp, FileAccess.WRITE)
    if file == null:
        return false
    file.store_string(JSON.stringify(envelope))
    file.flush()
    file.close()
    err = DirAccess.rename_absolute(ProjectSettings.globalize_path(temp), ProjectSettings.globalize_path(SAVE_FILE))
    if err != OK:
        push_warning("Server snapshot rename failed: %s" % err)
        return false
    return true

func read_snapshot() -> Dictionary:
    if not FileAccess.file_exists(SAVE_FILE):
        return {}
    var file := FileAccess.open(SAVE_FILE, FileAccess.READ)
    if file == null:
        return {}
    var envelope = JSON.parse_string(file.get_as_text())
    if not (envelope is Dictionary) or int(envelope.get("schema", 0)) != 2:
        return {}
    var encoded: String = str(envelope.get("state_base64", ""))
    if encoded.is_empty() or encoded.length() > 20000000:
        return {}
    var state = _decode(encoded)
    if state is Dictionary:
        return state
    return {}
