extends Control
## Мобильный сетевой бой. Все участники списка Host появляются на карте.
const Model = preload("res://scripts/low_poly_player.gd")
const TitanicMap = preload("res://scripts/titanic_map.gd")
const ZombieModel = preload("res://scripts/zombie_model.gd")
const EvacCutscene = preload("res://scripts/evac_cutscene.gd")
const TurretModel = preload("res://scripts/turret_model.gd")
const BattleShop = preload("res://scripts/battle_shop.gd")
const GraphicsFX = preload("res://scripts/graphics_fx.gd")
const CombatFX = preload("res://scripts/combat_fx.gd")
const UiGray = preload("res://scripts/ui_gray.gd")
var actors: Dictionary = {}
var viewport: SubViewport
var camera: Camera3D
var dropped_items: Array[Node3D] = []
var world_nodes: Dictionary = {}
var zombie_visuals: Dictionary = {}
var zombie_seen_at: Dictionary = {}
var zombie_last_pos: Dictionary = {}
var zombie_speeds: Dictionary = {}
# Stage85: звуки зомби (шаги, рычание, укус).
const ZOMBIE_SOUND_RANGE := 28.0
const ZOMBIE_VOLUME_DB := -11.0   # Stage103: общая тихая громкость звуков зомби (дБ)
const ZOMBIE_STRIDE := [1.5, 2.2, 2.0]
var zombie_step_dist: Dictionary = {}
var zombie_growl_in: Dictionary = {}
var zombie_prev_attack: Dictionary = {}
var zombie_sound_budget := 0
# Stage86: оптимизация для телефонов.
const QUALITY_NAMES := ["Авто", "Низкая", "Средняя", "Высокая"]
const ZOMBIE_CULL_DISTANCE := 95.0
var gfx_quality := 0                 # 0 авто, 1 низкая, 2 средняя, 3 высокая
var gfx_button: Button
var gfx_fx: GraphicsFX               # Stage129: тени, солнце, погода
var pause_fallback_mode := 0         # 0 выкл (по умолчанию), 1 авто (если оригинальной нет), 2 всегда
var pause_fallback: Button          # запасная кнопка паузы: отдельный слой, не зависит от раскладки
var pause_fallback_layer: CanvasLayer
var combat_fx: CombatFX              # Stage132: кровь, попадания
var blood_enabled := true            # кровь включена (работает только на высокой графике)
var blood_button: Button
var damage_overlay: TextureRect      # красная виньетка при уроне / низком HP
var damage_flash := 0.0
var _last_my_hp := 100
var fx_budget := 6                   # лимит эффектов попаданий за кадр (дробовик)
var _peer_life_seen: Dictionary = {}
var zombie_gore_done: Dictionary = {}
var zombie_hit_dir: Dictionary = {}
var weather_mode := 0                # 0 выкл, 1 дождь, 2 туман, 3 гроза
var weather_button: Button
var fps_label: Label                 # счётчик FPS в меню паузы
var fps_acc := 0.0
var zombie_anim_acc: Dictionary = {}
var turret_sound_budget := 0
static var _turret_tracer_material: StandardMaterial3D
var zombie_timer_label: Label
# Stage83: эвакуация вертолётом на 00:00.
var evac: EvacCutscene
# Stage84: магазины и турели.
var shop_panel: PanelContainer
var shop_button: Button
var near_shop := -1
var turret_nodes: Dictionary = {}
var turret_prev_age: Dictionary = {}
var turret_notice_label: Label
var turret_notice_left := 0.0
var refill_button: Button            # Stage90: «Купить патроны» при наведении на турель
var aimed_turret := -1
var evac_active := false
var evac_fade: ColorRect
var evac_bar_top: ColorRect
var evac_bar_bottom: ColorRect
var evac_caption: Label
var evac_played := false              # Stage87: личная сцена вертолёта уже показана
var wave_notice: Label                # подсказка сверху: дойти до точки / вертолёт ждёт
var wave_banner: Label                # «Началась N волна»
var wave_banner_left := 0.0
var zombie_map: Node3D
var pickup_button: Button
var weapon_buttons: Array[Button] = []
var active_weapon_slot := -1
var held_weapon_model: Node3D
var held_weapon_key := ""
var weapon_tween: Tween
var weapon_motion_pivot: Node3D
var wp_mag: Node3D
var wp_mag_rest := Vector3.ZERO
var wp_mag_rot_rest := Vector3.ZERO
var magazine_tween: Tween
var weapon_motion_time := 0.0
var weapon_jump_kick := 0.0
var weapon_walk_blend := 0.0
var weapon_sound: AudioStreamPlayer
const Weapons = preload("res://scripts/weapons.gd")
const WeaponModels = preload("res://scripts/weapon_models.gd")
const ItemModels = preload("res://scripts/item_models.gd")
const FpArms = preload("res://scripts/fp_arms.gd")
const COLLIMATOR_ZOOM := 1.25         # увеличение картинки при прицеливании через коллиматор
## true — использовать старую GLB-модель АК-47 вместо процедурной детализированной.
const USE_GLB_AK := false
# Смещение оружия за кадром (достать / убрать).
const HIDDEN_OFFSET := Vector3(0.13, -0.55, 0.13)
var weapon_refs: Dictionary = {}      # подвижные детали текущей модели
var mags: Dictionary = {}             # id оружия -> патроны в магазине
var fx_tween: Tween                   # затвор / цевьё / барабан
var scope_overlay: ColorRect
var collimator_reticle: Control
var _sent_hold_weapon := "?"          # что уже отправили остальным игрокам
var _sent_hold_aim := false
var _sent_hold_attach := false
var _remote_weapon_seen: Dictionary = {}   # peer -> оружие, чей звук доставания уже сыграли
var fire_queued := 0.0                # нажатие курка для одиночных режимов
var flash_time := 0.0
var shell_reload := false             # дробовик заряжается по одному патрону
var shell_timer := 0.0
var melee_flip := false
var melee_combo := 0                  # Stage106: номер удара в серии меча (0, 1, 2)
var melee_last_ms := 0
var look_sway := Vector2.ZERO
var last_tracer_color := Color(1.0, 0.78, 0.18)
var last_tracer_radius := 0.018
var dry_fire_cooldown := 0.0
var aiming := false
var aim_button: Button
var aim_touch := -1
var pickup_hint: VBoxContainer
var pickup_icon: TextureRect
var pickup_name: Label
var aimed_item_id := -1
var direction := Vector2.ZERO
var joystick_touch := -1
var look_touch := -1
var joystick_center := Vector2.ZERO
var stick: Control
var knob: ColorRect
var pitch := -0.28
var yaw := 0.0
var velocity_y := 0.0
var vel_h := Vector3.ZERO          # горизонтальная скорость (м/с), как в Source/CS2
var leaving_battle := false
var revive_progress := 0.0
var reviving := false
var revive_label: Label
var _my_state := 0                    # Net.ST_*: наш игрок жив / в нокауте / мёртв
var life_box: VBoxContainer           # Health bar2 под прицелом (нокаут)
var life_caption: Label
var health_bar2: ProgressBar
var end_life_button: Button
var end_life_dialog: ConfirmationDialog
var spectate_box: VBoxContainer       # подпись + кнопка «Выйти в лобби» под прицелом (смерть)
var spectate_label: Label
var leave_button: Button
var player_floor_y := 1.0             # Stage122: высота пола под игроком (палуба 1.0, верх ящика выше)
var death_view_left := -1.0           # Stage108: >= 0 — идёт 10-секундный вид сверху после смерти
var death_view_t := 0.0
var death_focus := Vector3.ZERO
var death_yaw := 0.0
var death_overlay: ColorRect
var death_label: Label
var death_marker: Node3D
var death_buttons: HBoxContainer      # Stage109: «Лобби» и «Следить за игроками» на красном экране (если есть живые)
var death_lobby_btn: Button
var death_spectate_btn: Button
var death_spectating := false          # игрок выбрал наблюдение за живыми после смерти
var spec_focus := Vector3.ZERO        # точка, вокруг которой летает камера наблюдения
var downed_blend := 0.0
const CRAWL_SPEED := 0.9              # м/с: ползком в нокауте
const DEATH_VIEW_SECONDS := 10.0     # Stage108: после смерти 10 с вид сверху, потом лобби
const DEATH_VIEW_HEIGHT := 45.0       # м над местом гибели
const SPECTATE_DISTANCE := 3.4        # м: камера от 3-го лица за выжившим
const DOWNED_HIDDEN_CONTROLS := ["fire", "jump", "crouch", "reload", "aim", "weapon_1", "weapon_2", "weapon_3"]
var saved_bus_db := 0.0

# ---- Движение как в CS2 (константы Source: sv_accelerate, sv_friction и т.д.) ----
const SPEED_UNIT := 0.0254         # 1 unit CS2 = 0.0254 м; увеличьте, если бег слишком медленный
const GROUND_ACCEL := 5.5          # sv_accelerate
const AIR_ACCEL := 12.0            # sv_airaccelerate
const GROUND_FRICTION := 5.2       # sv_friction
const STOP_SPEED := 80.0 * SPEED_UNIT   # sv_stopspeed
const AIR_SPEED_CAP := 30.0 * SPEED_UNIT # потолок wishspeed в воздухе (air strafe)
const WALK_FACTOR := 0.52          # шаг (Shift) = 52% скорости
const CROUCH_FACTOR := 0.34        # присед = 34% скорости
var crouching := false
var crouch_blend := 0.0
var previous_crouch := false
var shooting := false
var shot_tracers: Array[Node3D] = []
var reserve := 0
var reload_left := 0.0
var shot_left := 0.0
# AK-47: accumulated recoil and shot dispersion (radians).
var recoil_kick := 0.0
const CAMERA_FOV_NORMAL := 75.0
const CAMERA_FOV_AIM := 64.0
var spread_heat := 0.0
var shot_rng := RandomNumberGenerator.new()
var inventory_panel: PanelContainer
var free_spectator := false
var free_camera_position := Vector3.ZERO
var spectator_vertical := 0.0
var screenshot_hud_hidden := false
var spectator_hud_button: Button
var spectator_exit_button: Button
var spectator_pause_button: Button
var pause_panel: PanelContainer
var status: Label
var health_bar: ProgressBar
var hit_marker: Label
var hit_marker_time := 0.0
var actor_tags: Dictionary = {}
var team_panel: PanelContainer
var team_invite_button: Button
var team_invite_popup: PanelContainer
var team_invite_target: int = 0
var team_invite_sender: int = 0
var stance_label: Label
var paused := false
var local_pos := Vector3.ZERO
var settings_panel: PanelContainer
var mic_allowed: bool = false
var mic_allow_check: CheckBox
var mic_hud_button: Button
var mic_quick_button: Button          # Stage130: всегда видимая кнопка микрофона (ПК и телефон)
var mic_button: Button
var mic_listen_check: CheckBox
var mic_hud_label: Label
var voice_box: VBoxContainer
var voice_rows: Dictionary = {}   # peer_id -> {"panel": PanelContainer, "label": Label, "last_ms": int}
const VOICE_SPEAK_SEC := 0.3      # столько после последнего пакета имя считается «говорит» (зелёное)
const VOICE_FADE_DELAY := 1.3     # через столько секунд молчания начинаем гасить
const VOICE_FADE_TIME := 0.5
const VOICE_BOX_WIDTH := 260.0     # ширина области «Говорящие» (в редакторе раскладки её можно двигать и масштабировать)
var voice_preview: PanelContainer  # образец строки: виден только в режиме «Изменить управление»
var editing_controls := false
var drag_control: Control
var drag_offset := Vector2.ZERO
var controls: Dictionary = {}
var selected_control_key := "fire"
var size_slider: HSlider
var size_slider_touch := -1
var size_slider_mouse_drag := false
var size_label: Label
var control_base_sizes: Dictionary = {}
var default_control_positions: Dictionary = {}
var default_control_offsets: Dictionary = {}   # offset_left/top/right/bottom: не зависят от размера экрана
var brightness_layer: ColorRect
const SETTINGS_PATH := "user://battle_settings.cfg"
var brightness := 100.0
var volume := 100.0
var player_fov := 75.0
var ammo_bar: Label
var ui_slider_touch := -1
var ui_slider_active: HSlider
var pc_mode := false
var pc_mouse_captured := false
# ---------- Чат ----------
const CHAT_VISIBLE_SEC := 10.0      # сообщение видно 10 секунд
const CHAT_FADE_SEC := 0.6          # и плавно гаснет в конце
const CHAT_MAX_LINES := 8
const CHAT_WIDTH := 460.0
var chat_open := false
var chat_box: VBoxContainer
var chat_input_panel: PanelContainer
var chat_input: LineEdit
var chat_list: VBoxContainer
var chat_entries: Array = []
var waiting_pc_action := ""
var pc_bind_buttons: Dictionary = {}
var pc_bind_panel: PanelContainer      # серое меню назначения клавиш (обычная панель, а не окно)
var pc_bind_hint: Label
const PC_BIND_SECTIONS := [
    ["Движение", ["forward", "back", "left", "right", "jump", "crouch", "walk"]],
    ["Бой", ["fire", "aim", "reload", "weapon1", "weapon2", "weapon3"]],
    ["Действия", ["pickup", "use", "inventory", "microphone", "chat"]],
    ["Система", ["pause", "cursor"]],
]
const PC_KEYBOARD_ONLY := ["forward", "back", "left", "right", "walk"]   # удерживаемые: только клавиши
const PC_BIND_LABELS := {
    "forward": "Вперёд", "back": "Назад", "left": "Влево", "right": "Вправо",
    "jump": "Прыжок", "crouch": "Присесть", "walk": "Шаг (тихо)", "fire": "Стрельба", "aim": "Прицел",
    "reload": "Перезарядка", "weapon1": "Оружие 1", "weapon2": "Оружие 2", "weapon3": "Оружие 3",
    "pickup": "Подобрать", "use": "Использовать (магазин / турель)", "inventory": "Инвентарь",
    "microphone": "Микрофон", "chat": "Чат", "pause": "Пауза", "cursor": "Захват курсора мыши",
}
const PC_DEFAULTS := {"left": KEY_A, "right": KEY_D, "forward": KEY_W, "back": KEY_S, "jump": KEY_SPACE, "crouch": KEY_CTRL, "walk": KEY_SHIFT, "reload": KEY_R, "inventory": KEY_I, "pause": KEY_ESCAPE, "weapon1": KEY_1, "weapon2": KEY_2, "weapon3": KEY_3, "pickup": KEY_F, "use": KEY_E, "cursor": KEY_F1, "chat": KEY_T, "fire": MOUSE_BUTTON_LEFT}
var pc_binds: Dictionary = PC_DEFAULTS.duplicate()
# Every actionable mobile HUD button can be assigned a PC key.
const PC_HUD_LABELS := {"fire": "Стрельба", "jump": "Прыжок", "crouch": "Присесть", "reload": "Перезарядка", "inventory": "Инвентарь", "pickup": "Подобрать", "pause": "Пауза", "weapon_1": "Оружие 1", "weapon_2": "Оружие 2", "weapon_3": "Оружие 3", "aim": "Прицел", "microphone": "Микрофон", "chat": "Чат"}
const PC_HUD_DEFAULTS := {"weapon_1": KEY_1, "weapon_2": KEY_2, "weapon_3": KEY_3, "aim": MOUSE_BUTTON_RIGHT, "microphone": KEY_K}

func _hud_action_name(control_key: String) -> String:
    if control_key.begins_with("weapon_"):
        return control_key.replace("weapon_", "weapon")
    return control_key

func _sync_pc_hud_actions() -> void:
    # Discover controls registered in the mobile HUD instead of maintaining
    # a second hard-coded list of PC actions.
    var cfg := ConfigFile.new()
    cfg.load(SETTINGS_PATH)
    for control_key in controls.keys():
        if control_key == "joystick" or control_key == "health_bar" or control_key == "voice" or control_key == "ammo_bar":
            continue
        var action := _hud_action_name(str(control_key))
        if not pc_binds.has(action):
            var default_code: int = int(PC_HUD_DEFAULTS.get(control_key, 0))
            pc_binds[action] = int(cfg.get_value("pc_binds", action, default_code))

func _trigger_hud_pc_action(action: String) -> void:
    if action == "fire":
        return
    for control_key in controls.keys():
        if _hud_action_name(str(control_key)) != action:
            continue
        var control: Control = controls[control_key]
        if control is BaseButton and not control.disabled:
            control.pressed.emit()
        return



var survival_join_banner: Label
var survival_join_banner_time: float = 0.0

func _show_survival_join_announcement(message: String) -> void:
    if survival_join_banner == null:
        survival_join_banner = Label.new()
        survival_join_banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
        survival_join_banner.position = Vector2(-350, 18)
        survival_join_banner.custom_minimum_size = Vector2(700, 48)
        survival_join_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        survival_join_banner.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        survival_join_banner.add_theme_font_size_override("font_size", 23)
        survival_join_banner.add_theme_color_override("font_color", Color.WHITE)
        survival_join_banner.add_theme_color_override("font_outline_color", Color.BLACK)
        survival_join_banner.add_theme_constant_override("outline_size", 7)
        survival_join_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
        add_child(survival_join_banner)
    survival_join_banner.text = message
    survival_join_banner.show()
    survival_join_banner_time = 5.0

var survival_join_dialog: ConfirmationDialog
var survival_join_peer: int = -1

## Приглашение зайти в чужую игру, пришедшее во время боя (выживание).
## Раньше окно приглашения существовало только в лобби, поэтому в бою игрок его не видел.
var battle_invite_popup: PanelContainer
var battle_invite_label: Label

func _build_battle_invite_popup() -> void:
    if battle_invite_popup != null:
        return
    battle_invite_popup = _panel("ПРИГЛАШЕНИЕ В ИГРУ", Vector2(420, 250))
    battle_invite_popup.theme = _battle_menu_theme()
    battle_invite_popup.z_index = 100
    battle_invite_popup.hide()
    var v := battle_invite_popup.get_node("VBox") as VBoxContainer
    battle_invite_label = Label.new()
    battle_invite_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    battle_invite_label.custom_minimum_size = Vector2(380, 0)
    v.add_child(battle_invite_label)
    var accept := Button.new()
    accept.text = "Принять приглашение"
    accept.custom_minimum_size = Vector2(0, 52)
    accept.pressed.connect(_accept_battle_invite)
    v.add_child(accept)
    var decline := Button.new()
    decline.text = "Отменить приглашение"
    decline.custom_minimum_size = Vector2(0, 52)
    decline.pressed.connect(_decline_battle_invite)
    v.add_child(decline)
    battle_invite_popup.visibility_changed.connect(_sync_desktop_cursor)

func _on_battle_invite_received(from_nick: String) -> void:
    if leaving_battle or Net.game_mode != Net.MODE_SURVIVAL or not Net.battle_active:
        return
    _build_battle_invite_popup()
    battle_invite_label.text = "%s приглашает вас в свою игру.\nЕсли принять, вы выйдете из текущего мира (прогресс выживания сохранится)." % from_nick
    battle_invite_popup.show()
    battle_invite_popup.move_to_front()
    if _is_desktop():
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _on_battle_invite_closed() -> void:
    if battle_invite_popup != null:
        battle_invite_popup.hide()

func _decline_battle_invite() -> void:
    if battle_invite_popup != null:
        battle_invite_popup.hide()
    Net.decline_invite()
    _sync_desktop_cursor()

func _accept_battle_invite() -> void:
    if battle_invite_popup != null:
        battle_invite_popup.hide()
    if leaving_battle:
        return
    # Сохраняем выживание и аккуратно закрываем бой, затем (уже в лобби) принимаем приглашение.
    _survival_snapshot_now()
    _leave_battle("local")
    get_tree().create_timer(0.5).timeout.connect(Net.accept_invite)

func _show_survival_join_request(peer_id: int, nickname: String) -> void:
    if Net.role != "host" or Net.game_mode != Net.MODE_SURVIVAL:
        return
    if survival_join_dialog == null:
        survival_join_dialog = ConfirmationDialog.new()
        survival_join_dialog.title = "Заявка на вход в мир"
        survival_join_dialog.ok_button_text = "Принять"
        survival_join_dialog.cancel_button_text = "Отклонить"
        add_child(survival_join_dialog)
        survival_join_dialog.confirmed.connect(func() -> void:
            Net.answer_survival_join(survival_join_peer, true)
            survival_join_peer = -1
            _sync_desktop_cursor()
        )
        survival_join_dialog.canceled.connect(func() -> void:
            Net.answer_survival_join(survival_join_peer, false)
            survival_join_peer = -1
            _sync_desktop_cursor()
        )
    survival_join_peer = peer_id
    survival_join_dialog.dialog_text = "%s хочет войти в ваш мир выживания." % nickname
    survival_join_dialog.popup_centered(Vector2i(470, 170))
    if _is_desktop():
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _ready() -> void:
    Net.survival_local_provider = _survival_local_view
    if not Net.survival_state_restored.is_connected(_on_survival_state_restored):
        Net.survival_state_restored.connect(_on_survival_state_restored)
    if not Net.invite_received.is_connected(_on_battle_invite_received):
        Net.invite_received.connect(_on_battle_invite_received)
    if not Net.invite_closed.is_connected(_on_battle_invite_closed):
        Net.invite_closed.connect(_on_battle_invite_closed)
    if not Net.survival_join_announcement.is_connected(_show_survival_join_announcement):
        Net.survival_join_announcement.connect(_show_survival_join_announcement)
    if not Net.survival_join_request.is_connected(_show_survival_join_request):
        Net.survival_join_request.connect(_show_survival_join_request)
    # Capture the cursor automatically on desktop when battle starts.
    if _is_desktop():
        pc_mouse_captured = true
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    # Touch events must not generate synthetic left mouse clicks: those fired the gun.
    # Native GUI receives mouse-like touch for sliders; gameplay touch remains separately tracked.
    Input.set_emulate_mouse_from_touch(true)
    saved_bus_db = AudioServer.get_bus_volume_db(0)
    # Scene-based world: editable in Godot rather than created from code.
    var container := $WorldView as SubViewportContainer
    viewport = $WorldView/Viewport as SubViewport
    var world := $WorldView/Viewport/World as Node3D
    camera = $WorldView/Viewport/World/Camera3D as Camera3D
    if Net.game_mode == Net.MODE_ZOMBIES:
        _setup_zombie_world(world)
        _setup_zombie_timer()
    for id in Net.battle_positions.keys():
        _add_actor(id, world)
    local_pos = Net.battle_positions.get(Net.my_id(), Vector3(0, 1, 0))
    if Net.game_mode == Net.MODE_ZOMBIES:
        yaw = PI   # на площадке появления смотрим вдоль корабля
    GameState.begin_battle()
    if Net.game_mode == Net.MODE_SURVIVAL and Net.role != "client":
        var saved := SurvivalSaves.load_slot(SurvivalSaves.pending_slot)
        if not saved.is_empty():
            var xyz: Array = saved.get("pos", [])
            if xyz.size() == 3:
                local_pos = Vector3(float(xyz[0]), float(xyz[1]), float(xyz[2]))
                Net.battle_positions[Net.my_id()] = local_pos
            Net.battle_health[Net.my_id()] = int(saved.get("health", 100))
            GameState.battle_inventory = saved.get("inventory", []).duplicate(true)
            GameState.battle_equipment = saved.get("equipment", []).duplicate(true)
            yaw = float(saved.get("yaw", 0.0))
            pitch = float(saved.get("pitch", 0.0))
            GameState.changed.emit()
        SurvivalSaves.pending_slot = ""
    if Net.game_mode == Net.MODE_SURVIVAL and Net.role == "client" and not Net.survival_restore_clients.is_empty():
        var restore: Dictionary = Net.survival_restore_clients
        var xyz: Array = restore.get("pos", [])
        if xyz.size() == 3:
            local_pos = Vector3(float(xyz[0]), float(xyz[1]), float(xyz[2]))
        yaw = float(restore.get("yaw", 0.0))
        pitch = float(restore.get("pitch", 0.0))
        GameState.battle_inventory = GameState.sanitize_battle_slots(restore.get("inventory", []), GameState.INV_SIZE)
        GameState.battle_equipment = GameState.sanitize_battle_slots(restore.get("equipment", []), GameState.GEAR_SIZE)
        GameState.changed.emit()
        Net.survival_restore_clients.clear()
    Net.world_item_added.connect(_show_world_drop)
    Net.world_item_removed.connect(_remove_world_drop)
    Net.pickup_accepted.connect(_receive_pickup)
    Net.world_items_reset.connect(_clear_world_drops)
    Net.death_bags_changed.connect(_refresh_death_bags)
    Net.death_bag_item_received.connect(_on_death_bag_item)
    _make_death_bag_ui()
    _refresh_death_bags()
    viewport.audio_listener_enable_3d = true
    Net.shot_visual.connect(_show_tracer)
    Net.shot_fired.connect(_on_shot_fired)
    Net.battle_event.connect(_on_battle_event)
    Net.shot_confirmed.connect(_on_shot_confirmed)
    Net.zombie_phase_changed.connect(_on_zombie_phase_changed)
    Net.creator_sword_zombie_burn.connect(_on_creator_sword_zombie_burn)
    _sync_reserve()
    # HUD elements are scene nodes; scripts update their state only.
    brightness_layer = $HUD/Brightness as ColorRect
    _load_settings()
    _apply_graphics_quality()
    _apply_settings()
    var hud := HBoxContainer.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    add_child(hud)
    status = Label.new()
    status.add_theme_font_size_override("font_size", 22)
    hud.add_child(status)
    var health_row := $HUD/HealthRow as HBoxContainer
    health_bar = $HUD/HealthRow/HealthBar as ProgressBar
    stance_label = $HUD/HealthRow/Stance as Label
    controls["health_bar"] = health_row
    ammo_bar = Label.new()
    ammo_bar.name = "AmmoBar"
    ammo_bar.text = "30/120"
    ammo_bar.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ammo_bar.add_theme_font_size_override("font_size", 30)
    ammo_bar.add_theme_color_override("font_color", Color(1, 0.94, 0.72))
    ammo_bar.position = Vector2(1040, 580)
    ammo_bar.size = Vector2(185, 48)
    ammo_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(ammo_bar)
    controls["ammo_bar"] = ammo_bar
    var pause := _button("Пауза", Vector2(110, 58), Vector2(20, 20), Control.PRESET_TOP_LEFT)
    pause.pressed.connect(func(): _toggle_pause())
    controls["pause"] = pause
    stick = Control.new()
    stick.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
    stick.position = Vector2(45, -205)
    stick.custom_minimum_size = Vector2(175, 175)
    stick.size = Vector2(175, 175)
    stick.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(stick)
    controls["joystick"] = stick
    var base := ColorRect.new()
    base.color = Color(1, 1, 1, 0.8)
    base.material = null
    base.size = Vector2(175, 175)
    base.mouse_filter = Control.MOUSE_FILTER_IGNORE
    stick.add_child(base)
    var joystick_art := TextureRect.new()
    joystick_art.texture = load("res://assets/hud/joystick_base.png")
    joystick_art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    joystick_art.stretch_mode = TextureRect.STRETCH_SCALE
    joystick_art.size = Vector2(175, 175)
    joystick_art.mouse_filter = Control.MOUSE_FILTER_IGNORE
    stick.add_child(joystick_art)
    base.hide()
    knob = ColorRect.new()
    knob.color = Color(0.85, 0.9, 1.0, 0.6)
    knob.size = Vector2(66, 66)
    knob.position = Vector2(54, 54)
    knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
    stick.add_child(knob)
    var knob_art := TextureRect.new()
    knob_art.texture = load("res://assets/hud/joystick_knob.png")
    knob_art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    knob_art.stretch_mode = TextureRect.STRETCH_SCALE
    knob_art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    knob_art.mouse_filter = Control.MOUSE_FILTER_IGNORE
    knob.add_child(knob_art)
    knob.color = Color.TRANSPARENT
    controls["fire"] = _hold_button("ОГОНЬ", Vector2(125, 95), Vector2(-25, -215), func(v: bool): _set_trigger(v))
    var jump := _button("Прыжок", Vector2(112, 65), Vector2(-160, -145), Control.PRESET_BOTTOM_RIGHT)
    jump.pressed.connect(_jump)
    controls["jump"] = jump
    var crouch := _button("Присед", Vector2(112, 65), Vector2(-25, -320), Control.PRESET_BOTTOM_RIGHT)
    crouch.pressed.connect(_spectator_crouch_or_player)
    controls["crouch"] = crouch
    var reload := _button("Перезарядка", Vector2(145, 65), Vector2(-25, -405), Control.PRESET_BOTTOM_RIGHT)
    reload.pressed.connect(_reload)
    controls["reload"] = reload
    aim_button = _button("Прицел", Vector2(94, 94), Vector2(-185, -335), Control.PRESET_BOTTOM_RIGHT)
    # Touch is processed in _input to avoid Android GUI gesture conflicts.
    # Mouse/keyboard activation still uses the normal Button signal.
    aim_button.pressed.connect(_toggle_aim)
    controls["aim"] = aim_button
    aim_button.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var inv := _button("Инвентарь", Vector2(145, 65), Vector2(-25, -490), Control.PRESET_BOTTOM_RIGHT)
    inv.pressed.connect(_toggle_battle_inventory)
    controls["inventory"] = inv
    mic_hud_button = _button("МИКР ВЫКЛ", Vector2(132, 65), Vector2(-180, -565), Control.PRESET_BOTTOM_RIGHT)
    mic_hud_button.pressed.connect(_toggle_game_mic)
    controls["microphone"] = mic_hud_button
    var chat_btn := _button("Чат", Vector2(112, 65), Vector2(-25, -575), Control.PRESET_BOTTOM_RIGHT)
    chat_btn.pressed.connect(_toggle_chat)
    controls["chat"] = chat_btn
    # Stage130: быстрая кнопка микрофона справа сверху — и на телефоне, и на ПК (на ПК ещё клавиша K).
    mic_quick_button = Button.new()
    mic_quick_button.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
    mic_quick_button.position = Vector2(-190, 20)
    mic_quick_button.size = Vector2(170, 58)
    mic_quick_button.add_theme_font_size_override("font_size", 20)
    mic_quick_button.focus_mode = Control.FOCUS_NONE
    mic_quick_button.pressed.connect(_toggle_game_mic)
    add_child(mic_quick_button)
    inventory_panel = preload("res://scripts/battle_inventory.gd").new()
    add_child(inventory_panel)
    inventory_panel.hide()
    inventory_panel.visibility_changed.connect(_sync_inventory_weapon_buttons)
    inventory_panel.visibility_changed.connect(_sync_desktop_cursor)
    _create_shop_ui()
    _create_chat_ui()
    _create_pickup_hud()
    _create_scope_overlay()
    _create_collimator_overlay()
    _create_weapon_bar()
    _create_life_hud()
    GameState.changed.connect(_on_battle_equipment_changed)
    _refresh_weapon_bar()
    _sync_inventory_weapon_buttons()
    for item_id in Net.world_items:
        var record: Dictionary = Net.world_items[item_id]
        _show_world_drop(item_id, record["stack"], record["pos"], record["facing"])
    pause_panel = _panel("ПАУЗА", Vector2(380, 270))
    pause_panel.theme = _battle_menu_theme()
    pause_panel.visible = false
    pause_panel.visibility_changed.connect(_sync_desktop_cursor)
    spectator_pause_button = Button.new()
    spectator_pause_button.text = "Спектатор"
    spectator_pause_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    spectator_pause_button.position = Vector2(-170, 14)
    spectator_pause_button.size = Vector2(155, 54)
    spectator_pause_button.pressed.connect(_toggle_free_spectator)
    add_child(spectator_pause_button)
    spectator_pause_button.hide()
    pause_panel.visibility_changed.connect(func(): spectator_pause_button.visible = pause_panel.visible)
    spectator_hud_button = Button.new()
    spectator_hud_button.text = "HUD: скрыть"
    spectator_hud_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    spectator_hud_button.position = Vector2(-150, 12)
    spectator_hud_button.size = Vector2(140, 48)
    spectator_hud_button.pressed.connect(_toggle_spectator_hud)
    add_child(spectator_hud_button)
    spectator_hud_button.hide()
    spectator_exit_button = Button.new()
    spectator_exit_button.text = "Выход из спектатора"
    spectator_exit_button.set_anchors_preset(Control.PRESET_TOP_LEFT)
    spectator_exit_button.position = Vector2(12, 12)
    spectator_exit_button.size = Vector2(220, 48)
    spectator_exit_button.pressed.connect(_toggle_free_spectator)
    add_child(spectator_exit_button)
    spectator_exit_button.hide()
    var back := Button.new()
    back.text = "Выйти из боя (поражение)"
    pause_panel.get_node("VBox").add_child(back)
    back.pressed.connect(_exit_battle)
    var resume := Button.new()
    resume.text = "Продолжить"
    pause_panel.get_node("VBox").add_child(resume)
    resume.pressed.connect(_toggle_pause)
    var settings_button := Button.new()
    settings_button.text = "Настройки"
    pause_panel.get_node("VBox").add_child(settings_button)
    settings_button.pressed.connect(func():
        pause_panel.hide()
        settings_panel.show()
    )
    if Net.game_mode == Net.MODE_SURVIVAL and Net.role == "solo":
        var save_button := Button.new()
        save_button.text = "Сохранить"
        pause_panel.get_node("VBox").add_child(save_button)
        save_button.pressed.connect(_open_survival_save_dialog)
    if Net.game_mode == Net.MODE_SURVIVAL:
        var team_button := Button.new()
        team_button.text = "Команда"
        pause_panel.get_node("VBox").add_child(team_button)
        team_button.pressed.connect(func():
            pause_panel.hide()
            _refresh_team_panel()
            team_panel.show()
        )
        team_panel = _panel("КОМАНДА", Vector2(400, 360))
        team_panel.theme = _battle_menu_theme()
        team_panel.hide()
        team_invite_button = _button("Пригласить в команду", Vector2(240, 52), Vector2(0, 85), Control.PRESET_CENTER_BOTTOM)
        team_invite_button.text = "Пригласить в команду"
        team_invite_button.pressed.connect(func(): Net.invite_survival_team(team_invite_target))
        team_invite_button.hide()
        team_invite_popup = _panel("ПРИГЛАШЕНИЕ В КОМАНДУ", Vector2(400, 210))
        team_invite_popup.theme = _battle_menu_theme()
        team_invite_popup.hide()
        var accept_team := Button.new()
        accept_team.text = "Принять"
        team_invite_popup.get_node("VBox").add_child(accept_team)
        accept_team.pressed.connect(func():
            Net.answer_survival_team(true)
            team_invite_popup.hide()
        )
        var reject_team := Button.new()
        reject_team.text = "Отклонить"
        team_invite_popup.get_node("VBox").add_child(reject_team)
        reject_team.pressed.connect(func():
            Net.answer_survival_team(false)
            team_invite_popup.hide()
        )
        Net.team_invitation.connect(_on_team_invitation)
        Net.teams_changed.connect(_on_teams_changed)
    settings_panel = _panel("НАСТРОЙКИ", Vector2(400, 590))
    settings_panel.theme = _battle_menu_theme()
    settings_panel.hide()
    settings_panel.visibility_changed.connect(_sync_desktop_cursor)
    _setting_slider("Яркость", brightness, func(value: float):
        brightness = value
        _apply_settings()
        _save_settings()
    )
    _setting_slider("FOV", player_fov, func(value: float):
        player_fov = value
        _save_settings()
    , 60.0, 110.0)
    _setting_slider("Звук", volume, func(value: float):
        volume = value
        _apply_settings()
        _save_settings()
    )
    _build_voice_settings()
    gfx_button = Button.new()
    gfx_button.text = "Графика: " + QUALITY_NAMES[gfx_quality]
    settings_panel.get_node("VBox").add_child(gfx_button)
    gfx_button.pressed.connect(func():
        gfx_quality = (gfx_quality + 1) % QUALITY_NAMES.size()
        gfx_button.text = "Графика: " + QUALITY_NAMES[gfx_quality]
        _apply_graphics_quality()
        _save_settings()
    )
    # Stage129: погода (Выкл / Дождь / Туман / Гроза) — только на средней и высокой графике.
    weather_button = Button.new()
    settings_panel.get_node("VBox").add_child(weather_button)
    weather_button.pressed.connect(func():
        if _gfx_level() < 2:
            return
        weather_mode = (weather_mode + 1) % GraphicsFX.WEATHER_NAMES.size()
        if gfx_fx != null:
            gfx_fx.apply(_gfx_level(), weather_mode)
        _refresh_weather_button()
        _save_settings()
    )
    _refresh_weather_button()
    # Stage132: кровь при попаданиях и убийствах — только на высокой графике.
    blood_button = Button.new()
    settings_panel.get_node("VBox").add_child(blood_button)
    blood_button.pressed.connect(func():
        if _gfx_level() < 3:
            return
        blood_enabled = not blood_enabled
        if combat_fx != null:
            combat_fx.blood_enabled = blood_enabled
        _refresh_blood_button()
        _save_settings()
    )
    _refresh_blood_button()
    # Stage129: счётчик FPS справа сверху, виден только в меню паузы.
    fps_label = Label.new()
    fps_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    fps_label.position = Vector2(-170, 76)
    fps_label.size = Vector2(155, 36)
    fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    fps_label.add_theme_font_size_override("font_size", 22)
    fps_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    fps_label.add_theme_constant_override("outline_size", 6)
    fps_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fps_label.visible = false
    add_child(fps_label)
    var pc_button := Button.new()
    pc_button.text = "Управление ПК / назначить клавиши"
    settings_panel.get_node("VBox").add_child(pc_button)
    pc_button.pressed.connect(_show_pc_binds)
    var edit_button := Button.new()
    edit_button.text = "Изменить управление"
    settings_panel.get_node("VBox").add_child(edit_button)
    edit_button.pressed.connect(_begin_edit)
    var settings_back := Button.new()
    settings_back.text = "Назад"
    settings_panel.get_node("VBox").add_child(settings_back)
    settings_back.pressed.connect(func():
        settings_panel.hide()
        pause_panel.show()
    )
    var done := Button.new()
    done.name = "LayoutDone"
    done.text = "Готово — сохранить расположение"
    done.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    done.position = Vector2(-150, 12)
    done.custom_minimum_size = Vector2(300, 55)
    add_child(done)
    done.hide()
    done.pressed.connect(_finish_edit)
    # A dedicated opaque panel makes the size control easy to see and touch.
    var size_panel := PanelContainer.new()
    size_panel.name = "LayoutSizePanel"
    size_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    size_panel.position = Vector2(-250, 78)
    size_panel.custom_minimum_size = Vector2(500, 142)
    size_panel.size = Vector2(500, 142)
    size_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    var panel_style := StyleBoxFlat.new()
    panel_style.bg_color = UiGray.PANEL
    panel_style.border_color = UiGray.EDGE_STRONG
    panel_style.set_border_width_all(2)
    panel_style.set_corner_radius_all(16)
    panel_style.set_content_margin_all(16)
    size_panel.add_theme_stylebox_override("panel", panel_style)
    add_child(size_panel)
    size_panel.hide()
    var size_column := VBoxContainer.new()
    size_column.add_theme_constant_override("separation", 8)
    size_panel.add_child(size_column)
    size_label = Label.new()
    size_label.name = "ControlSizeLabel"
    size_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    size_label.add_theme_font_size_override("font_size", 23)
    size_column.add_child(size_label)
    size_slider = HSlider.new()
    size_slider.name = "ControlSizeSlider"
    size_slider.custom_minimum_size = Vector2(0, 72)
    size_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    size_slider.size_flags_vertical = Control.SIZE_EXPAND_FILL
    size_slider.min_value = 0
    size_slider.max_value = 300
    size_slider.step = 1
    size_slider.mouse_filter = Control.MOUSE_FILTER_STOP
    size_column.add_child(size_slider)
    size_slider.value_changed.connect(_resize_selected_control)
    var reset_button := Button.new()
    reset_button.name = "LayoutReset"
    reset_button.text = "Сбросить управление"
    reset_button.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    reset_button.position = Vector2(-150, 230)
    reset_button.custom_minimum_size = Vector2(300, 50)
    add_child(reset_button)
    reset_button.hide()
    reset_button.pressed.connect(_reset_mobile_layout)
    for key in controls:
        default_control_positions[key] = controls[key].position
        var c0: Control = controls[key]
        default_control_offsets[key] = [c0.offset_left, c0.offset_top, c0.offset_right, c0.offset_bottom]
    for key in controls:
        control_base_sizes[key] = controls[key].size
    _restore_layout()
    get_viewport().size_changed.connect(_clamp_all_mobile_controls)
    call_deferred("_clamp_all_mobile_controls")
    _load_pc_binds()
    _sync_pc_hud_actions()
    _set_mobile_hud_visible(not pc_mode)

## Health bar2 (нокаут) и подпись + кнопка «Выйти в лобби» (смерть) — обе под прицелом.
func _create_life_hud() -> void:
    var hud_root := $HUD as Control
    life_box = VBoxContainer.new()
    life_box.name = "LifeBox"
    life_box.anchor_left = 0.5
    life_box.anchor_right = 0.5
    life_box.anchor_top = 0.5
    life_box.anchor_bottom = 0.5
    life_box.offset_left = -150.0
    life_box.offset_right = 150.0
    life_box.offset_top = 42.0
    life_box.offset_bottom = 104.0
    life_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    life_box.add_theme_constant_override("separation", 4)
    life_box.visible = false
    hud_root.add_child(life_box)
    life_caption = Label.new()
    life_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    life_caption.add_theme_font_size_override("font_size", 20)
    life_caption.add_theme_color_override("font_color", Color(1.0, 0.35, 0.30))
    life_caption.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    life_caption.add_theme_constant_override("outline_size", 5)
    life_caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
    life_box.add_child(life_caption)
    health_bar2 = ProgressBar.new()
    health_bar2.name = "HealthBar2"
    health_bar2.min_value = 0.0
    health_bar2.max_value = float(Net.BLEED_START)
    health_bar2.value = float(Net.BLEED_START)
    health_bar2.show_percentage = false
    health_bar2.custom_minimum_size = Vector2(300, 26)
    health_bar2.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var bar_bg := StyleBoxFlat.new()
    bar_bg.bg_color = Color(0.08, 0.04, 0.04, 0.85)
    bar_bg.border_color = Color(0.85, 0.85, 0.85, 0.7)
    bar_bg.set_border_width_all(2)
    bar_bg.set_corner_radius_all(5)
    var bar_fill := StyleBoxFlat.new()
    bar_fill.bg_color = Color(0.86, 0.14, 0.12)
    bar_fill.set_corner_radius_all(4)
    health_bar2.add_theme_stylebox_override("background", bar_bg)
    health_bar2.add_theme_stylebox_override("fill", bar_fill)
    life_box.add_child(health_bar2)
    life_box.mouse_filter = Control.MOUSE_FILTER_PASS
    end_life_button = Button.new()
    end_life_button.text = "Закончить жизнь"
    end_life_button.custom_minimum_size = Vector2(300, 48)
    end_life_button.focus_mode = Control.FOCUS_NONE
    life_box.add_child(end_life_button)
    end_life_dialog = ConfirmationDialog.new()
    end_life_dialog.title = "Закончить жизнь?"
    end_life_dialog.dialog_text = "Вы действительно хотите умереть?"
    end_life_dialog.ok_button_text = "Да"
    end_life_dialog.cancel_button_text = "Нет"
    add_child(end_life_dialog)
    end_life_button.pressed.connect(func():
        if _my_state == Net.ST_DOWNED:
            end_life_dialog.popup_centered()
    )
    end_life_dialog.confirmed.connect(func():
        if _my_state == Net.ST_DOWNED:
            Net.request_end_life()
    )

    spectate_box = VBoxContainer.new()
    spectate_box.name = "SpectateBox"
    spectate_box.anchor_left = 0.5
    spectate_box.anchor_right = 0.5
    spectate_box.anchor_top = 0.5
    spectate_box.anchor_bottom = 0.5
    spectate_box.offset_left = -150.0
    spectate_box.offset_right = 150.0
    spectate_box.offset_top = 42.0
    spectate_box.offset_bottom = 130.0
    spectate_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    spectate_box.add_theme_constant_override("separation", 8)
    spectate_box.visible = false
    hud_root.add_child(spectate_box)
    spectate_label = Label.new()
    spectate_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    spectate_label.add_theme_font_size_override("font_size", 20)
    spectate_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    spectate_label.add_theme_constant_override("outline_size", 5)
    spectate_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    spectate_box.add_child(spectate_label)
    leave_button = Button.new()
    leave_button.name = "LeaveToLobby"
    leave_button.text = "Выйти в лобби"
    leave_button.theme = _battle_menu_theme()
    leave_button.focus_mode = Control.FOCUS_NONE
    leave_button.custom_minimum_size = Vector2(300, 58)
    leave_button.add_theme_font_size_override("font_size", 22)
    leave_button.pressed.connect(_leave_dead_to_lobby)
    spectate_box.add_child(leave_button)

## Смена состояния нашего игрока: жив -> нокаут -> мёртв.
func _on_life_changed(state: int) -> void:
    _my_state = state
    shooting = false
    fire_queued = 0.0
    shell_reload = false
    reload_left = 0.0
    if end_life_dialog != null and state != Net.ST_DOWNED:
        end_life_dialog.hide()
    if state != Net.ST_DEAD:
        _cancel_death_view()
        if _my_state == Net.ST_ALIVE and Net.game_mode == Net.MODE_SURVIVAL:
            local_pos = Net.battle_positions.get(Net.my_id(), Vector3(0, 1, 0))
            GameState.battle_inventory = GameState._empty(GameState.INV_SIZE)
            GameState.battle_equipment = GameState._empty(GameState.GEAR_SIZE)
            GameState.changed.emit()
    if state == Net.ST_DOWNED:
        crouching = false
        _set_aim(false)
        if active_weapon_slot >= 0:
            _holster_weapon()
        if GameState.downed_pistol_talent:
            var slots: Array = GameState.get_slots("gear")
            if slots.size() > 1 and not slots[1].is_empty():
                var pistol_id := str(slots[1].get("id", ""))
                if Weapons.has(pistol_id) and int(Weapons.get_def(pistol_id).get("slot", -1)) == 1:
                    active_weapon_slot = 1
                    _refresh_weapon_bar()
                    _update_held_weapon()
    elif state == Net.ST_DEAD:
        var remains: Array = []
        for slot in GameState.battle_equipment + GameState.battle_inventory:
            if slot is Dictionary and not slot.is_empty():
                remains.append(slot.duplicate(true))
        # Эвакуированный игрок ничего не теряет: вещи уже сохранены в профиле.
        if not (Net.game_mode == Net.MODE_DUEL and Net.duel_spectators.has(Net.my_id())) and not Net.is_evacuated(Net.my_id()):
            Net.submit_death_bag(remains, local_pos)
        if Net.game_mode == Net.MODE_SURVIVAL:
            GameState.battle_inventory = GameState._empty(GameState.INV_SIZE)
            GameState.battle_equipment = GameState._empty(GameState.GEAR_SIZE)
            GameState.changed.emit()
        crouching = false
        _set_aim(false)
        active_weapon_slot = -1
        _clear_held_weapon()
        _refresh_weapon_bar()
        if inventory_panel != null:
            inventory_panel.hide()
        direction = Vector2.ZERO
        vel_h = Vector3.ZERO
        # Курсор нужен, чтобы нажать «Выйти в лобби»; осматриваться можно правой кнопкой мыши.
        pc_mouse_captured = false
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
        # Камера начинает за спиной выжившего и дальше свободно облетает его.
        var target := Net.spectate_target(Net.my_id())
        spec_focus = local_pos + Vector3(0, 1.35, 0)
        if target != -1:
            yaw = float(Net.battle_yaws.get(target, 0.0))
            if actors.has(target):
                spec_focus = (actors[target] as Node3D).position + Vector3(0, 1.35, 0)
        pitch = -0.25
        # Stage108: эвакуированный игрок и дуэльные зрители не переходят на вид сверху.
        if not Net.is_evacuated(Net.my_id()) and Net.game_mode != Net.MODE_DUEL:
            _start_death_view()
    _set_mobile_hud_visible(not paused and not pc_mode)

func _update_life_hud(life: int) -> void:
    if life_box == null:
        return
    life_box.visible = life == Net.ST_DOWNED and not editing_controls
    spectate_box.visible = life == Net.ST_DEAD and not paused and not editing_controls and death_view_left < 0.0
    if life == Net.ST_DOWNED:
        var left := int(Net.battle_bleed.get(Net.my_id(), 0))
        health_bar2.value = float(left)
        life_caption.text = "НОКАУТ  %d HP" % left
    elif life == Net.ST_DEAD:
        var target := Net.spectate_target(Net.my_id())
        if target != -1:
            var nick: String = str(Net.roster.get(target, {}).get("nick", "Игрок %s" % str(target)))
            spectate_label.text = "Вы наблюдаете за: %s" % nick
        else:
            spectate_label.text = "Бой окончен"

# ------------------------------------------------------------------ Stage108: вид сверху после смерти
# 10 секунд камера висит в 45 м над местом гибели и смотрит вниз, экран пульсирует красным,
# затем игрок уходит в лобби (Net.leave_battle_locally) и больше не считается участником боя.
func _start_death_view() -> void:
    if death_view_left >= 0.0 or leaving_battle:
        return
    death_view_left = DEATH_VIEW_SECONDS
    death_view_t = 0.0
    death_focus = local_pos
    if death_focus.y < 0.0:
        death_focus.y = maxf(death_focus.y, -7.5)   # утонул: тело и кольцо на поверхности воды
    death_yaw = yaw
    _make_death_overlay()
    death_overlay.visible = true
    death_label.visible = true
    _make_death_marker()

# Пока игрок погиб (и не эвакуирован), общий конец боя не должен выкинуть его в лобби раньше 10 секунд.
func _death_view_blocks_exit() -> bool:
    if death_spectating:
        return false
    if death_view_left >= 0.0:
        return true
    return Net.peer_state(Net.my_id()) == Net.ST_DEAD and not Net.is_evacuated(Net.my_id()) and Net.game_mode != Net.MODE_DUEL

func _cancel_death_view() -> void:
    death_spectating = false
    if death_view_left < 0.0:
        return
    death_view_left = -1.0
    if death_overlay != null:
        death_overlay.visible = false
    if death_label != null:
        death_label.visible = false
    if death_buttons != null:
        death_buttons.visible = false
    if is_instance_valid(death_marker):
        death_marker.queue_free()
        death_marker = null

func _make_death_overlay() -> void:
    if death_overlay != null:
        return
    var hud_root := $HUD as Control
    death_overlay = ColorRect.new()
    death_overlay.name = "DeathGlow"
    death_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    death_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    death_overlay.color = Color(1, 1, 1, 1)
    var shader := Shader.new()
    shader.code = "shader_type canvas_item;\nuniform float strength = 0.6;\nvoid fragment() {\n    vec2 uv = UV - vec2(0.5);\n    float edge = smoothstep(0.12, 0.78, length(uv * vec2(1.15, 1.0)));\n    COLOR = vec4(0.9, 0.0, 0.02, clamp(edge * strength + 0.10 * strength, 0.0, 0.85));\n}\n"
    var material := ShaderMaterial.new()
    material.shader = shader
    death_overlay.material = material
    death_overlay.visible = false
    hud_root.add_child(death_overlay)
    hud_root.move_child(death_overlay, 0)
    death_label = Label.new()
    death_label.name = "DeathCountdown"
    death_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    death_label.offset_left = -260.0
    death_label.offset_right = 260.0
    death_label.offset_top = 70.0
    death_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    death_label.add_theme_font_size_override("font_size", 34)
    death_label.add_theme_color_override("font_color", Color(1.0, 0.25, 0.22))
    death_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.95))
    death_label.add_theme_constant_override("outline_size", 8)
    death_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    death_label.visible = false
    hud_root.add_child(death_label)
    death_buttons = HBoxContainer.new()
    death_buttons.name = "DeathButtons"
    death_buttons.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
    death_buttons.offset_left = -330.0
    death_buttons.offset_right = 330.0
    death_buttons.offset_top = -170.0
    death_buttons.offset_bottom = -90.0
    death_buttons.alignment = BoxContainer.ALIGNMENT_CENTER
    death_buttons.add_theme_constant_override("separation", 20)
    death_buttons.mouse_filter = Control.MOUSE_FILTER_IGNORE
    death_buttons.visible = false
    hud_root.add_child(death_buttons)
    death_lobby_btn = Button.new()
    death_lobby_btn.name = "DeathLobby"
    death_lobby_btn.text = "Лобби"
    death_spectate_btn = Button.new()
    death_spectate_btn.name = "DeathSpectate"
    death_spectate_btn.text = "Заспавниться"
    for button in [death_lobby_btn, death_spectate_btn]:
        var bt: Button = button
        bt.theme = _battle_menu_theme()
        bt.focus_mode = Control.FOCUS_NONE
        bt.custom_minimum_size = Vector2(300, 70)
        bt.add_theme_font_size_override("font_size", 24)
        death_buttons.add_child(bt)
    death_lobby_btn.pressed.connect(_leave_dead_to_lobby)
    death_spectate_btn.pressed.connect(_death_respawn)

# Тело и красное кольцо на месте гибели — видны с высоты 45 м.
func _make_death_marker() -> void:
    if is_instance_valid(death_marker):
        death_marker.queue_free()
    var world := get_node_or_null("WorldView/Viewport/World") as Node3D
    if world == null:
        return
    death_marker = Node3D.new()
    death_marker.name = "DeathMarker"
    death_marker.position = Vector3(death_focus.x, death_focus.y + 0.04, death_focus.z)
    death_marker.rotation.y = death_yaw
    world.add_child(death_marker)
    var cloth := StandardMaterial3D.new()
    cloth.albedo_color = Color(0.22, 0.35, 0.30) if Net.my_id() == 1 else Color(0.28, 0.32, 0.55)
    var skin := StandardMaterial3D.new()
    skin.albedo_color = Color(0.85, 0.66, 0.52)
    var parts := [
        [Vector3(0.52, 0.22, 0.75), Vector3(0, 0.11, 0), cloth],
        [Vector3(0.26, 0.24, 0.26), Vector3(0, 0.12, -0.55), skin],
        [Vector3(0.18, 0.18, 0.70), Vector3(-0.15, 0.09, 0.70), cloth],
        [Vector3(0.18, 0.18, 0.70), Vector3(0.15, 0.09, 0.66), cloth],
        [Vector3(0.16, 0.16, 0.60), Vector3(-0.42, 0.08, -0.10), cloth],
        [Vector3(0.16, 0.16, 0.60), Vector3(0.44, 0.08, -0.25), cloth]]
    for p in parts:
        var box := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = p[0]
        box.mesh = mesh
        box.material_override = p[2]
        box.position = p[1]
        death_marker.add_child(box)
    var ring := MeshInstance3D.new()
    ring.name = "DeathRing"
    var torus := TorusMesh.new()
    torus.inner_radius = 1.5
    torus.outer_radius = 1.9
    ring.mesh = torus
    ring.scale = Vector3(1.0, 0.05, 1.0)
    var glow := StandardMaterial3D.new()
    glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    glow.albedo_color = Color(1.0, 0.05, 0.05)
    ring.material_override = glow
    death_marker.add_child(ring)

# Есть ли в бою другие живые игроки (не боты), за которыми можно следить.
func _living_humans_exist() -> bool:
    var me := Net.my_id()
    for id in Net.battle_state.keys():
        var peer := int(id)
        if peer == me or Net.is_bot(peer):
            continue
        if int(Net.battle_state[id]) == Net.ST_ALIVE:
            return true
    return false

# Кнопка «Следить за игроками»: красный экран и вид сверху заканчиваются, камера летает за выжившим.
func _death_respawn() -> void:
    if Net.game_mode != Net.MODE_SURVIVAL or leaving_battle or Net.peer_state(Net.my_id()) != Net.ST_DEAD:
        return
    Net.request_survival_respawn()

func _death_start_spectating() -> void:
    if leaving_battle or death_view_left < 0.0 or not _living_humans_exist():
        return
    death_spectating = true
    death_view_left = -1.0
    if death_overlay != null:
        death_overlay.visible = false
    if death_label != null:
        death_label.visible = false
    if death_buttons != null:
        death_buttons.visible = false
    if is_instance_valid(death_marker):
        death_marker.queue_free()
        death_marker = null
    var target := Net.spectate_target(Net.my_id())
    spec_focus = death_focus + Vector3(0, 1.35, 0)
    if target != -1:
        yaw = float(Net.battle_yaws.get(target, 0.0))
        if actors.has(target):
            spec_focus = (actors[target] as Node3D).position + Vector3(0, 1.35, 0)
    pitch = -0.25
    camera.fov = player_fov

func _update_death_view(delta: float) -> void:
    if death_view_left < 0.0:
        return
    death_view_t += delta
    var living := _living_humans_exist()
    if Net.game_mode == Net.MODE_SURVIVAL:
        if death_buttons != null:
            death_buttons.visible = true
        death_view_left = maxf(0.01, death_view_left - delta)
    else:
        if death_buttons != null:
            death_buttons.visible = living
        if not living:
            death_view_left -= delta
    var pulse := 0.5 + 0.5 * sin(death_view_t * 4.2)
    if death_overlay != null and death_overlay.material is ShaderMaterial:
        (death_overlay.material as ShaderMaterial).set_shader_parameter("strength", 0.55 + 0.35 * pulse)
    if death_label != null:
        if Net.game_mode == Net.MODE_SURVIVAL:
            death_label.text = "ВЫ ПОГИБЛИ\nВыберите: заспавниться или лобби"
        elif living:
            death_label.text = "ВЫ ПОГИБЛИ\nВ бою ещё есть живые игроки"
        else:
            death_label.text = "ВЫ ПОГИБЛИ\nВозврат в лобби через %d" % int(ceil(maxf(death_view_left, 0.0)))
    if is_instance_valid(death_marker):
        var ring := death_marker.get_node_or_null("DeathRing") as Node3D
        if ring != null:
            ring.scale = Vector3(1.0 + 0.35 * pulse, 0.05, 1.0 + 0.35 * pulse)
    if Net.game_mode != Net.MODE_SURVIVAL and not living and death_view_left <= 0.0 and not leaving_battle:
        death_view_left = -1.0
        var mode := "local"
        if Net.battle_over:
            mode = "win" if Net.game_mode == Net.MODE_ZOMBIES and Net.zombie_win else "end"
        _leave_battle(mode)

# Камера плавно поднимается на 45 м над телом и смотрит строго вниз.
func _update_death_camera(delta: float) -> void:
    var rise := smoothstep(0.0, 1.8, death_view_t)
    var height := lerpf(1.6, DEATH_VIEW_HEIGHT, rise)
    camera.position = death_focus + Vector3(0, height, 0)
    camera.rotation = Vector3(lerpf(-0.3, -deg_to_rad(89.0), rise), death_yaw, 0.0)
    camera.fov = lerpf(camera.fov, player_fov, minf(1.0, delta * 8.0))


## Вид от 3-го лица за выжившим: камера за спиной, поворот мышью/свайпом облетает игрока.
func _update_spectator_camera(delta: float) -> void:
    var target := Net.spectate_target(Net.my_id())
    if target != -1 and actors.has(target):
        var focus_goal: Vector3 = (actors[target] as Node3D).position + Vector3(0, 1.35, 0)
        spec_focus = spec_focus.lerp(focus_goal, clampf(delta * 10.0, 0.0, 1.0))
    pitch = clampf(pitch, -1.2, 0.35)
    var orbit := Basis.from_euler(Vector3(pitch, yaw, 0.0))
    var cam_pos: Vector3 = spec_focus + orbit * Vector3(0, 0, SPECTATE_DISTANCE)
    cam_pos.y = maxf(cam_pos.y, 0.3)
    camera.position = cam_pos
    camera.rotation = Vector3(pitch, yaw, 0)
    camera.fov = lerpf(camera.fov, player_fov, minf(1.0, delta * 8.0))

func _on_shot_confirmed(victim: int, damage: int) -> void:
    if hit_marker == null:
        hit_marker = Label.new()
        hit_marker.text = "✕"
        hit_marker.add_theme_font_size_override("font_size", 42)
        hit_marker.add_theme_color_override("font_color", Color(1, 0.25, 0.20))
        hit_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
        hit_marker.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
        hit_marker.position = Vector2(-15, -20)
        add_child(hit_marker)
    hit_marker.visible = true
    hit_marker_time = 0.22
    var held_id := _active_weapon_id()
    if held_id != "" and Weapons.is_melee(held_id):
        _play_weapon_sound(str(Weapons.get_def(held_id).get("sound_hit", "")))

func _on_team_invitation(sender: int, title: String) -> void:
    team_invite_sender = sender
    (team_invite_popup.get_node("VBox").get_child(0) as Label).text = "Приглашение: " + title
    team_invite_popup.show()

func _on_teams_changed() -> void:
    if team_panel != null and team_panel.visible:
        _refresh_team_panel()

func _refresh_team_panel() -> void:
    if team_panel == null:
        return
    var layout: VBoxContainer = team_panel.get_node("VBox")
    for child in layout.get_children():
        layout.remove_child(child)
        child.queue_free()
    var leader := Net.team_leader(Net.my_id())
    if leader == 0:
        var edit := LineEdit.new()
        edit.placeholder_text = "Название команды"
        edit.max_length = 24
        layout.add_child(edit)
        var create := Button.new()
        create.text = "Создать команду"
        layout.add_child(create)
        create.pressed.connect(func():
            Net.create_survival_team(edit.text)
            _refresh_team_panel()
        )
    else:
        var team: Dictionary = Net.survival_teams.get(leader, {})
        var heading := Label.new()
        heading.text = str(team.get("name", "Команда"))
        layout.add_child(heading)
        for member in team.get("members", []):
            var line := Label.new()
            line.text = str(Net.roster.get(int(member), {}).get("nick", "Игрок " + str(member))) + (" (Лидер)" if int(member) == leader else "")
            line.add_theme_color_override("font_color", UiGray.TEXT)
            layout.add_child(line)
        for identity in Net.survival_team_offline.keys():
            var info: Dictionary = Net.survival_team_offline[identity]
            if int(info.get("team", 0)) != leader:
                continue
            var offline_line := Label.new()
            offline_line.text = str(info.get("nick", "Игрок")) + (" (Лидер)" if bool(info.get("leader", false)) else "") + " — не в сети"
            offline_line.add_theme_color_override("font_color", UiGray.TEXT_MUTE)
            layout.add_child(offline_line)
        var leave := Button.new()
        leave.text = "Выйти из команды"
        layout.add_child(leave)
        leave.pressed.connect(func():
            Net.leave_survival_team()
            _refresh_team_panel()
        )
    var back := Button.new()
    back.text = "Назад"
    layout.add_child(back)
    back.pressed.connect(func():
        team_panel.hide()
        pause_panel.show()
    )

func _update_team_invite() -> void:
    if team_invite_button == null:
        return
    team_invite_target = 0
    if paused or Net.team_leader(Net.my_id()) != Net.my_id() or Net.peer_state(Net.my_id()) != Net.ST_ALIVE:
        team_invite_button.hide()
        return
    for raw_id in Net.battle_positions.keys():
        var peer := int(raw_id)
        if peer == Net.my_id() or Net.is_bot(peer) or Net.team_leader(peer) != 0:
            continue
        var pos: Vector3 = Net.battle_positions[peer] + Vector3.UP
        var distance := camera.global_position.distance_to(pos)
        if distance > 1.5:
            continue
        var aim: Vector3 = -camera.global_transform.basis.z
        if aim.dot((pos - camera.global_position).normalized()) > 0.93:
            team_invite_target = peer
            break
    team_invite_button.visible = team_invite_target != 0

func _add_actor(id: int, world: Node3D) -> void:
    var actor: Node3D = Model.new()
    world.add_child(actor)
    var base_color := Color(0.22, 0.35, 0.30) if id == 1 else Color(0.28, 0.32, 0.55)
    # Stage126: выбранный в лобби скин (у ботов в roster записи нет — остаются стандартные цвета).
    var skin_index := int(Net.roster.get(id, {}).get("skin", 0))
    actor.setup(GameState.skin_color(skin_index, base_color))
    actors[id] = actor
    var tag := Label3D.new()
    tag.name = "PlayerTag"
    tag.position = Vector3(0, 2.35, 0)
    tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    tag.no_depth_test = false
    tag.font_size = 36
    tag.pixel_size = 0.006
    tag.outline_size = 6
    tag.modulate = Color.WHITE
    actor.add_child(tag)
    actor_tags[id] = tag

func _button(title: String, dims: Vector2, offset: Vector2, preset: Control.LayoutPreset) -> Button:
    var b: Button = preload("res://scripts/hud_pixel_button.gd").new()
    b.text = ""
    var icon_key := ""
    match title:
        "Пауза": icon_key = "pause"
        "ОГОНЬ": icon_key = "fire"
        "Прыжок": icon_key = "jump"
        "Присед": icon_key = "crouch"
        "Перезарядка": icon_key = "reload"
        "Прицел": icon_key = "aim"
        "Инвентарь": icon_key = "inventory"
        "Взять": icon_key = "pickup"
        "Чат": icon_key = "chat"
    if icon_key != "":
        b.icon = load("res://assets/hud/" + icon_key + ".png")
        b.expand_icon = true
        b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
        b.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("hover", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("pressed", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.tooltip_text = title
    b.custom_minimum_size = dims
    b.set_anchors_and_offsets_preset(preset)
    b.position += offset
    add_child(b)
    return b

func _hold_button(title: String, dims: Vector2, offset: Vector2, callback: Callable) -> Button:
    var b := _button(title, dims, offset, Control.PRESET_BOTTOM_RIGHT)
    b.button_down.connect(func(): callback.call(true))
    b.button_up.connect(func(): callback.call(false))
    return b

func _menu_box(bg: Color, radius: int, edge: Color, border_width: int, inset: int) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.set_corner_radius_all(radius)
    style.border_color = edge
    style.set_border_width_all(border_width)
    style.set_content_margin_all(inset)
    return style

func _battle_menu_theme() -> Theme:
    # Та же серая тема, что и в лобби (scripts/ui_gray.gd).
    return UiGray.make_theme(22)

## Все меню подстраиваются под экран: по центру, а если не влезают (маленький или узкий экран) — уменьшаются.
var fit_panels: Array = []

func _register_fit_panel(p: Control) -> void:
    if not get_viewport().size_changed.is_connected(_fit_all_panels):
        get_viewport().size_changed.connect(_fit_all_panels)
    fit_panels.append(p)
    p.visibility_changed.connect(_fit_panel.bind(p))
    p.resized.connect(_fit_panel.bind(p))

func _fit_all_panels() -> void:
    fit_panels = fit_panels.filter(func(item): return is_instance_valid(item))
    for item in fit_panels:
        _fit_panel(item)

func _fit_panel(p: Control) -> void:
    if not is_instance_valid(p) or not p.visible:
        return
    var screen := get_viewport_rect().size
    var need := p.get_combined_minimum_size()
    var size_now := Vector2(maxf(p.size.x, need.x), maxf(p.size.y, need.y))
    if size_now.x < 1.0 or size_now.y < 1.0:
        return
    var k := minf(1.0, minf(screen.x * 0.96 / size_now.x, screen.y * 0.96 / size_now.y))
    p.pivot_offset = size_now * 0.5
    p.scale = Vector2(k, k)

func _panel(title: String, dims: Vector2) -> PanelContainer:
    var p := PanelContainer.new()
    p.custom_minimum_size = dims
    p.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    p.grow_horizontal = Control.GROW_DIRECTION_BOTH
    p.grow_vertical = Control.GROW_DIRECTION_BOTH
    add_child(p)
    _register_fit_panel(p)
    var v := VBoxContainer.new()
    v.name = "VBox"
    p.add_child(v)
    var label := Label.new()
    label.text = title
    v.add_child(label)
    return p

func _equipment_text() -> String:
    var output := ""
    for item in GameState.battle_equipment:
        if not item.is_empty():
            var key: String = item.get("id", "")
            output += str(GameState.ITEMS.get(key, {}).get("name", key)) + " x" + str(item.get("count", 1)) + "\n"
    return output if output != "" else "Снаряжение пусто"

func _input(event: InputEvent) -> void:
    if chat_open:
        # Пока печатаем, игровые клавиши (WASD, K, пауза...) не работают; Esc закрывает чат.
        if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
            _close_chat()
            get_viewport().set_input_as_handled()
        return
    if event is InputEventKey and event.pressed and not event.echo and _is_desktop() and _pc_key(event, "microphone") and waiting_pc_action == "":
        if not paused and not editing_controls:
            _toggle_game_mic()
            get_viewport().set_input_as_handled()
            return
    if evac_active and not (event is InputEventKey and _pc_key(event, "cursor")):
        return   # во время эвакуации управление отключено
    # Handle F1 before key-binding capture so it always releases/captures the cursor.
    if event is InputEventKey and event.pressed and not event.echo and _pc_key(event, "cursor") and _is_desktop():
        if waiting_pc_action == "":
            pc_mouse_captured = not pc_mouse_captured
            _sync_desktop_cursor()
            shooting = false
            get_viewport().set_input_as_handled()
            return
    if waiting_pc_action != "":
        if event is InputEventKey and event.pressed and not event.echo:
            # Escape cancels binding instead of accidentally closing pause.
            if _event_code(event) != KEY_ESCAPE:
                _assign_pc_bind(waiting_pc_action, _event_code(event))
            waiting_pc_action = ""
            _refresh_pc_bind_buttons()
            get_viewport().set_input_as_handled()
        elif event is InputEventMouseButton and event.pressed:
            if PC_KEYBOARD_ONLY.has(waiting_pc_action):
                if pc_bind_hint != null:
                    pc_bind_hint.text = "Для движения и шага нужна клавиша клавиатуры. Esc — отмена."
            else:
                _assign_pc_bind(waiting_pc_action, event.button_index)
                waiting_pc_action = ""
                _refresh_pc_bind_buttons()
            get_viewport().set_input_as_handled()
        return
    # Esc закрывает меню назначения клавиш (а не паузу).
    if pc_bind_panel != null and is_instance_valid(pc_bind_panel) and event is InputEventKey and event.pressed and not event.echo and _event_code(event) == KEY_ESCAPE:
        _close_pc_binds()
        get_viewport().set_input_as_handled()
        return
    # Android generates synthetic mouse events for every screen tap.
    # They must never enable PC mode or fire the equipped weapon.
    if event is InputEventKey or ((event is InputEventMouseButton or event is InputEventMouseMotion) and _is_real_mouse(event)):
        if (event is InputEventKey and event.pressed) or (event is InputEventMouseButton and event.pressed):
            _set_pc_mode(true)
    elif event is InputEventScreenTouch and event.pressed:
        _set_pc_mode(false)
    # Stage109: кнопки красного экрана смерти — на сенсоре ловим нажатие сами.
    if death_view_left >= 0.0 and death_buttons != null and death_buttons.visible and event is InputEventScreenTouch and event.pressed:
        if death_lobby_btn.get_global_rect().has_point(event.position):
            _leave_dead_to_lobby()
            get_viewport().set_input_as_handled()
            return
        if death_spectate_btn.get_global_rect().has_point(event.position):
            _death_respawn()
            get_viewport().set_input_as_handled()
            return
    # Кнопка «Выйти в лобби» у наблюдателя: на сенсоре нажатие ловим сами (как кнопку прицела).
    if _my_state == Net.ST_DEAD and not paused and not editing_controls and spectate_box != null and spectate_box.visible:
        if event is InputEventScreenTouch and event.pressed and leave_button.get_global_rect().has_point(event.position):
            _leave_dead_to_lobby()
            get_viewport().set_input_as_handled()
            return
    if event is InputEventKey and event.pressed and not event.echo:
        if _pc_key(event, "pause"):
            _toggle_pause()
            return
        if not paused and not editing_controls:
            if _pc_key(event, "jump"): _jump()
            elif _pc_key(event, "crouch"): _spectator_crouch_or_player()
            elif _pc_key(event, "chat"):
                _toggle_chat()
                get_viewport().set_input_as_handled()
            elif free_spectator:
                pass
            elif _pc_key(event, "reload"): _reload()
            elif _pc_key(event, "inventory"): _toggle_battle_inventory()
            elif _pc_key(event, "weapon1"): _select_weapon(0)
            elif _pc_key(event, "weapon2"): _select_weapon(1)
            elif _pc_key(event, "weapon3"): _select_weapon(2)
            elif _pc_key(event, "pickup"): _try_pickup_pc()
            elif _pc_key(event, "use"):
                if aimed_turret >= 0:
                    _buy_turret_ammo()
                else:
                    _toggle_shop()
            else:
                for action in pc_binds.keys():
                    if action in PC_DEFAULTS or int(pc_binds[action]) == 0:
                        continue
                    if _pc_key(event, action):
                        _trigger_hud_pc_action(action)
                        break
    # Only actual PC mouse input fires here. On touch devices the dedicated
    # on-screen FIRE button is the sole way to shoot.
    if event is InputEventKey and not event.echo and not _is_mouse_code(int(pc_binds["fire"])) and _event_code(event) == int(pc_binds["fire"]):
        _set_trigger(event.pressed and not paused and not editing_controls)
    if free_spectator:
        shooting = false
    if not free_spectator and event is InputEventMouseButton and event.button_index == pc_binds["fire"] and int(pc_binds["fire"]) <= MOUSE_BUTTON_XBUTTON2:
        if _is_real_mouse(event):
            _set_trigger(event.pressed and not paused and not editing_controls)
    # Right mouse button aims on desktop. Respect custom PC binding and menus.
    if not free_spectator and event is InputEventMouseButton and _is_real_mouse(event) and event.pressed and _is_desktop():
        if int(pc_binds.get("aim", MOUSE_BUTTON_RIGHT)) == event.button_index:
            if not paused and not editing_controls and not _shop_open() and (inventory_panel == null or not inventory_panel.visible) and (settings_panel == null or not settings_panel.visible):
                _toggle_aim()
                get_viewport().set_input_as_handled()
                return
    if event is InputEventMouseButton and _is_real_mouse(event) and event.pressed and _is_desktop() and not paused and not editing_controls and not free_spectator and _is_mouse_code(event.button_index):
        for action in pc_binds.keys():
            if action == "fire" or action == "aim" or PC_KEYBOARD_ONLY.has(action):
                continue
            if int(pc_binds[action]) == event.button_index:
                _pc_mouse_action(action)
                get_viewport().set_input_as_handled()
                return
    if editing_controls:
        _layout_input(event)
        return
    if _handle_settings_slider_touch(event):
        get_viewport().set_input_as_handled()
        return
    if paused:
        return
    # Give the ADS touch its own finger index. Godot GUI buttons can miss
    # presses when a second finger is already dragging the camera/fire control.
    # Process the press before joystick/look assignment, using the actual
    # resized/repositioned button rectangle from the mobile layout editor.
    if event is InputEventScreenTouch:
        if not event.pressed and event.index == aim_touch:
            aim_touch = -1
            get_viewport().set_input_as_handled()
            return
        if event.pressed and aim_touch == -1 and not pc_mode and aim_button != null and aim_button.visible and aim_button.get_global_rect().has_point(event.position):
            aim_touch = event.index
            _toggle_aim()
            get_viewport().set_input_as_handled()
            return
    elif event is InputEventScreenDrag and event.index == aim_touch:
        get_viewport().set_input_as_handled()
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport_rect().size.x * 0.36 and event.position.y > get_viewport_rect().size.y * 0.48 and joystick_touch == -1:
                joystick_touch = event.index
                joystick_center = event.position
                _stick_move(event.position)
            elif event.position.x > get_viewport_rect().size.x * 0.35 and look_touch == -1:
                look_touch = event.index
        else:
            if event.index == joystick_touch:
                joystick_touch = -1
                direction = Vector2.ZERO
                knob.position = Vector2(54, 54)
            if event.index == look_touch:
                look_touch = -1
    elif event is InputEventScreenDrag:
        if event.index == joystick_touch:
            _stick_move(event.position)
        elif event.index == look_touch and not paused:
            _look(event.relative)
    elif event is InputEventMouseMotion and not paused and not editing_controls:
        if pc_mouse_captured or Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
            _look(event.relative)

func _stick_move(point: Vector2) -> void:
    direction = (point - joystick_center) / 65.0
    direction = direction.limit_length(1.0)
    knob.position = Vector2(54, 54) + direction * 48.0

func _look(motion: Vector2) -> void:
    # В прицеле чувствительность падает вместе с полем зрения.
    var zoom_scale := 1.0
    if aiming and is_instance_valid(camera):
        zoom_scale = clampf(camera.fov / CAMERA_FOV_NORMAL, 0.25, 1.0)
    yaw -= motion.x * 0.004 * zoom_scale
    pitch = clampf(pitch - motion.y * 0.004 * zoom_scale, -1.25, 1.15)
    # Оружие слегка отстаёт от поворота камеры.
    look_sway = (look_sway + motion * 0.00028).limit_length(0.035)

func _set_trigger(pressed: bool) -> void:
    if _my_state != Net.ST_ALIVE and not _can_downed_pistol():
        shooting = false
        return
    shooting = pressed
    if pressed:
        fire_queued = 0.2

func _aiming_at_downed_player() -> bool:
    var origin := camera.global_position
    var ray := -camera.global_transform.basis.z.normalized()
    for id in Net.battle_positions.keys():
        var peer := int(id)
        if peer == Net.my_id() or Net.peer_state(peer) != Net.ST_DOWNED:
            continue
        var center: Vector3 = Net.battle_positions[peer] + Vector3(0, 0.65, 0)
        var along := (center - origin).dot(ray)
        if along >= 0.0 and along <= 2.5 and (origin + ray * along).distance_to(center) <= 0.75:
            return true
    return false

func _fire_weapon(weapon_id: String, def: Dictionary) -> void:
    # Отдача камеры поднимается вверх и слегка уходит в сторону.
    var recoil_scale: float = float(def["recoil_ads"]) if aiming else float(def["recoil"])
    var kick := deg_to_rad((0.8 + minf(recoil_kick, 2.0) * 0.45) * recoil_scale)
    pitch = clampf(pitch + kick, -1.25, 1.15)
    yaw += deg_to_rad(shot_rng.randf_range(-0.42, 0.42) * recoil_scale)
    recoil_kick = minf(recoil_kick + 0.28, 2.0)
    spread_heat = minf(spread_heat + deg_to_rad(float(def["spread_gain"])), deg_to_rad(3.2))
    # Направления пуль считаются отдельно: разброс не двигает камеру.
    var basis := Basis.from_euler(Vector3(pitch, yaw, 0.0))
    var spread := (deg_to_rad(float(def["spread"])) + spread_heat) * (0.6 if aiming else 1.0)
    var directions := PackedVector3Array()
    for i in int(def.get("pellets", 1)):
        var aim := Vector3(shot_rng.randf_range(-spread, spread), shot_rng.randf_range(-spread, spread), -1.0).normalized()
        directions.append((basis * aim).normalized())
    # Точка попадания определяется от камеры, трассер рисуется от дула.
    Net.request_shot(weapon_id, camera.global_position, directions)

## Скорость бега с текущим оружием (м/с). В оптическом прицеле — медленнее, как в CS2.
func _run_speed() -> float:
    var id := _active_weapon_id()
    var scoped := aiming and bool(Weapons.get_def(id).get("scope", false))
    return (Weapons.run_speed(id, scoped) + (550.0 if id == "diamond_sword" else 0.0)) * SPEED_UNIT

## Потолок скорости: бег / шаг (Shift) / присед.
func _max_move_speed() -> float:
    if _my_state == Net.ST_DOWNED:
        return CRAWL_SPEED
    var speed := _run_speed()
    if crouching:
        return speed * CROUCH_FACTOR
    if pc_mode and _pc_held("walk"):
        return speed * WALK_FACTOR
    return speed

## Трение на земле (Source): тормозит сильнее на малых скоростях (stopspeed).
func _apply_friction(delta: float) -> void:
    var speed := vel_h.length()
    if speed < 0.01:
        vel_h = Vector3.ZERO
        return
    var control := maxf(speed, STOP_SPEED)
    var new_speed := maxf(speed - control * GROUND_FRICTION * delta, 0.0)
    vel_h *= new_speed / speed

## Ускорение (Source): добавляем скорость только до wish_speed вдоль направления.
func _accelerate(wish_dir: Vector3, wish_speed: float, accel: float, delta: float, cap: float) -> void:
    if wish_dir == Vector3.ZERO or wish_speed <= 0.0:
        return
    var capped := minf(wish_speed, cap)
    var add_speed := capped - vel_h.dot(wish_dir)
    if add_speed <= 0.0:
        return
    vel_h += wish_dir * minf(accel * wish_speed * delta, add_speed)

func _spectator_crouch_or_player() -> void:
    if free_spectator:
        spectator_vertical = -1.0 if spectator_vertical >= 0.0 else 0.0
    else:
        crouching = not crouching

func _jump() -> void:
    if free_spectator:
        spectator_vertical = 1.0 if spectator_vertical <= 0.0 else 0.0
        return
    if _my_state != Net.ST_ALIVE:
        return
    if local_pos.y <= player_floor_y + 0.01 and not paused:
        velocity_y = 5.0
        weapon_jump_kick = 1.0

func _active_weapon_id() -> String:
    if active_weapon_slot < 0:
        return ""
    var gear: Array = GameState.get_slots("gear")
    if active_weapon_slot >= gear.size():
        return ""
    var stack: Dictionary = gear[active_weapon_slot]
    var id := str(stack.get("id", ""))
    return id if Weapons.has(id) else ""

func _mag_of(weapon_id: String) -> int:
    if not mags.has(weapon_id):
        mags[weapon_id] = int(Weapons.get_def(weapon_id).get("mag", 0))
    return int(mags[weapon_id])

func _is_reloading() -> bool:
    return reload_left > 0.0 or shell_reload

func _count_ammo(ammo_id: String) -> int:
    var total: int = 0
    for bag in [GameState.battle_equipment, GameState.battle_inventory]:
        for entry in bag:
            if str(entry.get("id", "")) == ammo_id:
                total += int(entry.get("count", 0))
    return total

# Запас патронов показывается для типа боеприпасов текущего оружия.
# Инвентарь - единственный источник запасных патронов.
func _sync_reserve() -> void:
    var id := _active_weapon_id()
    var ammo_id := str(Weapons.get_def(id).get("ammo", "")) if id != "" else ""
    reserve = _count_ammo(ammo_id) if ammo_id != "" else 0

func _consume_ammo(ammo_id: String, requested: int) -> int:
    var left: int = maxi(requested, 0)
    var consumed: int = 0
    for bag in [GameState.battle_equipment, GameState.battle_inventory]:
        for i in bag.size():
            if left <= 0:
                break
            var entry: Dictionary = bag[i]
            if str(entry.get("id", "")) != ammo_id:
                continue
            var amount: int = mini(left, int(entry.get("count", 0)))
            if amount <= 0:
                continue
            left -= amount
            consumed += amount
            var remainder: int = int(entry.get("count", 0)) - amount
            if remainder <= 0:
                bag[i] = {}
            else:
                entry["count"] = remainder
    _sync_reserve()
    if consumed > 0:
        GameState.changed.emit()
    return consumed

func _reload() -> void:
    # Talent owners may reload only their second-slot pistol while downed.
    if _my_state != Net.ST_ALIVE and not _can_downed_pistol():
        return
    _set_aim(false)
    var id := _active_weapon_id()
    if id == "" or Weapons.is_melee(id) or _is_reloading():
        return
    _sync_reserve()
    var def: Dictionary = Weapons.get_def(id)
    var missing: int = int(def["mag"]) - _mag_of(id)
    if missing <= 0 or reserve <= 0:
        return
    Net.submit_battle_event("reload")   # остальные услышат и увидят перезарядку
    if str(def["reload_style"]) == "shell":
        shell_reload = true
        shell_timer = 0.35
        _animate_shell_reload(def, mini(missing, reserve))
    else:
        reload_left = float(def["reload"])
        _play_weapon_sound(str(def.get("sound_reload", "")))
        _animate_reload(def)

func _toggle_free_spectator() -> void:
    free_spectator = not free_spectator
    spectator_vertical = 0.0
    if free_spectator:
        free_camera_position = camera.position
        _set_aim(false)
        shooting = false
        vel_h = Vector3.ZERO
    else:
        screenshot_hud_hidden = false
    paused = false
    pause_panel.hide()
    settings_panel.hide()
    spectator_hud_button.visible = free_spectator
    spectator_exit_button.visible = free_spectator
    spectator_pause_button.text = "Вернуться" if free_spectator else "Спектатор"
    _refresh_spectator_hud()
    if _is_desktop():
        pc_mouse_captured = true
        _sync_desktop_cursor()

func _toggle_spectator_hud() -> void:
    screenshot_hud_hidden = not screenshot_hud_hidden
    _refresh_spectator_hud()

func _refresh_spectator_hud() -> void:
    if not free_spectator:
        _set_mobile_hud_visible(not paused and not pc_mode)
        spectator_hud_button.hide()
        spectator_exit_button.hide()
        return
    _set_mobile_hud_visible(not screenshot_hud_hidden and not paused and not pc_mode)
    for key in controls:
        controls[key].visible = not screenshot_hud_hidden and not paused and not pc_mode and key in ["joystick", "jump", "crouch", "pause"]
    for button in weapon_buttons:
        button.hide()
    if ammo_bar != null:
        ammo_bar.hide()
    spectator_hud_button.visible = not paused
    spectator_hud_button.text = "HUD: показать" if screenshot_hud_hidden else "HUD: скрыть"
    spectator_exit_button.visible = not paused and not screenshot_hud_hidden

func _update_free_spectator(delta: float) -> void:
    if not paused and not editing_controls:
        var move := direction
        if pc_mode:
            move += Vector2(float(int(_pc_held("right")) - int(_pc_held("left"))), float(int(_pc_held("back")) - int(_pc_held("forward"))))
        move = move.limit_length(1.0)
        var basis := Basis(Vector3.UP, yaw)
        var horizontal := basis * Vector3(move.x, 0.0, move.y)
        free_camera_position += (horizontal * 9.0 + Vector3.UP * spectator_vertical * 9.0) * delta
    camera.position = free_camera_position
    camera.rotation = Vector3(pitch, yaw, 0.0)
    camera.fov = player_fov

func _toggle_pause() -> void:
    if chat_open:
        _close_chat()
    _set_aim(false)
    paused = not paused
    if not paused and _is_desktop():
        pc_mouse_captured = true
    settings_panel.hide()
    pause_panel.visible = paused
    _set_mobile_hud_visible(not paused and not pc_mode)
    if free_spectator:
        _refresh_spectator_hud()
    if pickup_button != null:
        pickup_button.visible = false
    shooting = false
    direction = Vector2.ZERO

func _toggle_battle_inventory() -> void:
    if inventory_panel == null or _my_state == Net.ST_DEAD:
        return
    inventory_panel.visible = not inventory_panel.visible
    if not inventory_panel.visible and _is_desktop():
        pc_mouse_captured = true
    _sync_desktop_cursor()

func _sync_desktop_cursor() -> void:
    if not _is_desktop():
        return
    var menu_open := paused or editing_controls or chat_open
    menu_open = menu_open or (inventory_panel != null and inventory_panel.visible)
    menu_open = menu_open or (pause_panel != null and pause_panel.visible)
    menu_open = menu_open or (settings_panel != null and settings_panel.visible)
    menu_open = menu_open or (pc_bind_panel != null and is_instance_valid(pc_bind_panel))
    menu_open = menu_open or (team_panel != null and team_panel.visible)
    menu_open = menu_open or (survival_join_dialog != null and survival_join_dialog.visible)
    menu_open = menu_open or (battle_invite_popup != null and battle_invite_popup.visible)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if menu_open or not pc_mouse_captured else Input.MOUSE_MODE_CAPTURED

func _sync_inventory_weapon_buttons() -> void:
    if inventory_panel != null and inventory_panel.visible:
        _set_aim(false)
    # The battle inventory owns its own weapon slots. Hide only the three
    # mobile weapon-select HUD buttons while that inventory is open.
    var inventory_open: bool = inventory_panel != null and inventory_panel.visible
    for button in weapon_buttons:
        if is_instance_valid(button):
            button.visible = editing_controls or (not inventory_open and not paused and not pc_mode and _my_state == Net.ST_ALIVE)

func _set_mobile_hud_visible(is_visible: bool) -> void:
    for key in controls:
        var show_key: bool = is_visible
        if not editing_controls:
            if _my_state == Net.ST_DEAD:
                show_key = is_visible and (key == "pause" or key == "chat")
            elif _my_state == Net.ST_DOWNED and key in DOWNED_HIDDEN_CONTROLS:
                show_key = is_visible and key in ["fire", "reload", "aim"] and _can_downed_pistol()
        # Health and stance remain visible on PC too, but can be moved in layout mode.
        controls[key].visible = show_key or ((key == "health_bar" or key == "voice") and not editing_controls)
    _sync_inventory_weapon_buttons()
    if ammo_bar != null and not editing_controls:
        ammo_bar.visible = _my_state != Net.ST_DEAD and (is_visible or pc_mode) and _active_weapon_id() != "" and not Weapons.is_melee(_active_weapon_id())
    if not is_visible:
        aim_touch = -1
        joystick_touch = -1
        look_touch = -1
        direction = Vector2.ZERO
        shooting = false
        knob.position = Vector2(54, 54)

func _process(delta: float) -> void:
    _update_chat()
    if gfx_fx != null:
        gfx_fx.feet_y = local_pos.y - 1.0
    var pause_menu_open: bool = (pause_panel != null and pause_panel.visible) or (settings_panel != null and settings_panel.visible)
    if fps_label != null:
        fps_label.visible = pause_menu_open
        fps_acc += delta
        if pause_menu_open and fps_acc >= 0.25:
            fps_acc = 0.0
            var fps := Engine.get_frames_per_second()
            fps_label.text = "FPS: %d" % fps
            fps_label.add_theme_color_override("font_color", Color(0.4, 1.0, 0.5) if fps >= 50 else (Color(1.0, 0.85, 0.3) if fps >= 30 else Color(1.0, 0.4, 0.35)))
    if survival_join_banner_time > 0.0:
        survival_join_banner_time -= delta
        if survival_join_banner_time <= 0.0 and survival_join_banner != null:
            survival_join_banner.hide()
    _update_voice_rows()
    if Net.game_mode == Net.MODE_SURVIVAL:
        _update_team_invite()
    if Net.game_mode == Net.MODE_SURVIVAL and Net.battle_active and Net.peer_state(Net.my_id()) == Net.ST_ALIVE:
        _survival_autosave_elapsed += delta
        if _survival_autosave_elapsed >= 15.0:
            _survival_autosave_elapsed = 0.0
            _survival_snapshot_now()
    if Net.game_mode == Net.MODE_ZOMBIES:
        _update_zombie_display()
        _update_turrets(delta)
        _update_shop_prompt(delta)
        # Stage87: игрок коснулся точки появления -> личная сцена с вертолётом.
        if Net.is_evacuated(Net.my_id()) and not evac_played and not evac_active and not leaving_battle:
            _start_evac()
    if reviving:
        if paused or editing_controls or _my_state != Net.ST_ALIVE or not _aiming_at_downed_player():
            _cancel_reviving()
        else:
            revive_progress += delta
            if revive_label != null:
                revive_label.text = "Поднятие: %.1f сек / 5.0 сек" % minf(revive_progress, 5.0)
            if revive_progress >= 5.15:
                Net.request_revive(camera.global_position, -camera.global_transform.basis.z)
                reviving = false
                revive_progress = 0.0
                if revive_label != null:
                    revive_label.text = ""
    # Живых не осталось (в т.ч. единственный игрок погиб) — сразу в лобби.
    _update_death_view(delta)
    if Net.battle_over and not leaving_battle and not evac_active and not _death_view_blocks_exit():
        _leave_battle("win" if Net.game_mode == Net.MODE_ZOMBIES and Net.zombie_win else "end")
        return
    var life := Net.peer_state(Net.my_id())
    # Пока идёт моя сцена с вертолётом, интерфейс «наблюдателя» не включаем.
    if evac_active and life == Net.ST_DEAD and Net.is_evacuated(Net.my_id()):
        life = _my_state
    if life != _my_state:
        _on_life_changed(life)
    if life == Net.ST_DOWNED:
        crouching = false   # в нокауте только ползём на коленях
    if not free_spectator and not paused and not editing_controls and life != Net.ST_DEAD and not evac_active and not _shop_open():
        var pc_move := Vector2.ZERO
        if pc_mode:
            pc_move.x = int(_pc_held("right")) - int(_pc_held("left"))
            pc_move.y = int(_pc_held("back")) - int(_pc_held("forward"))
        var move := direction + pc_move
        move = move.limit_length(1.0)
        var wish3 := Vector3(move.x, 0, move.y).rotated(Vector3.UP, yaw)
        var wish_dir := wish3.normalized() if wish3.length() > 0.001 else Vector3.ZERO
        var wish_speed := _max_move_speed() * minf(wish3.length(), 1.0)
        # Stage122: пол — палуба, верх ящика (можно стоять) или пустота над водой.
        if Net.game_mode == Net.MODE_ZOMBIES:
            player_floor_y = TitanicMap.floor_height(local_pos.x, local_pos.z, local_pos.y)
        else:
            player_floor_y = 1.0
        var grounded := local_pos.y <= player_floor_y + 0.001 and velocity_y <= 0.0
        if grounded:
            _apply_friction(delta)
            _accelerate(wish_dir, wish_speed, GROUND_ACCEL, delta, 1000.0)
        else:
            _accelerate(wish_dir, wish_speed, AIR_ACCEL, delta, AIR_SPEED_CAP)
        local_pos += vel_h * delta
        velocity_y -= 12.0 * delta
        if Net.game_mode == Net.MODE_ZOMBIES:
            player_floor_y = TitanicMap.floor_height(local_pos.x, local_pos.z, local_pos.y)
        local_pos.y = maxf(player_floor_y, local_pos.y + velocity_y * delta)
        if local_pos.y <= player_floor_y and player_floor_y > -500.0:
            velocity_y = 0.0
        if Net.game_mode == Net.MODE_ZOMBIES:
            # Stage80: палуба «Титаника» — борта и надстройки не пускают игрока.
            var resolved := TitanicMap.resolve_player(local_pos)
            if absf(resolved.x - local_pos.x) > 0.0001:
                vel_h.x = 0.0
            if absf(resolved.z - local_pos.z) > 0.0001:
                vel_h.z = 0.0
            local_pos = resolved
            # Stage123: на айсберге игрока уносит назад вместе с льдом (корабль идёт вперёд).
            if TitanicMap.on_ice(local_pos):
                local_pos.z += TitanicMap.SHIP_SPEED * delta
        else:
            if absf(local_pos.x) > 24.0:
                vel_h.x = 0.0
            if absf(local_pos.z) > 24.0:
                vel_h.z = 0.0
            local_pos.x = clampf(local_pos.x, -24, 24)
            local_pos.z = clampf(local_pos.z, -24, 24)
        _update_weapon_motion(delta, clampf(vel_h.length() / maxf(_run_speed(), 0.1), 0.0, 1.0))
        Net.submit_battle_position(local_pos, yaw, pitch)
        _sync_hold_state()
        shot_left -= delta
        recoil_kick = move_toward(recoil_kick, 0.0, delta * 2.2)
        spread_heat = move_toward(spread_heat, 0.0, delta * 0.11)
        fire_queued = maxf(fire_queued - delta, 0.0)
        dry_fire_cooldown = maxf(dry_fire_cooldown - delta, 0.0)
        _update_reload(delta)
        _update_firing()
    if flash_time > 0.0:
        flash_time -= delta
        if flash_time <= 0.0:
            var flash := _ref_node("flash")
            if flash != null:
                flash.visible = false
    if hit_marker_time > 0.0:
        hit_marker_time -= delta
        if hit_marker_time <= 0.0 and hit_marker != null:
            hit_marker.hide()
    if collimator_reticle != null and collimator_reticle.visible and not aiming:
        _set_collimator(false)
    _update_combat_feedback(delta)
    var id := Net.my_id()
    for peer_id in Net.battle_positions.keys():
        if not actors.has(peer_id):
            _add_actor(peer_id, viewport.get_child(0))
        if evac_active and evac != null and evac.cam_active and peer_id == id:
            continue   # мою позицию ведёт сцена эвакуации (остальные игроки живут как обычно)
        var actor: Node3D = actors[peer_id]
        var target_pos: Vector3 = local_pos if peer_id == id else Net.battle_positions[peer_id]
        # Чужие позиции приходят ~20 раз в секунду: сглаживаем, иначе анимация шага рваная.
        if peer_id == id or not actor.has_meta("placed") or actor.position.distance_to(target_pos) > 4.0:
            actor.position = target_pos
            actor.set_meta("placed", true)
        else:
            actor.position = actor.position.lerp(target_pos, clampf(delta * 16.0, 0.0, 1.0))
        # Вращаем тело по горизонтальному углу камеры; наклон головы не вращает корпус.
        # Модель смотрит в +Z, камера — в -Z, поэтому разворачиваем на PI.
        actor.rotation.y = (yaw if peer_id == id else float(Net.battle_yaws.get(peer_id, 0.0))) + PI
        # Stage123: брызги, когда кто-то (и я) коснулся воды.
        if zombie_map != null and Net.game_mode == Net.MODE_ZOMBIES:
            var in_water: bool = target_pos.y <= TitanicMap.WATER_TOUCH_Y
            if in_water and not actor.has_meta("splashed"):
                actor.set_meta("splashed", true)
                TitanicMap.splash(zombie_map, Vector3(target_pos.x, TitanicMap.WATER_Y + 0.15, target_pos.z))
            elif target_pos.y > -3.0 and actor.has_meta("splashed"):
                actor.remove_meta("splashed")
        var peer_life := Net.peer_state(peer_id)
        # Погибшие и ушедшие в лобби игроки с поля исчезают.
        var on_field: bool = peer_life != Net.ST_DEAD and peer_life != Net.ST_LEFT
        var shadow_body: bool = gfx_fx != null and gfx_fx.real_shadows()
        actor.call("set_real_shadows", shadow_body)
        if peer_id == id:
            actor.call("hide_from_camera", shadow_body)   # свой игрок: не виден камере, но отбрасывает тень
        actor.visible = on_field and (peer_id != id or shadow_body)
        if actor_tags.has(peer_id):
            var nick: String = "БОТ %d" % (peer_id - Net.BOT_ID_START) if Net.is_bot(peer_id) else str(Net.roster.get(peer_id, {}).get("nick", "Игрок %s" % str(peer_id)))
            var hp: int = clampi(int(Net.battle_health.get(peer_id, 100)), 0, 100)
            if peer_life == Net.ST_DOWNED:
                (actor_tags[peer_id] as Label3D).text = "%s\nНОКАУТ: %d" % [nick, int(Net.battle_bleed.get(peer_id, 0))]
            else:
                (actor_tags[peer_id] as Label3D).text = "%s\nHP: %d / 100" % [nick, hp]
            var tag_node: Label3D = actor_tags[peer_id]
            var leader := Net.team_leader(int(peer_id))
            var ally := Net.same_team(Net.my_id(), int(peer_id)) and int(peer_id) != Net.my_id()
            var meters := local_pos.distance_to(Net.battle_positions[peer_id])
            # Allies beyond 50m are shown through walls; close allies use ordinary depth testing.
            tag_node.no_depth_test = ally and meters > 50.0
            if ally and meters > 50.0:
                tag_node.text = "%s\n%d м" % [nick, roundi(meters)]
            elif leader == int(peer_id) and Net.survival_teams.has(leader):
                tag_node.text = str(Net.survival_teams[leader].get("name", "")) + "\n" + tag_node.text
            tag_node.visible = not ally or meters > 50.0

    # Smooth eye-height transition and synchronized third-person crouch pose.
    crouch_blend = move_toward(crouch_blend, 1.0 if crouching else 0.0, delta * 4.5)
    if previous_crouch != crouching:
        previous_crouch = crouching
        Net.submit_battle_crouch(crouching)
    for peer_id in actors.keys():
        if evac_active and evac != null and evac.cam_active and peer_id == id:
            continue
        var model = actors[peer_id]
        var target_crouch: bool = crouching if peer_id == id else bool(Net.battle_crouches.get(peer_id, false))
        model.set_crouching(target_crouch, delta)
        var model_life := Net.peer_state(peer_id)
        model.set_downed(model_life == Net.ST_DOWNED, delta)
        if peer_id != id:
            # Оружие в руках, куда оно направлено и прицеливается ли игрок — как у владельца.
            var held_now := str(Net.battle_weapons.get(peer_id, ""))
            if model_life != Net.ST_ALIVE:
                held_now = ""   # в нокауте оружие убрано
            if str(_remote_weapon_seen.get(peer_id, "")) != held_now:
                _remote_weapon_seen[peer_id] = held_now
                if held_now != "":
                    # Игрок достал оружие — слышно из его позиции.
                    _play_world_sound("res://assets/audio/draw.wav", (model as Node3D).global_position + Vector3(0, 1.2, 0), -3.0)
            model.set_weapon(held_now, bool(Net.battle_attach.get(peer_id, false)))
            model.set_aim_state(bool(Net.battle_aims.get(peer_id, false)), float(Net.battle_pitches.get(peer_id, 0.0)))
        model.auto_animate(delta)
    downed_blend = move_toward(downed_blend, 1.0 if life == Net.ST_DOWNED else 0.0, delta * 2.5)
    if evac_active:
        _update_evac(delta)
    if evac_active and evac != null and evac.cam_active:
        pass   # камеру ведёт сцена эвакуации
    elif free_spectator:
        _update_free_spectator(delta)
    elif life == Net.ST_DEAD:
        if death_view_left >= 0.0:
            _update_death_camera(delta)
        else:
            _update_spectator_camera(delta)
    else:
        # В нокауте камера опускается почти к земле.
        var eye_height := lerpf(lerpf(1.45, 0.75, crouch_blend), 0.5, downed_blend)
        camera.position = local_pos + Vector3(0, eye_height, 0)
        camera.rotation = Vector3(pitch, yaw, 0)
        # Small smooth zoom when looking through the iron sights.
        var target_fov := player_fov
        if aiming:
            target_fov = float(Weapons.get_def(_active_weapon_id()).get("fov_ads", CAMERA_FOV_AIM))
            if _collimator_active():
                # Увеличение в 1.25 раза: поле зрения сужается так, чтобы картинка выросла на 25%.
                target_fov = rad_to_deg(2.0 * atan(tan(deg_to_rad(target_fov) * 0.5) / COLLIMATOR_ZOOM))
        camera.fov = lerpf(camera.fov, target_fov, minf(1.0, delta * 12.0))
    if not editing_controls and not evac_active:
        _update_pickup_target()
    var current_hp: int = clampi(int(Net.battle_health.get(Net.my_id(), 100)), 0, 100)
    health_bar.max_value = 440 if _active_weapon_id() == "diamond_sword" else 100
    health_bar.value = current_hp
    stance_label.text = "%s  %d" % ["Присяд" if crouching else "Стоя", int(round(vel_h.length() / SPEED_UNIT))]
    var weapon_id := _active_weapon_id()
    var weapon_text := ""
    if weapon_id != "":
        var weapon_def: Dictionary = Weapons.get_def(weapon_id)
        if Weapons.is_melee(weapon_id):
            weapon_text = " | %s" % str(weapon_def["name"])
        else:
            weapon_text = " | %s %d / %d" % [str(weapon_def["name"]), _mag_of(weapon_id), reserve]
    if ammo_bar != null:
        var ammo_id := str(Weapons.get_def(weapon_id).get("ammo", "")) if weapon_id != "" else ""
        ammo_bar.text = "%d/%d" % [_mag_of(weapon_id), _count_ammo(ammo_id)] if ammo_id != "" else ""
        if not editing_controls:
            ammo_bar.visible = ammo_id != "" and life != Net.ST_DEAD and (not paused or pc_mode) and not evac_active
    status.text = "БОЙ | HP %d%s" % [current_hp, weapon_text]
    if life == Net.ST_DOWNED:
        status.text = "НОКАУТ | доступен пистолет" if _can_downed_pistol() else "НОКАУТ | ползите, стрелять нельзя"
    elif life == Net.ST_DEAD:
        if death_view_left >= 0.0:
            if Net.game_mode == Net.MODE_SURVIVAL:
                status.text = "ВЫ ПОГИБЛИ | заспавниться или лобби"
            elif _living_humans_exist():
                status.text = "ВЫ ПОГИБЛИ | выберите: лобби или наблюдение"
            else:
                status.text = "ВЫ ПОГИБЛИ | возврат в лобби через %d с" % int(ceil(death_view_left))
        else:
            status.text = "ВЫ ЭВАКУИРОВАНЫ | наблюдение за выжившим" if Net.is_evacuated(id) else "ВЫ ПОГИБЛИ | наблюдение за выжившим"
    _update_life_hud(life)

## Вызывать также из будущей системы HP/смерти при реальном поражении.
func _lose_battle() -> void:
    _leave_battle()

## Пауза -> «Выйти из боя».
func _exit_battle() -> void:
    _leave_battle("local")

func _leave_dead_to_lobby() -> void:
    _leave_battle("local")

## Аккуратный выход в лобби: сначала убираем 3D-мир и временные ресурсы боя,
## восстанавливаем глобальные настройки и только потом меняем сцену.
## mode: "party" — выйти и покинуть лобби-группу (как раньше);
##       "end"   — бой закончен для всех, в лобби идём вместе с группой;
##       "dead"  — мёртвый уходит в лобби, бой у остальных продолжается.
func _leave_battle(mode: String = "party") -> void:
    if leaving_battle:
        return
    # Выход из боя: сначала сохраняем выживание (Client - на телефон и Host-у, Host - в мир).
    _survival_snapshot_now()
    leaving_battle = true
    if mode == "win":
        GameState.win_zombie_battle()
    else:
        GameState.lose_battle()
    match mode:
        "end":
            Net.request_finish_battle()
            Net.leave_battle_locally()
        _:
            Net.leave_battle_locally()
    paused = true
    if weapon_tween != null:
        weapon_tween.kill()
    if fx_tween != null:
        fx_tween.kill()
    _clear_held_weapon()
    _clear_world_drops()
    if viewport != null:
        viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
    if has_node("WorldView"):
        var view := $WorldView
        remove_child(view)
        view.queue_free()
    set_process(false)
    set_process_input(false)
    set_process_unhandled_input(false)
    # Настройки, которые бой менял глобально, возвращаем лобби.
    Input.set_emulate_mouse_from_touch(true)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    AudioServer.set_bus_volume_db(0, saved_bus_db)
    # Для клиента бой закрывается локально после отправки Host сообщения о выходе.
    # Если в сцене уже нет активного боя, сбрасываем флаг, чтобы можно было играть снова.
    if Net.role == "client" and not Net.battle_active:
        Net.local_battle_left = false
    # Два кадра, чтобы рендер успел освободить ресурсы мира до загрузки лобби.
    await get_tree().process_frame
    await get_tree().process_frame
    get_tree().change_scene_to_file("res://main.tscn")

func _handle_settings_slider_touch(event: InputEvent) -> bool:
    if settings_panel == null or not settings_panel.visible:
        return false
    if event is InputEventScreenTouch:
        if event.pressed and ui_slider_touch == -1:
            for node in get_tree().get_nodes_in_group("battle_settings_sliders"):
                var slider := node as HSlider
                if slider != null and slider.is_visible_in_tree() and slider.get_global_rect().grow(16.0).has_point(event.position):
                    ui_slider_touch = event.index
                    ui_slider_active = slider
                    _set_settings_slider_from_touch(event.position)
                    return true
        elif event.index == ui_slider_touch:
            _set_settings_slider_from_touch(event.position)
            if not event.pressed:
                ui_slider_touch = -1
                ui_slider_active = null
            return true
    elif event is InputEventScreenDrag and event.index == ui_slider_touch:
        _set_settings_slider_from_touch(event.position)
        return true
    return false

func _set_settings_slider_from_touch(point: Vector2) -> void:
    if ui_slider_active == null:
        return
    var bounds := ui_slider_active.get_global_rect()
    var ratio := clampf((point.x - bounds.position.x) / maxf(bounds.size.x, 1.0), 0.0, 1.0)
    ui_slider_active.value = lerpf(ui_slider_active.min_value, ui_slider_active.max_value, ratio)

func _setting_slider(title: String, initial: float, changed: Callable, minimum: float = 0.0, maximum: float = 100.0) -> void:
    var label := Label.new()
    label.text = "%s: %d" % [title, int(initial)]
    settings_panel.get_node("VBox").add_child(label)
    var slider := HSlider.new()
    slider.min_value = minimum
    slider.max_value = maximum
    slider.step = 1
    slider.value = initial
    slider.custom_minimum_size.x = 285
    settings_panel.get_node("VBox").add_child(slider)
    slider.add_to_group("battle_settings_sliders")
    slider.value_changed.connect(func(value: float):
        label.text = "%s: %d" % [title, int(value)]
        changed.call(value)
    )

## Stage124: голосовой чат — кнопка «Микрофон» и под ней галочка «Слышать других игроков».
func _build_voice_settings() -> void:
    var box := settings_panel.get_node("VBox")
    mic_allow_check = CheckBox.new()
    mic_allow_check.text = "Разрешить микрофон (кнопка / назначенная клавиша)"
    mic_allow_check.button_pressed = mic_allowed
    box.add_child(mic_allow_check)
    mic_allow_check.toggled.connect(func(on: bool):
        mic_allowed = on
        if not on:
            VoiceChat.set_mic(false)
        _on_mic_changed(VoiceChat.mic_enabled)
        _save_settings()
    )
    mic_button = Button.new()
    box.add_child(mic_button)
    mic_button.pressed.connect(_toggle_game_mic)
    mic_listen_check = CheckBox.new()
    mic_listen_check.text = "Слышать других игроков"
    mic_listen_check.button_pressed = VoiceChat.listen_enabled
    box.add_child(mic_listen_check)
    mic_listen_check.toggled.connect(func(on: bool):
        VoiceChat.set_listening(on)
        _save_settings()
    )
    # Красная надпись сверху экрана, пока ваш микрофон включён.
    mic_hud_label = Label.new()
    mic_hud_label.text = "● МИКРОФОН ВКЛЮЧЁН"
    mic_hud_label.add_theme_font_size_override("font_size", 20)
    mic_hud_label.add_theme_color_override("font_color", Color(1.0, 0.3, 0.3))
    mic_hud_label.add_theme_color_override("font_outline_color", Color.BLACK)
    mic_hud_label.add_theme_constant_override("outline_size", 6)
    mic_hud_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
    mic_hud_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    mic_hud_label.position.y = 8.0
    mic_hud_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    mic_hud_label.hide()
    add_child(mic_hud_label)
    VoiceChat.mic_changed.connect(_on_mic_changed)
    VoiceChat.mic_permission_denied.connect(_on_mic_permission_denied)
    _on_mic_changed(VoiceChat.mic_enabled)
    # Список говорящих — элемент HUD: переносится и масштабируется в «Изменить управление»
    # (на телефоне и на ПК). По умолчанию: телефон — под прицелом, ПК — справа по центру.
    voice_box = VBoxContainer.new()
    voice_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    voice_box.add_theme_constant_override("separation", 4)
    voice_box.custom_minimum_size = Vector2(VOICE_BOX_WIDTH, 44.0)
    voice_box.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
    $HUD.add_child(voice_box)
    voice_box.size = voice_box.custom_minimum_size
    var screen := get_viewport_rect().size
    if screen.x < 100.0 or screen.y < 100.0:
        screen = Vector2(1280, 720)
    if DisplayServer.is_touchscreen_available():
        voice_box.position = Vector2(screen.x * 0.5 - VOICE_BOX_WIDTH * 0.5, screen.y * 0.5 + 48.0)
    else:
        voice_box.position = Vector2(screen.x - VOICE_BOX_WIDTH - 20.0, screen.y * 0.5 - 22.0)
    controls["voice"] = voice_box
    voice_preview = _make_voice_row("Имя игрока")["panel"]
    voice_preview.hide()
    VoiceChat.voice_activity.connect(_on_voice_activity)

func _make_voice_row(text: String) -> Dictionary:
    var panel := PanelContainer.new()
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    panel.add_theme_stylebox_override("panel", _menu_box(Color(0.03, 0.05, 0.09, 0.62), 10, Color(0.32, 0.42, 0.58, 0.8), 1, 8))
    var label := Label.new()
    label.text = text
    label.add_theme_font_size_override("font_size", 20)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    panel.add_child(label)
    voice_box.add_child(panel)
    return {"panel": panel, "label": label}

## Образец строки показываем только пока игрок двигает HUD — иначе пустую область не найти.
func _show_voice_preview(on: bool) -> void:
    if not is_instance_valid(voice_preview):
        return
    voice_preview.visible = on
    if on:
        voice_box.move_child(voice_preview, voice_box.get_child_count() - 1)

func _on_voice_activity(peer_id: int) -> void:
    if peer_id != Net.my_id() and not VoiceChat.is_peer_audible(peer_id):
        return
    var now := Time.get_ticks_msec()
    if voice_rows.has(peer_id) and is_instance_valid(voice_rows[peer_id]["panel"]):
        voice_rows[peer_id]["last_ms"] = now
        return
    var row := _make_voice_row(str(Net.roster.get(peer_id, {}).get("nick", "Игрок %s" % str(peer_id))))
    row["last_ms"] = now
    voice_rows[peer_id] = row

## Имя зеленеет, пока игрок говорит; через 1.3 с тишины текст и фон плавно исчезают.
func _update_voice_rows() -> void:
    if voice_rows.is_empty():
        return
    var now := Time.get_ticks_msec()
    for peer_id in voice_rows.keys():
        if peer_id != Net.my_id() and not VoiceChat.is_peer_audible(int(peer_id)):
            var hidden_row: Dictionary = voice_rows[peer_id]
            if is_instance_valid(hidden_row["panel"]):
                hidden_row["panel"].queue_free()
            voice_rows.erase(peer_id)
            continue
        var row: Dictionary = voice_rows[peer_id]
        var panel: PanelContainer = row["panel"]
        if not is_instance_valid(panel):
            voice_rows.erase(peer_id)
            continue
        var silent := float(now - int(row["last_ms"])) / 1000.0
        var label: Label = row["label"]
        label.add_theme_color_override("font_color", Color(0.3, 1.0, 0.4) if silent < VOICE_SPEAK_SEC else Color.WHITE)
        if silent <= VOICE_FADE_DELAY:
            panel.modulate.a = 1.0
        else:
            panel.modulate.a = clampf(1.0 - (silent - VOICE_FADE_DELAY) / VOICE_FADE_TIME, 0.0, 1.0)
            if panel.modulate.a <= 0.0:
                panel.queue_free()
                voice_rows.erase(peer_id)

func _toggle_game_mic() -> void:
    if not mic_allowed:
        # Нажатие на кнопку микрофона само даёт разрешение (раньше нужно было искать галочку в настройках).
        mic_allowed = true
        if mic_allow_check != null:
            mic_allow_check.set_pressed_no_signal(true)
        _save_settings()
    VoiceChat.toggle_mic()
    _on_mic_changed(VoiceChat.mic_enabled)

func _on_mic_changed(enabled: bool) -> void:
    if mic_quick_button != null:
        var key_hint := ""
        if _is_desktop() and pc_binds.has("microphone") and int(pc_binds["microphone"]) != 0:
            key_hint = " (%s)" % _bind_name("microphone", int(pc_binds["microphone"]))
        mic_quick_button.text = ("МИК ВКЛ" if enabled else "МИК ВЫКЛ") + key_hint
        mic_quick_button.modulate = Color(0.5, 1.0, 0.5) if enabled else Color(1, 1, 1, 0.9)
    if mic_hud_button != null:
        mic_hud_button.disabled = false
        mic_hud_button.text = "МИКР ВКЛ" if enabled else "МИКР ВЫКЛ"
        mic_hud_button.modulate = Color(0.5, 1.0, 0.5) if enabled else Color.WHITE
    if mic_button != null:
        mic_button.text = "Микрофон: ВКЛ" if enabled else "Микрофон: ВЫКЛ"
        mic_button.disabled = false
        mic_button.modulate = Color(0.6, 1.0, 0.6) if enabled else Color.WHITE
    if mic_hud_label != null:
        mic_hud_label.visible = enabled

func _on_mic_permission_denied() -> void:
    if mic_button != null:
        mic_button.text = "Микрофон: нет разрешения"

func _apply_settings() -> void:
    brightness_layer.color = Color(0, 0, 0, (100.0 - brightness) / 100.0 * 0.85)
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume / 100.0, 0.0001)))

func _save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("general", "brightness", brightness)
    cfg.set_value("general", "volume", volume)
    cfg.set_value("general", "fov", player_fov)
    cfg.set_value("general", "graphics", gfx_quality)
    cfg.set_value("general", "weather", weather_mode)
    cfg.set_value("general", "blood", blood_enabled)
    cfg.set_value("general", "pause_fallback", pause_fallback_mode)
    cfg.set_value("general", "voice_listen", VoiceChat.listen_enabled)
    cfg.set_value("general", "mic_allowed", mic_allowed)
    _ensure_pause_button()
    for key in controls:
        var control: Control = controls[key]
        _clamp_mobile_control(control)
        cfg.set_value("layout", key, control.position)
        cfg.set_value("sizes", key, int(round(control.scale.x * 100.0)))
    cfg.save(SETTINGS_PATH)

func _load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SETTINGS_PATH) == OK:
        brightness = float(cfg.get_value("general", "brightness", 100.0))
        volume = float(cfg.get_value("general", "volume", 100.0))
        player_fov = clampf(float(cfg.get_value("general", "fov", 75.0)), 60.0, 110.0)
        gfx_quality = clampi(int(cfg.get_value("general", "graphics", 0)), 0, QUALITY_NAMES.size() - 1)
        weather_mode = clampi(int(cfg.get_value("general", "weather", 0)), 0, GraphicsFX.WEATHER_NAMES.size() - 1)
        blood_enabled = bool(cfg.get_value("general", "blood", true))
        pause_fallback_mode = clampi(int(cfg.get_value("general", "pause_fallback", 0)), 0, 2)
        VoiceChat.set_listening(bool(cfg.get_value("general", "voice_listen", true)))
        mic_allowed = bool(cfg.get_value("general", "mic_allowed", false))
        if not mic_allowed:
            VoiceChat.set_mic(false)
        if mic_allow_check != null:
            mic_allow_check.set_pressed_no_signal(mic_allowed)
        _on_mic_changed(VoiceChat.mic_enabled)

func _restore_layout() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SETTINGS_PATH) != OK:
        return
    for key in controls:
        if cfg.has_section_key("layout", key):
            controls[key].position = cfg.get_value("layout", key)
        var saved_size := clampf(float(cfg.get_value("sizes", key, 100)), 0.0, 300.0)
        if key == "pause" and saved_size < 50.0:
            saved_size = 100.0
        controls[key].scale = Vector2.ONE * maxf(saved_size, 0.01) / 100.0
    call_deferred("_clamp_all_mobile_controls")

# Keep the entire scaled touch target within the visible viewport, even after
# restoring old settings, changing resolution or resizing buttons to 300%.
func _clamp_mobile_control(control: Control) -> void:
    if not is_instance_valid(control):
        return
    var screen := get_viewport_rect().size
    if screen.x <= 0.0 or screen.y <= 0.0:
        return
    var margin := 4.0
    var displayed_size := control.size * control.scale
    # Кнопка могла быть ещё не разложена (size = 0): берём минимальный размер.
    displayed_size = Vector2(maxf(displayed_size.x, control.get_combined_minimum_size().x * control.scale.x), maxf(displayed_size.y, control.get_combined_minimum_size().y * control.scale.y))
    var safe_min := _safe_area_min_in_viewport()
    # A control larger than the screen cannot fit: shrink it uniformly.
    var available := screen - Vector2.ONE * margin * 2.0
    if displayed_size.x > available.x or displayed_size.y > available.y:
        var factor := minf(available.x / maxf(displayed_size.x, 1.0), available.y / maxf(displayed_size.y, 1.0))
        control.scale *= maxf(factor, 0.01)
        displayed_size = control.size * control.scale
    var global_top_left := control.global_position
    var lo := Vector2(margin, margin) + safe_min
    var bounded := Vector2(
        clampf(global_top_left.x, lo.x, maxf(lo.x, screen.x - margin - displayed_size.x)),
        clampf(global_top_left.y, lo.y, maxf(lo.y, screen.y - margin - displayed_size.y))
    )
    control.global_position += bounded - global_top_left

# Левый/верхний отступ под вырез экрана (чёлка), в координатах вьюпорта.
func _safe_area_min_in_viewport() -> Vector2:
    var win := DisplayServer.window_get_size()
    var screen := get_viewport_rect().size
    if win.x <= 0 or win.y <= 0 or screen.x <= 0.0:
        return Vector2.ZERO
    var safe := DisplayServer.get_display_safe_area()
    var origin := DisplayServer.window_get_position()
    var k := Vector2(screen.x / float(win.x), screen.y / float(win.y))
    var left := maxf(0.0, float(safe.position.x - origin.x)) * k.x
    var top := maxf(0.0, float(safe.position.y - origin.y)) * k.y
    return Vector2(minf(left, screen.x * 0.15), minf(top, screen.y * 0.15))

func _clamp_all_mobile_controls() -> void:
    for key in controls:
        _clamp_mobile_control(controls[key])
    _ensure_pause_button()

## Кнопка паузы не должна пропасть: слишком маленькая (размер 0% в настройках), ещё не
## разложенная или целиком за краем экрана/под вырезом — возвращаем на место по умолчанию.
func _ensure_pause_button() -> void:
    var pb := controls.get("pause") as Control
    if pb == null or not is_instance_valid(pb):
        return
    var screen := get_viewport_rect().size
    if screen.x <= 0.0 or screen.y <= 0.0:
        return
    var broken := false
    if pb.scale.x < 0.5 or pb.scale.y < 0.5:
        pb.scale = Vector2.ONE
        broken = true
    var shown := pb.size * pb.scale
    if shown.x < 20.0 or shown.y < 20.0:
        broken = true
    var safe := _safe_area_min_in_viewport()
    var area := Rect2(safe, screen - safe)
    var seen := area.intersection(Rect2(pb.global_position, shown))
    if shown.x >= 20.0 and (seen.size.x < shown.x * 0.9 or seen.size.y < shown.y * 0.9):
        broken = true
    if not broken:
        return
    var o: Array = [20.0, 20.0, 130.0, 78.0]   # фиксированное место: слева сверху, 110x58
    pb.scale = Vector2.ONE
    pb.offset_left = o[0]
    pb.offset_top = o[1]
    pb.offset_right = o[2]
    pb.offset_bottom = o[3]
    pb.global_position = Vector2(maxf(pb.global_position.x, safe.x + 8.0), maxf(pb.global_position.y, safe.y + 8.0))
    _clamp_mobile_control(pb)

func _begin_edit() -> void:
    editing_controls = true
    _set_mobile_hud_visible(true)
    _show_voice_preview(true)
    pickup_button.show()
    settings_panel.hide()
    pause_panel.hide()
    inventory_panel.hide()
    shooting = false
    get_node("LayoutDone").show()
    get_node("LayoutSizePanel").show()
    get_node("LayoutReset").show()
    _select_control(selected_control_key)
    for control in controls.values():
        control.mouse_filter = Control.MOUSE_FILTER_IGNORE
    # Editor controls must stay above the mobile HUD to receive touch events.
    get_node("LayoutDone").move_to_front()
    get_node("LayoutSizePanel").move_to_front()
    get_node("LayoutReset").move_to_front()

func _finish_edit() -> void:
    editing_controls = false
    _set_mobile_hud_visible(false)
    _show_voice_preview(false)
    pickup_button.hide()
    drag_control = null
    size_slider_touch = -1
    size_slider_mouse_drag = false
    get_node("LayoutDone").hide()
    get_node("LayoutSizePanel").hide()
    get_node("LayoutReset").hide()
    for key in controls:
        controls[key].mouse_filter = Control.MOUSE_FILTER_IGNORE if key in ["joystick", "aim", "voice"] else Control.MOUSE_FILTER_STOP
    settings_panel.show()
    _save_settings()

func _reset_mobile_layout() -> void:
    # Restore every mobile HUD element, including pickup and weapon 1/2/3.
    # Keep brightness, audio and PC bindings untouched.
    drag_control = null
    for key in default_control_offsets:
        if not controls.has(key):
            continue
        var control: Control = controls[key]
        var o: Array = default_control_offsets[key]
        control.scale = Vector2.ONE
        control.offset_left = o[0]
        control.offset_top = o[1]
        control.offset_right = o[2]
        control.offset_bottom = o[3]
    _clamp_all_mobile_controls()
    _select_control(selected_control_key)
    _save_settings()
    # Размеры кнопок пересчитываются только после кадра: повторно зажимаем и сохраняем.
    await get_tree().process_frame
    _clamp_all_mobile_controls()
    _save_settings()

func _layout_input(event: InputEvent) -> void:
    # Handle the slider directly in _input: Android touch events do not need
    # mouse emulation. Both a single tap and a finger drag change its value.
    var slider_area := size_slider.get_global_rect().grow(24.0)
    if event is InputEventScreenTouch:
        if event.pressed and slider_area.has_point(event.position):
            size_slider_touch = event.index
            drag_control = null
            _set_size_slider_from_touch(event.position)
            get_viewport().set_input_as_handled()
            return
        if event.index == size_slider_touch:
            if not event.pressed:
                _set_size_slider_from_touch(event.position)
                size_slider_touch = -1
                _save_settings()
            get_viewport().set_input_as_handled()
            return
    elif event is InputEventScreenDrag and event.index == size_slider_touch:
        _set_size_slider_from_touch(event.position)
        get_viewport().set_input_as_handled()
        return
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed and slider_area.has_point(event.position):
            size_slider_mouse_drag = true
            drag_control = null
            _set_size_slider_from_touch(event.position)
            get_viewport().set_input_as_handled()
            return
        if size_slider_mouse_drag:
            if not event.pressed:
                size_slider_mouse_drag = false
                _save_settings()
            get_viewport().set_input_as_handled()
            return
    elif event is InputEventMouseMotion and size_slider_mouse_drag:
        _set_size_slider_from_touch(event.position)
        get_viewport().set_input_as_handled()
        return
    var point := Vector2.ZERO
    var started := false
    var released := false
    var moving := false
    if event is InputEventScreenTouch:
        point = event.position
        started = event.pressed
        released = not event.pressed
    elif event is InputEventScreenDrag:
        point = event.position
        moving = true
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        point = event.position
        started = event.pressed
        released = not event.pressed
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        point = event.position
        moving = true
    else:
        return
    if started:
        # Do not start dragging a HUD button when touching the size slider or
        # other editor widgets. They must receive their own GUI input.
        for widget in [get_node("LayoutDone"), get_node("LayoutSizePanel"), get_node("LayoutReset")]:
            if widget.visible and widget.get_global_rect().has_point(point):
                drag_control = null
                return
        drag_control = null
        for key in controls:
            var control: Control = controls[key]
            var rect := Rect2(control.global_position, control.size * control.scale)
            if rect.has_point(point):
                drag_control = control
                drag_offset = point - control.global_position
                _select_control(key)
                break
    elif moving and drag_control != null:
        var parent_control := drag_control.get_parent() as Control
        var parent_origin := parent_control.global_position if parent_control != null else Vector2.ZERO
        drag_control.position = point - drag_offset - parent_origin
        _clamp_mobile_control(drag_control)
    elif released:
        drag_control = null

func _set_size_slider_from_touch(point: Vector2) -> void:
    var slider_rect := size_slider.get_global_rect()
    if slider_rect.size.x <= 0.0:
        return
    # Use a small inset to account for the slider grabber width.
    var grabber_margin := minf(16.0, slider_rect.size.x * 0.1)
    var usable_width := maxf(1.0, slider_rect.size.x - grabber_margin * 2.0)
    var fraction := clampf((point.x - slider_rect.position.x - grabber_margin) / usable_width, 0.0, 1.0)
    size_slider.value = roundf(lerpf(size_slider.min_value, size_slider.max_value, fraction))

func _select_control(key: String) -> void:
    selected_control_key = key
    var control: Control = controls[key]
    size_label.text = "Размер %s: %d%%" % [_control_title(key), int(round(control.scale.x * 100.0))]
    size_slider.set_value_no_signal(clampf(round(control.scale.x * 100.0), 0, 300))

func _control_title(key: String) -> String:
    return "«Говорящие»" if key == "voice" else key

func _resize_selected_control(value: float) -> void:
    if not controls.has(selected_control_key):
        return
    var control: Control = controls[selected_control_key]
    if selected_control_key == "pause":
        value = maxf(value, 50.0)   # кнопку паузы нельзя уменьшить до невидимости
    control.scale = Vector2.ONE * maxf(value, 0.01) / 100.0
    _clamp_mobile_control(control)
    size_label.text = "Размер %s: %d%%" % [_control_title(selected_control_key), int(value)]

## Предметы появляются перед игроком в виде объёмных моделей, а не шаров/ящиков.
func is_downed() -> bool:
    return _my_state == Net.ST_DOWNED

func spawn_dropped_item(stack: Dictionary) -> bool:
    if _my_state != Net.ST_ALIVE:
        return false   # в нокауте лут выбрасывать нельзя
    var forward := Vector3(-sin(yaw), 0, -cos(yaw))
    var pos := Vector3(local_pos.x, 1.2, local_pos.z) + forward * 1.8
    return Net.request_world_drop(stack, pos, yaw)

func _drop_box_size(item_id: String) -> Vector3:
    if item_id == "ak47":
        return Vector3(0.8, 0.25, 0.25)
    if Weapons.has(item_id):
        match int(Weapons.get_def(item_id)["slot"]):
            0:
                return Vector3(1.0, 0.25, 0.25)
            1:
                return Vector3(0.35, 0.25, 0.25)
            _:
                return Vector3(0.5, 0.12, 0.12)
    if item_id == "collimator":
        return Vector3(0.22, 0.2, 0.3)
    return Vector3(0.3, 0.25, 0.3)

func _show_world_drop(id: int, stack: Dictionary, pos: Vector3, facing: float) -> void:
    if world_nodes.has(id):
        return
    var obj := RigidBody3D.new()
    obj.name = "Dropped_%d" % id
    obj.mass = 2.0
    obj.continuous_cd = true
    obj.can_sleep = true
    obj.linear_damp = 0.8
    obj.angular_damp = 1.2
    obj.collision_layer = 1
    obj.collision_mask = 1
    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = _drop_box_size(str(stack.get("id", "")))
    shape.shape = box_shape
    obj.add_child(shape)
    viewport.get_child(0).add_child(obj)
    # Spawn above the floor: a falling rigid body must not begin embedded in it.
    obj.position = Vector3(pos.x, maxf(pos.y, 0.5), pos.z)
    obj.rotation.y = facing
    obj.apply_torque_impulse(Vector3(0.3, 0.1, 0.25))
    obj.set_meta("item_stack", stack.duplicate(true))
    var item_id := str(stack.get("id", ""))
    if item_id == "ak47" and USE_GLB_AK:
        _make_ak47_model(obj)
    elif Weapons.has(item_id):
        WeaponModels.build(str(Weapons.get_def(item_id)["kind"]), obj, true)
    elif item_id == "medkit" or item_id.begins_with("ammo_") or item_id == "collimator":
        ItemModels.build(item_id, obj)
    world_nodes[id] = obj

func _remove_world_drop(id: int) -> void:
    if world_nodes.has(id):
        world_nodes[id].queue_free()
        world_nodes.erase(id)
    if aimed_item_id == id:
        aimed_item_id = -1

func _clear_world_drops() -> void:
    for id in world_nodes.keys():
        _remove_world_drop(id)

func _create_pickup_hud() -> void:
    pickup_hint = VBoxContainer.new()
    pickup_hint.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    pickup_hint.position = Vector2(-90, 45)
    pickup_hint.custom_minimum_size = Vector2(180, 90)
    pickup_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(pickup_hint)
    pickup_icon = TextureRect.new()
    pickup_icon.custom_minimum_size = Vector2(58, 52)
    pickup_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    pickup_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    pickup_hint.add_child(pickup_icon)
    pickup_name = Label.new()
    pickup_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    pickup_hint.add_child(pickup_name)
    pickup_button = _button("Взять", Vector2(105, 68), Vector2(-165, -305), Control.PRESET_BOTTOM_RIGHT)
    pickup_button.button_down.connect(_pickup_down)
    pickup_button.button_up.connect(_pickup_up)
    revive_label = Label.new()
    revive_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    pickup_hint.add_child(revive_label)
    controls["pickup"] = pickup_button
    pickup_button.hide()
    pickup_hint.hide()

func _update_pickup_target() -> void:
    aimed_item_id = -1
    if paused or editing_controls or inventory_panel.visible or _shop_open() or _my_state == Net.ST_DEAD:
        pickup_hint.hide()
        pickup_button.hide()
        return
    var best_distance := 3.5
    var forward := -camera.global_transform.basis.z.normalized()
    for id in world_nodes:
        var node: Node3D = world_nodes[id]
        var delta := node.global_position + Vector3.UP * 0.15 - camera.global_position
        var dist := delta.length()
        if dist > 3.5 or dist < 0.01:
            continue
        if forward.dot(delta.normalized()) < 0.94:
            continue
        if dist < best_distance:
            best_distance = dist
            aimed_item_id = id
    var revive_target := _my_state == Net.ST_ALIVE and _aiming_at_downed_player()
    var visible_target := aimed_item_id >= 0 or revive_target or _nearest_death_bag_exists()
    pickup_hint.visible = visible_target
    pickup_button.visible = visible_target and not paused
    if revive_target:
        pickup_name.text = "Поднять игрока (50 HP)"
        pickup_icon.texture = null
    elif _nearest_death_bag_exists():
        pickup_name.text = "Открыть рюкзак"
        pickup_icon.texture = null
    elif aimed_item_id >= 0:
        var stack: Dictionary = world_nodes[aimed_item_id].get_meta("item_stack")
        pickup_name.text = str(GameState.ITEMS.get(str(stack.get("id", "")), {}).get("name", "Предмет"))
        pickup_icon.texture = _item_preview_texture(str(stack.get("id", "")))

func _item_preview_texture(item_id: String) -> Texture2D:
    for icon_path in ["res://assets/hud/weapons/%s.png" % item_id, "res://assets/shop/%s.png" % item_id]:
        if ResourceLoader.exists(icon_path):
            return load(icon_path) as Texture2D
    var img := Image.create(56, 48, false, Image.FORMAT_RGBA8)
    img.fill(Color(0.14, 0.18, 0.22, 0.85))
    var tint: Color = GameState.ITEMS.get(item_id, {}).get("color", Color.WHITE)
    img.fill_rect(Rect2i(9, 13, 38, 22), tint)
    return ImageTexture.create_from_image(img)

func _pickup_down() -> void:
    if _my_state == Net.ST_ALIVE and _aiming_at_downed_player():
        reviving = true
        revive_progress = 0.0
        if revive_label != null:
            revive_label.text = "Поднятие: 0.0 сек / 5.0 сек"
        Net.begin_revive(camera.global_position, -camera.global_transform.basis.z)
    else:
        if not _open_nearest_death_bag():
            _pickup_aimed()

func _pickup_up() -> void:
    if reviving:
        _cancel_reviving()

func _cancel_reviving() -> void:
    reviving = false
    revive_progress = 0.0
    Net.cancel_revive()
    if revive_label != null:
        revive_label.text = ""

func _pickup_aimed() -> void:
    if _my_state == Net.ST_ALIVE and _aiming_at_downed_player():
        return
    if aimed_item_id < 0 or not world_nodes.has(aimed_item_id):
        return
    var stack: Dictionary = world_nodes[aimed_item_id].get_meta("item_stack")
    if not _can_fit_pickup(stack):
        return
    Net.request_world_pickup(aimed_item_id)

func _can_fit_pickup(stack: Dictionary) -> bool:
    var item_id: String = str(stack.get("id", ""))
    if not GameState.ITEMS.has(item_id):
        return false
    var count: int = int(stack.get("count", 0))
    if count <= 0:
        return false
    var maximum: int = int(GameState.ITEMS[item_id].get("stack", 1))
    var category: String = str(GameState.ITEMS[item_id].get("category", "other"))
    var target: int = -1
    match category:
        "rifle": target = 0
        "pistol": target = 1
        "knife": target = 2
        "attachment": target = GameState.ATTACH_SLOT
    if target >= 0 and GameState.battle_equipment[target].is_empty():
        count -= maximum
    for bag in [GameState.battle_equipment, GameState.battle_inventory]:
        for i in bag.size():
            if bag == GameState.battle_equipment and i <= GameState.ATTACH_SLOT:
                continue
            var slot: Dictionary = bag[i]
            if slot.is_empty():
                count -= maximum
            elif str(slot.get("id", "")) == item_id:
                count -= maximum - int(slot.get("count", 0))
            if count <= 0:
                return true
    return false

func _receive_pickup(stack: Dictionary) -> void:
    var item_id: String = str(stack.get("id", ""))
    if not GameState.ITEMS.has(item_id):
        return
    var remaining: int = int(stack.get("count", 0))
    var maximum: int = int(GameState.ITEMS[item_id].get("stack", 1))
    var category: String = str(GameState.ITEMS[item_id].get("category", "other"))
    var target: int = -1
    match category:
        "rifle": target = 0
        "pistol": target = 1
        "knife": target = 2
        "attachment": target = GameState.ATTACH_SLOT
    if target >= 0 and GameState.battle_equipment[target].is_empty() and remaining > 0:
        var added: int = mini(remaining, maximum)
        GameState.battle_equipment[target] = {"id": item_id, "count": added}
        remaining -= added
    for bag in [GameState.battle_equipment, GameState.battle_inventory]:
        for i in bag.size():
            if remaining <= 0:
                break
            if bag == GameState.battle_equipment and i <= GameState.ATTACH_SLOT:
                continue
            var slot: Dictionary = bag[i]
            if not slot.is_empty() and str(slot.get("id", "")) == item_id:
                var added: int = mini(remaining, maximum - int(slot.get("count", 0)))
                slot["count"] = int(slot.get("count", 0)) + added
                remaining -= added
        for i in bag.size():
            if remaining <= 0:
                break
            if bag == GameState.battle_equipment and i <= GameState.ATTACH_SLOT:
                continue
            if bag[i].is_empty():
                var added: int = mini(remaining, maximum)
                bag[i] = {"id": item_id, "count": added}
                remaining -= added
    GameState.changed.emit()
    _sync_reserve()

func _part(parent: Node3D, dimensions: Vector3, offset: Vector3, tint: Color, angle: Vector3 = Vector3.ZERO) -> void:
    var part := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    part.mesh = mesh
    part.position = offset
    part.rotation = angle
    var material := StandardMaterial3D.new()
    material.albedo_color = tint
    material.metallic = 0.25
    material.roughness = 0.68
    part.material_override = material
    parent.add_child(part)

func _make_ak47_model(parent: Node3D) -> void:
    # Imported GLB points along its local +X axis. Rotate to face Godot -Z.
    # Shared by the first-person weapon and dropped world items.
    var packed := load("res://assets/models/low_poly_ak-47.glb") as PackedScene
    if packed == null:
        push_warning("AK-47 GLB could not be loaded")
        return
    var model := packed.instantiate() as Node3D
    if model == null:
        push_warning("AK-47 GLB root is not Node3D")
        return
    model.name = "AK47_GLTF_Model"
    parent.add_child(model)
    model.scale = Vector3.ONE * 0.34
    model.rotation_degrees = Vector3(0, 90, 0)
    # The sight line sits above the receiver, aligned with the camera in ADS.
    model.position = Vector3(0, -0.035, -0.16)
    # GLB hierarchy: Cube.008 is the COMPLETE detachable magazine assembly.
    # Its children include the magazine body and Cylinder.012 parts. Animating
    # only Cube.008_Material.001_0 left the other parts attached to the gun.
    if parent.name == "WeaponAnimationPivot":
        var magazine_group := model.find_child("Cube.008", true, false) as Node3D
        if magazine_group == null:
            push_warning("AK47 magazine group Cube.008 not found in imported GLB")
        else:
            wp_mag = magazine_group
            wp_mag_rest = magazine_group.position
            wp_mag_rot_rest = magazine_group.rotation_degrees

func _make_medkit_model(parent: Node3D) -> void:
    _part(parent, Vector3(0.42, 0.25, 0.32), Vector3(0, 0.10, 0), Color(0.80, 0.85, 0.80))
    _part(parent, Vector3(0.09, 0.015, 0.23), Vector3(0, 0.235, 0), Color.RED)
    _part(parent, Vector3(0.25, 0.015, 0.08), Vector3(0, 0.24, 0), Color.RED)

func _make_ammo_model(parent: Node3D, tint: Color = Color(0.68, 0.47, 0.16)) -> void:
    for i in 6:
        _part(parent, Vector3(0.045, 0.15, 0.045), Vector3((i % 3 - 1) * 0.065, 0.08, (i / 3 - 0.5) * 0.09), tint.lightened(0.15))

func _create_weapon_bar() -> void:
    # Each weapon button is an independent HUD control: editable and saved like jump/fire.
    for i in range(3):
        var button := Button.new()
        button.name = "WeaponHUD%d" % (i + 1)
        button.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
        button.position = Vector2(265 + i * 153, -90)
        button.size = Vector2(145, 57)
        button.add_theme_font_size_override("font_size", 16)
        var style := StyleBoxFlat.new()
        style.bg_color = Color(0.09, 0.13, 0.19, 0.78)
        style.border_color = Color(0.55, 0.65, 0.72, 0.85)
        style.set_border_width_all(2)
        style.set_corner_radius_all(7)
        button.add_theme_stylebox_override("normal", style)
        button.pressed.connect(_select_weapon.bind(i))
        add_child(button)
        weapon_buttons.append(button)
        controls["weapon_%d" % (i + 1)] = button

func _refresh_weapon_bar() -> void:
    var items: Array = GameState.get_slots("gear")
    for i in range(weapon_buttons.size()):
        var stack: Dictionary = items[i] if i < items.size() else {}
        var name_text := str(GameState.ITEMS.get(str(stack.get("id", "")), {}).get("name", "Пусто"))
        var item_id := str(stack.get("id", ""))
        var category := str(GameState.ITEMS.get(item_id, {}).get("category", ""))
        var icon_path := "res://assets/hud/weapons/%s.png" % item_id
        if not ResourceLoader.exists(icon_path):
            icon_path = "res://assets/hud/weapons/%s.png" % category
        if not stack.is_empty() and ResourceLoader.exists(icon_path):
            weapon_buttons[i].icon = load(icon_path)
            weapon_buttons[i].expand_icon = true
            weapon_buttons[i].icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
            weapon_buttons[i].text = ""
            weapon_buttons[i].tooltip_text = name_text
        else:
            weapon_buttons[i].icon = null
            weapon_buttons[i].text = "%d  |  %s" % [i + 1, name_text]
        weapon_buttons[i].modulate = Color(0.65, 1.0, 0.72) if i == active_weapon_slot else Color.WHITE
        if stack.is_empty() and active_weapon_slot == i:
            active_weapon_slot = -1

func _on_battle_equipment_changed() -> void:
    # Always reconcile the view model after inventory changes (including inventory drops).
    _refresh_weapon_bar()
    _update_held_weapon()
    _sync_reserve()

func _drop_held_weapon() -> void:
    if _my_state != Net.ST_ALIVE:
        return
    if paused or editing_controls or inventory_panel.visible or _shop_open() or active_weapon_slot < 0:
        return
    var items: Array = GameState.get_slots("gear")
    if active_weapon_slot >= items.size() or items[active_weapon_slot].is_empty():
        return
    var slot := active_weapon_slot
    var stack: Dictionary = items[slot].duplicate(true)
    if str(stack.get("id", "")) == "diamond_sword":
        return
    if not spawn_dropped_item(stack):
        return
    items[slot] = {}
    active_weapon_slot = -1
    GameState.changed.emit()

func _select_weapon(slot_index: int) -> void:
    _set_aim(false)
    if _my_state != Net.ST_ALIVE:
        return
    if paused or editing_controls or inventory_panel.visible or _shop_open():
        return
    var items: Array = GameState.get_slots("gear")
    if slot_index >= items.size() or items[slot_index].is_empty():
        return
    if active_weapon_slot == slot_index:
        _holster_weapon()
        return
    active_weapon_slot = slot_index
    _refresh_weapon_bar()
    _update_held_weapon()

func _clear_held_weapon() -> void:
    aiming = false
    _set_scope(false)
    _set_collimator(false)
    reload_left = 0.0
    shell_reload = false
    flash_time = 0.0
    # Free immediately: queue_free() alone leaves the old mesh visible until frame end.
    if weapon_tween != null:
        weapon_tween.kill()
        weapon_tween = null
    if fx_tween != null:
        fx_tween.kill()
        fx_tween = null
    if is_instance_valid(held_weapon_model):
        held_weapon_model.free()
    held_weapon_model = null
    weapon_motion_pivot = null
    _reset_weapon_magazine()
    wp_mag = null
    weapon_refs = {}
    if magazine_tween != null:
        magazine_tween.kill()
    held_weapon_key = ""

func _update_held_weapon() -> void:
    var desired_key := ""
    var item_id := ""
    var items: Array = GameState.get_slots("gear")
    if active_weapon_slot >= 0 and active_weapon_slot < items.size():
        var stack: Dictionary = items[active_weapon_slot]
        if not stack.is_empty():
            item_id = str(stack.get("id", ""))
            if Weapons.has(item_id):
                desired_key = "%d:%s:%d" % [active_weapon_slot, item_id, int(GameState.has_attachment("collimator") and Weapons.has_collimator(item_id))]
    # Do not rebuild the viewmodel on every inventory/gear changed signal.
    if desired_key == held_weapon_key and is_instance_valid(held_weapon_model):
        return
    _clear_held_weapon()
    if desired_key.is_empty():
        _sync_reserve()
        return
    var def: Dictionary = Weapons.get_def(item_id)
    var rest: Vector3 = def["rest"]
    var weapon := Node3D.new()
    weapon.name = "HeldWeaponViewmodel"
    for child in camera.get_children():
        if child is Node3D and child.name.begins_with("HeldWeaponViewmodel"):
            child.free()
    camera.add_child(weapon)
    weapon.position = rest + HIDDEN_OFFSET
    weapon.rotation_degrees = Vector3(38, 0, -18)
    var motion_pivot := Node3D.new()
    motion_pivot.name = "WeaponAnimationPivot"
    weapon.add_child(motion_pivot)
    wp_mag = null
    weapon_refs = {}
    if item_id == "ak47" and USE_GLB_AK:
        _make_ak47_model(motion_pivot)
        weapon_refs = {
            "mag_drop": Vector3(1.2, 0.0, -5.0),
            "mag_drop_rot": Vector3(0, 18, 0),
            "eject": Vector3(0.05, 0.10, -0.20),
        }
        weapon_refs["flash"] = WeaponModels.make_flash(motion_pivot, def["muzzle"])
    else:
        var with_collimator: bool = GameState.has_attachment("collimator") and Weapons.has_collimator(item_id)
        weapon_refs = WeaponModels.build(str(def["kind"]), motion_pivot, false, with_collimator)
        # Руки от первого лица держат оружие и двигаются вместе с ним.
        var sleeve := Color(0.22, 0.35, 0.30) if Net.my_id() == 1 else Color(0.28, 0.32, 0.55)
        # Stage105: у меча CREATOR своя рука на рукояти (weapon_models.gd); общие FpArms давали вторую, лишнюю руку.
        if str(def["kind"]) != "diamond_sword":
            FpArms.build(motion_pivot, Weapons.GRIPS.get(str(def["kind"]), {}), sleeve)
        if weapon_refs.has("mag"):
            wp_mag = weapon_refs["mag"]
            wp_mag_rest = weapon_refs["mag_rest"]
            wp_mag_rot_rest = Vector3.ZERO
    weapon_motion_pivot = motion_pivot
    weapon_motion_time = 0.0
    weapon_walk_blend = 0.0
    held_weapon_model = weapon
    held_weapon_key = desired_key
    _mag_of(item_id)
    _sync_reserve()
    weapon_tween = create_tween()
    if item_id == "diamond_sword":
        _sword_draw_animation(weapon, rest)   # Stage106
    else:
        weapon_tween.set_trans(Tween.TRANS_SINE)
        weapon_tween.set_ease(Tween.EASE_OUT)
        weapon_tween.tween_property(weapon, "position", rest, 0.34)
        weapon_tween.parallel().tween_property(weapon, "rotation_degrees", Vector3.ZERO, 0.34)
    _play_weapon_sound("res://assets/audio/draw.wav", -6.0)

func _holster_weapon() -> void:
    var id := _active_weapon_id()
    _set_aim(false)
    active_weapon_slot = -1
    _refresh_weapon_bar()
    _sync_reserve()
    if not is_instance_valid(held_weapon_model):
        _clear_held_weapon()
        return
    if weapon_tween != null:
        weapon_tween.kill()
    if fx_tween != null:
        fx_tween.kill()
    _set_scope(false)
    var hidden_pos: Vector3 = (Weapons.get_def(id).get("rest", Vector3.ZERO) as Vector3) + HIDDEN_OFFSET
    var old_weapon := held_weapon_model
    old_weapon.name = "HeldWeaponViewmodelHolstering"
    old_weapon.visible = true
    held_weapon_model = null
    weapon_motion_pivot = null
    reload_left = 0.0
    shell_reload = false
    flash_time = 0.0
    _reset_weapon_magazine()
    wp_mag = null
    weapon_refs = {}
    if magazine_tween != null:
        magazine_tween.kill()
    held_weapon_key = ""
    weapon_tween = create_tween()
    weapon_tween.set_trans(Tween.TRANS_SINE)
    weapon_tween.tween_property(old_weapon, "position", hidden_pos, 0.25)
    weapon_tween.parallel().tween_property(old_weapon, "rotation_degrees", Vector3(38, 0, -18), 0.25)
    weapon_tween.tween_callback(func() -> void:
        if is_instance_valid(old_weapon):
            old_weapon.free()
    )

func _toggle_aim() -> void:
    if _my_state != Net.ST_ALIVE:
        return
    if paused or editing_controls or _shop_open() or (inventory_panel != null and inventory_panel.visible):
        return
    var id := _active_weapon_id()
    if id == "" or Weapons.is_melee(id) or _is_reloading() or not is_instance_valid(held_weapon_model):
        return
    _set_aim(not aiming)

func _set_aim(enabled: bool) -> void:
    if aiming == enabled:
        return
    aiming = enabled
    if not is_instance_valid(held_weapon_model):
        aiming = false
        _set_scope(false)
        return
    var def: Dictionary = Weapons.get_def(_active_weapon_id())
    if def.is_empty():
        aiming = false
        _set_scope(false)
        return
    var target: Vector3 = def["ads"] if aiming else def["rest"]
    if weapon_tween != null:
        weapon_tween.kill()
    weapon_tween = create_tween()
    weapon_tween.set_trans(Tween.TRANS_SINE)
    weapon_tween.set_ease(Tween.EASE_OUT)
    weapon_tween.tween_property(held_weapon_model, "position", target, 0.18)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3.ZERO, 0.18)
    if bool(def.get("scope", false)):
        if aiming:
            # Оптика включается, когда оружие поднято к глазу.
            weapon_tween.tween_callback(_set_scope.bind(true))
        else:
            _set_scope(false)
    if _collimator_active():
        if aiming:
            # Коллиматор: когда оружие у глаза, в окне появляется красная точка.
            weapon_tween.tween_callback(_set_collimator.bind(true))
        else:
            _set_collimator(false)

# Procedural animation of the imported GLB, independent of ADS/reload tweens.
# A dedicated child pivot prevents movement sway from overwriting weapon placement.
func _update_weapon_motion(delta: float, movement_amount: float) -> void:
    if not is_instance_valid(weapon_motion_pivot):
        return
    if _active_weapon_id() == "diamond_sword":
        # Двуручная стойка: плавный перенос веса при шаге, без ножевого покачивания.
        var grounded: bool = local_pos.y <= player_floor_y + 0.001
        var stride: float = clampf(movement_amount, 0.0, 1.0) if grounded else 0.0
        weapon_walk_blend = move_toward(weapon_walk_blend, stride, delta * 5.0)
        weapon_motion_time += delta * (8.0 if grounded else 3.0)
        var phase: float = weapon_motion_time
        var step_y: float = (1.0 - cos(phase * 2.0)) * 0.018 * weapon_walk_blend
        var airborne_y: float = -0.09 if not grounded else 0.0
        # Stage106: дыхание в стойке и наклон меча при беге (клинок отводится назад-вправо, рука ниже).
        var breath_t: float = Time.get_ticks_msec() * 0.001
        var rest_w: float = 1.0 - weapon_walk_blend
        var breath_y: float = sin(breath_t * 1.7) * 0.007 * rest_w
        var breath_roll: float = sin(breath_t * 1.1) * 1.4 * rest_w
        var lean: float = weapon_walk_blend
        var pose := Vector3(sin(phase) * 0.018 * weapon_walk_blend + 0.03 * lean, step_y + airborne_y + breath_y - 0.035 * lean, 0.015 * weapon_walk_blend)
        var angles := Vector3((-13.0 if not grounded else 0.0) + sin(phase * 2.0) * 2.5 * weapon_walk_blend + 6.0 * lean, sin(phase) * 2.5 * weapon_walk_blend, sin(phase) * 3.5 * weapon_walk_blend + breath_roll - 8.0 * lean)
        weapon_motion_pivot.position = weapon_motion_pivot.position.lerp(pose, minf(1.0, delta * 9.0))
        weapon_motion_pivot.rotation_degrees = weapon_motion_pivot.rotation_degrees.lerp(angles, minf(1.0, delta * 9.0))
        return
    var on_ground := local_pos.y <= player_floor_y + 0.001
    var walking := movement_amount > 0.08 and on_ground
    weapon_walk_blend = move_toward(weapon_walk_blend, 1.0 if walking else 0.0, delta * 7.0)
    weapon_motion_time += delta * (9.5 if crouching else 12.0)
    weapon_jump_kick = move_toward(weapon_jump_kick, 0.0, delta * 2.2)
    look_sway = look_sway.move_toward(Vector2.ZERO, delta * 0.09)
    var ads_factor := 0.24 if aiming else 1.0
    var breath := sin(Time.get_ticks_msec() * 0.0017) * 0.0025 * ads_factor
    var bob_x := sin(weapon_motion_time) * 0.014 * weapon_walk_blend * ads_factor
    var bob_y := absf(cos(weapon_motion_time)) * 0.018 * weapon_walk_blend * ads_factor
    var airborne := not on_ground
    var jump_y := -0.055 * weapon_jump_kick + (0.035 if airborne else 0.0)
    var jump_pitch := -9.0 * weapon_jump_kick + (5.0 if airborne else 0.0)
    var sway := Vector3(-look_sway.x, look_sway.y, 0.0) * ads_factor
    var target_position := Vector3(bob_x, bob_y + jump_y + breath, 0.018 * weapon_walk_blend * ads_factor) + sway
    var target_rotation := Vector3(
        jump_pitch + sin(weapon_motion_time) * 1.8 * weapon_walk_blend * ads_factor + look_sway.y * 45.0 * ads_factor,
        look_sway.x * 70.0 * ads_factor,
        sin(weapon_motion_time) * 2.5 * weapon_walk_blend * ads_factor)
    weapon_motion_pivot.position = weapon_motion_pivot.position.lerp(target_position, minf(1.0, delta * 11.0))
    weapon_motion_pivot.rotation_degrees = weapon_motion_pivot.rotation_degrees.lerp(target_rotation, minf(1.0, delta * 11.0))

func _reset_weapon_magazine() -> void:
    if magazine_tween != null and magazine_tween.is_running():
        magazine_tween.kill()
    if is_instance_valid(wp_mag):
        wp_mag.visible = true
        wp_mag.position = wp_mag_rest
        wp_mag.rotation_degrees = wp_mag_rot_rest

func _play_weapon_sound(path: String, volume_db: float = 0.0) -> void:
    if path == "" or not ResourceLoader.exists(path):
        return
    # Отдельный плеер на каждый звук: выстрел не обрывает механику оружия.
    var player := AudioStreamPlayer.new()
    player.stream = load(path)
    player.volume_db = volume_db
    add_child(player)
    player.finished.connect(player.queue_free)
    player.play()

func _show_tracer(origin: Vector3, target: Vector3, shooter: int = -1) -> void:
    # Авторитетный луч идёт от камеры стрелка, а визуальный трассер — от дула его оружия:
    # у себя — от дула оружия в руках, у других игроков — от дула их модели.
    if viewport == null:
        return
    var mine: bool = shooter == Net.my_id()
    var weapon_id: String = _active_weapon_id() if (mine or shooter < 0) else str(Net.battle_weapons.get(shooter, ""))
    var def: Dictionary = Weapons.get_def(weapon_id)
    if (mine or shooter < 0) and is_instance_valid(held_weapon_model) and origin.distance_to(camera.global_position) < 1.8:
        var muzzle: Vector3 = def.get("muzzle", Vector3(0, 0.20, -1.13))
        origin = held_weapon_model.to_global(muzzle)
    elif not mine and actors.has(shooter):
        origin = actors[shooter].muzzle_global()
    if origin.distance_to(target) < 0.01:
        return
    _impact_fx(origin, target, shooter)
    var tint: Color = def.get("tracer", last_tracer_color)
    var radius: float = 0.009 if int(def.get("pellets", 1)) > 1 else 0.018
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = origin.distance_to(target)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mesh.material = mat
    var tracer := MeshInstance3D.new()
    tracer.mesh = mesh
    tracer.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    viewport.get_child(0).add_child(tracer)
    tracer.position = (origin + target) * 0.5
    tracer.look_at(target, Vector3.UP)
    tracer.rotate_object_local(Vector3.RIGHT, PI * 0.5)
    var timer := get_tree().create_timer(0.085)
    timer.timeout.connect(func():
        if is_instance_valid(tracer):
            tracer.queue_free()
    )

## Звук в мире: слышно направление и расстояние до источника (чужие выстрелы, перезарядка).
func _play_world_sound(path: String, pos: Vector3, volume_db: float = 0.0) -> void:
    if viewport == null or path == "" or not ResourceLoader.exists(path):
        return
    var player := AudioStreamPlayer3D.new()
    player.stream = load(path)
    player.volume_db = volume_db
    player.pitch_scale = shot_rng.randf_range(0.97, 1.03)
    player.max_distance = 140.0
    player.unit_size = 16.0
    viewport.get_child(0).add_child(player)
    player.global_position = pos
    player.finished.connect(player.queue_free)
    player.play()

func _play_world_sound_later(delay: float, path: String, pos: Vector3, volume_db: float = 0.0) -> void:
    get_tree().create_timer(delay).timeout.connect(func(): _play_world_sound(path, pos, volume_db))

# Выстрел любого игрока: запоминаем цвет трассера; чужие выстрелы видны (вспышка, отдача,
# гильза) и слышны (звук выстрела и затвора/цевья из точки дула).
func _on_shot_fired(shooter: int, weapon_id: String, origin: Vector3) -> void:
    var def: Dictionary = Weapons.get_def(weapon_id)
    if def.is_empty():
        return
    last_tracer_color = def.get("tracer", Color(1.0, 0.78, 0.18))
    last_tracer_radius = 0.009 if int(def.get("pellets", 1)) > 1 else 0.018
    if shooter == Net.my_id() or viewport == null:
        return
    var source: Vector3 = origin
    if actors.has(shooter):
        var actor: Node3D = actors[shooter]
        actor.play_attack()   # отдача, вспышка у дула, взмах ножа
        source = actor.muzzle_global()
        if not Weapons.is_melee(weapon_id):
            _remote_casing(actor, str(def["kind"]))
    _play_world_sound(str(def.get("sound_fire", "")), source, 4.0)
    # затвор / цевьё после выстрела
    if def.has("sound_pump"):
        _play_world_sound_later(0.45, str(def["sound_pump"]), source, 0.0)
    if def.has("sound_bolt"):
        _play_world_sound_later(0.5, str(def["sound_bolt"]), source, 0.0)

## Гильза вылетает из окна чужого оружия вправо-вверх относительно стрелка.
func _remote_casing(actor: Node3D, kind: String) -> void:
    var start: Vector3 = actor.eject_global()
    if start == Vector3.INF:
        return
    var right: Vector3 = -actor.global_transform.basis.x   # модель смотрит в +Z, правая рука — в -X
    var velocity := right * shot_rng.randf_range(1.3, 2.0) + Vector3.UP * shot_rng.randf_range(0.9, 1.6) \
            - actor.global_transform.basis.z * shot_rng.randf_range(0.0, 0.4)
    var scale_factor := 1.0
    match kind:
        "shotgun": scale_factor = 1.6
        "svd": scale_factor = 1.3
        "pm", "revolver": scale_factor = 0.8
    _spawn_casing(start, velocity, scale_factor)

## Чужое действие: перезарядка — слышен звук оружия, модель опускает ствол.
func _on_battle_event(peer: int, kind: String) -> void:
    if peer == Net.my_id() or kind != "reload" or not actors.has(peer):
        return
    var weapon_id := str(Net.battle_weapons.get(peer, ""))
    var def: Dictionary = Weapons.get_def(weapon_id)
    if def.is_empty() or Weapons.is_melee(weapon_id):
        return
    var actor: Node3D = actors[peer]
    actor.play_reload(float(def.get("reload", 2.0)))
    _play_world_sound(str(def.get("sound_reload", "")), actor.muzzle_global(), 0.0)

# Stage116: local crash-resistant survival snapshots.
var _survival_autosave_elapsed: float = 0.0

## Текущее состояние игрока для сохранения Client-а на телефоне и для ответа Host-у.
func _survival_local_view() -> Dictionary:
    return {"pos": local_pos, "health": int(Net.battle_health.get(Net.my_id(), 100)), "yaw": yaw, "pitch": pitch}

## Host вернул Client-у его данные с этого сервера: применяем позицию, камеру и инвентарь прямо в бою.
func _on_survival_state_restored(state: Dictionary) -> void:
    if leaving_battle or Net.game_mode != Net.MODE_SURVIVAL or Net.role != "client":
        return
    var xyz: Array = state.get("pos", [])
    if xyz.size() == 3:
        local_pos = Vector3(float(xyz[0]), float(xyz[1]), float(xyz[2]))
    yaw = float(state.get("yaw", yaw))
    pitch = float(state.get("pitch", pitch))
    GameState.battle_inventory = GameState.sanitize_battle_slots(state.get("inventory", []), GameState.INV_SIZE)
    GameState.battle_equipment = GameState.sanitize_battle_slots(state.get("equipment", []), GameState.GEAR_SIZE)
    GameState.changed.emit()
    Net.survival_restore_clients.clear()

func _survival_snapshot_now() -> void:
    if Net.game_mode != Net.MODE_SURVIVAL or not Net.battle_active:
        return
    var stamp := Time.get_datetime_string_from_system().replace("T", " ")
    var name := SurvivalSaves.active_slot if not SurvivalSaves.active_slot.is_empty() else "notAdataGame " + stamp
    var hp := int(Net.battle_health.get(Net.my_id(), 100))
    if Net.role == "client":
        # Всегда пишем на телефон; на сервер отправляем, только если есть соединение.
        if multiplayer.has_multiplayer_peer() and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
            Net.survival_send_local_snapshot()
        else:
            Net.survival_client_save_local()
    else:
        Net.survival_collect_save(name, local_pos, hp, yaw, pitch)

func _notification(what: int) -> void:
    # Запасной способ открыть паузу, даже если кнопки не видно: системная кнопка «Назад».
    if what == NOTIFICATION_WM_GO_BACK_REQUEST and not editing_controls and not leaving_battle and settings_panel != null:
        if settings_panel.visible:
            settings_panel.hide()
            pause_panel.show()
        else:
            _toggle_pause()
        return
    if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        _survival_snapshot_now()

func _exit_tree() -> void:
    _survival_snapshot_now()
    if Net.survival_local_provider == _survival_local_view:
        Net.survival_local_provider = Callable()
    # Микрофон не должен «висеть» включённым после выхода из боя.
    if VoiceChat.voice_activity.is_connected(_on_voice_activity):
        VoiceChat.voice_activity.disconnect(_on_voice_activity)
    if VoiceChat.mic_changed.is_connected(_on_mic_changed):
        VoiceChat.mic_changed.disconnect(_on_mic_changed)
    if VoiceChat.mic_permission_denied.is_connected(_on_mic_permission_denied):
        VoiceChat.mic_permission_denied.disconnect(_on_mic_permission_denied)
    VoiceChat.set_mic(false)
    if pc_mouse_captured:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
        pc_mouse_captured = false

func _set_pc_mode(enabled: bool) -> void:
    if pc_mode == enabled:
        return
    pc_mode = enabled
    if not editing_controls:
        _set_mobile_hud_visible(not paused and not pc_mode)

## Stage128: клавиши привязаны к ФИЗИЧЕСКОМУ положению на клавиатуре (physical keycode), а не к символу раскладки:
## WASD и остальные клавиши работают одинаково на русской, английской и любой другой раскладке.
## Windows/macOS/Linux считаются ПК даже с сенсорным экраном (ноутбуки-трансформеры); на телефонах — сенсор.
func _is_desktop() -> bool:
    return OS.has_feature("pc") or not DisplayServer.is_touchscreen_available()

## Касание экрана Godot превращает в «виртуальную» мышь (device = -1): такие события не считаем мышью ПК.
func _is_real_mouse(event: InputEvent) -> bool:
    return _is_desktop() and event.device != InputEvent.DEVICE_ID_EMULATION

func _event_code(event: InputEventKey) -> int:
    var physical := int(event.physical_keycode)
    return physical if physical != 0 else int(event.keycode)

func _pc_key(event: InputEventKey, action: String) -> bool:
    return pc_binds.has(action) and int(pc_binds[action]) != 0 and _event_code(event) == int(pc_binds[action])

func _pc_held(action: String) -> bool:
    if chat_open:
        return false
    var code := int(pc_binds.get(action, 0))
    return code > 0 and not _is_mouse_code(code) and Input.is_physical_key_pressed(code)

## Для «Стрельбы» в pc_binds лежит либо кнопка мыши (1..9), либо код клавиши клавиатуры (больше 9).
func _is_mouse_code(code: int) -> bool:
    return code >= MOUSE_BUTTON_LEFT and code <= MOUSE_BUTTON_XBUTTON2

func _bind_name(action: String, code: int) -> String:
    if code == 0:
        return "Не назначена"
    if _is_mouse_code(code):
        match code:
            MOUSE_BUTTON_LEFT: return "ЛКМ"
            MOUSE_BUTTON_RIGHT: return "ПКМ"
            MOUSE_BUTTON_MIDDLE: return "СКМ (колесо)"
            MOUSE_BUTTON_WHEEL_UP: return "Колесо вверх"
            MOUSE_BUTTON_WHEEL_DOWN: return "Колесо вниз"
            _: return "Кнопка мыши %d" % code
    # Название показываем как на вашей клавиатуре (в текущей раскладке), если ОС его знает.
    var layout_code := int(DisplayServer.keyboard_get_keycode_from_physical(code))
    var key_name := OS.get_keycode_string(layout_code) if layout_code != 0 else ""
    if key_name == "":
        key_name = OS.get_keycode_string(code)
    return key_name if key_name != "" else "Клавиша %d" % code

func _try_pickup_pc() -> void:
    if pickup_button != null and pickup_button.visible:
        _pickup_down() if not reviving else _pickup_up()

func _assign_pc_bind(action: String, code: int) -> void:
    # Одна клавиша — одно действие: прежнее действие на этой клавише остаётся без клавиши
    # (стрельба при этом возвращается на ЛКМ). Кнопки мыши и клавиши клавиатуры не конфликтуют.
    for other in pc_binds.keys():
        if other == action:
            continue
        var other_code := int(pc_binds[other])
        if other_code != 0 and other_code == code:
            pc_binds[other] = 0
    pc_binds[action] = code
    _save_pc_binds()

func _bind_label(action: String) -> String:
    return str(PC_BIND_LABELS.get(action, PC_HUD_LABELS.get(action, action)))

## Серая тема меню назначения клавиш (серый HUD).
func _gray_theme() -> Theme:
    return UiGray.make_theme(21)

func _show_pc_binds() -> void:
    _sync_pc_hud_actions()
    if is_instance_valid(pc_bind_panel):
        pc_bind_panel.queue_free()
    waiting_pc_action = ""
    var screen := get_viewport_rect().size
    var dims := Vector2(minf(720.0, screen.x * 0.94), minf(740.0, screen.y * 0.94))
    pc_bind_panel = PanelContainer.new()
    pc_bind_panel.theme = _gray_theme()
    pc_bind_panel.custom_minimum_size = dims
    pc_bind_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    pc_bind_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
    pc_bind_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
    pc_bind_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(pc_bind_panel)
    _register_fit_panel(pc_bind_panel)
    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 8)
    pc_bind_panel.add_child(root)
    var title := Label.new()
    title.text = "УПРАВЛЕНИЕ ПК — НАЗНАЧЕНИЕ КЛАВИШ"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 26)
    root.add_child(title)
    pc_bind_hint = Label.new()
    pc_bind_hint.text = "Нажми на клавишу справа, затем любую клавишу или кнопку мыши. Esc — отмена.\nЕсли клавиша занята, у прежнего действия она снимется. ✕ — убрать клавишу."
    pc_bind_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    pc_bind_hint.add_theme_font_size_override("font_size", 16)
    pc_bind_hint.add_theme_color_override("font_color", UiGray.TEXT_DIM)
    root.add_child(pc_bind_hint)
    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.custom_minimum_size = Vector2(0, dims.y - 190.0)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    root.add_child(scroll)
    var entries := VBoxContainer.new()
    entries.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    entries.add_theme_constant_override("separation", 6)
    scroll.add_child(entries)
    pc_bind_buttons.clear()
    var listed: Array = []
    var sections: Array = PC_BIND_SECTIONS.duplicate(true)
    var rest: Array = []
    for section in sections:
        listed.append_array(section[1])
    for action in pc_binds.keys():
        if not listed.has(action):
            rest.append(action)
    if not rest.is_empty():
        sections.append(["Прочее", rest])
    for section in sections:
        var header := Label.new()
        header.text = "— " + str(section[0]).to_upper() + " —"
        header.add_theme_color_override("font_color", UiGray.TEXT_MUTE)
        header.add_theme_font_size_override("font_size", 17)
        entries.add_child(header)
        for action in section[1]:
            if not pc_binds.has(action):
                continue
            var row := HBoxContainer.new()
            row.add_theme_constant_override("separation", 8)
            entries.add_child(row)
            var name_label := Label.new()
            name_label.text = _bind_label(action)
            name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            name_label.clip_text = true
            row.add_child(name_label)
            var key_button := Button.new()
            key_button.custom_minimum_size = Vector2(210, 42)
            key_button.focus_mode = Control.FOCUS_NONE
            row.add_child(key_button)
            pc_bind_buttons[action] = key_button
            var bind_action: String = action
            key_button.pressed.connect(func() -> void:
                waiting_pc_action = bind_action
                _refresh_pc_bind_buttons()
            )
            var clear_button := Button.new()
            clear_button.text = "✕"
            clear_button.custom_minimum_size = Vector2(42, 42)
            clear_button.focus_mode = Control.FOCUS_NONE
            row.add_child(clear_button)
            clear_button.pressed.connect(func() -> void:
                waiting_pc_action = ""
                _clear_pc_bind(bind_action)
                _refresh_pc_bind_buttons()
            )
    var bottom := HBoxContainer.new()
    bottom.add_theme_constant_override("separation", 10)
    root.add_child(bottom)
    var reset := Button.new()
    reset.text = "Сбросить по умолчанию"
    reset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    reset.focus_mode = Control.FOCUS_NONE
    bottom.add_child(reset)
    reset.pressed.connect(func() -> void:
        pc_binds = PC_DEFAULTS.duplicate()
        _sync_pc_hud_actions()
        waiting_pc_action = ""
        _save_pc_binds()
        _refresh_pc_bind_buttons()
    )
    var close := Button.new()
    close.text = "Готово"
    close.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    close.focus_mode = Control.FOCUS_NONE
    bottom.add_child(close)
    close.pressed.connect(_close_pc_binds)
    if settings_panel != null:
        settings_panel.hide()
    _refresh_pc_bind_buttons()
    _sync_desktop_cursor()

func _close_pc_binds() -> void:
    waiting_pc_action = ""
    if is_instance_valid(pc_bind_panel):
        pc_bind_panel.queue_free()
    pc_bind_panel = null
    pc_bind_buttons.clear()
    if settings_panel != null:
        settings_panel.show()
    _on_mic_changed(VoiceChat.mic_enabled)
    _sync_desktop_cursor()

func _clear_pc_bind(action: String) -> void:
    pc_binds[action] = 0
    _save_pc_binds()

func _refresh_pc_bind_buttons() -> void:
    for action in pc_bind_buttons:
        var button: Button = pc_bind_buttons[action]
        if not is_instance_valid(button):
            continue
        if action == waiting_pc_action:
            button.text = "нажмите клавишу..."
            button.modulate = Color(1.0, 1.0, 1.0)
        else:
            button.text = _bind_name(action, int(pc_binds[action]))
            button.modulate = Color(0.6, 0.6, 0.62) if int(pc_binds[action]) == 0 else Color.WHITE
    _on_mic_changed(VoiceChat.mic_enabled)

## Действия, привязанные к кнопке мыши (кроме стрельбы и прицела — их ведут свои обработчики).
func _pc_mouse_action(action: String) -> void:
    match action:
        "jump": _jump()
        "crouch": _spectator_crouch_or_player()
        "reload": _reload()
        "inventory": _toggle_battle_inventory()
        "weapon1": _select_weapon(0)
        "weapon2": _select_weapon(1)
        "weapon3": _select_weapon(2)
        "pickup": _try_pickup_pc()
        "use":
            if aimed_turret >= 0:
                _buy_turret_ammo()
            else:
                _toggle_shop()
        "pause": _toggle_pause()
        "chat": _toggle_chat()
        "cursor":
            pc_mouse_captured = not pc_mouse_captured
            _sync_desktop_cursor()
            shooting = false
        _: _trigger_hud_pc_action(action)

func _save_pc_binds() -> void:
    var cfg := ConfigFile.new()
    cfg.load(SETTINGS_PATH)
    for action in pc_binds:
        cfg.set_value("pc_binds", action, pc_binds[action])
    cfg.save(SETTINGS_PATH)

func _load_pc_binds() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SETTINGS_PATH) != OK:
        return
    for action in PC_DEFAULTS:
        pc_binds[action] = int(cfg.get_value("pc_binds", action, PC_DEFAULTS[action]))


# =====================================================================
#  Оружие: стрельба, перезарядка, анимации, прицел
# =====================================================================

func _ref_node(key: String) -> Node3D:
    var value: Variant = weapon_refs.get(key)
    if value != null and is_instance_valid(value):
        return value as Node3D
    return null

func _new_fx_tween() -> Tween:
    if fx_tween != null:
        fx_tween.kill()
    fx_tween = create_tween()
    fx_tween.set_trans(Tween.TRANS_SINE)
    return fx_tween

# Завершение перезарядки патронами из инвентаря + дробовик по одному патрону.
func _update_reload(delta: float) -> void:
    if reload_left > 0.0:
        reload_left -= delta
        if reload_left <= 0.0:
            reload_left = 0.0
            var id := _active_weapon_id()
            if id != "":
                var def: Dictionary = Weapons.get_def(id)
                var added: int = _consume_ammo(str(def["ammo"]), int(def["mag"]) - _mag_of(id))
                mags[id] = _mag_of(id) + added
    if shell_reload:
        shell_timer -= delta
        if shell_timer > 0.0:
            return
        var shell_id := _active_weapon_id()
        if shell_id == "":
            shell_reload = false
            return
        var shell_def: Dictionary = Weapons.get_def(shell_id)
        if _mag_of(shell_id) >= int(shell_def["mag"]) or _consume_ammo(str(shell_def["ammo"]), 1) <= 0:
            shell_reload = false
            return
        mags[shell_id] = _mag_of(shell_id) + 1
        _play_weapon_sound(str(shell_def.get("sound_reload", "")))
        shell_timer = float(shell_def["reload"])
        if _mag_of(shell_id) >= int(shell_def["mag"]) or reserve <= 0:
            shell_reload = false

func _update_firing() -> void:
    if _my_state != Net.ST_ALIVE and not _can_downed_pistol():
        return
    var id := _active_weapon_id()
    if id == "":
        return
    var def: Dictionary = Weapons.get_def(id)
    var melee := bool(def.get("melee", false))
    var wants_fire := false
    if melee:
        wants_fire = shooting or fire_queued > 0.0
    elif bool(def["auto"]):
        wants_fire = shooting
    else:
        wants_fire = fire_queued > 0.0
    if not wants_fire or shot_left > 0.0 or reload_left > 0.0:
        return
    if melee:
        fire_queued = 0.0
        shot_left = float(def["rate"])
        _melee_attack(id, def)
        return
    var loaded := _mag_of(id)
    if loaded <= 0:
        if shell_reload:
            return
        fire_queued = 0.0
        if dry_fire_cooldown <= 0.0:
            dry_fire_cooldown = 0.35
            _play_weapon_sound("res://assets/audio/dry_fire.wav")
        _sync_reserve()
        if reserve > 0:
            _reload()
        return
    # Выстрел прерывает посимвольную зарядку дробовика.
    if shell_reload:
        _cancel_reload()
    mags[id] = loaded - 1
    shot_left = float(def["rate"])
    fire_queued = 0.0
    _fire_weapon(id, def)
    _play_weapon_sound(str(def.get("sound_fire", "")))
    _animate_shot(id, def)

func _cancel_reload() -> void:
    var was_reloading := _is_reloading()
    reload_left = 0.0
    shell_reload = false
    _reset_weapon_magazine()
    _reset_parts()
    if was_reloading:
        _return_to_rest()

func _return_to_rest() -> void:
    if not is_instance_valid(held_weapon_model):
        return
    var def: Dictionary = Weapons.get_def(_active_weapon_id())
    if def.is_empty():
        return
    var target: Vector3 = def["ads"] if aiming else def["rest"]
    if weapon_tween != null:
        weapon_tween.kill()
    weapon_tween = create_tween()
    weapon_tween.set_trans(Tween.TRANS_SINE)
    weapon_tween.set_ease(Tween.EASE_OUT)
    weapon_tween.tween_property(held_weapon_model, "position", target, 0.2)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3.ZERO, 0.2)

func _reset_parts() -> void:
    if fx_tween != null:
        fx_tween.kill()
    for pair in [["slide", "slide_rest"], ["pump", "pump_rest"], ["bolt", "bolt_rest"], ["cylinder", "cylinder_rest"]]:
        var node := _ref_node(str(pair[0]))
        if node != null and weapon_refs.has(str(pair[1])):
            node.position = weapon_refs[str(pair[1])]
    var cylinder := _ref_node("cylinder")
    if cylinder != null:
        cylinder.rotation_degrees = Vector3.ZERO

func _show_flash() -> void:
    var flash := _ref_node("flash")
    if flash == null:
        return
    flash.visible = true
    var flash_size := shot_rng.randf_range(0.8, 1.35)
    flash.rotation.z = shot_rng.randf() * TAU
    flash.scale = Vector3(flash_size, flash_size, 2.4 * flash_size)
    flash_time = 0.045

func _animate_shot(weapon_id: String, def: Dictionary) -> void:
    if not is_instance_valid(held_weapon_model):
        return
    _show_flash()
    var kind := str(def["kind"])
    if kind != "revolver" and kind != "shotgun":
        _eject_casing(1.0)
    var base_pos: Vector3 = def["ads"] if aiming else def["rest"]
    var back: float = float(def["kick_back"])
    var rot_kick: float = back * (22.0 if aiming else 45.0)
    var settle := clampf(float(def["rate"]) * 0.65, 0.07, 0.3)
    if weapon_tween != null:
        weapon_tween.kill()
    held_weapon_model.rotation_degrees = Vector3.ZERO
    weapon_tween = create_tween()
    weapon_tween.tween_property(held_weapon_model, "position", base_pos + Vector3(0, back * 0.38, back), 0.035)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3(rot_kick, 0, 0), 0.035)
    weapon_tween.tween_property(held_weapon_model, "position", base_pos, settle)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3.ZERO, settle)
    match kind:
        "pm":
            _animate_slide(_mag_of(weapon_id) <= 0)
        "svd":
            _animate_bolt(def)
        "shotgun":
            _animate_pump(def)
        "revolver":
            _spin_cylinder()

func _animate_slide(lock_back: bool) -> void:
    var slide := _ref_node("slide")
    if slide == null:
        return
    var tw := _new_fx_tween()
    tw.tween_property(slide, "position", weapon_refs["slide_back"], 0.03)
    if not lock_back:
        tw.tween_property(slide, "position", weapon_refs["slide_rest"], 0.07)

func _animate_bolt(def: Dictionary) -> void:
    var bolt := _ref_node("bolt")
    if bolt == null:
        return
    var tw := _new_fx_tween()
    tw.tween_interval(0.25)
    tw.tween_property(bolt, "position", weapon_refs["bolt_back"], 0.10)
    tw.tween_property(bolt, "position", weapon_refs["bolt_rest"], 0.14)
    get_tree().create_timer(0.30).timeout.connect(_eject_casing.bind(1.3))
    get_tree().create_timer(0.30).timeout.connect(_play_weapon_sound.bind(str(def.get("sound_bolt", "")), -4.0))

func _animate_pump(def: Dictionary) -> void:
    var pump := _ref_node("pump")
    if pump == null:
        return
    var tw := _new_fx_tween()
    tw.tween_interval(0.2)
    tw.tween_callback(_play_weapon_sound.bind(str(def.get("sound_pump", "")), -3.0))
    tw.tween_property(pump, "position", weapon_refs["pump_back"], 0.13)
    tw.tween_callback(_eject_casing.bind(1.7))
    tw.tween_property(pump, "position", weapon_refs["pump_rest"], 0.15)

func _spin_cylinder() -> void:
    var cylinder := _ref_node("cylinder")
    if cylinder == null:
        return
    var tw := _new_fx_tween()
    tw.tween_property(cylinder, "rotation_degrees:z", cylinder.rotation_degrees.z + 60.0, 0.12)

# Гильза вылетает вправо-вверх и падает на землю (мировые координаты).
func _eject_casing(scale_factor: float = 1.0) -> void:
    if not is_instance_valid(held_weapon_model) or not weapon_refs.has("eject") or viewport == null:
        return
    var start: Vector3 = held_weapon_model.to_global(weapon_refs["eject"] as Vector3)
    var cam_basis := camera.global_transform.basis
    var velocity := cam_basis.x * shot_rng.randf_range(1.3, 2.0) + cam_basis.y * shot_rng.randf_range(0.9, 1.6) + cam_basis.z * shot_rng.randf_range(0.0, 0.5)
    _spawn_casing(start, velocity, scale_factor)

func _spawn_casing(start: Vector3, velocity: Vector3, scale_factor: float) -> void:
    if viewport == null:
        return
    var casing := WeaponModels.make_casing(scale_factor)
    viewport.get_child(0).add_child(casing)
    casing.global_position = start
    casing.rotation = Vector3(shot_rng.randf() * TAU, shot_rng.randf() * TAU, 0.0)
    var spin := Vector3(shot_rng.randf_range(-12.0, 12.0), shot_rng.randf_range(-12.0, 12.0), 0.0)
    var tw := create_tween()
    tw.tween_method(_casing_step.bind(casing, start, velocity, spin), 0.0, 0.7, 0.7)
    tw.tween_callback(casing.queue_free)

func _casing_step(t: float, casing: Node3D, start: Vector3, velocity: Vector3, spin: Vector3) -> void:
    if not is_instance_valid(casing):
        return
    var p := start + velocity * t + Vector3(0.0, -4.9 * t * t, 0.0)
    p.y = maxf(p.y, 0.02)
    casing.global_position = p
    casing.rotation += spin * 0.016

# ------------------------------------------------------------------ melee
func _melee_attack(weapon_id: String, def: Dictionary) -> void:
    if not is_instance_valid(held_weapon_model):
        return
    _set_aim(false)
    var k := clampf(float(def["rate"]) / 0.5, 0.6, 2.0)
    var sword: bool = weapon_id == "diamond_sword"
    var rest: Vector3 = def["rest"]
    melee_flip = not melee_flip
    var side := -1.0 if melee_flip else 1.0
    if weapon_tween != null:
        weapon_tween.kill()
    weapon_tween = create_tween()
    weapon_tween.set_trans(Tween.TRANS_SINE)
    if sword:
        _sword_combo_attack(weapon_id, def, rest)
        return
    weapon_tween.set_ease(Tween.EASE_OUT)
    weapon_tween.tween_property(held_weapon_model, "position", rest + Vector3(0.14 * side, 0.02, 0.07), 0.10 * k)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3(-12, 30 * side, 38 * side), 0.10 * k)
    weapon_tween.tween_callback(_melee_strike.bind(weapon_id))
    weapon_tween.set_ease(Tween.EASE_IN)
    weapon_tween.tween_property(held_weapon_model, "position", rest + Vector3(-0.30 * side, -0.06, -0.16), 0.09 * k)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3(18, -65 * side, -45 * side), 0.09 * k)
    weapon_tween.set_ease(Tween.EASE_OUT)
    weapon_tween.tween_interval(0.03)
    weapon_tween.tween_property(held_weapon_model, "position", rest, 0.25 * k)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3.ZERO, 0.25 * k)
    _play_weapon_sound(str(def.get("sound_fire", "")))

# ------------------------------------------------------------------ Stage106: анимации меча CREATOR (в стиле ближнего боя PUBG Mobile)
# Поза меча задаётся направлением клинка в пространстве камеры и креном вокруг клинка;
# между позами тween интерполирует кватернионы (slerp), поэтому дуги плавные, без «кручения» эйлеров.
func _sword_q(dir: Vector3, roll_deg: float) -> Quaternion:
    var base: Vector3 = Basis.from_euler(Vector3(deg_to_rad(-65.2), deg_to_rad(-7.6), 0.0)) * Vector3.UP
    var arc := Quaternion(base, dir.normalized())
    var blade: Vector3 = arc * base
    return Quaternion(blade.normalized(), deg_to_rad(roll_deg)) * arc

# Серия из трёх ударов: 1 — косой сверху справа вниз влево, 2 — обратный слева направо вверх,
# 3 — тяжёлый вертикальный удар сверху вниз. Если пауза между ударами > 1.3 с — серия начинается заново.
# Ключ: [смещение от rest, направление клинка, крен].
func _sword_combo_keys(hit: int) -> Array:
    match hit:
        0:
            return [
                [Vector3(0.14, 0.20, 0.12), Vector3(0.30, 0.90, 0.30), -10.0],
                [Vector3(-0.04, 0.0, -0.16), Vector3(-0.20, 0.40, -0.90), 10.0],
                [Vector3(-0.30, -0.18, -0.22), Vector3(-0.90, -0.15, -0.45), 30.0]]
        1:
            return [
                [Vector3(-0.24, -0.12, -0.10), Vector3(-0.85, 0.05, -0.45), 25.0],
                [Vector3(0.0, 0.0, -0.18), Vector3(0.0, 0.45, -0.90), 0.0],
                [Vector3(0.26, 0.08, -0.16), Vector3(0.85, 0.50, -0.20), -20.0]]
        _:
            return [
                [Vector3(0.08, 0.30, 0.18), Vector3(0.10, 1.0, 0.30), -5.0],
                [Vector3(0.0, 0.05, -0.22), Vector3(0.0, 0.35, -0.93), 0.0],
                [Vector3(-0.04, -0.32, -0.34), Vector3(0.0, -0.55, -0.83), 0.0]]

func _sword_combo_attack(weapon_id: String, def: Dictionary, rest: Vector3) -> void:
    var now := Time.get_ticks_msec()
    if now - melee_last_ms > 1300:
        melee_combo = 0
    var hit := melee_combo % 3
    melee_combo = (melee_combo + 1) % 3
    melee_last_ms = now
    var keys := _sword_combo_keys(hit)
    var heavy := hit == 2
    var wind_t := 0.26 if heavy else 0.15
    var mid_t := 0.07 if heavy else 0.055
    var end_t := 0.08 if heavy else 0.07
    var hold_t := 0.07 if heavy else 0.04
    var back_t := 0.34 if heavy else 0.30
    var model := held_weapon_model
    # 1) замах: сначала быстро уходим в сторону/назад — как в PUBG Mobile, подготовка перед рывком
    weapon_tween.set_trans(Tween.TRANS_SINE)
    weapon_tween.set_ease(Tween.EASE_OUT)
    weapon_tween.tween_property(model, "position", rest + (keys[0][0] as Vector3), wind_t)
    weapon_tween.parallel().tween_property(model, "quaternion", _sword_q(keys[0][1], keys[0][2]), wind_t)
    # 2) рывок: клинок разгоняется, огненный шлейф и звук взмаха — в начале рывка
    weapon_tween.tween_callback(_creator_sword_swing_fire)
    weapon_tween.tween_callback(_play_weapon_sound.bind(str(def.get("sound_fire", "")), 2.0 if heavy else 0.0))
    weapon_tween.set_trans(Tween.TRANS_QUAD)
    weapon_tween.set_ease(Tween.EASE_IN)
    weapon_tween.tween_property(model, "position", rest + (keys[1][0] as Vector3), mid_t)
    weapon_tween.parallel().tween_property(model, "quaternion", _sword_q(keys[1][1], keys[1][2]), mid_t)
    # удар засчитывается, когда клинок проходит центр экрана
    weapon_tween.tween_callback(_melee_strike.bind(weapon_id))
    weapon_tween.set_ease(Tween.EASE_OUT)
    weapon_tween.tween_property(model, "position", rest + (keys[2][0] as Vector3), end_t)
    weapon_tween.parallel().tween_property(model, "quaternion", _sword_q(keys[2][1], keys[2][2]), end_t)
    # 3) короткая задержка в конце (вес удара) и мягкий возврат в стойку
    weapon_tween.tween_interval(hold_t)
    weapon_tween.set_trans(Tween.TRANS_SINE)
    weapon_tween.set_ease(Tween.EASE_IN_OUT)
    weapon_tween.tween_property(model, "position", rest, back_t)
    weapon_tween.parallel().tween_property(model, "quaternion", Quaternion.IDENTITY, back_t)

# Доставание меча: выносится снизу справа, подбрасывается вверх с оборотом, делает короткий рубящий
# взмах и встаёт в боевую стойку.
func _sword_draw_animation(weapon: Node3D, rest: Vector3) -> void:
    weapon.position = rest + Vector3(0.34, -0.55, 0.12)
    weapon.quaternion = _sword_q(Vector3(0.55, -0.35, -0.75), 40.0)
    weapon_tween.set_trans(Tween.TRANS_QUAD)
    weapon_tween.set_ease(Tween.EASE_OUT)
    weapon_tween.tween_property(weapon, "position", rest + Vector3(0.10, 0.18, 0.10), 0.26)
    weapon_tween.parallel().tween_property(weapon, "quaternion", _sword_q(Vector3(0.20, 0.95, 0.20), -25.0), 0.26)
    weapon_tween.set_trans(Tween.TRANS_SINE)
    weapon_tween.set_ease(Tween.EASE_IN_OUT)
    weapon_tween.tween_property(weapon, "position", rest + Vector3(-0.02, -0.04, -0.06), 0.14)
    weapon_tween.parallel().tween_property(weapon, "quaternion", _sword_q(Vector3(-0.10, 0.55, -0.85), 8.0), 0.14)
    weapon_tween.tween_property(weapon, "position", rest, 0.18)
    weapon_tween.parallel().tween_property(weapon, "quaternion", Quaternion.IDENTITY, 0.18)


func _melee_strike(weapon_id: String) -> void:
    if not is_instance_valid(camera):
        return
    Net.request_melee(weapon_id, camera.global_position, -camera.global_transform.basis.z)

# ------------------------------------------------------------------ reload animations
func _animate_reload(def: Dictionary) -> void:
    if not is_instance_valid(held_weapon_model):
        return
    _reset_parts()
    if weapon_tween != null:
        weapon_tween.kill()
    weapon_tween = create_tween()
    weapon_tween.set_trans(Tween.TRANS_SINE)
    weapon_tween.set_ease(Tween.EASE_IN_OUT)
    var rest: Vector3 = def["rest"]
    match str(def["reload_style"]):
        "pistol":
            _reload_pistol(rest)
        "revolver":
            _reload_revolver(def, rest)
        _:
            _reload_rifle(def, rest)

func _new_magazine_tween() -> Tween:
    _reset_weapon_magazine()
    magazine_tween = create_tween()
    magazine_tween.set_trans(Tween.TRANS_SINE)
    magazine_tween.set_ease(Tween.EASE_IN_OUT)
    return magazine_tween

# АК-47, M4A1, СВД: наклон, снятие магазина, новый магазин, затвор.
func _reload_rifle(def: Dictionary, rest: Vector3) -> void:
    var s: float = float(def["reload"]) / 3.0
    var model := held_weapon_model
    if is_instance_valid(wp_mag):
        var drop: Vector3 = weapon_refs.get("mag_drop", Vector3(0.0, -0.26, 0.04))
        var drop_rot: Vector3 = weapon_refs.get("mag_drop_rot", Vector3(0, 0, 14))
        var mt := _new_magazine_tween()
        mt.tween_interval(0.55 * s)
        mt.tween_property(wp_mag, "position", wp_mag_rest + drop, 0.65 * s)
        mt.parallel().tween_property(wp_mag, "rotation_degrees", wp_mag_rot_rest + drop_rot, 0.65 * s)
        mt.tween_interval(0.25 * s)
        mt.tween_property(wp_mag, "position", wp_mag_rest, 0.65 * s)
        mt.parallel().tween_property(wp_mag, "rotation_degrees", wp_mag_rot_rest, 0.65 * s)
        mt.tween_callback(_reset_weapon_magazine)
    weapon_tween.tween_property(model, "position", rest + Vector3(0.10, -0.22, 0.10), 0.38 * s)
    weapon_tween.parallel().tween_property(model, "rotation_degrees", Vector3(24, 0, -22), 0.38 * s)
    weapon_tween.tween_property(model, "rotation_degrees", Vector3(34, -12, -45), 0.38 * s)
    weapon_tween.tween_interval(0.46 * s)
    weapon_tween.tween_property(model, "rotation_degrees", Vector3(20, 8, -16), 0.36 * s)
    weapon_tween.tween_interval(0.42 * s)
    weapon_tween.tween_property(model, "position", rest + Vector3(0.06, -0.12, 0.04), 0.40 * s)
    weapon_tween.parallel().tween_property(model, "rotation_degrees", Vector3(-8, 0, 7), 0.40 * s)
    weapon_tween.tween_property(model, "position", rest, 0.60 * s)
    weapon_tween.parallel().tween_property(model, "rotation_degrees", Vector3.ZERO, 0.60 * s)
    var bolt := _ref_node("bolt")
    if bolt != null:
        var tw := _new_fx_tween()
        tw.tween_interval(float(def["reload"]) * 0.78)
        tw.tween_property(bolt, "position", weapon_refs["bolt_back"], 0.10)
        tw.tween_property(bolt, "position", weapon_refs["bolt_rest"], 0.14)

# Пистолет: магазин вниз, новый магазин, затвор оттягивается и отпускается.
func _reload_pistol(rest: Vector3) -> void:
    var model := held_weapon_model
    if is_instance_valid(wp_mag):
        var drop: Vector3 = weapon_refs.get("mag_drop", Vector3(0.0, -0.20, 0.05))
        var mt := _new_magazine_tween()
        mt.tween_interval(0.35)
        mt.tween_property(wp_mag, "position", wp_mag_rest + drop, 0.22)
        mt.tween_interval(0.25)
        mt.tween_property(wp_mag, "position", wp_mag_rest, 0.20)
        mt.tween_callback(_reset_weapon_magazine)
    weapon_tween.tween_property(model, "position", rest + Vector3(0.05, -0.10, 0.04), 0.30)
    weapon_tween.parallel().tween_property(model, "rotation_degrees", Vector3(28, 0, -32), 0.30)
    weapon_tween.tween_interval(0.75)
    weapon_tween.tween_property(model, "position", rest + Vector3(0.03, -0.05, 0.02), 0.25)
    weapon_tween.parallel().tween_property(model, "rotation_degrees", Vector3(12, 6, -12), 0.25)
    weapon_tween.tween_interval(0.10)
    weapon_tween.tween_property(model, "position", rest, 0.40)
    weapon_tween.parallel().tween_property(model, "rotation_degrees", Vector3.ZERO, 0.40)
    var slide := _ref_node("slide")
    if slide != null:
        var tw := _new_fx_tween()
        tw.tween_interval(1.35)
        tw.tween_property(slide, "position", weapon_refs["slide_back"], 0.05)
        tw.tween_property(slide, "position", weapon_refs["slide_rest"], 0.08)

# Револьвер: барабан откидывается, гильзы высыпаются, барабан крутится и закрывается.
func _reload_revolver(def: Dictionary, rest: Vector3) -> void:
    var model := held_weapon_model
    var tilt_pos := rest + Vector3(0.06, -0.14, 0.05)
    weapon_tween.tween_property(model, "position", tilt_pos, 0.35)
    weapon_tween.parallel().tween_property(model, "rotation_degrees", Vector3(26, 0, -50), 0.35)
    weapon_tween.tween_property(model, "rotation_degrees", Vector3(62, 0, -50), 0.22)
    weapon_tween.tween_interval(0.15)
    weapon_tween.tween_property(model, "rotation_degrees", Vector3(26, 0, -50), 0.20)
    weapon_tween.tween_interval(0.85)
    weapon_tween.tween_property(model, "rotation_degrees", Vector3(12, 0, -20), 0.30)
    weapon_tween.tween_property(model, "position", rest, 0.45)
    weapon_tween.parallel().tween_property(model, "rotation_degrees", Vector3.ZERO, 0.45)
    var cylinder := _ref_node("cylinder")
    if cylinder != null:
        var rest_pos: Vector3 = weapon_refs["cylinder_rest"]
        var tw := _new_fx_tween()
        tw.tween_interval(0.30)
        tw.tween_property(cylinder, "position", rest_pos + Vector3(-0.07, -0.01, 0.0), 0.18)
        tw.tween_interval(0.75)
        tw.tween_property(cylinder, "rotation_degrees:z", 360.0, 0.80)
        tw.tween_property(cylinder, "position", rest_pos, 0.18)
        tw.tween_callback(func() -> void:
            if is_instance_valid(cylinder):
                cylinder.rotation_degrees = Vector3.ZERO
        )
    for k in 6:
        get_tree().create_timer(0.62 + k * 0.04).timeout.connect(_eject_casing.bind(0.9))

# Дробовик: заряжается по одному патрону, выстрел прерывает перезарядку.
func _animate_shell_reload(def: Dictionary, count: int) -> void:
    if not is_instance_valid(held_weapon_model) or count <= 0:
        return
    _reset_parts()
    if weapon_tween != null:
        weapon_tween.kill()
    var rest: Vector3 = def["rest"]
    var load_pos := rest + Vector3(0.04, -0.10, 0.06)
    var period: float = float(def["reload"])
    weapon_tween = create_tween()
    weapon_tween.set_trans(Tween.TRANS_SINE)
    weapon_tween.set_ease(Tween.EASE_IN_OUT)
    weapon_tween.tween_property(held_weapon_model, "position", load_pos, 0.30)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3(22, 0, -18), 0.30)
    for k in count:
        weapon_tween.tween_property(held_weapon_model, "position", load_pos + Vector3(0, -0.025, 0.02), 0.10)
        weapon_tween.tween_property(held_weapon_model, "position", load_pos, 0.10)
        if k < count - 1:
            weapon_tween.tween_interval(maxf(period - 0.20, 0.0))
    weapon_tween.tween_property(held_weapon_model, "position", rest, 0.30)
    weapon_tween.parallel().tween_property(held_weapon_model, "rotation_degrees", Vector3.ZERO, 0.30)

# ------------------------------------------------------------------ scope
func _create_scope_overlay() -> void:
    scope_overlay = ColorRect.new()
    scope_overlay.name = "ScopeOverlay"
    scope_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    scope_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var shader := Shader.new()
    shader.code = """
shader_type canvas_item;
uniform float aspect = 1.7778;
void fragment() {
    vec2 p = (UV - vec2(0.5)) * vec2(aspect, 1.0);
    float r = length(p);
    float inside = smoothstep(0.455, 0.447, r);
    float thin_h = step(abs(p.y), 0.0012) * step(r, 0.447);
    float thin_v = step(abs(p.x), 0.0012) * step(r, 0.447);
    float thick_h = step(abs(p.y), 0.004) * step(0.14, abs(p.x)) * step(r, 0.447);
    float thick_v = step(abs(p.x), 0.004) * step(0.14, abs(p.y)) * step(r, 0.447);
    float marks = max(max(thin_h, thin_v), max(thick_h, thick_v));
    COLOR = vec4(0.0, 0.0, 0.0, max(1.0 - inside, marks));
}
"""
    var material := ShaderMaterial.new()
    material.shader = shader
    scope_overlay.material = material
    add_child(scope_overlay)
    # Под HUD (кнопки остаются видимыми), но поверх 3D-мира.
    move_child(scope_overlay, 1)
    scope_overlay.hide()

func _create_collimator_overlay() -> void:
    collimator_reticle = preload("res://scripts/collimator_reticle.gd").new()
    add_child(collimator_reticle)
    move_child(collimator_reticle, 1)   # под HUD, поверх 3D-мира
    collimator_reticle.hide()

## Коллиматор «надет»: предмет лежит в ячейке «Обвес», а текущее оружие его принимает.
func _collimator_active() -> bool:
    return GameState.has_attachment("collimator") and Weapons.has_collimator(_active_weapon_id())

## Красная точка коллиматора по центру экрана (только при прицеливании).
func _set_collimator(on: bool) -> void:
    if on and not aiming:
        return
    if collimator_reticle == null:
        return
    collimator_reticle.visible = on
    if on:
        collimator_reticle.queue_redraw()
    var crosshair := get_node_or_null("HUD/Crosshair") as Control
    if crosshair != null and not (scope_overlay != null and scope_overlay.visible):
        crosshair.visible = not on

## Отправляет остальным игрокам, какое оружие у меня в руках и целюсь ли я.
func _sync_hold_state() -> void:
    var weapon_id := _active_weapon_id()
    var aim := aiming and weapon_id != "" and not Weapons.is_melee(weapon_id)
    var attach := _collimator_active()
    if weapon_id != _sent_hold_weapon or aim != _sent_hold_aim or attach != _sent_hold_attach:
        _sent_hold_weapon = weapon_id
        _sent_hold_aim = aim
        _sent_hold_attach = attach
        Net.submit_battle_hold(weapon_id, aim, attach)

func _set_scope(on: bool) -> void:
    if on and not aiming:
        return
    if scope_overlay != null:
        scope_overlay.visible = on
        if on:
            var screen := get_viewport_rect().size
            (scope_overlay.material as ShaderMaterial).set_shader_parameter("aspect", screen.x / maxf(screen.y, 1.0))
    if is_instance_valid(held_weapon_model):
        held_weapon_model.visible = not on
    var crosshair := get_node_or_null("HUD/Crosshair") as Control
    if crosshair != null:
        crosshair.visible = not on

# Stage62: death bag view and interaction.
var death_bag_nodes: Dictionary = {}
var death_bag_panel: PanelContainer
var death_bag_list: VBoxContainer
var death_bag_selected: int = -1
var death_bag_pending_index: int = -1

func _make_death_bag_ui() -> void:
    death_bag_panel = PanelContainer.new()
    death_bag_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    death_bag_panel.offset_left = 20
    death_bag_panel.offset_top = 20
    death_bag_panel.offset_right = -20
    death_bag_panel.offset_bottom = -20
    add_child(death_bag_panel)
    var horizontal := HBoxContainer.new()
    death_bag_panel.add_child(horizontal)
    var left := VBoxContainer.new()
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    horizontal.add_child(left)
    var label := Label.new()
    label.text = "МОЙ ИНВЕНТАРЬ (слева)"
    left.add_child(label)
    var my_items := Label.new()
    my_items.name = "MyItems"
    left.add_child(my_items)
    var right := VBoxContainer.new()
    right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    horizontal.add_child(right)
    var title := Label.new()
    title.text = "РЮКЗАК ПОГИБШЕГО (справа)"
    right.add_child(title)
    death_bag_list = VBoxContainer.new()
    right.add_child(death_bag_list)
    var close := Button.new()
    close.text = "Закрыть"
    close.pressed.connect(func(): death_bag_panel.hide())
    right.add_child(close)
    death_bag_panel.hide()

func _refresh_death_bags() -> void:
    if not is_inside_tree() or not is_instance_valid(camera):
        return
    var world := $WorldView/Viewport/World as Node3D
    for node in death_bag_nodes.values():
        if is_instance_valid(node):
            node.queue_free()
    death_bag_nodes.clear()
    for key in Net.death_bags.keys():
        var bag: Dictionary = Net.death_bags[key]
        var node := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = Vector3(0.65, 0.36, 0.45)
        node.mesh = mesh
        var material := StandardMaterial3D.new()
        material.albedo_color = Color(0.34, 0.27, 0.16)
        node.material_override = material
        node.position = bag["pos"] + Vector3(0, 0.2, 0)
        world.add_child(node)
        death_bag_nodes[key] = node
    if death_bag_panel.visible:
        _render_death_bag()

func _open_nearest_death_bag() -> bool:
    if _my_state != Net.ST_ALIVE:
        return false
    var nearest := -1
    var distance := 3.5
    for key in Net.death_bags.keys():
        var bag: Dictionary = Net.death_bags[key]
        var diff: Vector3 = bag["pos"] - local_pos
        if diff.length() < distance:
            distance = diff.length()
            nearest = int(key)
    if nearest < 0:
        return false
    death_bag_selected = nearest
    death_bag_panel.show()
    _render_death_bag()
    return true

func _render_death_bag() -> void:
    if not Net.death_bags.has(death_bag_selected):
        death_bag_panel.hide()
        return
    for child in death_bag_list.get_children():
        child.queue_free()
    var my_items := death_bag_panel.find_child("MyItems", true, false) as Label
    var lines: Array[String] = []
    for slot in GameState.battle_equipment + GameState.battle_inventory:
        if slot is Dictionary and not slot.is_empty():
            lines.append("%s x%d" % [GameState.ITEMS.get(str(slot.get("id", "")), {}).get("name", str(slot.get("id", ""))), int(slot.get("count", 1))])
    my_items.text = "\n".join(lines) if not lines.is_empty() else "Пусто"
    var bag: Dictionary = Net.death_bags[death_bag_selected]
    var items: Array = bag["items"]
    for i in items.size():
        var stack: Dictionary = items[i]
        var button := Button.new()
        button.text = "%s x%d   →" % [GameState.ITEMS.get(str(stack.get("id", "")), {}).get("name", str(stack.get("id", ""))), int(stack.get("count", 1))]
        button.disabled = not _can_fit_pickup(stack)
        button.pressed.connect(_take_from_death_bag.bind(i))
        death_bag_list.add_child(button)

func _take_from_death_bag(index: int) -> void:
    if not Net.death_bags.has(death_bag_selected):
        return
    var items: Array = Net.death_bags[death_bag_selected]["items"]
    if index < 0 or index >= items.size() or not _can_fit_pickup(items[index]):
        return
    death_bag_pending_index = index
    Net.take_death_bag_item(death_bag_selected, index)

func _on_death_bag_item(stack: Dictionary) -> void:
    if death_bag_pending_index < 0 or not _can_fit_pickup(stack):
        return
    _receive_pickup(stack)
    Net.confirm_death_bag_take(death_bag_selected, death_bag_pending_index)
    death_bag_pending_index = -1
    _render_death_bag()

func _nearest_death_bag_exists() -> bool:
    for bag in Net.death_bags.values():
        if local_pos.distance_to(bag["pos"]) <= 3.5:
            return true
    return false

func _can_downed_pistol() -> bool:
    if _my_state != Net.ST_DOWNED or not GameState.downed_pistol_talent or active_weapon_slot != 1:
        return false
    var id := _active_weapon_id()
    return Weapons.has(id) and int(Weapons.get_def(id).get("slot", -1)) == 1

# ---------------------------------------------------------------- Stage84: магазины и турели

func _shop_open() -> bool:
    return shop_panel != null and shop_panel.visible

func _create_chat_ui() -> void:
    chat_box = VBoxContainer.new()
    chat_box.name = "ChatBox"
    chat_box.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
    chat_box.position = Vector2(20, 110)
    chat_box.custom_minimum_size = Vector2(CHAT_WIDTH, 0)
    chat_box.size = Vector2(CHAT_WIDTH, 10)
    chat_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    chat_box.add_theme_constant_override("separation", 6)
    add_child(chat_box)
    # Поле ввода (серое, как все меню) — показывается только пока чат открыт.
    chat_input_panel = PanelContainer.new()
    chat_input_panel.theme = UiGray.make_theme(20)
    chat_input_panel.add_theme_stylebox_override("panel", UiGray.box(UiGray.PANEL, 10, UiGray.EDGE, 2, 6))
    chat_input_panel.visible = false
    chat_box.add_child(chat_input_panel)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 6)
    chat_input_panel.add_child(row)
    chat_input = LineEdit.new()
    chat_input.placeholder_text = "Сообщение..."
    chat_input.max_length = Net.CHAT_MAX_LENGTH
    chat_input.custom_minimum_size = Vector2(0, 46)
    chat_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    chat_input.text_submitted.connect(_submit_chat)
    row.add_child(chat_input)
    var send := Button.new()
    send.text = "Отпр."
    send.custom_minimum_size = Vector2(86, 46)
    send.focus_mode = Control.FOCUS_NONE
    send.pressed.connect(func(): _submit_chat(chat_input.text))
    row.add_child(send)
    # Лента сообщений.
    chat_list = VBoxContainer.new()
    chat_list.mouse_filter = Control.MOUSE_FILTER_IGNORE
    chat_list.add_theme_constant_override("separation", 4)
    chat_box.add_child(chat_list)
    Net.chat_message.connect(_on_chat_message)

func _toggle_chat() -> void:
    if chat_open:
        _close_chat()
        return
    if chat_input == null or paused or editing_controls or evac_active:
        return
    if _shop_open() or (inventory_panel != null and inventory_panel.visible):
        return
    chat_open = true
    _set_aim(false)
    shooting = false
    direction = Vector2.ZERO
    chat_input.text = ""
    chat_input_panel.show()
    _sync_desktop_cursor()
    chat_input.call_deferred("grab_focus")   # на телефоне сразу открывается клавиатура

func _close_chat() -> void:
    chat_open = false
    if chat_input != null:
        chat_input.release_focus()
        chat_input.text = ""
    if chat_input_panel != null:
        chat_input_panel.hide()
    _sync_desktop_cursor()

func _submit_chat(text: String) -> void:
    Net.send_chat(text)
    _close_chat()

func _on_chat_message(peer: int, nick: String, text: String) -> void:
    if chat_list == null:
        return
    var mine := peer == Net.my_id()
    var nick_color := "#e8e8ea" if mine else "#9ec9ff"
    var plain := "%s: %s" % [nick, text]
    var label := RichTextLabel.new()
    label.bbcode_enabled = true
    label.fit_content = true
    label.scroll_active = false
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.add_theme_font_size_override("normal_font_size", 20)
    label.add_theme_font_size_override("bold_font_size", 20)
    label.add_theme_color_override("default_color", Color.WHITE)
    label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    label.add_theme_constant_override("outline_size", 5)
    # Квадратные скобки экранируем, чтобы игрок не мог вставить свою BBCode-разметку.
    label.text = "[color=%s][b]%s:[/b][/color] %s" % [nick_color, nick.replace("[", "[lb]"), text.replace("[", "[lb]")]
    var font := get_theme_default_font()
    var text_w: float = font.get_string_size(plain, HORIZONTAL_ALIGNMENT_LEFT, -1, 20).x if font != null else CHAT_WIDTH
    label.custom_minimum_size = Vector2(clampf(text_w + 6.0, 60.0, CHAT_WIDTH - 20.0), 0)
    var plate := PanelContainer.new()
    plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
    plate.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    plate.add_theme_stylebox_override("panel", UiGray.box(Color(0.04, 0.04, 0.05, 0.55), 8, Color(0, 0, 0, 0), 0, 6))
    plate.add_child(label)
    chat_list.add_child(plate)
    chat_entries.append({"node": plate, "born": Time.get_ticks_msec()})
    while chat_entries.size() > CHAT_MAX_LINES:
        var oldest: Dictionary = chat_entries.pop_front()
        if is_instance_valid(oldest["node"]):
            (oldest["node"] as Node).queue_free()

## Через 10 секунд сообщение гаснет и удаляется.
func _update_chat() -> void:
    if chat_entries.is_empty():
        return
    var now := Time.get_ticks_msec()
    for i in range(chat_entries.size() - 1, -1, -1):
        var entry: Dictionary = chat_entries[i]
        var node := entry["node"] as Control
        if not is_instance_valid(node):
            chat_entries.remove_at(i)
            continue
        var age := float(now - int(entry["born"])) / 1000.0
        if age >= CHAT_VISIBLE_SEC:
            node.queue_free()
            chat_entries.remove_at(i)
        elif age >= CHAT_VISIBLE_SEC - CHAT_FADE_SEC:
            node.modulate.a = clampf((CHAT_VISIBLE_SEC - age) / CHAT_FADE_SEC, 0.0, 1.0)

func _create_shop_ui() -> void:
    shop_panel = BattleShop.new()
    add_child(shop_panel)
    shop_panel.closed.connect(func(): direction = Vector2.ZERO)
    shop_button = Button.new()
    shop_button.text = "МАГАЗИН"
    shop_button.custom_minimum_size = Vector2(150, 64)
    shop_button.add_theme_font_size_override("font_size", 20)
    shop_button.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
    shop_button.position += Vector2(-75, -260)
    shop_button.pressed.connect(_toggle_shop)
    shop_button.hide()
    add_child(shop_button)
    refill_button = Button.new()
    refill_button.custom_minimum_size = Vector2(300, 64)
    refill_button.add_theme_font_size_override("font_size", 20)
    refill_button.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
    refill_button.position += Vector2(-150, -340)
    refill_button.pressed.connect(_buy_turret_ammo)
    refill_button.focus_mode = Control.FOCUS_NONE
    refill_button.hide()
    add_child(refill_button)
    turret_notice_label = Label.new()
    turret_notice_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    turret_notice_label.position += Vector2(-200, 110)
    turret_notice_label.custom_minimum_size = Vector2(400, 0)
    turret_notice_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    turret_notice_label.add_theme_font_size_override("font_size", 20)
    turret_notice_label.add_theme_color_override("font_color", Color(0.6, 0.95, 1.0))
    turret_notice_label.add_theme_color_override("font_outline_color", Color.BLACK)
    turret_notice_label.add_theme_constant_override("outline_size", 6)
    turret_notice_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    turret_notice_label.hide()
    add_child(turret_notice_label)
    Net.turret_use_requested.connect(_place_turret_from_inventory)
    Net.turret_place_approved.connect(_on_turret_place_approved)
    Net.turret_notice.connect(_show_turret_notice)
    Net.turret_refill_approved.connect(_on_turret_refill_approved)

func _toggle_shop() -> void:
    if evac_active or paused or editing_controls or _my_state != Net.ST_ALIVE:
        return
    if _shop_open():
        shop_panel.close_shop()
    elif near_shop >= 0:
        inventory_panel.hide()
        direction = Vector2.ZERO
        shooting = false
        shop_panel.open_shop()

func _update_shop_prompt(delta: float) -> void:
    near_shop = TitanicMap.nearest_shop(local_pos) if _my_state == Net.ST_ALIVE and not evac_active else -1
    if _shop_open() and near_shop < 0:
        shop_panel.close_shop()
    if shop_button != null:
        shop_button.visible = near_shop >= 0 and not paused and not editing_controls and not evac_active \
                and not _shop_open() and not inventory_panel.visible
        if pc_mode:
            shop_button.text = "МАГАЗИН [E]"
    _update_refill_prompt()
    if turret_notice_left > 0.0:
        turret_notice_left -= delta
        if turret_notice_left <= 0.0 and turret_notice_label != null:
            turret_notice_label.hide()

## Турель под прицелом (перед камерой, не дальше 5.5 м) — к ней можно купить патроны.
func _find_aimed_turret() -> int:
    if camera == null:
        return -1
    var origin := camera.global_position
    var dir := -camera.global_transform.basis.z
    var best := -1
    var best_along := 5.5
    for raw_id in Net.turrets.keys():
        var center: Vector3 = (Net.turrets[raw_id]["pos"] as Vector3) + Vector3(0.0, 0.7, 0.0)
        var to := center - origin
        var along := to.dot(dir)
        if along < 0.3 or along > best_along:
            continue
        if (to - dir * along).length() <= 0.85:
            best = int(raw_id)
            best_along = along
    return best

func _update_refill_prompt() -> void:
    aimed_turret = -1
    if _my_state == Net.ST_ALIVE and not evac_active and not paused and not editing_controls and not _shop_open() \
            and (inventory_panel == null or not inventory_panel.visible):
        aimed_turret = _find_aimed_turret()
    if refill_button == null:
        return
    if aimed_turret < 0:
        refill_button.hide()
        return
    var ammo_now := int(Net.turret_ammo.get(aimed_turret, 0))
    var full := ammo_now + Net.TURRET_REFILL_AMMO > Net.TURRET_AMMO_MAX
    var price := GameState.TURRET_REFILL_PRICE
    if full:
        refill_button.text = "Турель заряжена"
    elif GameState.money < price:
        refill_button.text = "Патроны %d — %s $ (не хватает денег)" % [Net.TURRET_REFILL_AMMO, GameState.format_money(price)]
    else:
        refill_button.text = "Купить патроны %d — %s $%s" % [Net.TURRET_REFILL_AMMO, GameState.format_money(price), " [E]" if pc_mode else ""]
    refill_button.disabled = full or GameState.money < price
    refill_button.show()

func _buy_turret_ammo() -> void:
    if aimed_turret < 0 or _my_state != Net.ST_ALIVE:
        return
    if GameState.money < GameState.TURRET_REFILL_PRICE:
        _show_turret_notice("Недостаточно денег: нужно %s $" % GameState.format_money(GameState.TURRET_REFILL_PRICE))
        return
    if int(Net.turret_ammo.get(aimed_turret, 0)) + Net.TURRET_REFILL_AMMO > Net.TURRET_AMMO_MAX:
        _show_turret_notice("Турель уже заряжена")
        return
    Net.request_turret_refill(aimed_turret)

func _on_turret_refill_approved(_turret_id: int) -> void:
    if GameState.spend_money(GameState.TURRET_REFILL_PRICE):
        _show_turret_notice("Патроны добавлены: +%d (−%s $)" % [Net.TURRET_REFILL_AMMO, GameState.format_money(GameState.TURRET_REFILL_PRICE)])

func _show_turret_notice(message: String) -> void:
    if turret_notice_label == null:
        return
    turret_notice_label.text = message
    turret_notice_label.show()
    turret_notice_left = 3.0

## «Использовать» у турели в инвентаре: ставим её перед игроком, хост проверяет и одобряет.
func _place_turret_from_inventory() -> void:
    if evac_active or _my_state != Net.ST_ALIVE:
        return
    if GameState.count_battle_item("turret") <= 0:
        return
    var forward := Vector3(-sin(yaw), 0.0, -cos(yaw))
    var spot := local_pos + forward * 2.2
    inventory_panel.hide()
    if not Net.request_turret_place(Vector3(spot.x, TitanicMap.GROUND_Y, spot.z), yaw + PI):
        _show_turret_notice("Турель можно поставить только в режиме «Волны зомби»")

func _on_turret_place_approved() -> void:
    if GameState.consume_battle_item("turret"):
        _show_turret_notice("Турель установлена")

func _update_turrets(delta: float) -> void:
    var world := $WorldView/Viewport/World as Node3D
    turret_sound_budget = 2
    for raw_id in Net.turrets.keys():
        var tid := int(raw_id)
        if not turret_nodes.has(tid):
            var created: Node3D = TurretModel.new()
            world.add_child(created)
            created.position = Net.turrets[tid]["pos"]
            turret_nodes[tid] = created
            turret_prev_age[tid] = 9.0
            var ammo_label := Label3D.new()
            ammo_label.name = "AmmoLabel"
            ammo_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
            ammo_label.position = Vector3(0.0, 1.95, 0.0)
            ammo_label.pixel_size = 0.006
            ammo_label.font_size = 48
            ammo_label.outline_size = 10
            ammo_label.no_depth_test = false
            created.add_child(ammo_label)
            created.set_meta("ammo_shown", -1)
        var node := turret_nodes[tid] as Node3D
        var aim: Vector4 = Net.turret_aims.get(tid, Vector4(0.0, 0.0, 9.0, -1.0))
        var shot: bool = aim.z + 0.001 < float(turret_prev_age[tid])
        turret_prev_age[tid] = aim.z
        (node as Object).call("aim", aim.x, aim.y, delta, aim.z < 0.6)
        var ammo_now := int(Net.turret_ammo.get(tid, Net.TURRET_AMMO))
        var hp_now := int(Net.turret_hp.get(tid, Net.TURRET_HP))
        var shown_key := ammo_now * 1000 + hp_now
        if int(node.get_meta("ammo_shown", -1)) != shown_key:
            node.set_meta("ammo_shown", shown_key)
            var label := node.get_node_or_null("AmmoLabel") as Label3D
            if label != null:
                var ammo_text := "%d/%d" % [ammo_now, Net.TURRET_AMMO_MAX] if ammo_now > 0 else "ПУСТО"
                label.text = "%s\nHP %d/%d" % [ammo_text, maxi(hp_now, 0), Net.TURRET_HP]
                label.modulate = Color(0.6, 0.95, 1.0) if ammo_now > 10 else (Color(1.0, 0.75, 0.2) if ammo_now > 0 else Color(1.0, 0.3, 0.25))
                if hp_now <= 15:
                    label.modulate = Color(1.0, 0.3, 0.25)
            (node as Object).call("set_active", ammo_now > 0)
        if shot:
            (node as Object).call("flash")
            var muzzle: Vector3 = (node as Object).call("muzzle_global")
            var target_id := int(aim.w)
            var turret_dist := muzzle.distance_to(camera.global_position)
            if Net.zombie_positions.has(target_id) and turret_dist < 55.0:
                _turret_tracer(muzzle, (Net.zombie_positions[target_id] as Vector3) + Vector3(0.0, 1.15, 0.0))
            if turret_dist < 40.0 and turret_sound_budget > 0:
                turret_sound_budget -= 1
                _play_world_sound("res://assets/audio/m4a1_fire.wav", muzzle, -6.0)
    for raw_id in turret_nodes.keys():
        if not Net.turrets.has(raw_id):
            (turret_nodes[raw_id] as Node).queue_free()
            turret_nodes.erase(raw_id)
            turret_prev_age.erase(raw_id)

func _turret_tracer(origin: Vector3, target: Vector3) -> void:
    if viewport == null or origin.distance_to(target) < 0.05:
        return
    var mesh := CylinderMesh.new()
    mesh.top_radius = 0.02
    mesh.bottom_radius = 0.02
    mesh.height = origin.distance_to(target)
    if _turret_tracer_material == null:
        _turret_tracer_material = StandardMaterial3D.new()
        _turret_tracer_material.albedo_color = Color(0.45, 0.9, 1.0)
        _turret_tracer_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mesh.radial_segments = 6
    mesh.rings = 1
    mesh.material = _turret_tracer_material
    var tracer := MeshInstance3D.new()
    tracer.mesh = mesh
    viewport.get_child(0).add_child(tracer)
    tracer.position = (origin + target) * 0.5
    tracer.look_at(target, Vector3.UP)
    tracer.rotate_object_local(Vector3.RIGHT, PI * 0.5)
    get_tree().create_timer(0.07).timeout.connect(func():
        if is_instance_valid(tracer):
            tracer.queue_free()
    )

## Stage85: шаги по пройденному пути, периодическое рычание и укус в момент удара.
func _update_zombie_sounds(zid: int, visual: Node3D, meta: Vector4, spawn_age: float, delta: float) -> void:
    var prev_attack: float = float(zombie_prev_attack.get(zid, -1.0))
    zombie_prev_attack[zid] = meta.z
    if meta.w >= 0.0 or evac_active:
        return   # мёртвые и замершие при эвакуации зомби молчат
    var pos := visual.global_position
    if pos.distance_to(camera.global_position) > ZOMBIE_SOUND_RANGE:
        return
    var kind := clampi(int(meta.x), 0, 2)
    var scale_k := float(ZombieModel.KIND_SCALE[kind])
    var base_pitch := pow(1.2 / scale_k, 0.7)
    # Укус: замах 0.35 с, дальше — момент попадания.
    if prev_attack < 0.35 and meta.z >= 0.35:
        _zombie_sound("res://assets/audio/zombie_bite_%d.wav" % (1 + shot_rng.randi() % 2), pos + Vector3(0, 1.3, 0), 4.0 + ZOMBIE_VOLUME_DB, base_pitch * shot_rng.randf_range(0.94, 1.06))
    # Шаги: один шаг на каждый «шаг» пройденного пути, только когда зомби вылез из люка.
    var speed := float(zombie_speeds.get(zid, 0.0))
    if speed > 0.6 and spawn_age > 1.4 and meta.z < 0.0:
        var walked: float = float(zombie_step_dist.get(zid, 0.0)) + speed * delta
        if walked >= float(ZOMBIE_STRIDE[kind]):
            walked = 0.0
            _zombie_sound("res://assets/audio/zombie_step_%d.wav" % (1 + shot_rng.randi() % 2), pos, -4.0 + ZOMBIE_VOLUME_DB + (3.0 if kind == 2 else 0.0), base_pitch * shot_rng.randf_range(0.92, 1.08))
        zombie_step_dist[zid] = walked
    # Рычание: у каждого свой случайный таймер; здоровяк рычит низко и чаще.
    var timer: float = float(zombie_growl_in.get(zid, shot_rng.randf_range(0.4, 5.0))) - delta
    if timer <= 0.0:
        var variant := 3 if kind == 2 else (2 if kind == 1 else 1 + shot_rng.randi() % 2)
        _zombie_sound("res://assets/audio/zombie_growl_%d.wav" % variant, pos + Vector3(0, 1.6, 0), 2.0 + ZOMBIE_VOLUME_DB, base_pitch * shot_rng.randf_range(0.93, 1.07))
        timer = shot_rng.randf_range(6.0, 13.0) * (0.7 if kind == 2 else 1.0)
    zombie_growl_in[zid] = timer

func _zombie_sound(path: String, pos: Vector3, volume_db: float, pitch: float) -> void:
    if viewport == null or zombie_sound_budget <= 0 or not ResourceLoader.exists(path):
        return
    zombie_sound_budget -= 1
    var player := AudioStreamPlayer3D.new()
    player.stream = load(path)
    player.volume_db = volume_db
    player.pitch_scale = pitch
    player.max_distance = 32.0
    player.unit_size = 4.0
    viewport.get_child(0).add_child(player)
    player.global_position = pos
    player.finished.connect(player.queue_free)
    player.play()

## Stage86: реальный уровень графики (1 низкая … 3 высокая). «Авто» выбирает по устройству.
func _gfx_level() -> int:
    if gfx_quality > 0:
        return gfx_quality
    if not OS.has_feature("mobile"):
        return 3
    var short_side := mini(DisplayServer.window_get_size().x, DisplayServer.window_get_size().y)
    return 1 if short_side >= 1200 else 2

## Применяет качество графики к миру боя:
##  - низкая: 3D рисуется в половинном разрешении, без тумана и шейдера неба;
##  - средняя: полное разрешение, туман, без шейдера неба;
##  - высокая: всё включено.
func _apply_graphics_quality() -> void:
    if viewport == null:
        return
    var level := _gfx_level()
    SwordFire.quality = level
    GraphicsFX.set_level(level)
    var container := $WorldView as SubViewportContainer
    container.stretch_shrink = 2 if level == 1 else 1
    # Атлас для точечных теней не нужен (тени только от солнца/луны).
    viewport.positional_shadow_atlas_size = 0
    viewport.msaa_3d = Viewport.MSAA_DISABLED
    viewport.use_debanding = false
    viewport.use_occlusion_culling = false
    if OS.has_feature("mobile"):
        Engine.max_fps = 60
    if zombie_map != null:
        var night := zombie_map.get_node_or_null("NightEnvironment") as WorldEnvironment
        if night != null and night.environment != null:
            var env := night.environment
            if level >= 3:
                env.background_mode = Environment.BG_SKY
            else:
                # Процедурное небо — полноэкранный шейдер каждый кадр; на телефоне заменяем ровным цветом.
                env.background_mode = Environment.BG_COLOR
                env.background_color = Color(0.035, 0.055, 0.11)
            env.fog_enabled = level >= 2
    _apply_graphics_fx(level)

## Stage129: подключает тени/солнце/погоду (graphics_fx.gd) к текущему уровню графики.
func _apply_graphics_fx(level: int) -> void:
    var world := $WorldView/Viewport/World as Node3D
    if world == null or camera == null:
        return
    if gfx_fx == null:
        gfx_fx = GraphicsFX.new()
        world.add_child(gfx_fx)
        var night: WorldEnvironment = null
        if zombie_map != null:
            night = zombie_map.get_node_or_null("NightEnvironment") as WorldEnvironment
        gfx_fx.setup(world, viewport, camera, night, Net.game_mode != Net.MODE_ZOMBIES)
        # Тело своего игрока для тени лежит на слое 2: камера его не рисует.
        camera.set_cull_mask_value(GraphicsFX.SHADOW_PROXY_LAYER, false)
    gfx_fx.apply(level, weather_mode)
    _refresh_weather_button()
    if combat_fx == null:
        combat_fx = CombatFX.new()
        combat_fx.name = "CombatFX"
        world.add_child(combat_fx)
    combat_fx.level = level
    combat_fx.blood_enabled = blood_enabled
    _refresh_blood_button()

func _refresh_blood_button() -> void:
    if blood_button == null:
        return
    if _gfx_level() < 3:
        blood_button.text = "Кровь: нужна высокая графика"
    else:
        blood_button.text = "Кровь: " + ("Вкл" if blood_enabled else "Выкл")

func _combat_fx() -> CombatFX:
    return combat_fx if is_instance_valid(combat_fx) else null

## Попадание пули: кровь и реакция на теле, иначе пыль и искры на поверхности.
func _impact_fx(origin: Vector3, target: Vector3, shooter: int) -> void:
    var fx := _combat_fx()
    if fx == null or fx_budget <= 0:
        return
    var ray := target - origin
    if ray.length() < 0.05:
        return
    var dir := ray.normalized()
    for pid in actors.keys():
        if int(pid) == shooter:
            continue
        var life := Net.peer_state(int(pid))
        if life != Net.ST_ALIVE and life != Net.ST_DOWNED:
            continue
        var actor := actors[pid] as Node3D
        if actor == null or not actor.visible:
            continue
        var feet := actor.global_position
        if Vector2(target.x - feet.x, target.z - feet.z).length() < 0.6 and target.y > feet.y - 0.15 and target.y < feet.y + 2.0:
            if int(pid) == Net.my_id():
                return
            fx_budget -= 1
            fx.blood_hit(target, dir, feet.y, false)
            actor.call("hit_react")
            return
    for raw_id in zombie_visuals.keys():
        var z := zombie_visuals[raw_id] as Node3D
        if z == null or not z.visible:
            continue
        var zmeta: Vector4 = Net.zombie_meta.get(int(raw_id), Vector4(0, 0, -1, -1))
        if zmeta.w >= 0.0:
            continue
        var sk := z.scale.x
        var zf := z.global_position
        if Vector2(target.x - zf.x, target.z - zf.z).length() < 0.5 * sk and target.y > zf.y - 0.15 and target.y < zf.y + 1.6 * sk + 0.2:
            fx_budget -= 1
            zombie_hit_dir[int(raw_id)] = dir
            fx.blood_hit(target, dir, zf.y, false)
            z.call("hit_flinch")
            return
    fx_budget -= 1
    fx.impact(target, dir)

## Красная виньетка при уроне (средняя и высокая графика) и пульсация при низком HP (высокая);
## убийства игроков — брызги крови.
func _update_combat_feedback(delta: float) -> void:
    fx_budget = 6
    _update_pause_fallback()
    _update_kill_fx()
    var lvl := _gfx_level()
    var my := Net.my_id()
    var hp := int(Net.battle_health.get(my, 100))
    if hp < _last_my_hp and hp >= 0:
        damage_flash = clampf(damage_flash + float(_last_my_hp - hp) / 35.0 + 0.25, 0.0, 1.0)
    _last_my_hp = hp
    damage_flash = move_toward(damage_flash, 0.0, delta * 1.6)
    var low := 0.0
    if lvl >= 3 and hp > 0 and hp < 35 and Net.peer_state(my) == Net.ST_ALIVE:
        low = (0.30 + 0.12 * sin(float(Time.get_ticks_msec()) * 0.006)) * (1.3 - float(hp) / 35.0)
    var a := 0.0 if lvl < 2 else maxf(damage_flash * 0.8, low)
    if a <= 0.01:
        if damage_overlay != null:
            damage_overlay.visible = false
        return
    if damage_overlay == null:
        var grad := Gradient.new()
        grad.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
        grad.colors = PackedColorArray([Color(0.6, 0, 0, 0), Color(0.6, 0, 0, 0), Color(0.7, 0, 0, 0.95)])
        var tex := GradientTexture2D.new()
        tex.gradient = grad
        tex.fill = GradientTexture2D.FILL_RADIAL
        tex.fill_from = Vector2(0.5, 0.5)
        tex.fill_to = Vector2(1.0, 0.5)
        tex.width = 256
        tex.height = 256
        damage_overlay = TextureRect.new()
        damage_overlay.texture = tex
        damage_overlay.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        damage_overlay.stretch_mode = TextureRect.STRETCH_SCALE
        damage_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
        damage_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
        add_child(damage_overlay)
        move_child(damage_overlay, $WorldView.get_index() + 1)
    damage_overlay.visible = true
    damage_overlay.modulate.a = clampf(a, 0.0, 1.0)

## Запасная кнопка паузы наверху экрана: рисуется на отдельном CanvasLayer поверх всего HUD,
## поэтому её нельзя потерять из-за сохранённой раскладки, масштаба или выреза экрана.
func _original_pause_ok() -> bool:
    var pb := controls.get("pause") as Control
    if pb == null or not is_instance_valid(pb) or not pb.is_visible_in_tree():
        return false
    var shown := pb.size * pb.scale
    if pb.scale.x < 0.5 or shown.x < 20.0 or shown.y < 20.0:
        return false
    var screen := get_viewport_rect().size
    var safe := _safe_area_min_in_viewport()
    var seen := Rect2(safe, screen - safe).intersection(Rect2(pb.global_position, shown))
    return seen.size.x >= shown.x * 0.9 and seen.size.y >= shown.y * 0.9

func _update_pause_fallback() -> void:
    if pause_fallback_mode == 0:
        if pause_fallback != null:
            pause_fallback.visible = false
        return
    if pause_fallback == null:
        pause_fallback_layer = CanvasLayer.new()
        pause_fallback_layer.name = "PauseFallbackLayer"
        pause_fallback_layer.layer = 60
        add_child(pause_fallback_layer)
        pause_fallback = Button.new()
        pause_fallback.name = "PauseFallback"
        pause_fallback.icon = load("res://assets/hud/pause.png")
        pause_fallback.expand_icon = true
        pause_fallback.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
        pause_fallback.focus_mode = Control.FOCUS_NONE
        for state in ["normal", "hover", "pressed", "focus", "disabled"]:
            pause_fallback.add_theme_stylebox_override(state, StyleBoxEmpty.new())
        pause_fallback.custom_minimum_size = Vector2(64, 64)
        pause_fallback.size = Vector2(64, 64)
        pause_fallback.pressed.connect(func(): _toggle_pause())
        pause_fallback_layer.add_child(pause_fallback)
    var screen := get_viewport_rect().size
    var safe := _safe_area_min_in_viewport()
    pause_fallback.position = Vector2(clampf(safe.x + 430.0, 4.0, maxf(4.0, screen.x - 70.0)), 8.0 + safe.y)
    var show_it := not paused and not editing_controls and not pc_mode and not leaving_battle and not screenshot_hud_hidden
    show_it = show_it and not chat_open and not (evac_active and evac != null and evac.cam_active)
    show_it = show_it and (inventory_panel == null or not inventory_panel.visible)
    show_it = show_it and (settings_panel == null or not settings_panel.visible)
    show_it = show_it and (pause_panel == null or not pause_panel.visible)
    if pause_fallback_mode == 1 and _original_pause_ok():
        show_it = false
    pause_fallback.visible = show_it

## Смерть/нокаут игрока: фонтан крови там, где он упал.
func _update_kill_fx() -> void:
    var fx := _combat_fx()
    for pid in actors.keys():
        var life := Net.peer_state(int(pid))
        var prev: int = int(_peer_life_seen.get(pid, life))
        _peer_life_seen[pid] = life
        if prev == life or fx == null or not fx.blood_on():
            continue
        if Net.battle_evacuated.has(pid):
            continue
        var actor := actors[pid] as Node3D
        if actor == null or actor.global_position.distance_to(camera.global_position) > 70.0:
            continue
        var feet := actor.global_position
        if life == Net.ST_DEAD and prev != Net.ST_LEFT:
            fx.blood_death(feet + Vector3(0, 1.0, 0), -actor.global_transform.basis.z, feet.y, false)
        elif life == Net.ST_DOWNED and prev == Net.ST_ALIVE:
            fx.blood_hit(feet + Vector3(0, 1.2, 0), -actor.global_transform.basis.z, feet.y, true)

func _refresh_weather_button() -> void:
    if weather_button == null:
        return
    if _gfx_level() < 2:
        weather_button.text = "Погода: нужна ср./выс. графика"
    else:
        weather_button.text = "Погода: " + GraphicsFX.WEATHER_NAMES[weather_mode]

## Stage83: счётчик дошёл до 00:00 — прилетает вертолёт и забирает игроков.
func _start_evac() -> void:
    evac_active = true
    var world := $WorldView/Viewport/World as Node3D
    # Закрываем окна и отпускаем кнопки, чтобы ничего не мешало сцене.
    _set_aim(false)
    if shop_panel != null:
        shop_panel.hide()
    if shop_button != null:
        shop_button.hide()
    if refill_button != null:
        refill_button.hide()
    shooting = false
    direction = Vector2.ZERO
    vel_h = Vector3.ZERO
    if paused:
        _toggle_pause()
    if inventory_panel != null:
        inventory_panel.hide()
    if pause_panel != null:
        pause_panel.hide()
    if settings_panel != null:
        settings_panel.hide()
    # Stage87: сцена личная — в вертолёт садится только тот, кто коснулся точки появления.
    evac_played = true
    var my_id := Net.my_id()
    # Деньги за волну (10 000 x номер волны) и сохранение снаряжения.
    GameState.evacuate_zombie_battle(Net.WAVE_BONUS * int(Net.battle_evacuated.get(my_id, 1)))
    var boarding: Array = []
    var tags: Array = []
    if actors.has(my_id):
        boarding.append(actors[my_id])
        tags.append(actor_tags.get(my_id))
    evac = EvacCutscene.new()
    evac.name = "EvacCutscene"
    world.add_child(evac)
    evac.setup(camera, boarding, tags)
    # Метка «ТОЧКА ПОЯВЛЕНИЯ» висит ровно там, где сядет вертолёт.
    if zombie_map != null:
        var spawn_label := zombie_map.get_node_or_null("SpawnLabel")
        if spawn_label is Node3D:
            (spawn_label as Node3D).visible = false
    # Оружие от первого лица (дочерние узлы камеры) в кадре не нужно.
    for child in camera.get_children():
        if child is Node3D:
            (child as Node3D).visible = false
    _evac_build_overlay()
    _evac_hide_hud()

func _evac_build_overlay() -> void:
    evac_fade = ColorRect.new()
    evac_fade.color = Color(0, 0, 0, 0)
    evac_fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    evac_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    evac_fade.z_index = 60
    add_child(evac_fade)
    evac_bar_top = ColorRect.new()
    evac_bar_top.color = Color.BLACK
    evac_bar_top.anchor_left = 0.0
    evac_bar_top.anchor_right = 1.0
    evac_bar_top.anchor_top = 0.0
    evac_bar_top.anchor_bottom = 0.0
    evac_bar_top.offset_left = 0.0
    evac_bar_top.offset_right = 0.0
    evac_bar_top.offset_top = 0.0
    evac_bar_top.offset_bottom = 0.0
    evac_bar_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    evac_bar_top.z_index = 61
    add_child(evac_bar_top)
    evac_bar_bottom = ColorRect.new()
    evac_bar_bottom.color = Color.BLACK
    evac_bar_bottom.anchor_left = 0.0
    evac_bar_bottom.anchor_right = 1.0
    evac_bar_bottom.anchor_top = 1.0
    evac_bar_bottom.anchor_bottom = 1.0
    evac_bar_bottom.offset_left = 0.0
    evac_bar_bottom.offset_right = 0.0
    evac_bar_bottom.offset_top = 0.0
    evac_bar_bottom.offset_bottom = 0.0
    evac_bar_bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
    evac_bar_bottom.z_index = 61
    add_child(evac_bar_bottom)
    evac_caption = Label.new()
    evac_caption.text = "ЭВАКУАЦИЯ"
    evac_caption.set_anchors_preset(Control.PRESET_CENTER_TOP)
    evac_caption.position = Vector2(-120, 60)
    evac_caption.add_theme_font_size_override("font_size", 34)
    evac_caption.add_theme_color_override("font_color", Color(0.55, 0.9, 1.0))
    evac_caption.add_theme_color_override("font_outline_color", Color.BLACK)
    evac_caption.add_theme_constant_override("outline_size", 8)
    evac_caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
    evac_caption.modulate.a = 0.0
    evac_caption.z_index = 62
    add_child(evac_caption)

## Сцена закончилась: игрок остаётся наблюдателем (может следить за остальными и выйти в лобби).
func _end_evac() -> void:
    evac_active = false
    if evac != null and is_instance_valid(evac):
        evac.queue_free()
    evac = null
    for node in [evac_fade, evac_bar_top, evac_bar_bottom, evac_caption]:
        if node != null and is_instance_valid(node):
            (node as Node).queue_free()
    evac_fade = null
    evac_bar_top = null
    evac_bar_bottom = null
    evac_caption = null
    if zombie_map != null:
        var spawn_label := zombie_map.get_node_or_null("SpawnLabel")
        if spawn_label is Node3D:
            (spawn_label as Node3D).visible = true
    for hud_name in ["HUD/Crosshair", "HUD/HealthRow"]:
        var node := get_node_or_null(hud_name) as Control
        if node != null:
            node.visible = true
    for hud_item in [status, stance_label, zombie_timer_label]:
        if hud_item != null:
            (hud_item as Control).visible = true
    for tag in actor_tags.values():
        if is_instance_valid(tag):
            (tag as Node3D).visible = true

func _on_zombie_phase_changed(phase: int, wave: int) -> void:
    if phase == Net.PHASE_FIGHT and wave >= 2 and wave_banner != null:
        wave_banner.text = "Началась %d волна" % wave
        wave_banner_left = 4.0

func _evac_hide_hud() -> void:
    for key in controls:
        (controls[key] as Control).visible = false
    for hud_name in ["HUD/Crosshair", "HUD/HealthRow"]:
        var node := get_node_or_null(hud_name) as Control
        if node != null:
            node.visible = false
    for hud_item in [status, ammo_bar, stance_label, hit_marker, zombie_timer_label]:
        if hud_item != null:
            (hud_item as Control).visible = false

func _update_evac(delta: float) -> void:
    if evac == null:
        return
    evac.step(delta)
    if evac.done:
        _end_evac()
        return
    var view := get_viewport_rect().size
    var bar := view.y * 0.11 * evac.letterbox
    if evac_fade != null:
        evac_fade.color.a = evac.fade
    if evac_bar_top != null:
        evac_bar_top.offset_bottom = bar
        evac_bar_bottom.offset_top = -bar
    if evac_caption != null:
        evac_caption.modulate.a = clampf(evac.t - 1.6, 0.0, 1.0) * (1.0 - clampf(evac.t - 5.0, 0.0, 1.0))
    # Подпись над игроками и интерфейс не возвращаются, пока идёт сцена.
    for tag in actor_tags.values():
        if is_instance_valid(tag) and evac.cam_active:
            (tag as Node3D).visible = false
    if status != null:
        status.visible = false
    if stance_label != null:
        stance_label.visible = false
    if pickup_button != null:
        pickup_button.visible = false
    if shop_button != null:
        shop_button.visible = false
    if refill_button != null:
        refill_button.visible = false

func _setup_zombie_world(world: Node3D) -> void:
    # Stage80: карта «Титаник» строится кодом (scripts/titanic_map.gd).
    # Небо рисуется самим миром, поэтому прозрачный фон SubViewport отключаем.
    viewport.transparent_bg = false
    for hidden_name in ["Floor", "GroundCollision"]:
        var old_node := world.get_node_or_null(hidden_name)
        if old_node is Node3D:
            (old_node as Node3D).visible = false
    zombie_map = TitanicMap.build(world)
    _apply_graphics_quality()

func _setup_zombie_timer() -> void:
    zombie_timer_label = Label.new()
    zombie_timer_label.name = "ZombieTimer"
    zombie_timer_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
    zombie_timer_label.position = Vector2(-150, 20)
    zombie_timer_label.add_theme_font_size_override("font_size", 32)
    zombie_timer_label.add_theme_color_override("font_color", Color.WHITE)
    zombie_timer_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(zombie_timer_label)
    # Stage87: подсказка про вертолёт (под таймером) и баннер новой волны.
    wave_notice = Label.new()
    wave_notice.name = "WaveNotice"
    wave_notice.set_anchors_preset(Control.PRESET_CENTER_TOP)
    wave_notice.grow_horizontal = Control.GROW_DIRECTION_BOTH
    wave_notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    wave_notice.position = Vector2(0, 66)
    wave_notice.add_theme_font_size_override("font_size", 24)
    wave_notice.add_theme_color_override("font_color", Color(0.55, 0.9, 1.0))
    wave_notice.add_theme_color_override("font_outline_color", Color.BLACK)
    wave_notice.add_theme_constant_override("outline_size", 7)
    wave_notice.mouse_filter = Control.MOUSE_FILTER_IGNORE
    wave_notice.visible = false
    add_child(wave_notice)
    wave_banner = Label.new()
    wave_banner.name = "WaveBanner"
    wave_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
    wave_banner.grow_horizontal = Control.GROW_DIRECTION_BOTH
    wave_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    wave_banner.position = Vector2(0, 120)
    wave_banner.add_theme_font_size_override("font_size", 46)
    wave_banner.add_theme_color_override("font_color", Color(1.0, 0.35, 0.25))
    wave_banner.add_theme_color_override("font_outline_color", Color.BLACK)
    wave_banner.add_theme_constant_override("outline_size", 10)
    wave_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    wave_banner.visible = false
    add_child(wave_banner)

## Подсказки сверху: что делать, когда время волны вышло.
func _update_wave_notices(delta: float) -> void:
    if wave_notice != null:
        var my_id := Net.my_id()
        var text := ""
        var fighting := Net.peer_state(my_id) == Net.ST_ALIVE or Net.peer_state(my_id) == Net.ST_DOWNED
        if fighting and not Net.is_evacuated(my_id):
            if Net.zombie_phase == Net.PHASE_GO or Net.zombie_phase == Net.PHASE_HELI:
                text = "Дойдите до точки появления — туда прилетит вертолёт"
        wave_notice.text = text
        wave_notice.visible = text != "" and not evac_active
    if wave_banner != null:
        wave_banner_left = maxf(0.0, wave_banner_left - delta)
        wave_banner.visible = wave_banner_left > 0.0 and not evac_active
        wave_banner.modulate.a = clampf(wave_banner_left / 1.0, 0.0, 1.0)

func _update_zombie_display() -> void:
    if zombie_timer_label != null:
        var heli := Net.zombie_phase == Net.PHASE_HELI
        var seconds := maxi(0, ceili(Net.zombie_heli_left if heli else Net.zombie_time_left))
        var title := "Вертолёт" if heli else "Волна %d" % Net.zombie_wave_no
        zombie_timer_label.text = "%s  %02d:%02d   Убито: %d" % [title, seconds / 60, seconds % 60, Net.zombie_kills]
    _update_wave_notices(get_process_delta_time())
    var world := $WorldView/Viewport/World as Node3D
    var delta := get_process_delta_time()
    var now := Time.get_ticks_msec() / 1000.0
    zombie_sound_budget = 6
    for raw_id in Net.zombie_positions.keys():
        var zid := int(raw_id)
        var meta: Vector4 = Net.zombie_meta.get(zid, Vector4(0, 0, -1, -1))
        if not zombie_visuals.has(zid):
            var enemy: Node3D = ZombieModel.new()
            enemy.name = "Zombie_%d" % zid
            world.add_child(enemy)
            enemy.setup(int(meta.x), zid)
            enemy.position = Net.zombie_positions[zid]
            zombie_visuals[zid] = enemy
            zombie_seen_at[zid] = now
            TitanicMap.open_vent(zombie_map, enemy.position)   # Stage103: решётка люка откидывается
            zombie_last_pos[zid] = enemy.position
            zombie_speeds[zid] = 0.0
        var visual := zombie_visuals[zid] as Node3D
        var target: Vector3 = Net.zombie_positions[zid]
        # Сглаживаем позицию между сетевыми снимками.
        var before := visual.position
        visual.position = before.lerp(target, minf(1.0, delta * 14.0))
        visual.rotation.y = lerp_angle(visual.rotation.y, meta.y, minf(1.0, delta * 10.0))
        var flat := Vector3(visual.position.x - before.x, 0.0, visual.position.z - before.z)
        var measured := flat.length() / maxf(delta, 0.0001)
        zombie_speeds[zid] = lerpf(float(zombie_speeds[zid]), minf(measured, 6.0), minf(1.0, delta * 8.0))
        var spawn_age := now - float(zombie_seen_at[zid])
        # Далёкие зомби анимируются реже, очень далёкие скрыты — меньше работы для процессора телефона.
        var dist_cam := visual.position.distance_to(camera.global_position)
        var far_cut := ZOMBIE_CULL_DISTANCE if _gfx_level() < 3 else ZOMBIE_CULL_DISTANCE * 1.4
        visual.visible = dist_cam < far_cut
        if meta.w >= 0.0 and not zombie_gore_done.has(zid):
            zombie_gore_done[zid] = true
            var gore := _combat_fx()
            if gore != null and meta.w < 1.0 and dist_cam < 50.0:
                var hit_dir: Vector3 = zombie_hit_dir.get(zid, -visual.global_transform.basis.z + Vector3(0, 0.2, 0))
                gore.blood_death(visual.global_position + Vector3(0, 1.0 * visual.scale.x, 0), hit_dir, visual.global_position.y, int(meta.x) == 2)
        var acc := float(zombie_anim_acc.get(zid, 0.0)) + delta
        var interval := 0.0 if dist_cam < 24.0 else (0.05 if dist_cam < 45.0 else 0.1)
        if _gfx_level() >= 3:
            interval = 0.0 if dist_cam < 45.0 else 0.05
        if visual.visible and acc >= interval:
            (visual as Object).call("update_anim", minf(acc, 0.25), float(zombie_speeds[zid]), meta.z, spawn_age, meta.w)
            acc = 0.0
        elif not visual.visible:
            acc = 0.0
        zombie_anim_acc[zid] = acc
        _update_zombie_sounds(zid, visual, meta, spawn_age, delta)
    for raw_id in zombie_visuals.keys():
        if not Net.zombie_positions.has(raw_id):
            (zombie_visuals[raw_id] as Node).queue_free()
            zombie_visuals.erase(raw_id)
            zombie_seen_at.erase(raw_id)
            zombie_last_pos.erase(raw_id)
            zombie_speeds.erase(raw_id)
            zombie_step_dist.erase(raw_id)
            zombie_growl_in.erase(raw_id)
            zombie_prev_attack.erase(raw_id)
            zombie_anim_acc.erase(raw_id)
            zombie_gore_done.erase(raw_id)
            zombie_hit_dir.erase(raw_id)

# Stage101: low-cost, shader-free flame meshes. All visuals are client-side;
# damage and kill ownership remain authoritative on the host.
func _creator_fire_material(color: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = color
    mat.emission_enabled = true
    mat.emission = Color(1.0, 0.27, 0.015)
    mat.emission_energy_multiplier = 2.0
    mat.no_depth_test = false
    return mat

func _creator_flame_piece(parent: Node3D, origin: Vector3, direction: Vector3, lifetime: float, width: float) -> void:
    var flame := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = width
    mesh.height = width * 2.8
    mesh.radial_segments = 6
    mesh.rings = 3
    flame.mesh = mesh
    flame.material_override = _creator_fire_material(Color(1.0, randf_range(0.28, 0.75), 0.015, 0.9))
    flame.position = origin
    parent.add_child(flame)
    var tw := create_tween()
    tw.set_parallel(true)
    tw.tween_property(flame, "position", origin + direction, lifetime)
    tw.tween_property(flame, "scale", Vector3(0.05, 0.12, 0.05), lifetime)
    tw.tween_property(flame, "transparency", 1.0, lifetime)
    tw.set_parallel(false)
    tw.tween_callback(flame.queue_free)

func _creator_sword_swing_fire() -> void:
    if not is_instance_valid(held_weapon_model):
        return
    # Stage102: огненный шлейф от клинка (частицы), а не россыпь отдельных мешей.
    var fire := held_weapon_model.find_child("SwordFire", true, false)
    if fire is SwordFire:
        (fire as SwordFire).swing_burst()

func _on_creator_sword_zombie_burn(_zid: int, position: Vector3) -> void:
    if viewport == null:
        return
    var world := $WorldView/Viewport/World as Node3D
    if not is_instance_valid(world):
        return
    SwordFire.spawn_burst(world, position + Vector3(0, 0.6, 0))
func _open_survival_save_dialog() -> void:
    var dialog := ConfirmationDialog.new()
    dialog.title = "Сохранить выживание"
    dialog.ok_button_text = "Сохранить"
    add_child(dialog)
    var edit := LineEdit.new()
    edit.placeholder_text = "Название сохранения"
    edit.custom_minimum_size = Vector2(330, 55)
    edit.text = SurvivalSaves.active_slot
    dialog.add_child(edit)
    dialog.confirmed.connect(func():
        if not edit.text.strip_edges().is_empty() and Net.role != "client":
            Net.survival_collect_save(edit.text, local_pos, int(Net.battle_health.get(Net.my_id(), 100)), yaw, pitch)
        if not SurvivalSaves.active_slot.is_empty():
            print("Выживание сохранено: ", SurvivalSaves.active_slot)
        else:
            push_warning("Не удалось сохранить выживание")
    )
    dialog.popup_centered()
