extends Node3D
## Stage80: низкополигональная модель зомби с процедурными анимациями.
## Собирается кодом из примитивов (model_kit.gd), без внешних ассетов.
## Лицом смотрит в +Z при rotation.y = 0 (как модель игрока). Начало координат — под ногами.
##
## Виды (kind): 0 — ходок, 1 — бегун (быстрый, худой), 2 — громила (крупный, медленный).
## API:
##   setup(kind, seed_value)                       — построить модель;
##   update_anim(delta, speed, attack_age, spawn_age, death_age) — вызывать каждый кадр:
##       speed       — скорость движения, м/с (ходьба/бег/стойка определяются сами);
##       attack_age  — секунды с начала удара (< 0 — не бьёт), удар длится ATTACK_TIME;
##       spawn_age   — секунды с появления (< RISE_TIME — вылезает из люка);
##       death_age   — секунды с момента смерти (< 0 — жив): падение назад, затем труп погружается.
## Анимации: вылезание из люка, стойка (покачивание), шаркающая ходьба, бег, удар
## (замах — рывок — возврат). Переходы между состояниями сглаживаются.

const Kit = preload("res://scripts/model_kit.gd")

const KIND_WALKER := 0
const KIND_RUNNER := 1
const KIND_BRUTE := 2
const RISE_TIME := 1.4
const ATTACK_TIME := 0.8
const HIP_Y := 0.95
const KIND_SCALE := [1.2, 1.14, 1.55]   # общий размер модели по видам (рост игрока ~1.8 м)
const DEATH_TIME := 0.7
const SINK_START := 2.6

var kind := KIND_WALKER
var _phase := 0.0
var _phase_offset := 0.0
var _t := 0.0
var _flinch := 0.0               # 1 -> 0: отшатывание от попадания
var _flinch_side := 1.0
var _death_side := 1.0           # на какой бок падает труп
var _twitch_seed := 0.0

var _rig: Node3D
var _hips: Node3D
var _spine: Node3D
var _head: Node3D
var _arm_l: Node3D
var _arm_r: Node3D
var _leg_l: Node3D
var _leg_r: Node3D
var _knee_l: Node3D
var _knee_r: Node3D


func setup(zombie_kind: int, seed_value: int) -> void:
    kind = zombie_kind
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value * 7919 + 13
    _phase_offset = rng.randf() * TAU
    _phase = _phase_offset
    _death_side = 1.0 if rng.randf() < 0.5 else -1.0
    _twitch_seed = rng.randf() * 10.0

    var width := 1.0
    var skin := Color(0.50, 0.60, 0.46).lerp(Color(0.62, 0.66, 0.52), rng.randf())
    match kind:
        KIND_RUNNER:
            width = 0.86
            skin = Color(0.66, 0.62, 0.50).lerp(Color(0.72, 0.58, 0.48), rng.randf())
        KIND_BRUTE:
            width = 1.35
            skin = Color(0.38, 0.46, 0.36)
    scale = Vector3.ONE * float(KIND_SCALE[clampi(kind, 0, 2)])
    var shirts := [Color(0.82, 0.80, 0.72), Color(0.18, 0.22, 0.36), Color(0.36, 0.26, 0.18), Color(0.10, 0.12, 0.20), Color(0.55, 0.50, 0.42)]
    var pants_list := [Color(0.12, 0.12, 0.15), Color(0.2, 0.17, 0.13), Color(0.16, 0.2, 0.22)]
    var shirt: Color = shirts[rng.randi() % shirts.size()]
    var pants: Color = pants_list[rng.randi() % pants_list.size()]
    var blood := Color(0.28, 0.03, 0.03)
    var bone := Color(0.86, 0.82, 0.7)
    var dark_skin := skin.darkened(0.35)

    _rig = Node3D.new()
    _rig.name = "Rig"
    add_child(_rig)
    _hips = Kit.group(_rig, Vector3(0, HIP_Y, 0), "Hips")
    _spine = Kit.group(_hips, Vector3(0, 0.02, 0), "Spine")
    _head = Kit.group(_spine, Vector3(0, 0.66, 0.02), "Head")
    _arm_l = Kit.group(_spine, Vector3(0.30 * width + 0.04, 0.55, 0), "ArmL")
    _arm_r = Kit.group(_spine, Vector3(-0.30 * width - 0.04, 0.55, 0), "ArmR")
    _leg_l = Kit.group(_hips, Vector3(0.14 * width + 0.02, -0.02, 0), "LegL")
    _leg_r = Kit.group(_hips, Vector3(-0.14 * width - 0.02, -0.02, 0), "LegR")
    _knee_l = Kit.group(_leg_l, Vector3(0, -0.46, 0), "KneeL")
    _knee_r = Kit.group(_leg_r, Vector3(0, -0.46, 0), "KneeR")

    # Таз.
    var kit := Kit.new()
    kit.box(Vector3(0.40 * width, 0.20, 0.24), Vector3(0, -0.08, 0), pants, Vector3.ZERO, 0.0, 0.9)
    kit.commit(_hips)

    # Торс: рваная рубашка, видны рёбра и кровь.
    kit = Kit.new()
    kit.box(Vector3(0.46 * width, 0.56, 0.25), Vector3(0, 0.30, 0), shirt, Vector3.ZERO, 0.0, 0.9)
    kit.box(Vector3(0.30 * width, 0.10, 0.26), Vector3(0.04, 0.03, 0), dark_skin, Vector3.ZERO, 0.0, 0.9)
    kit.box(Vector3(0.50 * width, 0.12, 0.28), Vector3(0, 0.54, 0), shirt.darkened(0.12), Vector3.ZERO, 0.0, 0.9)
    kit.box(Vector3(0.22 * width, 0.24, 0.26), Vector3(-0.08 * width, 0.28, 0.01), blood, Vector3(0, 0, 8), 0.0, 0.7)
    for i in range(3):
        kit.box(Vector3(0.16, 0.025, 0.02), Vector3(0.1 * width, 0.22 + float(i) * 0.07, 0.135), bone, Vector3.ZERO, 0.0, 0.8)
    kit.box(Vector3(0.1, 0.1, 0.1), Vector3(0, 0.62, 0), skin, Vector3.ZERO, 0.0, 0.9)  # шея
    if kind == KIND_BRUTE:
        kit.box(Vector3(0.6, 0.34, 0.34), Vector3(0, 0.22, 0.02), dark_skin, Vector3.ZERO, 0.0, 0.9)  # живот
        kit.box(Vector3(0.22, 0.2, 0.22), Vector3(0.38, 0.55, 0), skin, Vector3.ZERO, 0.0, 0.9)
        kit.box(Vector3(0.22, 0.2, 0.22), Vector3(-0.38, 0.55, 0), skin, Vector3.ZERO, 0.0, 0.9)
    kit.commit(_spine)

    # Голова: череп, нижняя челюсть, светящиеся глаза, клочья волос.
    kit = Kit.new()
    kit.box(Vector3(0.24, 0.24, 0.25), Vector3(0, 0.13, 0), skin, Vector3.ZERO, 0.0, 0.9)
    kit.box(Vector3(0.20, 0.07, 0.22), Vector3(0, -0.01, 0.015), dark_skin, Vector3.ZERO, 0.0, 0.9)
    kit.box(Vector3(0.13, 0.03, 0.02), Vector3(0, 0.035, 0.125), Color(0.05, 0.0, 0.0), Vector3.ZERO, 0.0, 0.9)
    for tooth in range(3):
        kit.box(Vector3(0.02, 0.025, 0.02), Vector3(-0.04 + float(tooth) * 0.04, 0.06, 0.126), bone, Vector3.ZERO, 0.0, 0.8)
    var eye_color := Color(1.0, 0.85, 0.15) if kind != KIND_RUNNER else Color(1.0, 0.25, 0.1)
    for eye in [-0.06, 0.06]:
        var eye_mesh := BoxMesh.new()
        eye_mesh.size = Vector3(0.05, 0.04, 0.02)
        kit.add_mesh(eye_mesh, Transform3D(Basis.IDENTITY, Vector3(eye, 0.16, 0.128)), Kit.glow_material(eye_color))
    if rng.randf() < 0.7:
        kit.box(Vector3(0.25, 0.06, 0.26), Vector3(0, 0.27, -0.01), Color(0.12, 0.09, 0.07), Vector3.ZERO, 0.0, 1.0)
        kit.box(Vector3(0.08, 0.1, 0.08), Vector3(rng.randf_range(-0.08, 0.08), 0.3, 0.05), Color(0.12, 0.09, 0.07), Vector3(0, 0, rng.randf_range(-25, 25)), 0.0, 1.0)
    kit.commit(_head)

    # Руки и ноги.
    for side in [1.0, -1.0]:
        var arm: Node3D = _arm_l if side > 0.0 else _arm_r
        kit = Kit.new()
        kit.box(Vector3(0.12 * width, 0.30, 0.12 * width), Vector3(0, -0.15, 0), shirt, Vector3.ZERO, 0.0, 0.9)
        kit.box(Vector3(0.10 * width, 0.28, 0.10 * width), Vector3(0, -0.41, 0.05), skin, Vector3(-18, 0, 0), 0.0, 0.9)
        kit.box(Vector3(0.11, 0.09, 0.07), Vector3(0, -0.56, 0.10), dark_skin, Vector3(-18, 0, 0), 0.0, 0.9)
        for finger in range(3):
            kit.box(Vector3(0.02, 0.02, 0.09), Vector3((float(finger) - 1.0) * 0.035, -0.58, 0.16), bone, Vector3(-18, 0, 0), 0.0, 0.8)
        kit.commit(arm)
        var thigh: Node3D = _leg_l if side > 0.0 else _leg_r
        var shin: Node3D = _knee_l if side > 0.0 else _knee_r
        kit = Kit.new()
        kit.box(Vector3(0.16 * width, 0.46, 0.16 * width), Vector3(0, -0.23, 0), pants, Vector3.ZERO, 0.0, 0.9)
        kit.commit(thigh)
        kit = Kit.new()
        kit.box(Vector3(0.13 * width, 0.34, 0.13 * width), Vector3(0, -0.17, 0), pants, Vector3.ZERO, 0.0, 0.9)
        kit.box(Vector3(0.12 * width, 0.12, 0.12 * width), Vector3(0, -0.38, 0), skin, Vector3.ZERO, 0.0, 0.9)
        kit.box(Vector3(0.14 * width, 0.08, 0.26), Vector3(0, -0.46, 0.06), Color(0.08, 0.07, 0.07), Vector3.ZERO, 0.0, 0.9)
        kit.commit(shin)

    # Далёких зомби не рисуем — экономия на телефонах.
    for node in find_children("*", "GeometryInstance3D", true, false):
        (node as GeometryInstance3D).visibility_range_end = 80.0


## Попадание: зомби дёргается назад, голова откидывается, руки взлетают.
func hit_flinch() -> void:
    _flinch = 1.0
    _flinch_side = -_flinch_side


func _blend(node: Node3D, target: Vector3, weight: float) -> void:
    node.rotation = node.rotation.lerp(target, weight)


func update_anim(delta: float, speed: float, attack_age: float, spawn_age: float, death_age: float = -1.0) -> void:
    if _rig == null:
        return
    _t += delta
    var w := 1.0 - exp(-delta * 12.0)
    var spread := 0.14

    # --- Смерть: падение навзничь, руки раскинуты, затем труп уходит под палубу ---
    if death_age >= 0.0:
        var k := clampf(death_age / DEATH_TIME, 0.0, 1.0)
        var e := k * k * (3.0 - 2.0 * k)
        var sink := clampf((death_age - SINK_START) / 1.4, 0.0, 1.0)
        _rig.rotation.x = lerpf(0.0, -1.5, e)
        _rig.rotation.z = lerpf(0.0, _death_side * 0.35, e)
        _rig.position.y = lerpf(0.0, 0.14, e) - sink * 1.2
        _hips.position.y = HIP_Y
        var fast := 1.0 - exp(-delta * 18.0)
        # предсмертные судороги: быстро затухающая дрожь конечностей
        var twitch := sin(death_age * 34.0 + _twitch_seed) * 0.22 * exp(-death_age * 2.2)
        _blend(_arm_l, Vector3(-0.4 + twitch, 0.0, 1.1), fast)
        _blend(_arm_r, Vector3(-0.2 - twitch, 0.0, -1.2), fast)
        _blend(_leg_l, Vector3(0.1 - twitch * 0.8, 0.0, 0.15), fast)
        _blend(_leg_r, Vector3(-0.05 + twitch * 0.8, 0.0, -0.2), fast)
        _blend(_knee_l, Vector3.ZERO, fast)
        _blend(_knee_r, Vector3(0.25, 0.0, 0.0), fast)
        _blend(_spine, Vector3(0.0, 0.0, 0.1), fast)
        _blend(_head, Vector3(0.25, 0.0, 0.5), fast)
        return

    # --- Вылезание из люка ---
    if spawn_age >= 0.0 and spawn_age < RISE_TIME:
        var k := clampf(spawn_age / RISE_TIME, 0.0, 1.0)
        var e := k * k * (3.0 - 2.0 * k)
        _rig.position.y = lerpf(-1.9, 0.0, e)
        _rig.rotation.x = lerpf(1.15, 0.0, e)
        var claw := sin(_t * 9.0 + _phase_offset) * 0.35
        _blend(_arm_l, Vector3(-2.7 + claw, 0.0, -spread), w)
        _blend(_arm_r, Vector3(-2.7 - claw, 0.0, spread), w)
        _blend(_spine, Vector3(0.3 * (1.0 - k), 0.0, 0.0), w)
        _blend(_head, Vector3(-0.5 + sin(_t * 12.0) * 0.1, 0.0, sin(_t * 7.0) * 0.2), w)
        _blend(_leg_l, Vector3.ZERO, w)
        _blend(_leg_r, Vector3.ZERO, w)
        _blend(_knee_l, Vector3.ZERO, w)
        _blend(_knee_r, Vector3.ZERO, w)
        return
    _rig.position.y = lerpf(_rig.position.y, 0.0, w)
    _rig.rotation.x = lerpf(_rig.rotation.x, 0.0, w) - _flinch * 0.10 * (1.0 - w)
    _rig.rotation.z = lerpf(_rig.rotation.z, 0.0, w)
    _flinch = move_toward(_flinch, 0.0, delta * 3.2)

    var moving := speed > 0.3
    var run_like := kind == KIND_RUNNER
    var stride := 3.2
    var amp := 0.0
    if moving:
        _phase += delta * speed * stride
        amp = clampf(speed / 2.2, 0.35, 1.35) * 0.55
    var s := sin(_phase)
    var c := cos(_phase)

    # Ноги: левая «подволакивается» у ходока.
    var drag := 0.7 if kind == KIND_WALKER else 1.0
    _blend(_leg_l, Vector3(s * amp * drag, 0.0, 0.0), w)
    _blend(_leg_r, Vector3(-s * amp, 0.0, 0.0), w)
    _blend(_knee_l, Vector3(maxf(0.0, c) * amp * 1.5 * drag, 0.0, 0.0), w)
    _blend(_knee_r, Vector3(maxf(0.0, -c) * amp * 1.5, 0.0, 0.0), w)

    # Корпус: наклон вперёд, качка, «пьяная» походка.
    var lean := 0.12 + (0.45 if run_like and moving else 0.18 if moving else 0.0)
    var bob := absf(s) * (0.07 if kind == KIND_BRUTE else 0.04) if moving else sin(_t * 1.6 + _phase_offset) * 0.012
    _hips.position.y = HIP_Y + bob
    var idle_sway := sin(_t * 1.4 + _phase_offset) * 0.03
    # резкое подёргивание головы и плеч (нервный тик), хрип дыханием
    var tic := pow(maxf(0.0, sin(_t * 3.1 + _twitch_seed)), 14.0)
    var breath := sin(_t * 2.6 + _phase_offset) * 0.025
    _blend(_spine, Vector3(lean + idle_sway + breath - _flinch * 0.45, s * 0.12 if moving else 0.0, (s * 0.07 if moving else idle_sway) + _flinch * _flinch_side * 0.25), w)
    _blend(_head, Vector3(0.18 + sin(_t * 2.3 + _phase_offset) * 0.07 + _flinch * 0.7 - tic * 0.25, tic * 0.35 * _flinch_side, ((sin(_phase * 0.5) * 0.14) if moving else sin(_t * 0.9 + _phase_offset) * 0.16) + tic * 0.2), w)

    # Руки: вытянуты вперёд (ходок/громила) или болтаются при беге.
    var arm_l := Vector3(-1.35 + sin(_t * 2.0 + _phase_offset) * 0.07, 0.0, -spread)
    var arm_r := Vector3(-1.30 + cos(_t * 2.2 + _phase_offset) * 0.07, 0.0, spread)
    if kind == KIND_BRUTE:
        arm_l = Vector3(-0.95 + s * 0.15, 0.0, -0.25)
        arm_r = Vector3(-0.95 - s * 0.15, 0.0, 0.25)
    elif run_like and moving:
        arm_l = Vector3(-0.5 + s * 1.0, 0.0, -0.1)
        arm_r = Vector3(-0.5 - s * 1.0, 0.0, 0.1)

    arm_l.x -= _flinch * 0.9
    arm_r.x -= _flinch * 0.9
    arm_l.z -= _flinch * 0.4
    arm_r.z += _flinch * 0.4

    # --- Удар: замах -> рывок -> возврат ---
    if attack_age >= 0.0 and attack_age < ATTACK_TIME:
        var reach_up := -2.75
        var reach_down := -0.85
        var a_x := 0.0
        var spine_x := 0.0
        var head_x := 0.0
        if attack_age < 0.35:
            var t1 := attack_age / 0.35
            a_x = lerpf(-1.35, reach_up, t1)
            spine_x = lerpf(0.15, -0.28, t1)
            head_x = lerpf(0.15, -0.4, t1)
        elif attack_age < 0.55:
            var t2 := (attack_age - 0.35) / 0.2
            a_x = lerpf(reach_up, reach_down, t2)
            spine_x = lerpf(-0.28, 0.65, t2)
            head_x = lerpf(-0.4, 0.45, t2)
        else:
            var t3 := (attack_age - 0.55) / (ATTACK_TIME - 0.55)
            a_x = lerpf(reach_down, -1.35, t3)
            spine_x = lerpf(0.65, 0.15, t3)
            head_x = lerpf(0.45, 0.15, t3)
        var fast := 1.0 - exp(-delta * 30.0)
        _blend(_arm_l, Vector3(a_x, 0.0, -0.12), fast)
        _blend(_arm_r, Vector3(a_x, 0.0, 0.12), fast)
        _blend(_spine, Vector3(spine_x, 0.0, 0.0), fast)
        _blend(_head, Vector3(head_x, 0.0, 0.0), fast)
        return
    _blend(_arm_l, arm_l, w)
    _blend(_arm_r, arm_r, w)
