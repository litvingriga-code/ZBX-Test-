extends Node3D
## Stage132: боевые эффекты.
##   Высокая графика (3): кровь при попадании и при убийстве (брызги, туман, лужи и пятна на земле),
##                        искры от пуль, пыль.
##   Средняя графика (2): только пыль от попаданий в предметы/землю.
##   Низкая графика (1):  ничего.
## Кровь можно отдельно выключить кнопкой «Кровь» в настройках (blood_enabled).
## Все частицы — CPUParticles3D (работают и на телефоне), без шейдеров и внешних файлов.
## Пятна на земле: не более MAX_SPLATS одновременно, постепенно исчезают.

const MAX_SPLATS := 36
const SPLAT_LIFE := 18.0
const SPLAT_FADE := 8.0

var level := 1
var blood_enabled := true

var _rng := RandomNumberGenerator.new()
var _splats: Array = []
var _splat_mat: StandardMaterial3D
var _drop_mat: StandardMaterial3D
var _mist_mat: StandardMaterial3D
var _dust_mat: StandardMaterial3D
var _spark_mat: StandardMaterial3D
var _shrink_curve: Curve
var _grow_curve: Curve


func _ready() -> void:
    _rng.randomize()
    _make_materials()


func blood_on() -> bool:
    return level >= 3 and blood_enabled


# ------------------------------------------------------------------ публичный API

## Попадание в тело: брызги по направлению выстрела, небольшой туман, иногда пятно на земле.
func blood_hit(pos: Vector3, dir: Vector3, ground_y: float, strong: bool = false) -> void:
    if not blood_on():
        return
    dir = _safe_dir(dir)
    _burst(pos, dir, 14 if strong else 9, 1.8, 5.0, 32.0, 0.06, 0.65, _drop_mat, -9.8, _shrink_curve)
    _burst(pos, -dir + Vector3(0, 0.4, 0), 4, 0.8, 2.2, 55.0, 0.045, 0.45, _drop_mat, -9.8, _shrink_curve)
    _burst(pos, dir, 3, 0.2, 0.8, 80.0, 0.35, 0.40, _mist_mat, 0.0, _grow_curve)
    if strong or _rng.randf() < 0.45:
        var flat := Vector3(dir.x, 0.0, dir.z)
        flat = flat.normalized() if flat.length() > 0.01 else Vector3.FORWARD
        var spot := Vector3(pos.x, ground_y, pos.z) + flat * _rng.randf_range(0.5, 1.6)
        _splat(spot, _rng.randf_range(0.28, 0.55))


## Смерть: большой фонтан, туман, лужа под телом и брызги вокруг.
func blood_death(pos: Vector3, dir: Vector3, ground_y: float, big: bool = false) -> void:
    if not blood_on():
        return
    dir = _safe_dir(dir)
    var k := 1.5 if big else 1.0
    _burst(pos, dir + Vector3(0, 0.25, 0), int(34.0 * k), 2.0, 6.5, 70.0, 0.07, 0.85, _drop_mat, -9.8, _shrink_curve)
    _burst(pos, Vector3.UP, int(16.0 * k), 2.5, 6.0, 28.0, 0.06, 0.95, _drop_mat, -9.8, _shrink_curve)
    _burst(pos, Vector3.UP, 7, 0.4, 1.4, 70.0, 0.55 * k, 0.65, _mist_mat, 0.0, _grow_curve)
    # лужа под телом и брызги вокруг
    var base := Vector3(pos.x, ground_y, pos.z)
    _splat(base, _rng.randf_range(1.1, 1.6) * k)
    var n := 5 if big else 4
    for i in range(n):
        var a := _rng.randf() * TAU
        var r := _rng.randf_range(0.5, 1.5) * k
        _splat(base + Vector3(cos(a), 0.0, sin(a)) * r, _rng.randf_range(0.35, 0.85))


## Попадание в стену/землю/предмет: пыль (средняя и высокая графика) и искры (высокая).
func impact(pos: Vector3, ray_dir: Vector3) -> void:
    if level < 2:
        return
    var back := -_safe_dir(ray_dir) + Vector3(0, 0.35, 0)
    _burst(pos, back, 6, 0.6, 2.0, 45.0, 0.20, 0.55, _dust_mat, -0.6, _grow_curve)
    if level >= 3:
        _burst(pos, back, 5, 3.0, 6.0, 50.0, 0.03, 0.25, _spark_mat, -9.8, _shrink_curve)


# ------------------------------------------------------------------ внутреннее

func _safe_dir(d: Vector3) -> Vector3:
    return d.normalized() if d.length() > 0.001 else Vector3.UP


func _make_materials() -> void:
    _drop_mat = StandardMaterial3D.new()
    _drop_mat.albedo_color = Color(0.58, 0.02, 0.03)
    _drop_mat.roughness = 0.25
    _drop_mat.metallic_specular = 0.8
    _mist_mat = StandardMaterial3D.new()
    _mist_mat.albedo_color = Color(0.5, 0.02, 0.03, 0.30)
    _mist_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    _mist_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    _dust_mat = StandardMaterial3D.new()
    _dust_mat.albedo_color = Color(0.62, 0.58, 0.50, 0.38)
    _dust_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    _dust_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    _spark_mat = StandardMaterial3D.new()
    _spark_mat.albedo_color = Color(1.0, 0.82, 0.35)
    _spark_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    _spark_mat.emission_enabled = true
    _spark_mat.emission = Color(1.0, 0.6, 0.15)
    _spark_mat.emission_energy_multiplier = 2.0
    _splat_mat = StandardMaterial3D.new()
    _splat_mat.albedo_texture = _make_blob()
    _splat_mat.albedo_color = Color(0.42, 0.02, 0.03, 0.93)
    _splat_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    _splat_mat.roughness = 0.2
    _splat_mat.metallic_specular = 0.9
    _splat_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    _shrink_curve = Curve.new()
    _shrink_curve.add_point(Vector2(0.0, 1.0))
    _shrink_curve.add_point(Vector2(1.0, 0.25))
    _grow_curve = Curve.new()
    _grow_curve.add_point(Vector2(0.0, 0.4))
    _grow_curve.add_point(Vector2(1.0, 1.5))


## Неровное пятно с брызгами вокруг (рисуется один раз кодом).
func _make_blob() -> ImageTexture:
    var n := 64
    var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
    var p1 := _rng.randf() * TAU
    var p2 := _rng.randf() * TAU
    var p3 := _rng.randf() * TAU
    for y in range(n):
        for x in range(n):
            var p := Vector2(float(x) - float(n) * 0.5 + 0.5, float(y) - float(n) * 0.5 + 0.5) / (float(n) * 0.5)
            var d := p.length()
            var a := atan2(p.y, p.x)
            var edge := 0.52 + 0.14 * sin(a * 3.0 + p1) + 0.09 * sin(a * 7.0 + p2) + 0.05 * sin(a * 13.0 + p3)
            var alpha := clampf((edge - d) / 0.10, 0.0, 1.0)
            img.set_pixel(x, y, Color(1, 1, 1, alpha))
    for i in range(10):
        var ang := _rng.randf() * TAU
        var dist := _rng.randf_range(0.66, 0.93) * float(n) * 0.5
        var c := Vector2(float(n) * 0.5, float(n) * 0.5) + Vector2(cos(ang), sin(ang)) * dist
        var rad := _rng.randf_range(1.2, 3.2)
        for yy in range(-4, 5):
            for xx in range(-4, 5):
                if Vector2(float(xx), float(yy)).length() <= rad:
                    var px := int(c.x) + xx
                    var py := int(c.y) + yy
                    if px >= 0 and py >= 0 and px < n and py < n:
                        img.set_pixel(px, py, Color(1, 1, 1, 1))
    return ImageTexture.create_from_image(img)


func _splat(pos: Vector3, size: float) -> void:
    while _splats.size() >= MAX_SPLATS:
        var old = _splats.pop_front()
        if is_instance_valid(old):
            (old as Node).queue_free()
    var plane := PlaneMesh.new()
    plane.size = Vector2(size, size)
    var m := MeshInstance3D.new()
    m.mesh = plane
    m.material_override = _splat_mat
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(m)
    m.global_position = pos + Vector3(0.0, 0.022 + _rng.randf() * 0.012, 0.0)
    m.rotation.y = _rng.randf() * TAU
    var tw := create_tween()
    tw.tween_interval(SPLAT_LIFE)
    tw.tween_property(m, "transparency", 1.0, SPLAT_FADE)
    tw.tween_callback(m.queue_free)
    _splats.append(m)


func _burst(pos: Vector3, dir: Vector3, amount: int, v_min: float, v_max: float, spread: float, size: float, life: float, mat: Material, gravity_y: float, curve: Curve) -> void:
    var p := CPUParticles3D.new()
    p.one_shot = true
    p.emitting = false
    p.amount = maxi(amount, 1)
    p.lifetime = life
    p.explosiveness = 1.0
    p.local_coords = false
    p.direction = _safe_dir(dir)
    p.spread = spread
    p.initial_velocity_min = v_min
    p.initial_velocity_max = v_max
    p.gravity = Vector3(0.0, gravity_y, 0.0)
    p.scale_amount_min = size * 0.6
    p.scale_amount_max = size
    p.scale_amount_curve = curve
    var mesh := SphereMesh.new()
    mesh.radius = 0.5
    mesh.height = 1.0
    mesh.radial_segments = 5
    mesh.rings = 3
    mesh.material = mat
    p.mesh = mesh
    p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(p)
    p.global_position = pos
    p.emitting = true
    get_tree().create_timer(life + 0.4).timeout.connect(p.queue_free)
