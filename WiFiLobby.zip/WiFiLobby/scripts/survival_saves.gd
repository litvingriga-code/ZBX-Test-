extends Node
# Separate local save slots for survival mode.
const ROOT := "user://survival_slots/"
var pending_slot: String = ""
var active_slot: String = ""
var loaded_clients: Dictionary = {}
var client_snapshots: Dictionary = {}
var saved_teams: Array = []
var active_save_id: String = ""
var client_server_id: String = ""
var client_server_name: String = ""

func new_save_id() -> String:
    var result := ""
    for b in Crypto.new().generate_random_bytes(16):
        result += "%02x" % int(b)
    return result

func ensure_save_identity(name: String) -> String:
    var old := load_slot(name)
    var identity := str(old.get("save_id", ""))
    if identity.is_empty():
        identity = new_save_id()
    active_save_id = identity
    return identity

func set_client_server(identity: String, name: String) -> void:
    client_server_id = identity
    client_server_name = name


func slots() -> Array[String]:
    var names: Array[String] = []
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(ROOT))
    var dir := DirAccess.open(ROOT)
    if dir == null:
        return names
    dir.list_dir_begin()
    var file := dir.get_next()
    while file != "":
        if file.ends_with(".json"):
            names.append(file.trim_suffix(".json"))
        file = dir.get_next()
    dir.list_dir_end()
    names.sort()
    return names

func _safe_name(value: String) -> String:
    var result := value.strip_edges().substr(0, 48)
    for ch in ["/", "\\", ":", "*", "?", "\"", "<", ">", "|", "."]:
        result = result.replace(ch, "_")
    return result

func save_slot(value: String, position: Vector3, hp: int, facing_yaw: float = 0.0, facing_pitch: float = 0.0) -> bool:
    var name := _safe_name(value)
    if name.is_empty():
        return false
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(ROOT))
    # Read the existing save ID BEFORE opening the file for writing.
    # FileAccess.WRITE truncates the file immediately.
    # Идентификатор мира не меняем при первом/новом имени сохранения того же мира:
    # иначе клиенты теряют связь со своим сохранением на этом сервере.
    if active_save_id.is_empty():
        ensure_save_identity(name)
    elif active_slot != name and FileAccess.file_exists(ROOT + name + ".json"):
        ensure_save_identity(name)
    var file := FileAccess.open(ROOT + name + ".json", FileAccess.WRITE)
    if file == null:
        return false
    var payload := {"save_id": active_save_id, "save_name": name, "version": 2, "pos": [position.x, position.y, position.z], "health": hp, "inventory": GameState.battle_inventory, "equipment": GameState.battle_equipment, "yaw": facing_yaw, "pitch": facing_pitch, "clients": client_snapshots.duplicate(true), "teams": saved_teams.duplicate(true)}
    file.store_string(JSON.stringify(payload))
    active_slot = name
    return true

func load_slot(value: String) -> Dictionary:
    if value.is_empty() or not FileAccess.file_exists(ROOT + value + ".json"):
        return {}
    var file := FileAccess.open(ROOT + value + ".json", FileAccess.READ)
    if file == null:
        return {}
    var content := file.get_as_text()
    if content.strip_edges().is_empty():
        return {}
    var parser := JSON.new()
    if parser.parse(content) != OK:
        push_warning("Cannot read survival save '%s': invalid JSON (%s)" % [value, parser.get_error_message()])
        return {}
    var data = parser.data
    return data if data is Dictionary else {}

func delete_slot(value: String) -> void:
    if not value.is_empty():
        DirAccess.remove_absolute(ProjectSettings.globalize_path(ROOT + value + ".json"))

# Each server save has an isolated client recovery file, keyed by save ID.
const CLIENT_RECOVERY_ROOT := "user://survival_client_recovery/"

func _recovery_path(identity: String) -> String:
    return CLIENT_RECOVERY_ROOT + identity + ".json"

## Сохранение Client-а на телефоне: отдельный файл на каждый сервер (по save_id сервера).
## Возвращает записанное состояние (с номером версии "rev") либо {} если сервер ещё неизвестен.
func save_client_recovery(position: Vector3, hp: int, facing_yaw: float, facing_pitch: float) -> Dictionary:
    if client_server_id.is_empty():
        return {}
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(CLIENT_RECOVERY_ROOT))
    var old: Dictionary = load_client_recovery()
    var data := {"save_id": client_server_id, "save_name": client_server_name, "rev": int(old.get("rev", 0)) + 1, "saved_at": Time.get_unix_time_from_system(), "pos": [position.x, position.y, position.z], "health": hp, "yaw": facing_yaw, "pitch": facing_pitch, "inventory": GameState.battle_inventory.duplicate(true), "equipment": GameState.battle_equipment.duplicate(true)}
    # Пишем во временный файл и подменяем основной: сбой посреди записи не портит прошлое сохранение.
    var final_path: String = _recovery_path(client_server_id)
    var tmp_path: String = final_path + ".tmp"
    var file := FileAccess.open(tmp_path, FileAccess.WRITE)
    if file == null:
        return data
    file.store_string(JSON.stringify(data))
    file.flush()
    file.close()
    if DirAccess.rename_absolute(ProjectSettings.globalize_path(tmp_path), ProjectSettings.globalize_path(final_path)) != OK:
        var direct := FileAccess.open(final_path, FileAccess.WRITE)
        if direct != null:
            direct.store_string(JSON.stringify(data))
            direct.flush()
    return data

func load_client_recovery(identity: String = "") -> Dictionary:
    if identity.is_empty():
        identity = client_server_id
    if identity.is_empty() or not FileAccess.file_exists(_recovery_path(identity)):
        return {}
    var data = JSON.parse_string(FileAccess.get_file_as_string(_recovery_path(identity)))
    if data is Dictionary and str(data.get("save_id", "")) == identity:
        return data
    return {}
