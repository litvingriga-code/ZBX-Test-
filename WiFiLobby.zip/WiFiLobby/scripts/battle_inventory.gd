extends PanelContainer
## Боевой HUD: ячейки снаряжения и три оружейных слота, без сетки рюкзака.
const SlotScript = preload("res://scripts/item_slot.gd")
const UiGray = preload("res://scripts/ui_gray.gd")
var gear_slots: Array = []
var selected_index: int = -1
var selected_container: String = ""
var move_source_container: String = ""
var move_source_index: int = -1
var drop_button: Button
var use_button: Button
var action_notice: Label
var drop_overlay: ColorRect
var drop_slider: HSlider
var drop_count_label: Label
var drop_target_container: String = ""
var drop_target_index: int = -1
# One-finger drag for Android; desktop keeps Godot's built-in drag-and-drop.
var touch_drag_id: int = -1
var touch_source: Control
var touch_preview: Control
var touch_start: Vector2 = Vector2.ZERO
var touch_dragging: bool = false
var last_tap_ms: int = -1000
var last_tap_slot: String = ""

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    offset_left = 18
    offset_top = 18
    offset_right = -18
    offset_bottom = -18
    mouse_filter = Control.MOUSE_FILTER_STOP
    theme = UiGray.make_theme(22)
    var style := StyleBoxFlat.new()
    style.bg_color = UiGray.PANEL
    style.set_content_margin_all(16)
    add_theme_stylebox_override("panel", style)

    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 14)
    add_child(root)
    var header := HBoxContainer.new()
    root.add_child(header)
    var title := Label.new()
    title.text = "Снаряжение в бою"
    title.add_theme_font_size_override("font_size", 23)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    header.add_child(title)
    var close := Button.new()
    close.text = "✕"
    close.custom_minimum_size = Vector2(55, 45)
    close.pressed.connect(hide)
    header.add_child(close)

    var content := HBoxContainer.new()
    content.size_flags_vertical = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 24)
    root.add_child(content)

    var left := VBoxContainer.new()
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_child(left)
    var left_title := Label.new()
    left_title.text = "Предметы (9 ячеек)"
    left.add_child(left_title)
    var grid := GridContainer.new()
    grid.columns = 5
    grid.add_theme_constant_override("h_separation", 8)
    grid.add_theme_constant_override("v_separation", 8)
    left.add_child(grid)
    for i in range(GameState.ATTACH_SLOT + 1, GameState.GEAR_SIZE):
        grid.add_child(_slot(i, "gear", ""))
    var right := VBoxContainer.new()
    right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    right.add_theme_constant_override("separation", 10)
    content.add_child(right)
    var right_title := Label.new()
    right_title.text = "Оружие из лобби"
    right.add_child(right_title)
    for i in 3:
        right.add_child(_slot(i, "gear", "Weapon %d" % (i + 1)))
    right.add_child(_slot(GameState.ATTACH_SLOT, "gear", "Обвес"))
    # Actions sit directly below the three weapon slots, not in the HUD.
    var actions := HBoxContainer.new()
    actions.add_theme_constant_override("separation", 8)
    right.add_child(actions)
    use_button = Button.new()
    use_button.text = "Использовать"
    use_button.custom_minimum_size = Vector2(140, 52)
    use_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    use_button.pressed.connect(_use_selected)
    actions.add_child(use_button)
    drop_button = Button.new()
    drop_button.text = "Выбросить"
    drop_button.custom_minimum_size = Vector2(140, 52)
    drop_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    drop_button.pressed.connect(_drop_selected)
    actions.add_child(drop_button)
    action_notice = Label.new()
    action_notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    right.add_child(action_notice)

    _create_drop_dialog()
    GameState.changed.connect(refresh)
    Net.medkit_approved.connect(_on_medkit_approved)
    Net.adrenaline_approved.connect(_on_adrenaline_approved)
    refresh()

func _slot(idx: int, container: String, placeholder: String) -> Control:
    var wrapper := PanelContainer.new()
    wrapper.custom_minimum_size = Vector2(94, 94)
    var bg := StyleBoxFlat.new()
    bg.bg_color = UiGray.RAISED
    bg.set_border_width_all(1)
    bg.border_color = UiGray.EDGE_SOFT
    wrapper.add_theme_stylebox_override("panel", bg)
    var slot = SlotScript.new()
    slot.container_id = container
    slot.index = idx
    slot.custom_minimum_size = Vector2(92, 90)
    slot.tooltip_text = placeholder
    wrapper.add_child(slot)
    var label := Label.new()
    label.text = placeholder
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    wrapper.add_child(label)
    slot.set_meta("placeholder_label", label)
    slot.selected.connect(_on_selected)
    gear_slots.append(slot)
    return wrapper

func refresh() -> void:
    for slot in gear_slots:
        var data: Array = GameState.get_slots(slot.container_id)
        if slot.index < 0 or slot.index >= data.size():
            continue
        slot.set_item(data[slot.index])
        slot.is_selected = slot.container_id == selected_container and slot.index == selected_index
        slot.queue_redraw()
    var chosen: Array = GameState.get_slots(selected_container)
    var has_item: bool = selected_index >= 0 and selected_index < chosen.size() and not chosen[selected_index].is_empty()
    if drop_button != null:
        drop_button.disabled = not has_item
    if use_button != null:
        use_button.disabled = not has_item
    for slot in gear_slots:
        var slots: Array = GameState.get_slots(slot.container_id)
        slot.get_meta("placeholder_label").visible = slot.index < 0 or slot.index >= slots.size() or not (slots[slot.index] is Dictionary) or slots[slot.index].is_empty()

func _on_selected(container: String, index: int) -> void:
    # Selection is only for Use/Drop. Moving requires actual drag-and-drop.
    var key: String = "%s:%d" % [container, index]
    var now: int = Time.get_ticks_msec()
    var double_tap: bool = key == last_tap_slot and now - last_tap_ms <= 380
    selected_container = container
    selected_index = index
    last_tap_ms = -1000 if double_tap else now
    last_tap_slot = "" if double_tap else key
    refresh()
    if double_tap:
        var slots: Array = GameState.get_slots(container)
        if index >= 0 and index < slots.size() and str(slots[index].get("id", "")) == "medkit":
            _use_selected()

func _input(event: InputEvent) -> void:
    if not visible:
        return
    if event is InputEventScreenTouch:
        var touch: InputEventScreenTouch = event
        if touch.pressed and touch_drag_id == -1:
            for slot in gear_slots:
                if slot.get_global_rect().has_point(touch.position) and not slot.item.is_empty():
                    touch_drag_id = touch.index
                    touch_source = slot
                    touch_start = touch.position
                    touch_dragging = false
                    break
        elif not touch.pressed and touch.index == touch_drag_id:
            if touch_dragging and is_instance_valid(touch_source):
                for target in gear_slots:
                    if target.get_global_rect().has_point(touch.position):
                        var src_c: String = touch_source.container_id
                        var src_i: int = touch_source.index
                        var dst_c: String = target.container_id
                        var dst_i: int = target.index
                        var source: Array = GameState.get_slots(src_c)
                        var destination: Array = GameState.get_slots(dst_c)
                        if GameState.can_place(dst_c, dst_i, source[src_i]) and GameState.can_place(src_c, src_i, destination[dst_i]):
                            GameState.move_item(src_c, src_i, dst_c, dst_i)
                        break
            _end_touch_drag()
    elif event is InputEventScreenDrag:
        var motion: InputEventScreenDrag = event
        if motion.index == touch_drag_id and is_instance_valid(touch_source):
            if not touch_dragging and motion.position.distance_to(touch_start) > 14.0:
                touch_dragging = true
                touch_preview = SlotScript.new()
                touch_preview.is_preview = true
                touch_preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
                touch_preview.top_level = true
                touch_preview.z_index = 100
                touch_preview.size = Vector2(92, 90)
                touch_preview.modulate.a = 0.85
                add_child(touch_preview)
                touch_preview.set_item(touch_source.item.duplicate(true))
            if touch_dragging and is_instance_valid(touch_preview):
                touch_preview.global_position = motion.position - touch_preview.size * 0.5
                get_viewport().set_input_as_handled()

func _end_touch_drag() -> void:
    if is_instance_valid(touch_preview):
        touch_preview.queue_free()
    touch_preview = null
    touch_source = null
    touch_drag_id = -1
    touch_dragging = false

func _create_drop_dialog() -> void:
    drop_overlay = ColorRect.new()
    drop_overlay.name = "DropQuantityOverlay"
    drop_overlay.color = Color(0.0, 0.0, 0.0, 0.78)
    drop_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    drop_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    drop_overlay.visible = false
    add_child(drop_overlay)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    drop_overlay.add_child(center)
    var dialog := PanelContainer.new()
    dialog.custom_minimum_size = Vector2(350, 210)
    center.add_child(dialog)
    var style := StyleBoxFlat.new()
    style.bg_color = UiGray.PANEL
    style.border_color = UiGray.EDGE
    style.set_border_width_all(2)
    style.set_corner_radius_all(UiGray.RADIUS_PANEL)
    style.set_content_margin_all(18)
    dialog.add_theme_stylebox_override("panel", style)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 12)
    dialog.add_child(column)
    var heading := Label.new()
    heading.text = "Выбросить предметы"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    column.add_child(heading)
    drop_count_label = Label.new()
    drop_count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    column.add_child(drop_count_label)
    drop_slider = HSlider.new()
    drop_slider.min_value = 1
    drop_slider.max_value = 2
    drop_slider.step = 1
    drop_slider.custom_minimum_size = Vector2(280, 38)
    drop_slider.value_changed.connect(_on_drop_amount_changed)
    column.add_child(drop_slider)
    var buttons := HBoxContainer.new()
    buttons.add_theme_constant_override("separation", 12)
    column.add_child(buttons)
    var confirm := Button.new()
    confirm.text = "Выбросить"
    confirm.custom_minimum_size = Vector2(130, 48)
    confirm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    confirm.pressed.connect(_confirm_drop_quantity)
    buttons.add_child(confirm)
    var cancel := Button.new()
    cancel.text = "Выйти"
    cancel.custom_minimum_size = Vector2(130, 48)
    cancel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    cancel.pressed.connect(_close_drop_dialog)
    buttons.add_child(cancel)

func _on_drop_amount_changed(value: float) -> void:
    if drop_count_label != null:
        drop_count_label.text = "Количество: %d" % int(value)

func _close_drop_dialog() -> void:
    drop_overlay.hide()
    drop_target_container = ""
    drop_target_index = -1

func _drop_selected() -> void:
    if selected_index < 0:
        return
    var items: Array = GameState.get_slots(selected_container)
    if selected_index >= items.size() or items[selected_index].is_empty():
        return
    var stack: Dictionary = items[selected_index]
    var count: int = maxi(1, int(stack.get("count", 1)))
    if count == 1:
        _drop_quantity(selected_container, selected_index, 1)
        return
    drop_target_container = selected_container
    drop_target_index = selected_index
    drop_slider.max_value = count
    drop_slider.value = 1
    _on_drop_amount_changed(drop_slider.value)
    drop_overlay.show()
    drop_overlay.move_to_front()

func _confirm_drop_quantity() -> void:
    var container_id: String = drop_target_container
    var index: int = drop_target_index
    var quantity: int = int(drop_slider.value)
    _close_drop_dialog()
    _drop_quantity(container_id, index, quantity)

func _drop_quantity(container_id: String, index: int, quantity: int) -> void:
    var items: Array = GameState.get_slots(container_id)
    if index < 0 or index >= items.size() or items[index].is_empty():
        return
    var original: Dictionary = items[index]
    var available: int = maxi(1, int(original.get("count", 1)))
    if quantity < 1 or quantity > available:
        return
    var dropped: Dictionary = original.duplicate(true)
    dropped["count"] = quantity
    var battle = get_parent()
    if not battle.has_method("spawn_dropped_item"):
        return
    if battle.has_method("is_downed") and battle.is_downed():
        _notice("В нокауте нельзя выбрасывать предметы")
        return
    if not battle.spawn_dropped_item(dropped):
        _notice("Не удалось выбросить предмет")
        return
    if quantity == available:
        items[index] = {}
    else:
        items[index]["count"] = available - quantity
    move_source_index = -1
    GameState.changed.emit()
    refresh()


func _use_selected() -> void:
    if selected_index < 0:
        return
    var items: Array = GameState.get_slots(selected_container)
    if selected_index >= items.size() or items[selected_index].is_empty():
        return
    var item: Dictionary = items[selected_index]
    if str(item.get("id", "")) == "adrenaline":
        if not Net.request_adrenaline_use():
            _notice("Адреналин можно использовать только в бою")
        return
    if str(item.get("id", "")) == "medkit":
        if not Net.battle_active:
            _notice("Аптечка используется только во время боя")
            return
        # Разрешаем применение при 100 HP; аптечка всё равно расходуется.
        if not Net.request_medkit_use():
            _notice("Не удалось использовать аптечку")
        return
    if str(item.get("id", "")) == "turret":
        if not Net.battle_active or Net.game_mode != Net.MODE_ZOMBIES:
            _notice("Турель ставится только в бою «Волны зомби»")
            return
        Net.turret_use_requested.emit()
        return
    var category: String = str(GameState.ITEMS.get(str(item.get("id", "")), {}).get("category", "other"))
    var target := -1
    match category:
        "rifle": target = 0
        "pistol": target = 1
        "knife": target = 2
        "attachment": target = GameState.ATTACH_SLOT
        _:
            _notice("Предмет уже находится в снаряжении")
            return
    if selected_container == "gear" and selected_index == target:
        _notice("Оружие уже в нужном слоте")
        return
    var gear: Array = GameState.get_slots("gear")
    if not gear[target].is_empty():
        _notice("Нужный слот занят")
        return
    GameState.move_item(selected_container, selected_index, "gear", target)
    selected_container = "gear"
    selected_index = target
    move_source_index = -1
    move_source_container = ""
    _notice("Обвес установлен" if target == GameState.ATTACH_SLOT else "Оружие перемещено в слот")
    refresh()

func _notice(message: String) -> void:
    if action_notice != null:
        action_notice.text = message

func _consume_selected_medkit() -> void:
    var items: Array = GameState.get_slots(selected_container)
    if selected_index < 0 or selected_index >= items.size():
        return
    var stack: Dictionary = items[selected_index]
    if str(stack.get("id", "")) != "medkit":
        return
    var remaining: int = int(stack.get("count", 1)) - 1
    if remaining <= 0:
        items[selected_index] = {}
    else:
        stack["count"] = remaining
    GameState.changed.emit()
    _notice("Аптечка использована")
    refresh()

func _on_medkit_approved() -> void:
    _consume_selected_medkit()


func _on_adrenaline_approved() -> void:
    var slots: Array = GameState.get_slots(selected_container)
    if selected_index < 0 or selected_index >= slots.size():
        return
    if str(slots[selected_index].get("id", "")) != "adrenaline":
        return
    var remaining := int(slots[selected_index].get("count", 1)) - 1
    if remaining <= 0:
        slots[selected_index] = {}
    else:
        slots[selected_index]["count"] = remaining
    GameState.changed.emit()
    _notice("Адреналин использован")
    refresh()
