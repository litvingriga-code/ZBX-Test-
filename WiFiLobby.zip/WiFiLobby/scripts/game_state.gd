extends Node
## Профиль игрока на этом устройстве: ник, деньги, инвентарь и инвентарь снаряжения.
## Автозагрузка (autoload) "GameState". Всё сохраняется в user://profile.json.

signal changed

const SAVE_PATH := "user://profile.json"
const INV_SIZE := 100
const GEAR_SIZE := 13
const START_MONEY := 25000
const CREATOR_REWARD := 200000000000
const MAX_MONEY := 9223372036854775807
const ATTACH_SLOT := 3          # ячейка снаряжения «Обвес» (коллиматор и т.п.)
const MIN_NICK := 2
const MAX_NICK := 16

const ITEMS := {
    # Основное оружие (ячейка 1)
    "ak47": {"category": "rifle", "name": "АК-47", "stack": 1, "color": Color(0.30, 0.33, 0.38)},
    "m4a1": {"category": "rifle", "name": "M4A1", "stack": 1, "color": Color(0.27, 0.30, 0.34)},
    "shotgun": {"category": "rifle", "name": "Дробовик МР-133", "stack": 1, "color": Color(0.38, 0.27, 0.16)},
    "svd": {"category": "rifle", "name": "СВД", "stack": 1, "color": Color(0.33, 0.30, 0.22)},
    # Пистолеты (ячейка 2)
    "pm": {"category": "pistol", "name": "Пистолет ПМ", "stack": 1, "color": Color(0.28, 0.30, 0.34)},
    "revolver": {"category": "pistol", "name": "Револьвер .44", "stack": 1, "color": Color(0.36, 0.30, 0.24)},
    # Холодное оружие (ячейка 3)
    "knife": {"category": "knife", "name": "Боевой нож", "stack": 1, "color": Color(0.55, 0.58, 0.62)},
    "diamond_sword": {"category": "knife", "name": "Алмазный меч CREATOR", "stack": 1, "color": Color(0.12, 0.75, 1.0)},
    "machete": {"category": "knife", "name": "Мачете", "stack": 1, "color": Color(0.50, 0.53, 0.58)},
    # Обвес (ячейка 4 «Обвес»): работает, пока лежит в этой ячейке
    "collimator": {"category": "attachment", "name": "Коллиматор", "stack": 1, "color": Color(0.22, 0.25, 0.32)},
    # Расходники
    "adrenaline": {"name": "Адреналин", "stack": 5, "color": Color(0.20, 0.84, 0.72)},
    "medkit": {"name": "Аптечка", "stack": 5, "color": Color(0.80, 0.85, 0.88)},
    "ammo_762": {"name": "Патроны 7.62", "stack": 300, "color": Color(0.55, 0.42, 0.18)},
    "ammo_556": {"name": "Патроны 5.56", "stack": 300, "color": Color(0.58, 0.46, 0.20)},
    "ammo_9mm": {"name": "Патроны 9 мм", "stack": 200, "color": Color(0.60, 0.48, 0.24)},
    "ammo_12": {"name": "Патроны 12 калибр", "stack": 60, "color": Color(0.62, 0.20, 0.16)},
    "ammo_44": {"name": "Патроны .44", "stack": 60, "color": Color(0.62, 0.50, 0.22)},
    # Stage84: автоматическая турель (продаётся только в магазинах на карте «Титаник»)
    "turret": {"name": "Турель", "stack": 5, "color": Color(0.20, 0.45, 0.60)},
}
const TURRET_PRICE := 50000
const TURRET_REFILL_PRICE := 15000     # Stage90: +50 патронов в турель

var nickname: String = ""

# Stage126: скин игрока (цвет куртки/шлема/рюкзака модели). 0 = стандартный (цвета по умолчанию в лобби и в бою).
const SKIN_NAMES := ["Стандартный", "Красный", "Синий", "Зелёный", "Жёлтый", "Оранжевый", "Фиолетовый", "Розовый", "Голубой", "Белый", "Чёрный"]
const SKIN_COLORS := [
    Color(0, 0, 0, 0),
    Color(0.85, 0.12, 0.12),
    Color(0.15, 0.32, 0.90),
    Color(0.15, 0.68, 0.25),
    Color(0.95, 0.82, 0.12),
    Color(0.95, 0.50, 0.10),
    Color(0.55, 0.22, 0.80),
    Color(0.95, 0.45, 0.70),
    Color(0.20, 0.75, 0.90),
    Color(0.92, 0.92, 0.92),
    Color(0.14, 0.14, 0.16),
]
var skin: int = 0

static func clamp_skin(value: int) -> int:
    return clampi(value, 0, SKIN_NAMES.size() - 1)


## Цвет модели для скина; для стандартного (0) возвращает fallback (прежние цвета сцены).
static func skin_color(index: int, fallback: Color) -> Color:
    var i := clamp_skin(index)
    return fallback if i == 0 else SKIN_COLORS[i]


func set_skin(index: int) -> void:
    skin = clamp_skin(index)
    changed.emit()
    save_profile()
var money: int = START_MONEY
const DOWNED_PISTOL_PRICE := 50000
var downed_pistol_talent: bool = false
var creator_failures: int = 0
var creator_unlocked: bool = false
var creator_locked: bool = false
var inventory: Array = []   # INV_SIZE ячеек: {} или {"id": String, "count": int}
var equipment: Array = []   # GEAR_SIZE ячеек: всё отсюда попадает в игру

# Временный инвентарь боя: никогда не записывается в profile.json.
var battle_active: bool = false
var battle_inventory: Array = []
var battle_equipment: Array = []

func begin_battle() -> void:
    battle_inventory = _empty(INV_SIZE)
    battle_equipment = _empty(GEAR_SIZE)
    # Копируем только снаряжение лобби, без ссылок на исходные словари.
    for i in mini(GEAR_SIZE, equipment.size()):
        if Net.game_mode != Net.MODE_SURVIVAL:
            battle_equipment[i] = _clean_stack(equipment[i]).duplicate(true)
    battle_active = true
    changed.emit()

## Поражение: удаляем из постоянного снаряжения только предметы,
## с которыми игрок начал раунд. Выход из боя также считается поражением.
func win_zombie_battle() -> void:
    if not battle_active:
        return
    # Save every surviving equipped item and any newly equipped battle item.
    for i in mini(GEAR_SIZE, battle_equipment.size()):
        equipment[i] = _clean_stack(battle_equipment[i]).duplicate(true)
    money = mini(MAX_MONEY, money + 10000)
    save_profile()
    end_battle()

## Stage87: игрок сел в вертолёт. Снаряжение сохраняется, на счёт идёт WAVE_BONUS * номер волны.
## Бой для этого игрока закончен (end_battle), поэтому позднее lose_battle() уже ничего не отнимет.
func evacuate_zombie_battle(bonus: int) -> void:
    if not battle_active:
        return
    for i in mini(GEAR_SIZE, battle_equipment.size()):
        equipment[i] = _clean_stack(battle_equipment[i]).duplicate(true)
    money = mini(MAX_MONEY, money + maxi(0, bonus))
    save_profile()
    end_battle()

## Stage90: списать деньги профиля (покупка патронов для турели).
func spend_money(amount: int) -> bool:
    if amount < 0 or money < amount:
        return false
    money -= amount
    save_profile()
    changed.emit()
    return true

func lose_battle() -> void:
    if not battle_active:
        return
    # Снаряжение лобби не меняется во время боя, поэтому очищаем его слоты.
    for i in equipment.size():
        if str(equipment[i].get("id", "")) != "diamond_sword":
            equipment[i] = {}
    save_profile()
    end_battle()

func end_battle() -> void:
    battle_active = false
    battle_inventory.clear()
    battle_equipment.clear()
    changed.emit()

func get_slots(container: String) -> Array:
    return _bag(container)


func _ready() -> void:
    if not load_profile():
        _new_profile()
        save_profile()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST \
            or what == NOTIFICATION_APPLICATION_PAUSED \
            or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        save_profile()


func _exit_tree() -> void:
    save_profile()


# ---------- профиль ----------

func _new_profile() -> void:
    nickname = default_nick()
    money = START_MONEY
    downed_pistol_talent = false
    creator_failures = 0
    creator_unlocked = false
    creator_locked = false
    inventory = _empty(INV_SIZE)
    equipment = _empty(GEAR_SIZE)
    inventory[0] = {"id": "ak47", "count": 1}
    inventory[1] = {"id": "medkit", "count": 1}
    inventory[2] = {"id": "ammo_762", "count": 120}


func default_nick() -> String:
    var n: String = ""
    if OS.has_feature("android") or OS.has_feature("ios"):
        n = OS.get_model_name()
    if n == "" or n == "GenericDevice":
        n = OS.get_environment("USERNAME")
    if n == "":
        n = OS.get_environment("USER")
    n = clean_nick(n)
    if n.length() < MIN_NICK:
        n = "Player"
    return n


func clean_nick(value: String) -> String:
    var s: String = value.replace("\n", " ").replace("\t", " ").strip_edges()
    return s.substr(0, MAX_NICK)


func set_nickname(value: String) -> bool:
    var c: String = clean_nick(value)
    if c.length() < MIN_NICK:
        return false
    if c.to_upper() == "CREATORGAME" and (creator_locked or not creator_unlocked):
        return false
    nickname = c
    changed.emit()
    save_profile()
    return true


func check_creator_password(value: String) -> bool:
    if creator_locked:
        return false
    if value == "mifaogames":
        if not creator_unlocked:
            money = mini(MAX_MONEY, money + CREATOR_REWARD)
        creator_unlocked = true
        nickname = "CREATORGAME"
        save_profile()
        changed.emit()
        return true
    creator_failures += 1
    if creator_failures >= 3:
        creator_locked = true
    save_profile()
    changed.emit()
    return false


func set_money(value: int) -> void:
    money = clampi(value, 0, MAX_MONEY)
    changed.emit()
    save_profile()


# Магазин лобби: покупка только в постоянный инвентарь.
const SHOP := {
    "ak47": {"price": 8000, "count": 1},
    "m4a1": {"price": 11500, "count": 1},
    "shotgun": {"price": 6500, "count": 1},
    "svd": {"price": 15000, "count": 1},
    "pm": {"price": 1800, "count": 1},
    "revolver": {"price": 5200, "count": 1},
    "knife": {"price": 400, "count": 1},
    "machete": {"price": 900, "count": 1},
    "collimator": {"price": 2800, "count": 1},
    "medkit": {"price": 240, "count": 1},
    "adrenaline": {"price": 15000, "count": 1},
    "ammo_762": {"price": 430, "count": 120},
    "ammo_556": {"price": 480, "count": 120},
    "ammo_9mm": {"price": 260, "count": 120},
    "ammo_12": {"price": 380, "count": 24},
    "ammo_44": {"price": 420, "count": 36},
}

func buy_item(item_id: String) -> String:
    if not SHOP.has(item_id):
        return "Предмет не продаётся"
    if battle_active:
        return "Покупки доступны только в лобби"
    var price: int = int(SHOP[item_id]["price"])
    var count: int = int(SHOP[item_id]["count"])
    if money < price:
        return "Недостаточно денег"
    var capacity: int = 0
    var limit: int = int(ITEMS[item_id]["stack"])
    for slot in inventory:
        if slot.is_empty():
            capacity += limit
        elif str(slot.get("id", "")) == item_id:
            capacity += maxi(0, limit - int(slot.get("count", 0)))
    if capacity < count:
        return "Недостаточно места в инвентаре"
    var remaining: int = count
    for i in inventory.size():
        if remaining == 0:
            break
        var slot: Dictionary = inventory[i]
        if not slot.is_empty() and str(slot.get("id", "")) == item_id:
            var amount: int = mini(remaining, limit - int(slot["count"]))
            slot["count"] = int(slot["count"]) + amount
            remaining -= amount
    for i in inventory.size():
        if remaining == 0:
            break
        if inventory[i].is_empty():
            var amount: int = mini(remaining, limit)
            inventory[i] = {"id": item_id, "count": amount}
            remaining -= amount
    money -= price
    save_profile()
    changed.emit()
    return "Куплено: %s" % ITEMS[item_id]["name"]


func format_money(amount: int) -> String:
    var digits: String = str(maxi(amount, 0))
    var out: String = ""
    while digits.length() > 3:
        out = "." + digits.substr(digits.length() - 3, 3) + out
        digits = digits.substr(0, digits.length() - 3)
    return digits + out


# ---------- сохранение ----------

func save_profile() -> void:
    var data := {
        "version": 3,
        "nick": nickname,
        "skin": skin,
        "money": money,
        "downed_pistol_talent": downed_pistol_talent,
        "creator_failures": creator_failures,
        "creator_unlocked": creator_unlocked,
        "creator_locked": creator_locked,
        "inventory": inventory,
        "equipment": equipment,
    }
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f == null:
        push_warning("Не удалось сохранить профиль: %s" % FileAccess.get_open_error())
        return
    f.store_string(JSON.stringify(data))
    f.close()


func load_profile() -> bool:
    if not FileAccess.file_exists(SAVE_PATH):
        return false
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
    if typeof(parsed) != TYPE_DICTIONARY:
        return false
    var d: Dictionary = parsed
    nickname = clean_nick(str(d.get("nick", "")))
    if nickname.length() < MIN_NICK:
        nickname = default_nick()
    skin = clamp_skin(int(d.get("skin", 0)))
    money = clampi(int(d.get("money", START_MONEY)), 0, MAX_MONEY)
    downed_pistol_talent = bool(d.get("downed_pistol_talent", false))
    creator_failures = clampi(int(d.get("creator_failures", 0)), 0, 3)
    creator_unlocked = bool(d.get("creator_unlocked", false))
    creator_locked = bool(d.get("creator_locked", false)) or creator_failures >= 3
    if nickname.to_upper() == "CREATORGAME" and not creator_unlocked:
        nickname = default_nick()
    inventory = _load_slots(d.get("inventory", []), INV_SIZE)
    equipment = _load_slots(d.get("equipment", []), GEAR_SIZE)
    _migrate_attach_slot()
    # Preserve two extra equipment slots from the older 15-slot profile.
    var old_gear = d.get("equipment", [])
    if typeof(old_gear) == TYPE_ARRAY:
        for i in range(GEAR_SIZE, old_gear.size()):
            var extra: Dictionary = _clean_stack(old_gear[i])
            if not extra.is_empty():
                for j in inventory.size():
                    if inventory[j].is_empty():
                        inventory[j] = extra
                        break
    return true


## Ячейка «Обвес» принимает только обвес: прежний предмет из неё уходит в инвентарь.
func _migrate_attach_slot() -> void:
    if equipment.size() <= ATTACH_SLOT:
        return
    var stack: Dictionary = equipment[ATTACH_SLOT]
    if stack.is_empty():
        return
    if str(ITEMS.get(str(stack.get("id", "")), {}).get("category", "")) == "attachment":
        return
    for j in inventory.size():
        if inventory[j].is_empty():
            inventory[j] = stack
            equipment[ATTACH_SLOT] = {}
            return


## Стоит ли обвес с этим id в ячейке «Обвес» (в бою — во временном снаряжении боя).
func has_attachment(item_id: String) -> bool:
    var gear: Array = _bag("gear")
    if ATTACH_SLOT >= gear.size():
        return false
    return str(gear[ATTACH_SLOT].get("id", "")) == item_id


func _empty(n: int) -> Array:
    var a: Array = []
    for i in n:
        a.append({})
    return a


func _load_slots(raw, size: int) -> Array:
    var out: Array = _empty(size)
    if typeof(raw) != TYPE_ARRAY:
        return out
    for i in mini(size, raw.size()):
        out[i] = _clean_stack(raw[i])
    return out


func _clean_stack(v) -> Dictionary:
    if typeof(v) != TYPE_DICTIONARY:
        return {}
    var id: String = str(v.get("id", ""))
    if not ITEMS.has(id):
        return {}
    var count: int = int(v.get("count", 1))
    if count < 1:
        return {}
    return {"id": id, "count": mini(count, int(ITEMS[id]["stack"]))}


## Проверка инвентаря/снаряжения боя, пришедшего по сети или из файла: размер фиксирован, предметы только известные.
func sanitize_battle_slots(raw, size: int) -> Array:
    return _load_slots(raw, size)


## Проверка снаряжения, пришедшего по сети (Host не доверяет Client слепо).
func sanitize_loadout(arr: Array) -> Array:
    var out: Array = []
    for v in arr:
        var s: Dictionary = _clean_stack(v)
        if not s.is_empty():
            out.append(s)
        if out.size() >= GEAR_SIZE:
            break
    return out


## Оружие, которое персонаж держит в руках в лобби (Stage82):
## автомат/винтовка из ячейки 1; если там пусто — пистолет из ячейки 2; иначе пусто.
func get_hand_weapon() -> String:
    return hand_weapon_from(equipment)


## Тот же выбор для произвольного массива ячеек (индекс 0 = ячейка 1, индекс 1 = ячейка 2).
static func hand_weapon_from(slots: Array) -> String:
    var wanted := ["rifle", "pistol"]
    for i in range(wanted.size()):
        if i >= slots.size():
            break
        var stack: Dictionary = slots[i]
        if stack.is_empty():
            continue
        var id: String = str(stack.get("id", ""))
        if ITEMS.has(id) and str(ITEMS[id].get("category", "")) == wanted[i]:
            return id
    return ""


## То, что уходит в игру: непустые ячейки инвентаря снаряжения.
func get_loadout() -> Array:
    var out: Array = []
    for s in equipment:
        var d: Dictionary = s
        if not d.is_empty():
            out.append(d.duplicate())
    return out


# ---------- перемещение предметов ----------

func _bag(container: String) -> Array:
    if container == "inv":
        return battle_inventory if battle_active else inventory
    if container == "gear":
        return battle_equipment if battle_active else equipment
    return []


## Специальные ячейки: автомат, пистолет, нож, броня, Jetpack.
## Все остальные предметы разрешены в обычном инвентаре.
func can_place(container: String, index: int, item: Dictionary) -> bool:
    if item.is_empty() or container == "inv":
        return true
    if container != "gear" or index < 0 or index >= GEAR_SIZE:
        return false
    var id: String = str(item.get("id", ""))
    var category: String = str(ITEMS.get(id, {}).get("category", "other"))
    var allowed := ["rifle", "pistol", "knife", "attachment"]
    if index >= allowed.size():
        return true
    return category == allowed[index]


func move_item(from_c: String, from_i: int, to_c: String, to_i: int) -> void:
    var src: Array = _bag(from_c)
    var dst: Array = _bag(to_c)
    if from_i < 0 or from_i >= src.size() or to_i < 0 or to_i >= dst.size():
        return
    if from_c == to_c and from_i == to_i:
        return
    var a: Dictionary = src[from_i]
    var b: Dictionary = dst[to_i]
    if a.is_empty():
        return
    if not can_place(to_c, to_i, a) or not can_place(from_c, from_i, b):
        return
    if not b.is_empty() and str(a["id"]) == str(b["id"]):
        # одинаковые предметы: объединяем стаки
        var limit: int = int(ITEMS[str(a["id"])]["stack"])
        var moved: int = mini(limit - int(b["count"]), int(a["count"]))
        if moved <= 0:
            return
        b["count"] = int(b["count"]) + moved
        a["count"] = int(a["count"]) - moved
        if int(a["count"]) <= 0:
            src[from_i] = {}
    else:
        # пустая ячейка или другой предмет: меняем местами
        src[from_i] = b
        dst[to_i] = a
    changed.emit()
    if not battle_active:
        save_profile()


## Двойной тап: быстро перекинуть предмет в другой инвентарь.
func quick_move(from_c: String, from_i: int) -> void:
    var src: Array = _bag(from_c)
    if from_i < 0 or from_i >= src.size():
        return
    var a: Dictionary = src[from_i]
    if a.is_empty():
        return
    var dst: Array = _bag("gear" if from_c == "inv" else "inv")
    var limit: int = int(ITEMS[str(a["id"])]["stack"])
    var left: int = int(a["count"])
    for i in dst.size():
        var slot: Dictionary = dst[i]
        if not can_place("gear" if from_c == "inv" else "inv", i, a):
            continue
        if left <= 0:
            break
        var s: Dictionary = slot
        if not s.is_empty() and str(s["id"]) == str(a["id"]):
            var m: int = mini(limit - int(s["count"]), left)
            if m > 0:
                s["count"] = int(s["count"]) + m
                left -= m
    if left > 0:
        for i in dst.size():
            var s2: Dictionary = dst[i]
            if s2.is_empty() and can_place("gear" if from_c == "inv" else "inv", i, a):
                dst[i] = {"id": a["id"], "count": left}
                left = 0
                break
    if left <= 0:
        src[from_i] = {}
    else:
        a["count"] = left
    changed.emit()
    if not battle_active:
        save_profile()


## Sell one shop unit, or one entire AK-47, from the selected lobby slot.

# Стоимость продажи всего инвентаря лобби (включая экипировку).
# Неполные пачки патронов оцениваются пропорционально количеству.
func get_sell_all_total() -> int:
    var total: int = 0
    for slots in [inventory, equipment]:
        for raw_stack in slots:
            if typeof(raw_stack) != TYPE_DICTIONARY:
                continue
            var stack: Dictionary = raw_stack
            var item_id: String = str(stack.get("id", ""))
            if not SHOP.has(item_id):
                continue
            var amount: int = maxi(0, int(stack.get("count", 0)))
            var lot_size: int = maxi(1, int(SHOP[item_id]["count"]))
            var lot_price: int = int(SHOP[item_id]["price"]) / 2
            total += (amount * lot_price) / lot_size
    return total


func sell_all_items() -> String:
    if battle_active:
        return "Продажа доступна только в лобби"
    var total: int = get_sell_all_total()
    var has_items: bool = false
    for slots in [inventory, equipment]:
        for stack in slots:
            if typeof(stack) == TYPE_DICTIONARY and not stack.is_empty():
                has_items = true
                break
    if not has_items:
        return "Инвентарь пуст"
    if total > MAX_MONEY - money:
        return "Нельзя продать: превышен лимит денег"
    # После подтверждения очищаются обе части инвентаря.
    var protected_items: Array = []
    for slots in [inventory, equipment]:
        for stack in slots:
            if typeof(stack) == TYPE_DICTIONARY and str(stack.get("id", "")) == "diamond_sword":
                protected_items.append(stack.duplicate(true))
    inventory = _empty(INV_SIZE)
    equipment = _empty(GEAR_SIZE)
    for stack in protected_items:
        var target: Array = equipment if equipment[2].is_empty() else inventory
        var index: int = 2 if target == equipment else target.find({})
        if index >= 0:
            target[index] = stack
    money += total
    save_profile()
    changed.emit()
    return "Весь инвентарь продан за %s $" % format_money(total)

func sell_selected(container: String, index: int) -> String:
    if battle_active:
        return "Продажа доступна только в лобби"
    var slots: Array = _bag(container)
    if index < 0 or index >= slots.size() or slots[index].is_empty():
        return "Выберите предмет"
    var stack: Dictionary = slots[index]
    var id: String = str(stack["id"])
    if not SHOP.has(id):
        return "Этот предмет нельзя продать"
    var unit_count: int = int(SHOP[id]["count"])
    if int(stack["count"]) < unit_count:
        return "Для продажи нужна полная пачка"
    var price: int = int(SHOP[id]["price"]) / 2
    stack["count"] = int(stack["count"]) - unit_count
    if int(stack["count"]) <= 0:
        slots[index] = {}
    money += price
    save_profile()
    changed.emit()
    return "Продано за %d $" % price

func equip_selected(container: String, index: int) -> String:
    if battle_active:
        return "Недоступно во время боя"
    if container != "inv" or index < 0 or index >= inventory.size():
        return "Выберите предмет справа"
    var item: Dictionary = inventory[index]
    if item.is_empty():
        return "Выберите предмет"
    var category: String = str(ITEMS.get(str(item["id"]), {}).get("category", "other"))
    var target: int = -1
    match category:
        "rifle": target = 0
        "pistol": target = 1
        "knife": target = 2
        "attachment": target = ATTACH_SLOT
        _:
            for i in range(ATTACH_SLOT + 1, equipment.size()):
                if equipment[i].is_empty():
                    target = i
                    break
    if target < 0:
        return "Нет свободного слота снаряжения"
    if not equipment[target].is_empty():
        return "Нужный слот занят"
    move_item("inv", index, "gear", target)
    return "Предмет добавлен в снаряжение"


# Покупка нескольких лотов за одну атомарную операцию.
func buy_item_quantity(item_id: String, quantity: int) -> String:
    if not SHOP.has(item_id) or not ITEMS.has(item_id):
        return "Предмет не продаётся"
    if battle_active:
        return "Покупки доступны только в лобби"
    if quantity < 1 or quantity > 999:
        return "Количество должно быть от 1 до 999"
    var unit_price: int = int(SHOP[item_id]["price"])
    var unit_count: int = int(SHOP[item_id]["count"])
    var total_price: int = unit_price * quantity
    var total_count: int = unit_count * quantity
    if money < total_price:
        return "Недостаточно денег"
    var limit: int = int(ITEMS[item_id]["stack"])
    var capacity: int = 0
    for slot in inventory:
        if slot.is_empty():
            capacity += limit
        elif str(slot.get("id", "")) == item_id:
            capacity += maxi(0, limit - int(slot.get("count", 0)))
    if capacity < total_count:
        return "Недостаточно места в инвентаре"
    var remaining: int = total_count
    for i in inventory.size():
        if remaining == 0:
            break
        var slot: Dictionary = inventory[i]
        if not slot.is_empty() and str(slot.get("id", "")) == item_id:
            var amount: int = mini(remaining, limit - int(slot["count"]))
            slot["count"] = int(slot["count"]) + amount
            remaining -= amount
    for i in inventory.size():
        if remaining == 0:
            break
        if inventory[i].is_empty():
            var amount: int = mini(remaining, limit)
            inventory[i] = {"id": item_id, "count": amount}
            remaining -= amount
    money -= total_price
    save_profile()
    changed.emit()
    return "Куплено: %s × %d" % [str(ITEMS[item_id]["name"]), quantity]

## Stage84: покупка турели в магазине на карте (только в бою, в ячейки снаряжения «Предметы»).
func buy_turret() -> String:
    if not battle_active:
        return "Турели продаются только в бою"
    if money < TURRET_PRICE:
        return "Недостаточно денег"
    var limit: int = int(ITEMS["turret"]["stack"])
    var target := -1
    for i in range(ATTACH_SLOT + 1, battle_equipment.size()):
        var slot: Dictionary = battle_equipment[i]
        if not slot.is_empty() and str(slot.get("id", "")) == "turret" and int(slot.get("count", 0)) < limit:
            target = i
            break
    if target < 0:
        for i in range(ATTACH_SLOT + 1, battle_equipment.size()):
            if battle_equipment[i].is_empty():
                target = i
                break
    if target < 0:
        return "Нет места в инвентаре"
    if battle_equipment[target].is_empty():
        battle_equipment[target] = {"id": "turret", "count": 1}
    else:
        battle_equipment[target]["count"] = int(battle_equipment[target]["count"]) + 1
    money -= TURRET_PRICE
    save_profile()
    changed.emit()
    return "Куплено: Турель"


## Сколько штук предмета лежит в ячейках снаряжения боя.
func count_battle_item(item_id: String) -> int:
    var total := 0
    for slot in battle_equipment:
        if not slot.is_empty() and str(slot.get("id", "")) == item_id:
            total += int(slot.get("count", 0))
    return total


## Списывает одну штуку предмета из снаряжения боя (после одобрения хостом).
func consume_battle_item(item_id: String) -> bool:
    for i in battle_equipment.size():
        var slot: Dictionary = battle_equipment[i]
        if slot.is_empty() or str(slot.get("id", "")) != item_id:
            continue
        var left: int = int(slot.get("count", 1)) - 1
        if left <= 0:
            battle_equipment[i] = {}
        else:
            slot["count"] = left
        changed.emit()
        return true
    return false


func buy_downed_pistol_talent() -> bool:
    if downed_pistol_talent or money < DOWNED_PISTOL_PRICE or battle_active:
        return false
    money -= DOWNED_PISTOL_PRICE
    downed_pistol_talent = true
    save_profile()
    changed.emit()
    return true
