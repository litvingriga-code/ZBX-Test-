extends Control
## Интерфейс лобби.
##  слева сверху: статус сети и ник     справа сверху: [Выйти] [Друзья]
##  справа снизу: [Магазин] [Инвентарь]  справа по центру: приглашение

const StageScript = preload("res://scripts/lobby_stage.gd")
const SlotScript = preload("res://scripts/item_slot.gd")
const UiGray = preload("res://scripts/ui_gray.gd")

var stage: Control
var status_label: Label
var nick_edit: LineEdit
var friends_btn: Button
var leave_btn: Button
var friends_panel: PanelContainer
var friends_list: VBoxContainer
var invite_panel: PanelContainer
var invite_nick: Label
var inventory_panel: PanelContainer
var shop_panel: PanelContainer
var notice_label: Label
var notice_until: int = 0
var inv_slots: Array = []
var gear_slots: Array = []
var selected_container: String = ""
var selected_index: int = -1
var creator_overlay: ColorRect
var creator_password: LineEdit
var creator_feedback: Label
var creator_pending: bool = false
var creator_panel_button: Button
var creator_panel: PanelContainer


var lobby_background: TextureRect
var background_panel: PanelContainer
var background_dialog: FileDialog
var background_download_button: Button

var music_player: AudioStreamPlayer
var music_panel: PanelContainer
var music_dialog: FileDialog
var music_settings_panel: PanelContainer
var skin_panel: PanelContainer
var skin_buttons: Array = []
var music_volume_slider: HSlider
var music_volume_label: Label
var online_panel: PanelContainer
var online_ip_edit: LineEdit
var online_port_edit: LineEdit
var online_status: Label
var public_ip_label: Label
var public_ip_request: HTTPRequest
var public_ipv4: String = ""

func _apply_lobby_music(data: PackedByteArray) -> void:
    music_player.stop()
    music_player.stream = null
    if data.is_empty():
        return
    var stream := AudioStreamMP3.load_from_buffer(data)
    if stream == null:
        push_warning("Не удалось воспроизвести MP3 лобби")
        return
    stream.loop = true
    music_player.stream = stream
    music_player.play()

func _apply_lobby_music_volume(value: float) -> void:
    music_player.volume_linear = clampf(value / 100.0, 0.0, 1.0)
    if music_volume_slider != null:
        music_volume_slider.set_value_no_signal(value)
    if music_volume_label != null:
        music_volume_label.text = "Громкость музыки: %d" % roundi(value)

func _choose_music_file(path: String) -> void:
    if Net.role == "client":
        _show_notice("Музыку выбирает Host")
        return
    if not path.to_lower().ends_with(".mp3"):
        _show_notice("Выберите файл MP3")
        return
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null or file.get_length() > Net.MAX_MUSIC_BYTES:
        _show_notice("MP3 слишком большой (максимум 12 МБ)")
        return
    var data := file.get_buffer(file.get_length())
    Net.set_lobby_music(data)
    music_panel.hide()

func _build_music_ui() -> void:
    music_player = AudioStreamPlayer.new()
    add_child(music_player)
    Net.lobby_music_changed.connect(_apply_lobby_music)
    Net.lobby_music_volume_changed.connect(_apply_lobby_music_volume)
    _apply_lobby_music_volume(Net.lobby_music_volume)
    _apply_lobby_music(Net.lobby_music_data)
    music_panel = PanelContainer.new()
    music_panel.visible = false
    _place(music_panel, 0.5, 0.5, 0, 0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_BOTH)
    add_child(music_panel)
    var column := VBoxContainer.new()
    music_panel.add_child(column)
    column.add_child(_label("Музыка лобби (MP3)", 26))
    var import_btn := _button("Импортировать MP3", Vector2(340, 65))
    import_btn.pressed.connect(func(): music_dialog.popup_centered_ratio(0.8))
    column.add_child(import_btn)
    var close_btn := _button("Закрыть", Vector2(340, 55))
    close_btn.pressed.connect(func(): music_panel.hide())
    column.add_child(close_btn)
    music_dialog = FileDialog.new()
    music_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
    music_dialog.access = FileDialog.ACCESS_FILESYSTEM
    music_dialog.use_native_dialog = false
    music_dialog.filters = PackedStringArray(["*.mp3 ; MP3 audio"])
    music_dialog.file_selected.connect(_choose_music_file)
    add_child(music_dialog)
    music_settings_panel = PanelContainer.new()
    music_settings_panel.visible = false
    _place(music_settings_panel, 0.5, 0.5, 0, 0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_BOTH)
    add_child(music_settings_panel)
    var settings_column := VBoxContainer.new()
    music_settings_panel.add_child(settings_column)
    music_volume_label = _label("Громкость музыки: 100", 26)
    settings_column.add_child(music_volume_label)
    music_volume_slider = HSlider.new()
    music_volume_slider.custom_minimum_size = Vector2(340, 55)
    music_volume_slider.min_value = 0
    music_volume_slider.max_value = 100
    music_volume_slider.step = 1
    music_volume_slider.value_changed.connect(func(value: float): Net.set_lobby_music_volume(value))
    settings_column.add_child(music_volume_slider)
    var floor_toggle := CheckBox.new()
    floor_toggle.text = "Пол в лобби"
    floor_toggle.tooltip_text = "Без пола персонажи остаются на месте, а фон виден полностью."
    var floor_cfg := ConfigFile.new()
    floor_cfg.load("user://lobby_visual_settings.cfg")
    floor_toggle.button_pressed = bool(floor_cfg.get_value("visual", "floor_visible", true))
    stage.set_floor_visible(floor_toggle.button_pressed)
    floor_toggle.toggled.connect(func(enabled: bool):
        stage.set_floor_visible(enabled)
        floor_cfg.set_value("visual", "floor_visible", enabled)
        floor_cfg.save("user://lobby_visual_settings.cfg")
    )
    settings_column.add_child(floor_toggle)
    var friendly_fire_toggle := CheckBox.new()
    friendly_fire_toggle.text = "Урон по союзникам"
    friendly_fire_toggle.button_pressed = Net.friendly_fire_enabled
    friendly_fire_toggle.disabled = Net.role == "client"
    friendly_fire_toggle.tooltip_text = "Только хост может менять. Выключено: игроки не наносят урон друг другу."
    friendly_fire_toggle.toggled.connect(func(enabled: bool): Net.set_friendly_fire(enabled))
    settings_column.add_child(friendly_fire_toggle)
    Net.friendly_fire_changed.connect(func(enabled: bool):
        friendly_fire_toggle.set_pressed_no_signal(enabled)
    )
    var refresh_friendly_fire := func():
        friendly_fire_toggle.disabled = Net.role == "client"
        friendly_fire_toggle.set_pressed_no_signal(Net.friendly_fire_enabled)
    music_settings_panel.visibility_changed.connect(func():
        if music_settings_panel.visible:
            refresh_friendly_fire.call()
    )
    var no_bots_toggle := CheckBox.new()
    no_bots_toggle.text = "Бой без ИИ (снять галочку — добавить ботов)"
    no_bots_toggle.button_pressed = Net.bots_disabled
    no_bots_toggle.disabled = Net.role == "client"
    no_bots_toggle.toggled.connect(func(enabled: bool): Net.set_bots_disabled(enabled))
    settings_column.add_child(no_bots_toggle)
    Net.bots_setting_changed.connect(func(enabled: bool):
        no_bots_toggle.set_pressed_no_signal(enabled)
    )
    music_settings_panel.visibility_changed.connect(func():
        if music_settings_panel.visible:
            no_bots_toggle.disabled = Net.role == "client"
            no_bots_toggle.set_pressed_no_signal(Net.bots_disabled)
    )
    var bot_count_label := _label("Количество ботов (1–5)", 22)
    settings_column.add_child(bot_count_label)
    var bot_count_input := SpinBox.new()
    bot_count_input.min_value = 1
    bot_count_input.max_value = 5
    bot_count_input.step = 1
    bot_count_input.rounded = true
    bot_count_input.value = Net.bot_count
    bot_count_input.custom_minimum_size = Vector2(200, 48)
    bot_count_input.editable = Net.role != "client"
    bot_count_input.value_changed.connect(func(value: float): Net.set_bot_options(int(value), Net.bot_aggression_checked))
    settings_column.add_child(bot_count_input)
    var bot_aggression_toggle := CheckBox.new()
    bot_aggression_toggle.text = "Агрессия (снять галочку — боты атакуют сразу)"
    bot_aggression_toggle.button_pressed = Net.bot_aggression_checked
    bot_aggression_toggle.disabled = Net.role == "client"
    bot_aggression_toggle.toggled.connect(func(enabled: bool): Net.set_bot_options(Net.bot_count, enabled))
    settings_column.add_child(bot_aggression_toggle)
    Net.bot_options_changed.connect(func():
        bot_count_input.set_value_no_signal(Net.bot_count)
        bot_aggression_toggle.set_pressed_no_signal(Net.bot_aggression_checked)
    )
    music_settings_panel.visibility_changed.connect(func():
        if music_settings_panel.visible:
            bot_count_input.editable = Net.role != "client"
            bot_aggression_toggle.disabled = Net.role == "client"
            bot_count_input.set_value_no_signal(Net.bot_count)
            bot_aggression_toggle.set_pressed_no_signal(Net.bot_aggression_checked)
    )
    var skin_button := _button("Скин игрока", Vector2(340, 55))
    skin_button.pressed.connect(func():
        music_settings_panel.hide()
        _refresh_skin_marks()
        skin_panel.show()
    )
    settings_column.add_child(skin_button)
    _build_skin_panel()
    # Запасная кнопка паузы в бою: 0 выкл (по умолчанию), 1 авто (только если оригинальной нет), 2 всегда.
    var pause_modes := ["Выкл", "Авто (если нет оригинальной)", "Вкл"]
    var pause_cfg := ConfigFile.new()
    pause_cfg.load("user://battle_settings.cfg")
    var pause_mode := clampi(int(pause_cfg.get_value("general", "pause_fallback", 0)), 0, 2)
    var pause_fallback_button := _button("Запасная пауза: " + pause_modes[pause_mode], Vector2(340, 55))
    pause_fallback_button.tooltip_text = "Дополнительная кнопка паузы сверху экрана в бою. Авто: показывается, только если оригинальной кнопки не видно."
    pause_fallback_button.pressed.connect(func():
        pause_mode = (pause_mode + 1) % pause_modes.size()
        pause_fallback_button.text = "Запасная пауза: " + pause_modes[pause_mode]
        var save_cfg := ConfigFile.new()
        save_cfg.load("user://battle_settings.cfg")
        save_cfg.set_value("general", "pause_fallback", pause_mode)
        save_cfg.save("user://battle_settings.cfg")
    )
    settings_column.add_child(pause_fallback_button)
    var mobile_reset := _button("Сбросить мобильное управление", Vector2(340, 55))
    mobile_reset.pressed.connect(_reset_saved_mobile_layout)
    settings_column.add_child(mobile_reset)
    var settings_close := _button("Закрыть", Vector2(340, 55))
    settings_close.pressed.connect(func(): music_settings_panel.hide())
    settings_column.add_child(settings_close)
    _apply_lobby_music_volume(Net.lobby_music_volume)

## Stage126: окно выбора скина. Нажатие на цвет сразу применяет его (модель в лобби перекрашивается)
## и закрывает окно, чтобы было видно персонажа.
func _build_skin_panel() -> void:
    skin_panel = PanelContainer.new()
    skin_panel.visible = false
    _place(skin_panel, 0.5, 0.5, 0, 0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_BOTH)
    add_child(skin_panel)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 8)
    skin_panel.add_child(column)
    column.add_child(_label("Скин игрока", 26))
    var grid := GridContainer.new()
    grid.columns = 2
    grid.add_theme_constant_override("h_separation", 8)
    grid.add_theme_constant_override("v_separation", 8)
    column.add_child(grid)
    skin_buttons.clear()
    for i in GameState.SKIN_NAMES.size():
        var b := _button(str(GameState.SKIN_NAMES[i]), Vector2(200, 52))
        var fill: Color = GameState.SKIN_COLORS[i] if i > 0 else Color(0.34, 0.34, 0.37)
        for state in ["normal", "hover", "pressed"]:
            var box := StyleBoxFlat.new()
            box.bg_color = fill.lightened(0.12) if state == "hover" else fill
            box.set_corner_radius_all(10)
            box.set_content_margin_all(8)
            box.set_border_width_all(2)
            box.border_color = Color(1, 1, 1, 0.35)
            b.add_theme_stylebox_override(state, box)
        # Светлым скинам — тёмный текст, тёмным — белый, чтобы название читалось.
        var dark_text := fill.get_luminance() > 0.55
        b.add_theme_color_override("font_color", Color(0.05, 0.05, 0.08) if dark_text else Color.WHITE)
        b.add_theme_color_override("font_hover_color", Color(0.05, 0.05, 0.08) if dark_text else Color.WHITE)
        b.add_theme_color_override("font_pressed_color", Color(0.05, 0.05, 0.08) if dark_text else Color.WHITE)
        b.pressed.connect(func():
            GameState.set_skin(i)
            _refresh_skin_marks()
            skin_panel.hide()
        )
        grid.add_child(b)
        skin_buttons.append(b)
    var close := _button("Закрыть", Vector2(340, 55))
    close.pressed.connect(func(): skin_panel.hide())
    column.add_child(close)


## Выбранный скин отмечается галочкой и белой рамкой.
func _refresh_skin_marks() -> void:
    for i in skin_buttons.size():
        var b: Button = skin_buttons[i]
        var selected: bool = i == GameState.skin
        b.text = ("✓ " if selected else "") + str(GameState.SKIN_NAMES[i])
        for state in ["normal", "hover", "pressed"]:
            var box := b.get_theme_stylebox(state) as StyleBoxFlat
            if box != null:
                box.border_color = Color(1, 1, 1, 1.0) if selected else Color(1, 1, 1, 0.35)
                box.set_border_width_all(5 if selected else 2)


func _reset_saved_mobile_layout() -> void:
    # Reset only the saved mobile HUD positions and sizes.
    # Keep brightness, volume and PC key bindings unchanged.
    var cfg := ConfigFile.new()
    if cfg.load("user://battle_settings.cfg") == OK:
        if cfg.has_section("layout"):
            cfg.erase_section("layout")
        if cfg.has_section("sizes"):
            cfg.erase_section("sizes")
        if cfg.save("user://battle_settings.cfg") != OK:
            _show_notice("Не удалось сохранить сброс управления")
            return
    _show_notice("Мобильная раскладка сброшена. Применится в следующем бою")

func _apply_background_bytes(data: PackedByteArray) -> void:
    if data.is_empty():
        lobby_background.texture = null
        return
    var image := Image.new()
    var err := image.load_png_from_buffer(data)
    if err != OK:
        err = image.load_jpg_from_buffer(data)
    if err != OK or image.get_width() > 2048 or image.get_height() > 2048:
        return
    lobby_background.texture = ImageTexture.create_from_image(image)
    if is_instance_valid(background_download_button):
        _update_background_download_button()

func _choose_background_file(path: String) -> void:
    var image := Image.new()
    var err := image.load(path)
    if err != OK:
        push_warning("Не удалось открыть изображение: %s (ошибка %s)" % [path, err])
        return
    if image.is_empty():
        return
    # Preserve aspect ratio, but keep PNG transfer below ENet's payload limit.
    var max_side := maxi(image.get_width(), image.get_height())
    if max_side > 1024:
        var ratio := 1024.0 / float(max_side)
        image.resize(maxi(1, roundi(image.get_width() * ratio)), maxi(1, roundi(image.get_height() * ratio)))
    var data := image.save_png_to_buffer()
    while data.size() > 1000000 and image.get_width() > 128 and image.get_height() > 128:
        image.resize(maxi(1, image.get_width() / 2), maxi(1, image.get_height() / 2))
        data = image.save_png_to_buffer()
    if data.is_empty() or data.size() > 1000000:
        push_warning("Изображение слишком большое для фона")
        return
    Net.set_lobby_background(data)
    background_panel.hide()

func _build_background_picker() -> void:
    background_panel = PanelContainer.new()
    background_panel.visible = false
    _place(background_panel, 0.5, 0.5, 0, 0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_BOTH)
    add_child(background_panel)
    var column := VBoxContainer.new()
    background_panel.add_child(column)
    column.add_child(_button("Фон лобби", Vector2(350, 52)))
    for key in ["evening", "forest", "night"]:
        var path := "res://assets/lobby_backgrounds/%s.png" % key
        var btn := _button(key.capitalize(), Vector2(350, 70))
        btn.icon = load(path)
        btn.expand_icon = true
        btn.pressed.connect(func(): Net.set_lobby_background(FileAccess.get_file_as_bytes(path)); background_panel.hide())
        column.add_child(btn)
    var import_btn := _button("Импортировать PNG/JPG", Vector2(350, 60))
    import_btn.pressed.connect(func(): background_dialog.popup_centered_ratio(0.8))
    column.add_child(import_btn)
    var close_btn := _button("Закрыть", Vector2(350, 55))
    close_btn.pressed.connect(func(): background_panel.hide())
    column.add_child(close_btn)
    background_dialog = FileDialog.new()
    background_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
    background_dialog.access = FileDialog.ACCESS_FILESYSTEM
    background_dialog.use_native_dialog = false
    background_dialog.show_hidden_files = false
    background_dialog.filters = PackedStringArray(["*.png, *.jpg, *.jpeg ; Изображения"])
    background_dialog.file_selected.connect(_choose_background_file)
    add_child(background_dialog)

func _ready() -> void:
    theme = _build_theme()
    stage = StageScript.new()
    add_child(stage)
    lobby_background = TextureRect.new()
    lobby_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    lobby_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    lobby_background.stretch_mode = TextureRect.STRETCH_SCALE
    # Fill each device viewport independently, including different aspect ratios.
    lobby_background.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    lobby_background.size_flags_vertical = Control.SIZE_EXPAND_FILL
    lobby_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(lobby_background)
    # Render the chosen image inside the stage, above its gradient but below 3D models.
    remove_child(lobby_background)
    stage.add_child(lobby_background)
    stage.move_child(lobby_background, 1)
    lobby_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    Net.lobby_background_changed.connect(_apply_background_bytes)
    if not Net.lobby_background_data.is_empty():
        _apply_background_bytes(Net.lobby_background_data)
    _build_top_left()
    _build_top_right()
    _build_bottom_right()
    _build_play_button()
    _build_friends_panel()
    _build_invite_panel()
    _build_inventory_panel()
    _build_shop_panel()
    _build_background_picker()
    _build_music_ui()
    _build_online_panel()
    background_download_button = _button("Загрузить фон Host", Vector2(230, 52))
    _place(background_download_button, 1.0, 0.45, -20, 0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_BOTH)
    background_download_button.pressed.connect(func(): Net.request_lobby_background())
    add_child(background_download_button)
    _build_notice()
    _build_creator_dialog()
    _build_creator_panel()
    _update_creator_panel_visibility()

    GameState.changed.connect(_on_game_state_changed)
    Net.online_changed.connect(_update_status)
    Net.friends_changed.connect(_rebuild_friends)
    Net.roster_changed.connect(_on_lobby_changed)
    Net.role_changed.connect(_on_lobby_changed)
    Net.invite_received.connect(_on_invite_received)
    Net.invite_closed.connect(func(): invite_panel.hide())
    # Приглашение могло прийти, пока игрок был в бою: показываем его, как только лобби открылось.
    if Net.has_incoming_invite():
        _on_invite_received.call_deferred(Net.incoming_invite_nick())
    Net.notice.connect(_show_notice)
    Net.survival_lobby_opened.connect(_open_survival_lobby)
    Net.battle_started.connect(_enter_battle)

    _update_status(Net.online)
    _refresh_slots()
    _on_lobby_changed()
    _rebuild_friends()


func _process(_delta: float) -> void:
    if notice_label.visible and Time.get_ticks_msec() >= notice_until:
        notice_label.hide()


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):   # Esc / кнопка "назад"
        inventory_panel.hide()
        shop_panel.hide()
        friends_panel.hide()


# ======================================================================
#  Оформление и построение интерфейса
# ======================================================================

func _box(bg: Color, radius: int, border: Color, border_w: int, margin: int) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.set_corner_radius_all(radius)
    s.border_color = border
    s.set_border_width_all(border_w)
    s.set_content_margin_all(margin)
    return s


func _build_theme() -> Theme:
    return UiGray.make_theme(22)


## Привязывает контрол к точке экрана (якоря) и задаёт, в какую сторону он растёт.
func _place(c: Control, ax: float, ay: float, ox: float, oy: float,
        gh: Control.GrowDirection, gv: Control.GrowDirection) -> void:
    c.anchor_left = ax
    c.anchor_right = ax
    c.anchor_top = ay
    c.anchor_bottom = ay
    c.offset_left = ox
    c.offset_right = ox
    c.offset_top = oy
    c.offset_bottom = oy
    c.grow_horizontal = gh
    c.grow_vertical = gv


func _button(text: String, min_size: Vector2) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    return b


func _label(text: String, font_size: int, color: Color = UiGray.TEXT) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    return l


func _build_top_left() -> void:
    var box := VBoxContainer.new()
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    box.add_theme_constant_override("separation", 8)
    _place(box, 0.0, 0.0, 16, 12, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_END)
    add_child(box)

    status_label = Label.new()
    status_label.add_theme_font_size_override("font_size", 24)
    status_label.add_theme_color_override("font_outline_color", UiGray.OUTLINE)
    status_label.add_theme_constant_override("outline_size", 5)
    box.add_child(status_label)

    nick_edit = LineEdit.new()
    nick_edit.custom_minimum_size = Vector2(270, 48)
    nick_edit.max_length = GameState.MAX_NICK
    nick_edit.text = GameState.nickname
    nick_edit.placeholder_text = "Ваш ник"
    nick_edit.tooltip_text = "Нажмите, чтобы изменить ник"
    nick_edit.text_submitted.connect(_apply_nick)
    nick_edit.focus_exited.connect(func(): _apply_nick(nick_edit.text))
    box.add_child(nick_edit)


func _build_top_right() -> void:
    var box := HBoxContainer.new()
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    box.add_theme_constant_override("separation", 10)
    _place(box, 1.0, 0.0, -16, 12, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_END)
    add_child(box)
    leave_btn = _button("Выйти", Vector2(150, 58))
    leave_btn.pressed.connect(func(): Net.leave_lobby())
    box.add_child(leave_btn)
    friends_btn = _button("Друзья", Vector2(170, 58))
    friends_btn.pressed.connect(_toggle_friends)
    box.add_child(friends_btn)


func _build_bottom_right() -> void:
    var box := HBoxContainer.new()
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    box.add_theme_constant_override("separation", 12)
    _place(box, 1.0, 1.0, -16, -16, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_BEGIN)
    add_child(box)
    var online_btn := _button("Online", Vector2(140, 72))
    online_btn.pressed.connect(_toggle_online_panel)
    box.add_child(online_btn)
    var settings_btn := _button("Настройки", Vector2(160, 72))
    settings_btn.pressed.connect(func(): music_settings_panel.visible = not music_settings_panel.visible)
    box.add_child(settings_btn)
    var music_btn := _button("Музыка", Vector2(150, 72))
    music_btn.pressed.connect(func(): music_panel.visible = not music_panel.visible)
    box.add_child(music_btn)
    var background_btn := _button("Лобби", Vector2(160, 72))
    background_btn.pressed.connect(func(): background_panel.visible = not background_panel.visible)
    box.add_child(background_btn)
    var shop_btn := _button("Магазин", Vector2(190, 72))
    shop_btn.pressed.connect(_toggle_shop)
    box.add_child(shop_btn)
    var inv_btn := _button("Инвентарь", Vector2(210, 72))
    inv_btn.pressed.connect(_toggle_inventory)
    box.add_child(inv_btn)


func _build_online_panel() -> void:
    online_panel = PanelContainer.new()
    online_panel.visible = false
    online_panel.custom_minimum_size = Vector2(470, 0)
    _place(online_panel, 0.5, 0.5, 0, 0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_BOTH)
    add_child(online_panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    online_panel.add_child(v)
    var title := _label("Online — прямое подключение", 26)
    v.add_child(title)
    var info := _label("Host: публичный IPv4 + проброс UDP-порта на роутере.\nClient: введите публичный IPv4 телефона Host.", 17)
    v.add_child(info)
    public_ip_label = _label("Публичный IPv4: ещё не определён", 20)
    v.add_child(public_ip_label)
    var refresh_ip := _button("Обновить публичный IPv4", Vector2(0, 50))
    refresh_ip.pressed.connect(_request_public_ipv4)
    v.add_child(refresh_ip)
    public_ip_request = HTTPRequest.new()
    public_ip_request.timeout = 10.0
    add_child(public_ip_request)
    public_ip_request.request_completed.connect(_on_public_ip_response)
    online_ip_edit = LineEdit.new()
    online_ip_edit.placeholder_text = "IPv4 Host, например 203.0.113.10"
    online_ip_edit.custom_minimum_size = Vector2(430, 52)
    v.add_child(online_ip_edit)
    online_port_edit = LineEdit.new()
    online_port_edit.text = str(Net.GAME_PORT)
    online_port_edit.placeholder_text = "UDP порт"
    online_port_edit.max_length = 5
    online_port_edit.custom_minimum_size = Vector2(430, 52)
    v.add_child(online_port_edit)
    var host_button := _button("Создать Online Host", Vector2(0, 60))
    host_button.pressed.connect(_online_host_pressed)
    v.add_child(host_button)
    var join_button := _button("Подключиться (Join)", Vector2(0, 60))
    join_button.pressed.connect(_online_join_pressed)
    v.add_child(join_button)
    var leave_button := _button("Выйти из Online", Vector2(0, 55))
    leave_button.pressed.connect(func(): Net.leave_lobby())
    v.add_child(leave_button)
    online_status = _label("Нужен доступный UDP-порт; CGNAT не поддерживается.", 16)
    v.add_child(online_status)
    var close_button := _button("Закрыть", Vector2(0, 52))
    close_button.pressed.connect(func(): online_panel.hide())
    v.add_child(close_button)


func _toggle_online_panel() -> void:
    online_panel.visible = not online_panel.visible
    if online_panel.visible:
        _request_public_ipv4()


func _request_public_ipv4() -> void:
    if public_ip_request == null or public_ip_request.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
        return
    public_ip_label.text = "Публичный IPv4: определяем..."
    # HTTPS-запрос к внешнему сервису: локальный IP телефона не является публичным.
    var err := public_ip_request.request("https://api.ipify.org")
    if err != OK:
        public_ip_label.text = "Публичный IPv4: ошибка запроса (%d)" % err


func _on_public_ip_response(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        public_ip_label.text = "Публичный IPv4: не удалось определить (проверьте интернет)"
        return
    var candidate := body.get_string_from_utf8().strip_edges()
    if not _is_valid_ipv4(candidate):
        public_ip_label.text = "Публичный IPv4: сервис вернул неверный адрес"
        return
    public_ipv4 = candidate
    public_ip_label.text = "Публичный IPv4: " + public_ipv4


func _is_valid_ipv4(value: String) -> bool:
    var parts := value.split(".")
    if parts.size() != 4:
        return false
    for part in parts:
        if part.is_empty() or part.length() > 3 or not part.is_valid_int():
            return false
        var n := int(part)
        if n < 0 or n > 255 or str(n) != part:
            return false
    return true


func _online_port() -> int:
    var port_text := online_port_edit.text.strip_edges()
    if not port_text.is_valid_int():
        return -1
    return int(port_text)


func _online_host_pressed() -> void:
    if Net.start_online_host(_online_port()):
        online_status.text = "Host запущен. Передайте другу публичный IPv4 и UDP-порт %d." % Net.internet_port
        _request_public_ipv4()
    else:
        online_status.text = "Host не запущен. Проверьте порт и текущее лобби."


func _online_join_pressed() -> void:
    if Net.join_online_host(online_ip_edit.text, _online_port()):
        online_status.text = "Подключаемся к Host..."
    else:
        online_status.text = "Ошибка подключения. Проверьте IPv4, порт и лобби."


var mode_button: Button
var mode_dialog: AcceptDialog

func _build_play_button() -> void:
    mode_button = _button("Режим: " + Net.MODE_NAMES[Net.game_mode], Vector2(260, 58))
    _place(mode_button, 0.0, 1.0, 16, -100, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_BEGIN)
    add_child(mode_button)
    mode_button.pressed.connect(_show_game_modes)
    Net.game_mode_changed.connect(_update_mode_button)
    var play := _button("Играть", Vector2(220, 76))
    _place(play, 0.0, 1.0, 16, -16, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_BEGIN)
    add_child(play)
    play.pressed.connect(_play_pressed)
    mode_dialog = AcceptDialog.new()
    mode_dialog.title = "Выбор режима"
    mode_dialog.min_size = Vector2i(370, 300)
    add_child(mode_dialog)
    var choices := VBoxContainer.new()
    mode_dialog.add_child(choices)
    for i in range(3):
        var index := i
        var button := _button(Net.MODE_NAMES[index], Vector2(310, 62))
        choices.add_child(button)
        button.pressed.connect(func():
            Net.set_game_mode(index)
            mode_dialog.hide()
        )
    var hint := Label.new()
    hint.text = "1 на 1: 2–4 игрока, пары меняются каждый раунд."
    choices.add_child(hint)

var survival_overlay: Control
var survival_list: ItemList

func _play_pressed() -> void:
    if Net.game_mode == Net.MODE_SURVIVAL:
        if Net.role == "solo":
            _open_survival_lobby()
        elif Net.role == "host" and Net.roster.size() >= 2 and Net.roster.size() <= 4:
            Net.open_survival_lobby_for_group()
        elif Net.role == "client":
            Net.notice.emit("Ожидайте Host")
        else:
            Net.notice.emit("Для совместного выживания нужно 2–4 игрока")
    else:
        Net.start_battle()

func _open_survival_lobby() -> void:
    if survival_overlay != null:
        survival_overlay.queue_free()
    survival_overlay = Control.new()
    survival_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    survival_overlay.z_index = 200
    add_child(survival_overlay)
    var shade := ColorRect.new()
    shade.color = UiGray.BG_DEEP
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    survival_overlay.add_child(shade)
    var title := Label.new()
    title.text = "ВЫЖИВАНИЕ — СОХРАНЕНИЯ"
    title.position = Vector2(80, 36)
    title.add_theme_font_size_override("font_size", 29)
    survival_overlay.add_child(title)
    survival_list = ItemList.new()
    survival_list.set_anchors_preset(Control.PRESET_CENTER)
    survival_list.position = Vector2(-300, -190)
    survival_list.size = Vector2(510, 345)
    survival_overlay.add_child(survival_list)
    var guest := Net.role == "client"
    # Список сохранений существует только у владельца Host (или в одиночной игре).
    var names: Array = []
    if not guest:
        names = SurvivalSaves.slots()
    if names.is_empty():
        survival_list.add_item("У вас нет ни одного сохранения")
        survival_list.set_item_disabled(0, true)
    else:
        for name in names:
            survival_list.add_item(name)
    var start := _button("Играть", Vector2(190, 65))
    _place(start, 0.0, 1.0, 30, -28, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_BEGIN)
    survival_overlay.add_child(start)
    start.visible = not guest
    start.pressed.connect(func():
        var selected := survival_list.get_selected_items()
        SurvivalSaves.pending_slot = survival_list.get_item_text(selected[0]) if not selected.is_empty() and not survival_list.is_item_disabled(selected[0]) else ""
        SurvivalSaves.active_slot = SurvivalSaves.pending_slot
        Net.start_battle()
    )
    var remove := _button("Удалить", Vector2(180, 65))
    _place(remove, 0.0, 1.0, 232, -28, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_BEGIN)
    survival_overlay.add_child(remove)
    remove.visible = not guest
    remove.pressed.connect(func():
        var selected := survival_list.get_selected_items()
        if selected.is_empty() or survival_list.is_item_disabled(selected[0]):
            return
        SurvivalSaves.delete_slot(survival_list.get_item_text(selected[0]))
        _open_survival_lobby()
    )
    if guest:
        survival_list.mouse_filter = Control.MOUSE_FILTER_IGNORE
        title.text = "ВЫЖИВАНИЕ — ОЖИДАНИЕ HOST"
        survival_list.clear()
        survival_list.visible = false
        var waiting := Label.new()
        waiting.text = "Ожидание запуска игры Host"
        waiting.set_anchors_preset(Control.PRESET_CENTER)
        waiting.position = Vector2(-220, -20)
        survival_overlay.add_child(waiting)
    var close := _button("Выйти", Vector2(150, 55))
    _place(close, 1.0, 0.0, -25, 25, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_END)
    survival_overlay.add_child(close)
    close.pressed.connect(_close_survival_lobby)

func _close_survival_lobby() -> void:
    if is_instance_valid(survival_overlay):
        survival_overlay.queue_free()
    survival_overlay = null
    survival_list = null

func _show_game_modes() -> void:
    if Net.role == "client":
        Net.notice.emit("Режим выбирает Host")
        return
    mode_dialog.popup_centered()

func _update_mode_button(mode: int) -> void:
    if mode_button != null:
        mode_button.text = "Режим: " + Net.MODE_NAMES[mode]


func _enter_battle() -> void:
    if Net.local_battle_left:
        return
    get_tree().change_scene_to_file("res://battle.tscn")


func _build_friends_panel() -> void:
    friends_panel = PanelContainer.new()
    friends_panel.visible = false
    friends_panel.custom_minimum_size = Vector2(400, 0)
    _place(friends_panel, 1.0, 0.0, -16, 82, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_END)
    add_child(friends_panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    friends_panel.add_child(v)
    var head := HBoxContainer.new()
    v.add_child(head)
    var title := _label("Игроки в вашем Wi-Fi", 24)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    head.add_child(title)
    var close := _button("✕", Vector2(52, 46))
    close.pressed.connect(func(): friends_panel.hide())
    head.add_child(close)
    friends_list = VBoxContainer.new()
    friends_list.add_theme_constant_override("separation", 8)
    v.add_child(friends_list)


func _build_invite_panel() -> void:
    invite_panel = PanelContainer.new()
    invite_panel.visible = false
    invite_panel.custom_minimum_size = Vector2(340, 0)
    _place(invite_panel, 1.0, 0.5, -16, 0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_BOTH)
    add_child(invite_panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    invite_panel.add_child(v)
    var cap := _label("Приглашение в лобби", 20, UiGray.TEXT_DIM)
    cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(cap)
    invite_nick = _label("", 30, UiGray.ACCENT)
    invite_nick.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    invite_nick.clip_text = true
    v.add_child(invite_nick)
    var cancel := _button("Отменить приглашение", Vector2(0, 58))
    cancel.pressed.connect(func(): Net.decline_invite())
    v.add_child(cancel)
    var accept := _button("Принять приглашение", Vector2(0, 58))
    accept.pressed.connect(func(): Net.accept_invite())
    v.add_child(accept)


func _build_inventory_panel() -> void:
    inventory_panel = PanelContainer.new()
    inventory_panel.visible = false
    inventory_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    inventory_panel.offset_left = 18
    inventory_panel.offset_top = 18
    inventory_panel.offset_right = -18
    inventory_panel.offset_bottom = -18
    add_child(inventory_panel)
    var root := VBoxContainer.new()
    inventory_panel.add_child(root)
    var head := HBoxContainer.new()
    root.add_child(head)
    var title := _label("Снаряжение / Инвентарь", 24)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    head.add_child(title)
    var close := _button("✕", Vector2(60, 45))
    close.pressed.connect(func(): inventory_panel.hide())
    head.add_child(close)
    var talent_btn := _button("Таланты", Vector2(145, 45))
    talent_btn.pressed.connect(_open_talent_tree)
    head.add_child(talent_btn)
    var sell_all_btn := _button("Продать всё", Vector2(170, 45))
    sell_all_btn.pressed.connect(_confirm_sell_all)
    head.add_child(sell_all_btn)
    var body := HBoxContainer.new()
    body.size_flags_vertical = Control.SIZE_EXPAND_FILL
    body.add_theme_constant_override("separation", 14)
    root.add_child(body)

    # Left: three weapon slots and ten ordinary battle loadout slots.
    var left := VBoxContainer.new()
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    body.add_child(left)
    var weapons := _slot_grid(4)
    left.add_child(weapons)
    for i in 4:
        var cell := VBoxContainer.new()
        cell.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        cell.add_child(_label("Slot-%d" % (i + 1) if i < 3 else "Обвес", 16))
        var slot := _make_slot("gear", i, gear_slots)
        slot.custom_minimum_size = Vector2(76, 92)
        cell.add_child(slot)
        weapons.add_child(cell)
    var lower := ScrollContainer.new()
    lower.size_flags_vertical = Control.SIZE_EXPAND_FILL
    left.add_child(lower)
    var lower_grid := _slot_grid(5)
    lower.add_child(lower_grid)
    for i in range(4, 13):
        lower_grid.add_child(_make_slot("gear", i, gear_slots))

    # Middle: action buttons operate on the most recently touched item.
    var actions := VBoxContainer.new()
    actions.custom_minimum_size = Vector2(150, 0)
    actions.size_flags_vertical = Control.SIZE_EXPAND_FILL
    body.add_child(actions)
    var use_btn := _button("Использовать", Vector2(145, 95))
    use_btn.size_flags_vertical = Control.SIZE_EXPAND_FILL
    use_btn.pressed.connect(func(): _show_notice(GameState.equip_selected(selected_container, selected_index)))
    actions.add_child(use_btn)
    var sell_btn := _button("Продать", Vector2(145, 95))
    sell_btn.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sell_btn.pressed.connect(func(): _show_notice(GameState.sell_selected(selected_container, selected_index)))
    actions.add_child(sell_btn)

    # Right: scrollable 100-slot persistent inventory.
    var right := ScrollContainer.new()
    right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    right.size_flags_vertical = Control.SIZE_EXPAND_FILL
    right.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    body.add_child(right)
    var inv_grid := _slot_grid(5)
    right.add_child(inv_grid)
    for i in GameState.INV_SIZE:
        inv_grid.add_child(_make_slot("inv", i, inv_slots))

func _confirm_sell_all() -> void:
    if GameState.battle_active:
        _show_notice("Продажа доступна только в лобби")
        return
    var dialog := ConfirmationDialog.new()
    dialog.title = "Продать весь инвентарь?"
    dialog.dialog_text = "Вы уверены, что хотите продать всё за %s $?" % GameState.format_money(GameState.get_sell_all_total())
    dialog.ok_button_text = "Продать"
    dialog.cancel_button_text = "Нет"
    dialog.min_size = Vector2i(450, 180)
    add_child(dialog)
    dialog.confirmed.connect(func(): _show_notice(GameState.sell_all_items()))
    dialog.confirmed.connect(dialog.queue_free)
    dialog.canceled.connect(dialog.queue_free)
    dialog.close_requested.connect(dialog.queue_free)
    dialog.popup_centered()


func _select_slot(container: String, slot_index: int) -> void:
    selected_container = container
    selected_index = slot_index
    for slot in inv_slots:
        slot.is_selected = container == "inv" and slot.index == slot_index
        slot.queue_redraw()
    for slot in gear_slots:
        slot.is_selected = container == "gear" and slot.index == slot_index
        slot.queue_redraw()


func _slot_grid(columns: int) -> GridContainer:
    var g := GridContainer.new()
    g.columns = columns
    g.add_theme_constant_override("h_separation", 8)
    g.add_theme_constant_override("v_separation", 8)
    return g


func _make_slot(container_id: String, i: int, store: Array) -> Control:
    var s = SlotScript.new()
    s.container_id = container_id
    s.index = i
    store.append(s)
    s.selected.connect(_select_slot)
    return s


func _build_shop_panel() -> void:
    # Отдельная сцена магазина: редактируется через shop/metro_shop.tscn.
    var shop_scene: PackedScene = preload("res://shop/metro_shop.tscn")
    shop_panel = shop_scene.instantiate() as PanelContainer
    add_child(shop_panel)
    shop_panel.purchase_message.connect(_show_notice)


func _buy_shop_item(item_id: String) -> void:
    _show_notice(GameState.buy_item(item_id))


func _build_notice() -> void:
    notice_label = Label.new()
    notice_label.visible = false
    notice_label.add_theme_font_size_override("font_size", 24)
    notice_label.add_theme_stylebox_override("normal", _box(UiGray.PANEL, UiGray.RADIUS, UiGray.EDGE_STRONG, 2, 12))
    notice_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _place(notice_label, 0.5, 0.0, 0, 18, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_END)
    add_child(notice_label)


# ======================================================================
#  Обновление интерфейса
# ======================================================================

func _update_status(is_online: bool) -> void:
    if is_online:
        status_label.text = "● В сети"
        status_label.add_theme_color_override("font_color", UiGray.ACCENT)
    else:
        status_label.text = "● Нет подключения к сети"
        status_label.add_theme_color_override("font_color", UiGray.TEXT_MUTE)


func _apply_nick(value: String) -> void:
    var requested: String = GameState.clean_nick(value)
    if requested.to_upper() == "CREATORGAME" and not GameState.creator_unlocked:
        nick_edit.text = GameState.nickname
        nick_edit.release_focus()
        if GameState.creator_locked:
            _show_notice("Ник CREATORGAME заблокирован после 3 ошибок")
        else:
            creator_pending = true
            creator_password.clear()
            creator_feedback.text = "Введите пароль для CREATORGAME"
            creator_overlay.show()
            creator_password.grab_focus()
        return
    if requested != GameState.nickname:
        if GameState.set_nickname(requested):
            _show_notice("Ник изменён")
        else:
            _show_notice("Ник слишком короткий или недоступен")
    nick_edit.text = GameState.nickname
    nick_edit.release_focus()
    _update_creator_panel_visibility()


func _build_creator_dialog() -> void:
    creator_overlay = ColorRect.new()
    creator_overlay.color = UiGray.BG_DEEP
    creator_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    creator_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    creator_overlay.z_index = 100
    add_child(creator_overlay)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    creator_overlay.add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(450, 260)
    center.add_child(panel)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 16)
    panel.add_child(layout)
    var heading := _label("CREATORGAME", 32)
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    layout.add_child(heading)
    creator_password = LineEdit.new()
    creator_password.placeholder_text = "Пароль"
    creator_password.secret = true
    creator_password.custom_minimum_size = Vector2(390, 54)
    layout.add_child(creator_password)
    creator_feedback = _label("Введите пароль", 18)
    creator_feedback.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    layout.add_child(creator_feedback)
    var play := _button("Играть", Vector2(200, 55))
    layout.add_child(play)
    play.pressed.connect(_submit_creator_password)
    creator_password.text_submitted.connect(func(_value: String): _submit_creator_password())
    var cancel := _button("Отмена", Vector2(180, 45))
    layout.add_child(cancel)
    cancel.pressed.connect(func(): creator_pending = false; creator_overlay.hide())
    creator_overlay.hide()


func _submit_creator_password() -> void:
    if not creator_pending:
        return
    if GameState.check_creator_password(creator_password.text):
        creator_pending = false
        creator_overlay.hide()
        nick_edit.text = GameState.nickname
        _update_creator_panel_visibility()
        _show_notice("CREATORGAME: начислено 200.000.000.000 $")
    elif GameState.creator_locked:
        creator_pending = false
        creator_feedback.text = "3 ошибки. Ник CREATORGAME заблокирован"
        creator_password.editable = false
    else:
        creator_password.clear()
        creator_feedback.text = "Неверный пароль. Осталось попыток: %d" % (3 - GameState.creator_failures)



func _build_creator_panel() -> void:
    creator_panel_button = _button("Панель", Vector2(155, 58))
    _place(creator_panel_button, 1.0, 0.5, -16, 0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_BOTH)
    add_child(creator_panel_button)
    creator_panel_button.pressed.connect(func(): creator_panel.visible = not creator_panel.visible)

    creator_panel = PanelContainer.new()
    creator_panel.custom_minimum_size = Vector2(330, 0)
    _place(creator_panel, 1.0, 0.5, -180, 0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_BOTH)
    add_child(creator_panel)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 12)
    creator_panel.add_child(layout)
    layout.add_child(_label("Панель CREATORGAME", 24))
    var add_btn := _button("200  (+200.000 $)", Vector2(290, 54))
    layout.add_child(add_btn)
    add_btn.pressed.connect(_creator_add_money)
    var sword_btn := _button("400  (Получить алмазный меч)", Vector2(290, 54))
    layout.add_child(sword_btn)
    sword_btn.pressed.connect(_creator_give_sword)
    var reset_btn := _button("300  (Баланс = 0)", Vector2(290, 54))
    layout.add_child(reset_btn)
    reset_btn.pressed.connect(_creator_reset_money)
    var close_btn := _button("Закрыть меню", Vector2(290, 54))
    layout.add_child(close_btn)
    close_btn.pressed.connect(func(): creator_panel.hide())
    creator_panel.hide()


func _creator_panel_allowed() -> bool:
    return GameState.creator_unlocked and GameState.nickname.to_upper() == "CREATORGAME"


func _update_creator_panel_visibility() -> void:
    if creator_panel_button == null or creator_panel == null:
        return
    creator_panel_button.visible = _creator_panel_allowed()
    if not _creator_panel_allowed():
        creator_panel.hide()


func _creator_add_money() -> void:
    if not _creator_panel_allowed():
        return
    GameState.set_money(mini(GameState.MAX_MONEY, GameState.money + 200000))
    _show_notice("Добавлено 200.000 $")


func _creator_give_sword() -> void:
    if not _creator_panel_allowed():
        return
    for slot in GameState.inventory:
        if str(slot.get("id", "")) == "diamond_sword":
            _show_notice("Алмазный меч уже в инвентаре")
            return
    for i in GameState.inventory.size():
        if GameState.inventory[i].is_empty():
            GameState.inventory[i] = {"id": "diamond_sword", "count": 1}
            GameState.save_profile()
            GameState.changed.emit()
            _show_notice("Алмазный меч CREATOR получен!")
            return
    _show_notice("Нет свободного места в инвентаре")


func _creator_reset_money() -> void:
    if not _creator_panel_allowed():
        return
    GameState.set_money(0)
    _show_notice("Баланс обнулён")


func _on_game_state_changed() -> void:
    _refresh_slots()
    _update_creator_panel_visibility()
    if not nick_edit.has_focus():
        nick_edit.text = GameState.nickname


func _refresh_slots() -> void:
    for i in inv_slots.size():
        inv_slots[i].set_item(GameState.inventory[i])
    for i in gear_slots.size():
        gear_slots[i].set_item(GameState.equipment[i])


func _on_lobby_changed() -> void:
    # "Выйти" появляется рядом с "Друзья", когда в лобби двое
    leave_btn.visible = Net.role != "solo" and Net.roster.size() >= 2
    if friends_panel.visible:
        _rebuild_friends()
    _update_background_download_button()


func _update_background_download_button() -> void:
    if not is_instance_valid(background_download_button):
        return
    background_download_button.visible = Net.role == "client" and Net.roster.size() >= 2 and Net.lobby_background_data.is_empty()


func _toggle_friends() -> void:
    friends_panel.visible = not friends_panel.visible
    if friends_panel.visible:
        _rebuild_friends()


func _toggle_inventory() -> void:
    inventory_panel.visible = not inventory_panel.visible
    if inventory_panel.visible:
        shop_panel.hide()
        _refresh_slots()


func _toggle_shop() -> void:
    shop_panel.visible = not shop_panel.visible
    if shop_panel.visible:
        inventory_panel.hide()


func _rebuild_friends() -> void:
    if friends_list == null:
        return
    for c in friends_list.get_children():
        friends_list.remove_child(c)
        c.queue_free()
    if not Net.online:
        friends_list.add_child(_label("Нет подключения к сети", 20, UiGray.TEXT_MUTE))
        return
    var list: Array = Net.friends_list()
    if list.is_empty():
        friends_list.add_child(_label("В вашем Wi-Fi пока никого нет", 20, UiGray.TEXT_DIM))
        return
    var can: bool = Net.can_invite()
    for f in list:
        var d: Dictionary = f
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 10)
        var name_l := _label(str(d["nick"]), 24)
        name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        name_l.custom_minimum_size = Vector2(200, 0)
        name_l.clip_text = true
        row.add_child(name_l)
        var busy: bool = bool(d["busy"])
        if busy:
            row.add_child(_label("в лобби", 16, UiGray.TEXT_MUTE))
        var plus := _button("+", Vector2(64, 52))
        plus.disabled = busy or not can
        var friend_uid: String = str(d["uid"])
        plus.pressed.connect(func(): Net.invite(friend_uid))
        row.add_child(plus)
        friends_list.add_child(row)


func _on_invite_received(from_nick: String) -> void:
    invite_nick.text = from_nick
    invite_panel.show()
    invite_panel.move_to_front()


func _show_notice(text: String) -> void:
    notice_label.text = text
    notice_label.show()
    notice_label.move_to_front()
    notice_until = Time.get_ticks_msec() + 5000   # через 5 секунд исчезает

func _open_talent_tree() -> void:
    var dialog := AcceptDialog.new()
    dialog.title = "Древо талантов"
    dialog.min_size = Vector2i(480, 260)
    add_child(dialog)
    var content := VBoxContainer.new()
    dialog.add_child(content)
    var name_label := Label.new()
    name_label.text = "НОКДАУН — Последний шанс"
    name_label.add_theme_font_size_override("font_size", 22)
    content.add_child(name_label)
    var description := Label.new()
    description.text = "В нокдауне можно стрелять из пистолета во втором слоте.\nЦена: 50 000 $"
    content.add_child(description)
    var purchase := Button.new()
    purchase.text = "Куплено" if GameState.downed_pistol_talent else "Купить за 50 000 $"
    purchase.disabled = GameState.downed_pistol_talent or GameState.money < GameState.DOWNED_PISTOL_PRICE
    content.add_child(purchase)
    purchase.pressed.connect(func():
        if GameState.buy_downed_pistol_talent():
            purchase.text = "Куплено"
            purchase.disabled = true
    )
    dialog.confirmed.connect(dialog.queue_free)
    dialog.canceled.connect(dialog.queue_free)
    dialog.popup_centered()
