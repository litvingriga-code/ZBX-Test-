extends Control
## Красная точка коллиматора по центру экрана — только точка, без кольца и без PNG.
## Показывается battle.gd, когда игрок прицеливается из оружия, на котором стоит коллиматор.
## Размер считается от высоты экрана.

var dot_color := Color(1.0, 0.1, 0.06)


func _ready() -> void:
    name = "CollimatorReticle"
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    resized.connect(queue_redraw)


func _draw() -> void:
    var center := size * 0.5
    var r := maxf(2.2, 3.4 * maxf(size.y, 1.0) / 1080.0)
    # едва заметный ореол сглаживает край точки (как у настоящих коллиматоров)
    draw_circle(center, r * 1.9, Color(dot_color, 0.16))
    draw_circle(center, r, dot_color)
