extends RefCounted
## Набор для сборки процедурных моделей из примитивов Godot.
## Каждый экземпляр = одна жёсткая деталь (корпус оружия, магазин, рука...).
## Все примитивы одного цвета склеиваются в одну поверхность, а commit()
## создаёт ОДИН MeshInstance3D на деталь -> мало draw call на мобильных.
## Если что-то отображается неверно, поставьте BATCH_MESHES = false:
## тогда каждая часть станет отдельным MeshInstance3D (медленнее, но проще).

const BATCH_MESHES := true
const DEG := PI / 180.0

static var _materials: Dictionary = {}

var _batches: Dictionary = {}   # ключ материала -> {"mat": StandardMaterial3D, "st": SurfaceTool}
var _loose: Array = []          # запасной режим без склейки
var _target: Node3D


func _init(target: Node3D = null) -> void:
    _target = target


## Материал из кэша: одинаковые параметры = один и тот же ресурс.
static func material(tint: Color, metal: float = 0.3, rough: float = 0.6) -> StandardMaterial3D:
    var key := "%s|%.2f|%.2f" % [tint.to_html(true), metal, rough]
    if _materials.has(key):
        return _materials[key]
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    mat.metallic = metal
    mat.roughness = rough
    if tint.a < 0.99:
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    _materials[key] = mat
    return mat


static func glow_material(tint: Color) -> StandardMaterial3D:
    var key := "glow|" + tint.to_html(true)
    if _materials.has(key):
        return _materials[key]
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    _materials[key] = mat
    return mat


func add_mesh(mesh: Mesh, xform: Transform3D, mat: StandardMaterial3D) -> void:
    if BATCH_MESHES:
        var key := str(mat.get_instance_id())
        if not _batches.has(key):
            var st := SurfaceTool.new()
            st.begin(Mesh.PRIMITIVE_TRIANGLES)
            _batches[key] = {"mat": mat, "st": st}
        (_batches[key]["st"] as SurfaceTool).append_from(mesh, 0, xform)
    else:
        _loose.append([mesh, xform, mat])


## Создаёт MeshInstance3D(ы) внутри node (или внутри target из конструктора).
func commit(node: Node3D = null) -> Node3D:
    var host: Node3D = node if node != null else _target
    if BATCH_MESHES:
        if _batches.is_empty():
            return host
        var array_mesh := ArrayMesh.new()
        for key in _batches.keys():
            var st: SurfaceTool = _batches[key]["st"]
            st.commit(array_mesh)
            array_mesh.surface_set_material(array_mesh.get_surface_count() - 1, _batches[key]["mat"])
        var instance := MeshInstance3D.new()
        instance.name = "Mesh"
        instance.mesh = array_mesh
        host.add_child(instance)
    else:
        for entry in _loose:
            var instance := MeshInstance3D.new()
            instance.mesh = entry[0]
            instance.transform = entry[1]
            instance.material_override = entry[2]
            host.add_child(instance)
    _batches.clear()
    _loose.clear()
    return host


static func _xf(pos: Vector3, rot_deg: Vector3) -> Transform3D:
    return Transform3D(Basis.from_euler(rot_deg * DEG), pos)


# ---------------------------------------------------------------- примитивы

func box(size: Vector3, pos: Vector3, tint: Color, rot_deg: Vector3 = Vector3.ZERO,
        metal: float = 0.3, rough: float = 0.6) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    add_mesh(mesh, _xf(pos, rot_deg), material(tint, metal, rough))


## Цилиндр/конус вдоль оси Z: r_front — радиус на стороне -Z (дульный срез), r_back — на +Z.
func cyl_z(r_front: float, r_back: float, length: float, pos: Vector3, tint: Color,
        segs: int = 12, metal: float = 0.5, rough: float = 0.5, extra_rot: Vector3 = Vector3.ZERO) -> void:
    var mesh := CylinderMesh.new()
    mesh.top_radius = r_back
    mesh.bottom_radius = r_front
    mesh.height = length
    mesh.radial_segments = segs
    mesh.rings = 1
    var basis := Basis.from_euler(extra_rot * DEG) * Basis.from_euler(Vector3(PI * 0.5, 0.0, 0.0))
    add_mesh(mesh, Transform3D(basis, pos), material(tint, metal, rough))


## Цилиндр вдоль оси Y: r_top вверху (+Y), r_bottom внизу.
func cyl_y(r_bottom: float, r_top: float, height: float, pos: Vector3, tint: Color,
        segs: int = 12, metal: float = 0.3, rough: float = 0.7, extra_rot: Vector3 = Vector3.ZERO) -> void:
    var mesh := CylinderMesh.new()
    mesh.top_radius = r_top
    mesh.bottom_radius = r_bottom
    mesh.height = height
    mesh.radial_segments = segs
    mesh.rings = 1
    add_mesh(mesh, _xf(pos, extra_rot), material(tint, metal, rough))


## Цилиндр вдоль оси X: r_pos на стороне +X, r_neg на -X.
func cyl_x(r_neg: float, r_pos: float, length: float, pos: Vector3, tint: Color,
        segs: int = 12, metal: float = 0.4, rough: float = 0.6) -> void:
    var mesh := CylinderMesh.new()
    mesh.top_radius = r_pos
    mesh.bottom_radius = r_neg
    mesh.height = length
    mesh.radial_segments = segs
    mesh.rings = 1
    var basis := Basis.from_euler(Vector3(0.0, 0.0, -PI * 0.5))
    add_mesh(mesh, Transform3D(basis, pos), material(tint, metal, rough))


## Эллипсоид (scale — растяжение по осям).
func sphere(radius: float, pos: Vector3, tint: Color, scl: Vector3 = Vector3.ONE,
        metal: float = 0.0, rough: float = 0.8, segs: int = 12) -> void:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = segs
    mesh.rings = maxi(4, int(segs * 0.5))
    var basis := Basis.from_scale(scl)
    add_mesh(mesh, Transform3D(basis, pos), material(tint, metal, rough))


## Капсула вдоль оси Y; height — полная высота вместе с полусферами.
func capsule(radius: float, height: float, pos: Vector3, tint: Color,
        rot_deg: Vector3 = Vector3.ZERO, metal: float = 0.0, rough: float = 0.85, segs: int = 10) -> void:
    var mesh := CapsuleMesh.new()
    mesh.radius = radius
    mesh.height = maxf(height, radius * 2.0)
    mesh.radial_segments = segs
    mesh.rings = 4
    add_mesh(mesh, _xf(pos, rot_deg), material(tint, metal, rough))


## Треугольная призма (профиль в плоскости XY, выдавлена вдоль Z).
func prism(size: Vector3, pos: Vector3, tint: Color, rot_deg: Vector3 = Vector3.ZERO,
        apex: float = 0.5, metal: float = 0.3, rough: float = 0.6) -> void:
    var mesh := PrismMesh.new()
    mesh.size = size
    mesh.left_to_right = apex
    add_mesh(mesh, _xf(pos, rot_deg), material(tint, metal, rough))


# ---------------------------------------------------------------- узлы

static func group(parent: Node3D, pos: Vector3, label: String) -> Node3D:
    var node := Node3D.new()
    node.name = label
    node.position = pos
    parent.add_child(node)
    return node
