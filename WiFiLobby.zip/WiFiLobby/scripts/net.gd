extends Node
const Weapons = preload("res://scripts/weapons.gd")
const TitanicMap = preload("res://scripts/titanic_map.gd")
const ZombieModel = preload("res://scripts/zombie_model.gd")
## Сеть лобби (автозагрузка "Net").
##  * Поиск игроков в одной Wi-Fi сети: UDP-broadcast на порту 24568.
##  * Приглашения: UDP (пригласить -> принять/отклонить).
##  * Лобби на двоих: ENet на порту 24567. Пригласивший становится Host,
##    приглашённый - Client.
##  * Host авторитетен: принимает ВСЁ, что присылает Client (ник, поворот,
##    снаряжение), проверяет, применяет и рассылает состояние обратно.
##    Позицией Client в лобби управляет только Host.

signal battle_leader_changed(peer: int)
signal lobby_background_changed(data: PackedByteArray)
var lobby_background_data: PackedByteArray = PackedByteArray()
# Фон клиента хранится только в оперативной памяти. На диск он не записывается.
var _personal_background_data: PackedByteArray = PackedByteArray()
const PERSONAL_BACKGROUND_PATH := "user://lobby_personal_background.png"

func _load_personal_background() -> void:
    if not FileAccess.file_exists(PERSONAL_BACKGROUND_PATH):
        return
    var bytes := FileAccess.get_file_as_bytes(PERSONAL_BACKGROUND_PATH)
    if bytes.is_empty() or bytes.size() > 1500000:
        push_warning("Не удалось восстановить сохранённый фон лобби")
        return
    var img := Image.new()
    var err := img.load_png_from_buffer(bytes)
    if err != OK:
        err = img.load_jpg_from_buffer(bytes)
    if err != OK:
        push_warning("Сохранённый фон лобби повреждён")
        return
    _personal_background_data = bytes.duplicate()
    lobby_background_data = bytes.duplicate()
    lobby_background_changed.emit(lobby_background_data)

func _save_personal_background(data: PackedByteArray) -> void:
    var file := FileAccess.open(PERSONAL_BACKGROUND_PATH, FileAccess.WRITE)
    if file == null:
        push_warning("Не удалось сохранить фон лобби: %s" % FileAccess.get_open_error())
        return
    file.store_buffer(data)
    file.close()



func set_lobby_background(data: PackedByteArray) -> void:
    if data.size() > 1500000 or data.is_empty():
        return
    if role == "client":
        return
    lobby_background_data = data
    _personal_background_data = data.duplicate()
    _save_personal_background(data)
    lobby_background_changed.emit(data)
    if role == "host":
        _receive_lobby_background.rpc(data)

func request_lobby_background() -> void:
    if role == "client":
        _request_lobby_background.rpc_id(1)

@rpc("any_peer", "call_remote", "reliable")
func _request_lobby_background() -> void:
    if role == "host" and not lobby_background_data.is_empty():
        _receive_lobby_background.rpc_id(multiplayer.get_remote_sender_id(), lobby_background_data)

@rpc("authority", "call_remote", "reliable")
func _receive_lobby_background(data: PackedByteArray) -> void:
    if data.size() > 1500000 or data.is_empty():
        return
    if role != "client":
        return
    lobby_background_data = data
    lobby_background_changed.emit(data)

# Музыка лобби: MP3 сохраняется только у владельца, клиент получает временную копию.
signal lobby_music_changed(data: PackedByteArray)
signal lobby_music_volume_changed(value: float)
const PERSONAL_MUSIC_PATH := "user://lobby_music.mp3"
const PERSONAL_MUSIC_VOLUME_PATH := "user://lobby_music_volume.cfg"
const MAX_MUSIC_BYTES := 12000000
const MUSIC_CHUNK := 24000
var lobby_music_data: PackedByteArray = PackedByteArray()
var _personal_music_data: PackedByteArray = PackedByteArray()
var lobby_music_volume: float = 100.0
var _personal_music_volume: float = 100.0
var _music_receive: PackedByteArray = PackedByteArray()
var _music_expected: int = 0

func _load_personal_music() -> void:
    if FileAccess.file_exists(PERSONAL_MUSIC_VOLUME_PATH):
        var config := ConfigFile.new()
        if config.load(PERSONAL_MUSIC_VOLUME_PATH) == OK:
            lobby_music_volume = clampf(float(config.get_value("audio", "volume", 100.0)), 0.0, 100.0)
    _personal_music_volume = lobby_music_volume
    if FileAccess.file_exists(PERSONAL_MUSIC_PATH):
        var data := FileAccess.get_file_as_bytes(PERSONAL_MUSIC_PATH)
        if data.size() <= MAX_MUSIC_BYTES and data.size() > 0:
            lobby_music_data = data
            _personal_music_data = data.duplicate()

func set_lobby_music(data: PackedByteArray) -> void:
    if role == "client" or data.is_empty() or data.size() > MAX_MUSIC_BYTES:
        return
    if AudioStreamMP3.load_from_buffer(data) == null:
        notice.emit("Не удалось прочитать MP3")
        return
    var file := FileAccess.open(PERSONAL_MUSIC_PATH, FileAccess.WRITE)
    if file == null:
        notice.emit("Не удалось сохранить MP3")
        return
    file.store_buffer(data)
    file.close()
    lobby_music_data = data.duplicate()
    _personal_music_data = data.duplicate()
    lobby_music_changed.emit(lobby_music_data)
    if role == "host":
        _send_music_to_clients()

func set_lobby_music_volume(value: float) -> void:
    if role == "client":
        return
    lobby_music_volume = clampf(value, 0.0, 100.0)
    _personal_music_volume = lobby_music_volume
    var config := ConfigFile.new()
    config.set_value("audio", "volume", lobby_music_volume)
    config.save(PERSONAL_MUSIC_VOLUME_PATH)
    lobby_music_volume_changed.emit(lobby_music_volume)
    if role == "host":
        _music_volume_remote.rpc(lobby_music_volume)

func _send_music_to_clients(peer: int = 0) -> void:
    if role != "host":
        return
    var total := lobby_music_data.size()
    if peer == 0:
        _music_start_remote.rpc(total, lobby_music_volume)
    else:
        _music_start_remote.rpc_id(peer, total, lobby_music_volume)
    for offset in range(0, total, MUSIC_CHUNK):
        var part := lobby_music_data.slice(offset, mini(total, offset + MUSIC_CHUNK))
        if peer == 0:
            _music_chunk_remote.rpc(part)
        else:
            _music_chunk_remote.rpc_id(peer, part)

func request_lobby_music() -> void:
    if role == "client":
        _music_request_remote.rpc_id(1)

@rpc("any_peer", "call_remote", "reliable")
func _music_request_remote() -> void:
    if role == "host":
        _send_music_to_clients(multiplayer.get_remote_sender_id())

@rpc("authority", "call_remote", "reliable")
func _music_start_remote(total: int, volume: float) -> void:
    if role != "client" or total < 0 or total > MAX_MUSIC_BYTES:
        return
    _music_expected = total
    _music_receive.clear()
    lobby_music_volume = clampf(volume, 0.0, 100.0)
    lobby_music_volume_changed.emit(lobby_music_volume)
    if total == 0:
        lobby_music_data.clear()
        lobby_music_changed.emit(lobby_music_data)

@rpc("authority", "call_remote", "reliable")
func _music_chunk_remote(chunk: PackedByteArray) -> void:
    if role != "client" or _music_expected <= 0 or chunk.size() > MUSIC_CHUNK:
        return
    if _music_receive.size() + chunk.size() > _music_expected:
        _music_expected = 0
        _music_receive.clear()
        return
    _music_receive.append_array(chunk)
    if _music_receive.size() == _music_expected:
        if AudioStreamMP3.load_from_buffer(_music_receive) != null:
            lobby_music_data = _music_receive.duplicate()
            lobby_music_changed.emit(lobby_music_data)
        _music_expected = 0
        _music_receive.clear()

@rpc("authority", "call_remote", "reliable")
func _music_volume_remote(value: float) -> void:
    if role == "client":
        lobby_music_volume = clampf(value, 0.0, 100.0)
        lobby_music_volume_changed.emit(lobby_music_volume)

signal online_changed(online: bool)
signal friends_changed
signal roster_changed
signal role_changed
signal invite_received(from_nick: String)
signal invite_closed
signal notice(text: String)
signal battle_started
signal survival_lobby_opened
signal battle_positions_changed
signal world_item_added(item_id: int, stack: Dictionary, pos: Vector3, facing: float)
signal world_item_removed(item_id: int)
signal pickup_accepted(stack: Dictionary)
signal shot_visual(origin: Vector3, target: Vector3, shooter: int)
signal battle_event(peer: int, kind: String)   # действия игроков для звука/анимации: "reload"
signal shot_fired(shooter: int, weapon_id: String, origin: Vector3)
signal shot_confirmed(victim: int, damage: int)
signal health_changed(peer_id: int, hp: int)
signal player_state_changed(peer_id: int, state: int)   # ALIVE / DOWNED / DEAD / LEFT
signal battle_finished                                   # в бою не осталось живых игроков
signal adrenaline_approved
signal medkit_approved
signal world_items_reset
signal death_bags_changed
signal death_bag_item_received(stack: Dictionary)
var death_bags: Dictionary = {}
var _death_bag_seq: int = 0
var _death_bag_created_owners: Dictionary = {}
var _death_bag_pending: Dictionary = {}

func submit_death_bag(items: Array, position: Vector3) -> void:
    if role == "client":
        _submit_death_bag.rpc_id(1, items, position)
    else:
        _host_death_bag(my_id(), items, position)

@rpc("any_peer", "call_remote", "reliable")
func _submit_death_bag(items: Array, position: Vector3) -> void:
    if role == "host":
        _host_death_bag(multiplayer.get_remote_sender_id(), items, position)

func _host_death_bag(owner: int, items: Array, position: Vector3) -> void:
    if not battle_active or peer_state(owner) != ST_DEAD:
        return
    if _death_bag_created_owners.has(owner):
        return
    var clean: Array = []
    for entry in items:
        if not entry is Dictionary:
            continue
        var item_id := str(entry.get("id", ""))
        var count := int(entry.get("count", 0))
        if GameState.ITEMS.has(item_id) and count > 0:
            clean.append({"id": item_id, "count": mini(count, 9999)})
    _death_bag_created_owners[owner] = true
    _death_bag_seq += 1
    death_bags[_death_bag_seq] = {"owner": owner, "pos": position, "items": clean}
    _broadcast_death_bags()

func _broadcast_death_bags() -> void:
    death_bags_changed.emit()
    if role == "host":
        _death_bags_snapshot.rpc(death_bags)

@rpc("authority", "call_remote", "reliable")
func _death_bags_snapshot(bags: Dictionary) -> void:
    death_bags = bags.duplicate(true)
    death_bags_changed.emit()

func take_death_bag_item(bag_id: int, index: int) -> void:
    if role == "client":
        _take_death_bag_item.rpc_id(1, bag_id, index)
    else:
        _host_take_death_bag_item(my_id(), bag_id, index)

@rpc("any_peer", "call_remote", "reliable")
func _take_death_bag_item(bag_id: int, index: int) -> void:
    if role == "host":
        _host_take_death_bag_item(multiplayer.get_remote_sender_id(), bag_id, index)

func _host_take_death_bag_item(peer: int, bag_id: int, index: int) -> void:
    if peer_state(peer) != ST_ALIVE or not death_bags.has(bag_id):
        return
    var bag: Dictionary = death_bags[bag_id]
    if not battle_positions.has(peer) or battle_positions[peer].distance_to(bag["pos"]) > 3.5:
        return
    var items: Array = bag["items"]
    if index < 0 or index >= items.size():
        return
    var stack: Dictionary = items[index]
    _death_bag_pending[peer] = {"bag": bag_id, "index": index, "item": stack.duplicate(true)}
    # Client checks capacity; server receives an explicit acknowledgement before removal.
    if peer == my_id():
        death_bag_item_received.emit(stack.duplicate(true))
    else:
        _offer_death_bag_item.rpc_id(peer, bag_id, index, stack)

@rpc("authority", "call_remote", "reliable")
func _offer_death_bag_item(bag_id: int, index: int, stack: Dictionary) -> void:
    death_bag_item_received.emit(stack.duplicate(true))
    # Acknowledgement is sent by battle UI only after checking inventory capacity.

func confirm_death_bag_take(bag_id: int, index: int) -> void:
    if role == "client":
        _confirm_death_bag_take.rpc_id(1, bag_id, index)
    else:
        _host_confirm_death_bag_take(my_id(), bag_id, index)

@rpc("any_peer", "call_remote", "reliable")
func _confirm_death_bag_take(bag_id: int, index: int) -> void:
    if role == "host":
        _host_confirm_death_bag_take(multiplayer.get_remote_sender_id(), bag_id, index)

func _host_confirm_death_bag_take(peer: int, bag_id: int, index: int) -> void:
    if peer_state(peer) != ST_ALIVE or not death_bags.has(bag_id):
        return
    var bag: Dictionary = death_bags[bag_id]
    if not battle_positions.has(peer) or battle_positions[peer].distance_to(bag["pos"]) > 3.5:
        return
    if not _death_bag_pending.has(peer):
        return
    var pending: Dictionary = _death_bag_pending[peer]
    if int(pending.get("bag", -1)) != bag_id or int(pending.get("index", -1)) != index:
        return
    var items: Array = bag["items"]
    if index < 0 or index >= items.size() or items[index] != pending.get("item", {}):
        _death_bag_pending.erase(peer)
        return
    _death_bag_pending.erase(peer)
    items.remove_at(index)
    if items.is_empty():
        death_bags.erase(bag_id)
    _broadcast_death_bags()



const GAME_PORT := 24567
const DISCOVERY_PORT := 24568
const MAX_PLAYERS := 4
const PEER_TIMEOUT_MS := 6000
const INVITE_TIMEOUT := 30.0
const JOIN_TIMEOUT := 8.0
const WALK_SPEED := 3.0
const CLIENT_SPAWN_X := -4.6   # за левым краем экрана, Client "входит" в лобби
const CLIENT_SLOT_X := -1.5    # место Client: слева от Host

var world_items: Dictionary = {}
var _next_world_item_id := 1
# Game modes are selected by the lobby host and synchronized to clients.
const MODE_ZOMBIES := 0
const MODE_SURVIVAL := 1
const MODE_DUEL := 2
const MODE_NAMES := ["Волны зомби", "Выживание", "1 на 1"]
signal game_mode_changed(mode: int)
var game_mode: int = MODE_ZOMBIES
var zombie_time_left: float = 120.0
var zombie_win: bool = false
# Stage87: волны. Волна 1 — 2:00, дальше по 3:00. Когда время вышло, игроки идут на точку появления
# (PHASE_GO); первый, кто коснулся точки, вызывает вертолёт (PHASE_HELI, 1:00 на посадку).
# Кто сел — получает WAVE_BONUS * номер волны и выходит из боя (наблюдает). Потом начинается следующая волна.
const WAVE_FIRST_TIME := 120.0
const WAVE_NEXT_TIME := 180.0
const WAVE_HELI_TIME := 60.0
const WAVE_BONUS := 10000
const ZOMBIE_MAX_ALIVE := 70
const EVAC_TOUCH_RADIUS := 4.2       # радиус площадки «ТОЧКА ПОЯВЛЕНИЯ»
const PHASE_FIGHT := 0
const PHASE_GO := 1
const PHASE_HELI := 2
var zombie_wave_no: int = 1
var zombie_phase: int = PHASE_FIGHT
var zombie_heli_left: float = 0.0
## peer -> номер волны, на которой игрок сел в вертолёт (состояние такого игрока ST_DEAD, но без потери вещей).
var battle_evacuated: Dictionary = {}
signal zombie_phase_changed(phase: int, wave: int)
# Stage101: sword-only zombie death fire, sent reliably from host.
signal creator_sword_zombie_burn(zid: int, position: Vector3)

# Stage84: турели. Хост считает прицеливание и урон, клиенты получают позицию (reliable) и наводку (unreliable).
const TURRET_RANGE := 30.0
const TURRET_DAMAGE := 22
const TURRET_INTERVAL := 0.2
const TURRET_MAX_PER_PLAYER := 4
const TURRET_MAX_TOTAL := 12
const TURRET_AMMO := 50                # патронов в новой турели
const TURRET_HP := 50                  # Stage90: здоровье турели (зомби её атакуют)
const TURRET_AMMO_MAX := 100           # больше этого в турель не зарядить
const TURRET_REFILL_AMMO := 50         # патронов за одну покупку (цена: GameState.TURRET_REFILL_PRICE)
const TURRET_REFILL_REACH := 6.0       # дальше этого от турели купить патроны нельзя
const TURRET_AGGRO := 5.0              # зомби переключается на турель, если она ближе этого и ближе игрока
const TURRET_PLACE_REACH := 6.0
var turrets: Dictionary = {}        # id -> {"pos": Vector3, "owner": int}
var turret_ammo: Dictionary = {}    # id -> оставшиеся патроны
var turret_hp: Dictionary = {}      # id -> здоровье
signal turret_refill_approved(turret_id: int)   # хост одобрил покупку патронов: списать деньги
var turret_aims: Dictionary = {}    # id -> Vector4(yaw, pitch, секунд с последнего выстрела, id цели или -1)
var _turret_state: Dictionary = {}  # только хост: id -> {"cd", "yaw", "pitch", "age", "target"}
var _turret_serial := 0
signal turret_use_requested         # инвентарь -> боевая сцена: «поставить турель»
signal turret_place_approved        # хост одобрил: списать турель из инвентаря
signal turret_notice(message: String)
var zombie_positions: Dictionary = {}
var zombie_attack_cooldowns: Dictionary = {}
var zombie_spawn_clock: float = 0.0
var zombie_serial: int = 0
# Stage80: вид (0 ходок, 1 бегун, 2 громила), направление и фаза удара каждого зомби.
# zombie_meta[id] = Vector3(kind, yaw, attack_age или -1)
var zombie_meta: Dictionary = {}
var zombie_attack_age: Dictionary = {}
var zombie_attack_hit: Dictionary = {}
var zombie_rise_left: Dictionary = {}
var zombie_yaws: Dictionary = {}
var zombie_net_clock: float = 0.0
# Stage81: здоровье, время смерти (трупы лежат ZOMBIE_LINGER секунд), счётчик убийств.
var zombie_health: Dictionary = {}
var zombie_dead_age: Dictionary = {}
var zombie_kills: int = 0
signal zombie_updated
signal zombie_victory
var duel_round: int = 0
var duel_fighters: Array = []
var duel_spectators: Array = []
var duel_round_clock: float = 0.0
const DUEL_ROUND_SECONDS := 120.0

func set_game_mode(mode: int) -> void:
    if role == "client" or battle_active or mode < 0 or mode > 2:
        return
    game_mode = mode
    game_mode_changed.emit(mode)
    if role == "host":
        _receive_game_mode.rpc(mode)

@rpc("authority", "call_remote", "reliable")
func _receive_game_mode(mode: int) -> void:
    if role != "client" or mode < 0 or mode > 2:
        return
    game_mode = mode
    game_mode_changed.emit(mode)

func _duel_select_round() -> void:
    var ids: Array = roster.keys()
    ids.sort()
    duel_fighters.clear()
    duel_spectators.clear()
    if ids.size() < 2:
        return
    var offset := (duel_round * 2) % ids.size()
    duel_fighters = [int(ids[offset]), int(ids[(offset + 1) % ids.size()])]
    for id in ids:
        if not duel_fighters.has(int(id)):
            duel_spectators.append(int(id))
    duel_round_clock = 0.0
    for id in ids:
        battle_state[int(id)] = ST_ALIVE if duel_fighters.has(int(id)) else ST_DEAD
        battle_health[int(id)] = 100
    if role == "host":
        _duel_round_sync.rpc(duel_round, duel_fighters, duel_spectators)
    _broadcast_states()

@rpc("authority", "call_remote", "reliable")
func _duel_round_sync(round_index: int, fighters: Array, spectators: Array) -> void:
    duel_round = round_index
    duel_fighters = fighters.duplicate()
    duel_spectators = spectators.duplicate()
    duel_round_clock = 0.0

func _tick_duel(delta: float) -> void:
    if game_mode != MODE_DUEL or not battle_active or battle_over or role == "client":
        return
    duel_round_clock += delta
    var living := 0
    for id in duel_fighters:
        if peer_state(int(id)) == ST_ALIVE or peer_state(int(id)) == ST_DOWNED:
            living += 1
    if living < 2 or duel_round_clock >= DUEL_ROUND_SECONDS:
        duel_round += 1
        _duel_select_round()

var battle_active: bool = false
var battle_positions: Dictionary = {}
var battle_yaws: Dictionary = {}
var battle_crouches: Dictionary = {}
var battle_pitches: Dictionary = {}   # peer -> угол взгляда вверх/вниз (рад), для головы и оружия
var battle_weapons: Dictionary = {}   # peer -> id оружия в руках ("" = пусто)
var battle_aims: Dictionary = {}      # peer -> прицеливается ли игрок
var battle_attach: Dictionary = {}    # peer -> установлен ли коллиматор на оружии
# Настройка хоста: урон между участниками одной команды.
# В текущем лобби команды не разделены, поэтому все участники считаются союзниками.
signal friendly_fire_changed(enabled: bool)
var friendly_fire_enabled: bool = true

# Галочка «Бой без ИИ»: при выключении появляются боты.
signal bots_setting_changed(enabled: bool)
var bots_disabled: bool = true
signal bot_options_changed
var bot_count: int = 1
# Галочка включена: бот атакует только после попадания по нему.
var bot_aggression_checked: bool = true

func set_bot_options(count: int, aggression_checked: bool) -> void:
    if role == "client":
        return
    bot_count = clampi(count, 1, 5)
    bot_aggression_checked = aggression_checked
    bot_options_changed.emit()
    if role == "host":
        _sync_bot_options.rpc(bot_count, bot_aggression_checked)

@rpc("authority", "call_remote", "reliable")
func _sync_bot_options(count: int, aggression_checked: bool) -> void:
    if role != "client":
        return
    bot_count = clampi(count, 1, 5)
    bot_aggression_checked = aggression_checked
    bot_options_changed.emit()

const BOT_ID_START: int = 10000
var bot_loot: Dictionary = {}
var bot_aggressive: Dictionary = {}
var _bot_attack_clock: float = 0.0
var _bot_patrol: Dictionary = {}
var _bot_revive: Dictionary = {}
var _bot_rng := RandomNumberGenerator.new()

func set_bots_disabled(enabled: bool) -> void:
    if role == "client":
        return
    bots_disabled = enabled
    bots_setting_changed.emit(enabled)
    if role == "host":
        _sync_bots_disabled.rpc(enabled)

@rpc("authority", "call_remote", "reliable")
func _sync_bots_disabled(enabled: bool) -> void:
    if role != "client":
        return
    bots_disabled = enabled
    bots_setting_changed.emit(enabled)

@rpc("authority", "call_remote", "reliable")
func _sync_bot_loot(values: Dictionary) -> void:
    if role != "client":
        return
    bot_loot = values.duplicate(true)
    for raw_id in bot_loot.keys():
        var id := int(raw_id)
        battle_weapons[id] = str(bot_loot[id].get("weapon", "ak47"))

func is_bot(peer: int) -> bool:
    return peer >= BOT_ID_START and bot_loot.has(peer)

func _random_bot_inventory(weapon_id: String) -> Array:
    var items: Array = []
    if GameState.ITEMS.has(weapon_id):
        items.append({"id": weapon_id, "count": 1})
    var ammo_for_weapon := {
        "ak47": "ammo_762", "m4a1": "ammo_556",
        "pm": "ammo_9mm", "shotgun": "ammo_12", "revolver": "ammo_44"
    }
    var ammo_id := str(ammo_for_weapon.get(weapon_id, ""))
    if ammo_id != "" and GameState.ITEMS.has(ammo_id):
        items.append({"id": ammo_id, "count": _bot_rng.randi_range(20, 120)})
    var extras := ["medkit", "knife", "machete", "collimator", "ammo_762", "ammo_556", "ammo_9mm", "ammo_12", "ammo_44"]
    extras.shuffle()
    var extra_count := _bot_rng.randi_range(1, 5)
    for i in mini(extra_count, extras.size()):
        var item_id := str(extras[i])
        if not GameState.ITEMS.has(item_id):
            continue
        var max_stack := int(GameState.ITEMS[item_id].get("stack", 1))
        var count := _bot_rng.randi_range(1, mini(max_stack, 45))
        items.append({"id": item_id, "count": count})
    return items

func _create_bots() -> void:
    bot_loot.clear()
    bot_aggressive.clear()
    _bot_patrol.clear()
    _bot_revive.clear()
    if bots_disabled:
        return
    _bot_rng.randomize()
    var human_ids := battle_positions.keys().duplicate()
    if human_ids.is_empty():
        return
    var weapons := ["ak47", "m4a1", "pm", "vss", "knife"]
    for i in range(clampi(bot_count, 1, 5)):
        var human_id := int(human_ids[i % human_ids.size()])
        var bot_id := BOT_ID_START + i
        var chosen := str(weapons[_bot_rng.randi_range(0, weapons.size() - 1)])
        if not Weapons.has(chosen):
            chosen = "ak47"
        bot_loot[bot_id] = {"weapon": chosen, "inventory": _random_bot_inventory(chosen)}
        bot_aggressive[bot_id] = not bot_aggression_checked
        _bot_patrol[bot_id] = {"angle": _bot_rng.randf_range(-PI, PI), "time": _bot_rng.randf_range(1.0, 3.0), "pause": 0.0}
        var angle := float(i) * TAU / float(maxi(bot_count, 1))
        battle_positions[bot_id] = battle_positions[human_id] + Vector3(cos(angle) * 3.0, 0.0, sin(angle) * 3.0)
        battle_yaws[bot_id] = 0.0
        battle_health[bot_id] = 100
        battle_state[bot_id] = ST_ALIVE
        battle_bleed[bot_id] = BLEED_START
        battle_weapons[bot_id] = chosen

# Bot decisions are authoritative on the host. Every bot has its own revive clock.
func _tick_bots(delta: float) -> void:
    if not battle_active or battle_over or role == "client" or bot_loot.is_empty():
        return
    _bot_attack_clock += delta
    var can_attack: bool = _bot_attack_clock >= 1.2
    for raw_id in bot_loot.keys():
        var bot_id := int(raw_id)
        if peer_state(bot_id) != ST_ALIVE or not battle_positions.has(bot_id):
            _bot_revive.erase(bot_id)
            continue
        var bot_pos: Vector3 = battle_positions[bot_id]
        var patrol: Dictionary = _bot_patrol.get(bot_id, {"angle": 0.0, "time": 0.0, "pause": 0.0})
        # A downed bot or human is an ally while the bot is not hostile to them.
        var ally := -1
        var ally_distance := 18.0
        for raw_target in battle_positions.keys():
            var target := int(raw_target)
            if target == bot_id or peer_state(target) != ST_DOWNED:
                continue
            if friendly_fire_enabled and bool(bot_aggressive.get(bot_id, false)) and not is_bot(target):
                continue
            var d: float = bot_pos.distance_to(battle_positions[target])
            if d < ally_distance:
                ally = target
                ally_distance = d
        if ally >= 0:
            var ally_pos: Vector3 = battle_positions[ally]
            var toward: Vector3 = ally_pos - bot_pos
            toward.y = 0.0
            if toward.length_squared() > 0.01:
                battle_yaws[bot_id] = atan2(-toward.x, -toward.z)
            if ally_distance > 1.7:
                _bot_revive.erase(bot_id)
                if toward.length_squared() > 0.01:
                    battle_positions[bot_id] += toward.normalized() * minf(delta * 2.5, maxf(0.0, ally_distance - 1.5))
            else:
                var session: Dictionary = _bot_revive.get(bot_id, {})
                if int(session.get("target", -1)) != ally:
                    session = {"target": ally, "elapsed": 0.0}
                session["elapsed"] = float(session["elapsed"]) + delta
                _bot_revive[bot_id] = session
                if float(session["elapsed"]) >= 5.0 and peer_state(ally) == ST_DOWNED:
                    _bot_revive.erase(bot_id)
                    battle_state[ally] = ST_ALIVE
                    battle_bleed[ally] = 0
                    battle_health[ally] = 50
                    health_changed.emit(ally, 50)
                    if role == "host":
                        _health_snapshot.rpc(battle_health)
                    _after_state_change()
            _bot_patrol[bot_id] = patrol
            continue
        _bot_revive.erase(bot_id)
        var hostile: bool = friendly_fire_enabled and (not bot_aggression_checked or bool(bot_aggressive.get(bot_id, false)))
        var closest := -1
        var distance := 100000.0
        if hostile:
            for raw_target in battle_positions.keys():
                var target := int(raw_target)
                if target == bot_id or is_bot(target) or peer_state(target) != ST_ALIVE:
                    continue
                var d: float = bot_pos.distance_to(battle_positions[target])
                if d < distance:
                    closest = target
                    distance = d
        if closest >= 0 and distance < 30.0:
            var direction: Vector3 = battle_positions[closest] - bot_pos
            direction.y = 0.0
            if direction.length_squared() > 0.01:
                battle_yaws[bot_id] = atan2(-direction.x, -direction.z)
            var weapon_id := str(bot_loot[bot_id].get("weapon", "knife"))
            var melee: bool = Weapons.has(weapon_id) and Weapons.is_melee(weapon_id)
            var desired_distance := 1.4 if melee else 7.0
            if distance > desired_distance and direction.length_squared() > 0.01:
                battle_positions[bot_id] += direction.normalized() * minf(delta * 2.6, maxf(0.0, distance - desired_distance))
            if can_attack and Weapons.has(weapon_id):
                var origin: Vector3 = battle_positions[bot_id] + Vector3(0, 1.45, 0)
                var target_pos: Vector3 = battle_positions[closest] + Vector3(0, 1.0, 0)
                var shot_direction: Vector3 = (target_pos - origin).normalized()
                if melee and distance <= 2.7:
                    _resolve_melee(bot_id, weapon_id, origin, shot_direction)
                elif not melee and distance < 28.0:
                    shot_direction = (shot_direction + Vector3(_bot_rng.randf_range(-0.08, 0.08), _bot_rng.randf_range(-0.06, 0.06), _bot_rng.randf_range(-0.08, 0.08))).normalized()
                    _resolve_shot(bot_id, weapon_id, origin, PackedVector3Array([shot_direction]))
        else:
            patrol["time"] = float(patrol.get("time", 0.0)) - delta
            if float(patrol["time"]) <= 0.0:
                patrol["angle"] = _bot_rng.randf_range(-PI, PI)
                patrol["time"] = _bot_rng.randf_range(1.5, 5.0)
                patrol["pause"] = _bot_rng.randf_range(0.0, 1.5)
            var angle: float = float(patrol["angle"])
            var forward := Vector3(-sin(angle), 0.0, -cos(angle))
            battle_yaws[bot_id] = lerp_angle(float(battle_yaws.get(bot_id, 0.0)), angle, minf(1.0, delta * 2.0))
            if float(patrol.get("pause", 0.0)) > 0.0:
                patrol["pause"] = maxf(0.0, float(patrol["pause"]) - delta)
            else:
                var next_pos: Vector3 = bot_pos + forward * delta * 1.7
                if absf(next_pos.x) < 220.0 and absf(next_pos.z) < 220.0:
                    battle_positions[bot_id] = next_pos
                else:
                    patrol["time"] = 0.0
            battle_pitches[bot_id] = sin(Time.get_ticks_msec() * 0.001 + float(bot_id)) * 0.12
        _bot_patrol[bot_id] = patrol
    if can_attack:
        _bot_attack_clock = 0.0


func set_friendly_fire(enabled: bool) -> void:
    if role == "client":
        return
    friendly_fire_enabled = enabled
    if not enabled:
        bot_aggressive.clear()
    friendly_fire_changed.emit(enabled)
    if role == "host":
        _sync_friendly_fire.rpc(enabled)

@rpc("authority", "call_remote", "reliable")
func _sync_friendly_fire(enabled: bool) -> void:
    if role != "client":
        return
    friendly_fire_enabled = enabled
    friendly_fire_changed.emit(enabled)

var battle_health: Dictionary = {}
## Состояние игрока в бою: ST_ALIVE -> ST_DOWNED (нокаут, ползёт) -> ST_DEAD (наблюдает) -> ST_LEFT (вышел в лобби).
const ST_ALIVE := 0
const ST_DOWNED := 1
const ST_DEAD := 2
const ST_LEFT := 3
const BLEED_START := 100        # шкала Health bar2 в нокауте
var battle_state: Dictionary = {}   # peer -> ST_*
var battle_bleed: Dictionary = {}   # peer -> HP нокаута, уменьшается от попаданий и на 1 каждые 2 секунды
var battle_over: bool = false       # живых не осталось: бой закончен для всех
var _bleed_clock: float = 0.0
var _last_shot_ms: Dictionary = {}
var online: bool = false
var battle_leader_id: int = 1
var local_battle_left: bool = false
var role: String = "solo"      # "solo" | "host" | "client"
## peer_id -> {"nick", "money", "loadout", "hand", "x", "tx", "yaw"}
## Для solo/host это авторитетные данные, для client - копия данных Host.
var roster: Dictionary = {}
var friends: Dictionary = {}   # uid -> {"nick", "ip", "busy", "seen"}
var uid: String = ""
var my_yaw: float = 0.0

var _udp := PacketPeerUDP.new()
var _udp_ok: bool = false
var _enet: ENetMultiplayerPeer = null
var _online_timer: float = 0.0
var _hello_timer: float = 0.0
var _sync_timer: float = 0.0
var _full_timer: float = 0.0
var _yaw_timer: float = 0.0
var _dirty: bool = false
var _yaw_pending: bool = false
var _last_sig: String = ""
var _last_reply: Dictionary = {}

var _pending_uid: String = ""   # кого пригласили мы
var _pending_left: float = 0.0
var _incoming_uid: String = ""  # кто пригласил нас
var _incoming_ip: String = ""
var _incoming_left: float = 0.0
var _incoming_nick: String = ""  # ник пригласившего (для окна приглашения в бою и в лобби)
var _joining_uid: String = ""   # к кому подключаемся
var _joining_left: float = 0.0
var _host_wait_left: float = 0.0
var internet_mode: bool = false
var internet_port: int = GAME_PORT
const MIN_ONLINE_PORT := 1024
const MAX_ONLINE_PORT := 65535


func _ready() -> void:
    _load_personal_background()
    _load_personal_music()
    randomize()
    uid = "%d-%d-%d" % [Time.get_ticks_usec(), randi(), randi()]
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_to_server)
    multiplayer.connection_failed.connect(_on_connection_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnected)
    var state_node: Node = get_node_or_null("/root/GameState")
    if state_node != null and state_node.has_signal("changed"):
        state_node.connect("changed", Callable(self, "_on_local_changed"))
    else:
        push_error("GameState не загружен. Проверьте первую ошибку парсинга scripts/game_state.gd.")
    _reset_solo_roster()
    _udp.set_broadcast_enabled(true)
    _udp_ok = _udp.bind(DISCOVERY_PORT) == OK
    if not _udp_ok:
        push_warning("Поиск игроков недоступен: порт %d занят" % DISCOVERY_PORT)
    _check_online()


func _process(delta: float) -> void:
    _tick_duel(delta)
    _online_timer += delta
    if _online_timer >= 1.0:
        _online_timer = 0.0
        _check_online()
    _hello_timer += delta
    if _hello_timer >= 1.5:
        _hello_timer = 0.0
        if online:
            _broadcast_hello()
        _expire_friends()
    _poll_udp()
    _tick_knockout_hp(delta)
    _tick_water_death()
    if game_mode == MODE_ZOMBIES:
        _tick_zombies(delta)
    else:
        _tick_bots(delta)
    if battle_active and role == "host":
        _battle_broadcast_timer += delta
        if _battle_broadcast_timer >= 0.05:
            _battle_broadcast_timer = 0.0
            _battle_snapshot.rpc(battle_positions, battle_yaws, battle_pitches)
    _tick_invites(delta)
    if role == "client":
        _yaw_timer += delta
        if _yaw_pending and _yaw_timer >= 0.05:
            _yaw_timer = 0.0
            _yaw_pending = false
            _req_yaw.rpc_id(1, my_yaw)
    elif role == "host":
        _host_tick(delta)


# ======================================================================
#  Публичный API для интерфейса
# ======================================================================

var _battle_broadcast_timer: float = 0.0

func open_survival_lobby_for_group() -> void:
    if role != "host" or game_mode != MODE_SURVIVAL or roster.size() < 2 or roster.size() > 4:
        return
    _receive_survival_lobby.rpc()
    survival_lobby_opened.emit()

@rpc("authority", "call_remote", "reliable")
func _receive_survival_lobby() -> void:
    if role == "client" and game_mode == MODE_SURVIVAL:
        survival_lobby_opened.emit()

# Host owns survival saves. Clients only send their own current state on request.
# Persistent client identity, independent of ENet peer IDs.
var survival_client_ids: Dictionary = {}
var survival_recovered_states: Dictionary = {}
var survival_save_id: String = ""

func _survival_local_id() -> String:
    const ID_FILE := "user://survival_player_id.txt"
    if FileAccess.file_exists(ID_FILE):
        var old := FileAccess.get_file_as_string(ID_FILE).strip_edges()
        if old.length() == 32:
            return old
    var new_id := ""
    for b in Crypto.new().generate_random_bytes(16):
        new_id += "%02x" % int(b)
    var f := FileAccess.open(ID_FILE, FileAccess.WRITE)
    if f != null:
        f.store_string(new_id)
        f.flush()
    return new_id

@rpc("any_peer", "call_remote", "reliable")
func _survival_submit_recovery(player_id: String, save_id: String, state: Dictionary) -> void:
    if role != "host" or player_id.length() != 32:
        return
    if save_id.is_empty() or save_id != survival_save_id:
        return   # Client прислал данные другого сервера - не принимаем
    var sender := multiplayer.get_remote_sender_id()
    if not roster.has(sender):
        return
    var submitted: Dictionary = _survival_clean_state(state, save_id)
    if not state.is_empty() and submitted.is_empty():
        return
    survival_client_ids[sender] = player_id
    # Берём самое свежее: сохранение с телефона Client-а или копия, которую Host уже хранит для этого игрока.
    var best: Dictionary = submitted
    var host_copy: Dictionary = SurvivalSaves.client_snapshots.get(player_id, {})
    host_copy = _survival_clean_state(host_copy, save_id) if not host_copy.is_empty() else {}
    if best.is_empty() or (not host_copy.is_empty() and int(host_copy.get("rev", 0)) > int(best.get("rev", 0))):
        best = host_copy
    if not best.is_empty():
        survival_recovered_states[player_id] = best.duplicate(true)
    _team_reconnect(sender, player_id)
    if game_mode == MODE_SURVIVAL and not survival_save_name.is_empty():
        if not best.is_empty():
            SurvivalSaves.client_snapshots[player_id] = best.duplicate(true)
            SurvivalSaves.save_slot(survival_save_name, survival_host_position, survival_host_hp, survival_host_yaw, survival_host_pitch)
    # Возвращаем игрока в сохранённую точку ТОЛЬКО ОДИН РАЗ при входе в идущий бой.
    # Повторные отправки сохранения (автосохранение) позицию уже не трогают.
    if battle_active and game_mode == MODE_SURVIVAL and roster.has(sender) and not _survival_live_restored.has(sender):
        var restored: Dictionary = _survival_saved_state_for(sender)
        if not restored.is_empty():
            _survival_live_restored[sender] = true
            _survival_apply_live_state(sender, restored)
            _survival_restore_player.rpc_id(sender, restored)
            _survival_live_positions.rpc(battle_positions, battle_health)
    notice.emit("Данные выживания игрока получены")

func survival_submit_saved_recovery() -> void:
    if role != "client":
        return
    if SurvivalSaves.client_server_id.is_empty():
        return
    _survival_submit_recovery.rpc_id(1, _survival_local_id(), SurvivalSaves.client_server_id, SurvivalSaves.load_client_recovery())

var survival_restore_clients: Dictionary = {}
@rpc("authority", "call_remote", "reliable")
func _survival_server_identity(save_id: String, save_name: String) -> void:
    if role != "client" or save_id.length() != 32:
        return
    SurvivalSaves.set_client_server(save_id, save_name)
    survival_submit_saved_recovery()

## peer -> "save_id|имя", которые Host уже отправил. Раньше identity уходила КАЖДОМУ клиенту при каждом автосохранении Host-а,
## клиент в ответ заново отправлял старое сохранение, и Host телепортировал его в старую точку (раз в 15-60 с).
var _survival_identity_sent: Dictionary = {}
## peer -> true: Host уже вернул этому игроку сохранённое состояние в текущем бою. Повторно в бою НЕ применяем.
var _survival_live_restored: Dictionary = {}
## ник -> время (мс), до которого вход этого игрока уже одобрен принятым приглашением (второе подтверждение не нужно).
var _survival_invited_nicks: Dictionary = {}
const SURVIVAL_INVITE_APPROVAL_MS: int = 60000

func _survival_sync_identity(peer_id: int, force: bool = false) -> void:
    if role != "host" or survival_save_id.is_empty():
        return
    var sig: String = survival_save_id + "|" + survival_save_name
    if not force and str(_survival_identity_sent.get(peer_id, "")) == sig:
        return
    _survival_identity_sent[peer_id] = sig
    _survival_server_identity.rpc_id(peer_id, survival_save_id, survival_save_name)

func _survival_preapprove_nick(nick: String) -> void:
    _survival_invited_nicks[GameState.clean_nick(nick)] = Time.get_ticks_msec() + SURVIVAL_INVITE_APPROVAL_MS

func _survival_consume_preapproval(nick: String) -> bool:
    var key: String = GameState.clean_nick(nick)
    var until_ms: int = int(_survival_invited_nicks.get(key, 0))
    if until_ms <= 0:
        return false
    _survival_invited_nicks.erase(key)
    return until_ms > Time.get_ticks_msec()

func _survival_has_preapproval(nick: String) -> bool:
    return int(_survival_invited_nicks.get(GameState.clean_nick(nick), 0)) > Time.get_ticks_msec()

## Host: игрок вышел из игры/боя -> запоминаем его ПОСЛЕДНЕЕ положение/HP/взгляд и пишем в сохранение мира.
func _survival_store_disconnected(peer: int) -> void:
    if role != "host" or game_mode != MODE_SURVIVAL or not battle_active or survival_save_name.is_empty():
        return
    var key: String = str(survival_client_ids.get(peer, ""))
    if key.is_empty() or not battle_positions.has(peer):
        return
    var base: Dictionary = survival_recovered_states.get(key, SurvivalSaves.client_snapshots.get(key, {}))
    if base.is_empty():
        base = {"save_id": survival_save_id, "save_name": survival_save_name, "rev": 0, "inventory": [], "equipment": []}
    var pos: Vector3 = battle_positions[peer]
    base = base.duplicate(true)
    base["pos"] = [pos.x, pos.y, pos.z]
    base["health"] = clampi(int(battle_health.get(peer, 100)), 1, 100)
    base["yaw"] = float(battle_yaws.get(peer, base.get("yaw", 0.0)))
    base["pitch"] = float(battle_pitches.get(peer, base.get("pitch", 0.0)))
    base["rev"] = int(base.get("rev", 0)) + 1
    base["saved_at"] = Time.get_unix_time_from_system()
    var clean: Dictionary = _survival_clean_state(base, survival_save_id)
    if clean.is_empty():
        return
    SurvivalSaves.client_snapshots[key] = clean
    survival_recovered_states[key] = clean.duplicate(true)
    SurvivalSaves.save_slot(survival_save_name, survival_host_position, survival_host_hp, survival_host_yaw, survival_host_pitch)

var survival_save_name: String = ""
var survival_host_position: Vector3 = Vector3.ZERO
var survival_host_hp: int = 100
var survival_host_yaw: float = 0.0
var survival_host_pitch: float = 0.0

func survival_collect_save(slot_name: String, pos: Vector3, hp: int, facing_yaw: float, facing_pitch: float) -> void:
    if role == "client":
        return
    var clean_name := SurvivalSaves._safe_name(slot_name)
    if survival_save_name != clean_name or survival_save_id.is_empty():
        if not survival_save_id.is_empty() and not FileAccess.file_exists(SurvivalSaves.ROOT + clean_name + ".json"):
            # Идущий мир сохраняется под новым именем: id мира остаётся прежним,
            # поэтому сохранения клиентов этого сервера не теряются.
            SurvivalSaves.active_save_id = survival_save_id
        else:
            survival_save_id = SurvivalSaves.ensure_save_identity(clean_name)
            survival_recovered_states.clear()
            SurvivalSaves.client_snapshots.clear()
    survival_save_name = clean_name
    if role == "host":
        for peer in roster.keys():
            if int(peer) != my_id():
                _survival_sync_identity(int(peer))
    survival_host_position = pos
    survival_host_hp = hp
    survival_host_yaw = facing_yaw
    survival_host_pitch = facing_pitch
    # Keep the last received client state if a peer has disconnected.
    if role == "host":
        for peer in roster.keys():
            if int(peer) != my_id():
                _survival_request_snapshot.rpc_id(int(peer))
    SurvivalSaves.saved_teams = _team_export_saved()
    SurvivalSaves.save_slot(slot_name, pos, hp, facing_yaw, facing_pitch)

## Откуда Client берёт СВОЁ актуальное состояние (позиция, взгляд камеры, HP): battle.gd задаёт эту функцию.
## Должна вернуть {"pos": Vector3, "health": int, "yaw": float, "pitch": float}.
var survival_local_provider: Callable = Callable()

## Client: записывает своё состояние на телефон (отдельный файл для этого сервера) и возвращает его.
func survival_client_save_local() -> Dictionary:
    if role != "client" or game_mode != MODE_SURVIVAL or SurvivalSaves.client_server_id.is_empty():
        return {}
    var view: Dictionary = {}
    if survival_local_provider.is_valid():
        view = survival_local_provider.call()
    var pos: Vector3 = view.get("pos", battle_positions.get(my_id(), Vector3.ZERO))
    var hp: int = int(view.get("health", battle_health.get(my_id(), 100)))
    var yaw_value: float = float(view.get("yaw", battle_yaws.get(my_id(), 0.0)))
    var pitch_value: float = float(view.get("pitch", battle_pitches.get(my_id(), 0.0)))
    return SurvivalSaves.save_client_recovery(pos, hp, yaw_value, pitch_value)

func survival_send_local_snapshot() -> void:
    if role != "client" or game_mode != MODE_SURVIVAL or not battle_active or SurvivalSaves.client_server_id.is_empty():
        return
    var state: Dictionary = survival_client_save_local()
    if state.is_empty():
        return
    state["save_id"] = SurvivalSaves.client_server_id
    _survival_receive_snapshot.rpc_id(1, state)

@rpc("authority", "call_remote", "reliable")
func _survival_request_snapshot() -> void:
    if role != "client" or game_mode != MODE_SURVIVAL or not battle_active or SurvivalSaves.client_server_id.is_empty():
        return
    var state: Dictionary = survival_client_save_local()
    if state.is_empty():
        return
    state["save_id"] = SurvivalSaves.client_server_id
    _survival_receive_snapshot.rpc_id(1, state)

## Host не доверяет данным Client-а: проверяем формат, числа и предметы. Пустой словарь = данные отклонены.
func _survival_clean_state(state: Dictionary, expected_save_id: String) -> Dictionary:
    if state.is_empty():
        return {}
    if str(state.get("save_id", expected_save_id)) != expected_save_id:
        return {}   # состояние с ДРУГОГО сервера не принимаем
    var xyz = state.get("pos", [])
    if not (xyz is Array) or xyz.size() != 3:
        return {}
    var x := float(xyz[0])
    var y := float(xyz[1])
    var z := float(xyz[2])
    if not (is_finite(x) and is_finite(y) and is_finite(z)):
        return {}
    var yaw_value := float(state.get("yaw", 0.0))
    var pitch_value := float(state.get("pitch", 0.0))
    if not is_finite(yaw_value) or not is_finite(pitch_value):
        return {}
    return {
        "save_id": expected_save_id,
        "save_name": str(state.get("save_name", survival_save_name)),
        "rev": maxi(0, int(state.get("rev", 0))),
        "saved_at": float(state.get("saved_at", 0.0)),
        "pos": [x, y, z],
        "health": clampi(int(state.get("health", 100)), 0, 100),
        "yaw": wrapf(yaw_value, -PI, PI),
        "pitch": clampf(pitch_value, -PI * 0.5, PI * 0.5),
        "inventory": GameState.sanitize_battle_slots(state.get("inventory", []), GameState.INV_SIZE),
        "equipment": GameState.sanitize_battle_slots(state.get("equipment", []), GameState.GEAR_SIZE),
    }

@rpc("any_peer", "call_remote", "reliable")
func _survival_receive_snapshot(state: Dictionary) -> void:
    if role != "host" or survival_save_name.is_empty() or game_mode != MODE_SURVIVAL:
        return
    var sender := multiplayer.get_remote_sender_id()
    if not roster.has(sender):
        return
    # Peer IDs are scoped to this Host session. Rejoining with a different ID starts fresh.
    var stable_key: String = str(survival_client_ids.get(sender, str(sender)))
    if survival_save_id.is_empty() or str(state.get("save_id", "")) != survival_save_id:
        return
    var clean_snapshot: Dictionary = _survival_clean_state(state, survival_save_id)
    if clean_snapshot.is_empty():
        return
    SurvivalSaves.client_snapshots[stable_key] = clean_snapshot
    survival_recovered_states[stable_key] = clean_snapshot.duplicate(true)
    SurvivalSaves.save_slot(survival_save_name, survival_host_position, survival_host_hp, survival_host_yaw, survival_host_pitch)

## Host загрузил данные игрока на сервер и вернул их: позиция, взгляд камеры, HP, инвентарь.
## Если бой уже идёт, battle.gd применяет их сразу (раньше они применялись только при создании сцены боя).
signal survival_state_restored(state: Dictionary)

@rpc("authority", "call_remote", "reliable")
func _survival_restore_player(state: Dictionary) -> void:
    if role != "client" or game_mode != MODE_SURVIVAL:
        return
    survival_restore_clients = state.duplicate(true)
    survival_state_restored.emit(survival_restore_clients)
    var xyz: Array = state.get("pos", [])
    if xyz.size() == 3:
        battle_positions[my_id()] = Vector3(float(xyz[0]), float(xyz[1]), float(xyz[2]))
    battle_health[my_id()] = int(state.get("health", 100))
    battle_yaws[my_id()] = float(state.get("yaw", 0.0))
    battle_pitches[my_id()] = float(state.get("pitch", 0.0))

func start_battle() -> void:
    if battle_active:
        if role != "client":
            notice.emit("Бой ещё идёт")
        return
    if role == "client":
        notice.emit("Бой запускает Host")
        return
    if game_mode == MODE_DUEL and (roster.size() < 2 or roster.size() > 4):
        notice.emit("Для режима 1 на 1 нужно от 2 до 4 игроков")
        return
    survival_restore_clients.clear()
    _survival_live_restored.clear()
    survival_teams.clear()
    survival_team_offline.clear()
    pending_team_invites.clear()
    teams_changed.emit()
    if game_mode == MODE_SURVIVAL:
        var saved_survival := SurvivalSaves.load_slot(SurvivalSaves.pending_slot)
        var saved_clients: Dictionary = saved_survival.get("clients", {})
        if role == "host":
            _team_import_saved(saved_survival.get("teams", []))
        if role == "host":
            survival_save_name = SurvivalSaves._safe_name(SurvivalSaves.pending_slot)
            survival_save_id = SurvivalSaves.ensure_save_identity(survival_save_name)
            for peer in roster.keys():
                if int(peer) != my_id():
                    _survival_sync_identity(int(peer))
        if role == "host":
            SurvivalSaves.client_snapshots = saved_clients.duplicate(true)
            for stable_id in survival_recovered_states.keys():
                var recovered: Dictionary = survival_recovered_states[stable_id]
                if str(recovered.get("save_id", "")) == survival_save_id:
                    SurvivalSaves.client_snapshots[stable_id] = recovered.duplicate(true)
        if role == "host":
            for key in saved_clients.keys():
                var peer := int(key)
                if roster.has(peer) and peer != my_id():
                    survival_restore_clients[peer] = saved_clients[key]
            for peer_id in survival_client_ids.keys():
                var stable_key: String = str(survival_client_ids[peer_id])
                if roster.has(peer_id):
                    if survival_recovered_states.has(stable_key) and str(survival_recovered_states[stable_key].get("save_id", "")) == survival_save_id:
                        survival_restore_clients[peer_id] = survival_recovered_states[stable_key]
                    elif saved_clients.has(stable_key):
                        survival_restore_clients[peer_id] = saved_clients[stable_key]
    duel_round = 0
    battle_positions.clear()
    battle_crouches.clear()
    battle_yaws.clear()
    battle_pitches.clear()
    battle_weapons.clear()
    battle_aims.clear()
    battle_attach.clear()
    battle_health.clear()
    _reset_life_states()
    local_battle_left = false
    battle_leader_id = 1
    death_bags.clear()
    _death_bag_created_owners.clear()
    _death_bag_pending.clear()
    bot_loot.clear()
    _last_shot_ms.clear()
    downed_pistol_peers.clear()
    downed_pistol_peers[1] = GameState.downed_pistol_talent
    var spawn_index := 0
    for id in roster.keys():
        if game_mode == MODE_ZOMBIES:
            # Stage80: игроки появляются на площадке «Титаника».
            battle_positions[int(id)] = TitanicMap.player_spawn(spawn_index)
        else:
            battle_positions[int(id)] = Vector3((battle_positions.size() - 1) * 3.0, 1.0, 0.0)
        spawn_index += 1
        battle_yaws[int(id)] = 0.0
        battle_health[int(id)] = 100
        battle_state[int(id)] = ST_ALIVE
        battle_bleed[int(id)] = BLEED_START
    if game_mode == MODE_SURVIVAL:
        for peer in survival_restore_clients.keys():
            var state: Dictionary = survival_restore_clients[peer]
            var xyz: Array = state.get("pos", [])
            if xyz.size() == 3:
                battle_positions[int(peer)] = Vector3(float(xyz[0]), float(xyz[1]), float(xyz[2]))
            battle_health[int(peer)] = int(state.get("health", 100))
            battle_yaws[int(peer)] = float(state.get("yaw", 0.0))
            battle_pitches[int(peer)] = float(state.get("pitch", 0.0))
        _create_bots()
    zombie_time_left = 120.0
    zombie_win = false
    zombie_positions.clear()
    zombie_attack_cooldowns.clear()
    zombie_spawn_clock = 0.0
    zombie_nav = null
    zombie_paths.clear()
    _reset_zombie_state()
    battle_active = true
    if game_mode == MODE_DUEL:
        _duel_select_round()
    if role == "host":
        _receive_game_mode.rpc(game_mode)
        _battle_begin.rpc(battle_positions)
        _health_snapshot.rpc(battle_health)
        for peer in survival_restore_clients.keys():
            _survival_restore_player.rpc_id(int(peer), survival_restore_clients[peer])
            _survival_live_restored[int(peer)] = true
        _sync_bot_loot.rpc(bot_loot)
    battle_started.emit()


@rpc("authority", "call_remote", "reliable")
func _battle_begin(positions: Dictionary) -> void:
    if role != "client":
        return
    battle_positions = positions.duplicate(true)
    battle_pitches.clear()
    battle_weapons.clear()
    battle_aims.clear()
    battle_attach.clear()
    battle_health.clear()
    _reset_life_states()
    bot_loot.clear()
    for id in positions.keys():
        battle_health[int(id)] = 100
        battle_state[int(id)] = ST_ALIVE
        battle_bleed[int(id)] = BLEED_START
    battle_active = true
    zombie_time_left = 120.0
    zombie_win = false
    zombie_positions.clear()
    _reset_zombie_state()
    local_battle_left = false
    battle_leader_id = 1
    register_downed_pistol_talent()
    battle_started.emit()


func submit_battle_crouch(value: bool) -> void:
    if not battle_active:
        return
    if role == "client":
        _client_crouch.rpc_id(1, value)
    else:
        battle_crouches[1] = value
        if role == "host":
            _sync_crouch.rpc(1, value)

@rpc("any_peer", "call_remote", "reliable")
func _client_crouch(value: bool) -> void:
    if role != "host" or not battle_active:
        return
    var peer := multiplayer.get_remote_sender_id()
    if not roster.has(peer):
        return
    battle_crouches[peer] = value
    _sync_crouch.rpc(peer, value)

@rpc("authority", "call_remote", "reliable")
func _sync_crouch(peer: int, value: bool) -> void:
    if role == "client" and battle_active:
        battle_crouches[peer] = value

func submit_battle_position(pos: Vector3, facing_yaw: float = 0.0, pitch: float = 0.0) -> void:
    if not battle_active:
        return
    if role == "client":
        _battle_move.rpc_id(1, pos, facing_yaw, pitch)
    else:
        battle_positions[1] = pos
        battle_yaws[1] = facing_yaw
        battle_pitches[1] = pitch


## Действие игрока (сейчас "reload"): хост рассылает остальным, чтобы они слышали и видели его.
func submit_battle_event(kind: String) -> void:
    if not battle_active or kind != "reload":
        return
    if role == "client":
        _client_event.rpc_id(1, kind)
    elif role == "host":
        _sync_event.rpc(1, kind)

@rpc("any_peer", "call_remote", "reliable")
func _client_event(kind: String) -> void:
    if role != "host" or not battle_active or kind != "reload":
        return
    var peer := multiplayer.get_remote_sender_id()
    if not roster.has(peer):
        return
    battle_event.emit(peer, kind)
    _sync_event.rpc(peer, kind)

@rpc("authority", "call_remote", "reliable")
func _sync_event(peer: int, kind: String) -> void:
    if role == "client" and battle_active and kind == "reload":
        battle_event.emit(peer, kind)


## ---------- Чат боя ----------
## Клиент шлёт текст хосту, хост проверяет (длина, частота, ник из списка игроков) и рассылает всем.
## В одиночной игре сообщение просто показывается у себя.
signal chat_message(peer: int, nick: String, text: String)
const CHAT_MAX_LENGTH := 120
const CHAT_MIN_INTERVAL_MS := 400
var _chat_last_ms: Dictionary = {}

func _clean_chat_text(raw: String) -> String:
    var out := ""
    for i in raw.length():
        var code := raw.unicode_at(i)
        out += " " if code < 32 or code == 127 else raw[i]   # управляющие символы -> пробел
    return out.strip_edges().left(CHAT_MAX_LENGTH)

func _chat_nick(peer: int) -> String:
    var nick := str(roster.get(peer, {}).get("nick", ""))
    if nick == "":
        nick = GameState.nickname if peer == my_id() else "Игрок %d" % peer
    return nick

func send_chat(text: String) -> void:
    text = _clean_chat_text(text)
    if text == "":
        return
    if role == "client":
        _client_chat.rpc_id(1, text)
    else:
        chat_message.emit(1, _chat_nick(1), text)
        if role == "host":
            _sync_chat.rpc(1, _chat_nick(1), text)

@rpc("any_peer", "call_remote", "reliable")
func _client_chat(text: String) -> void:
    if role != "host":
        return
    var peer := multiplayer.get_remote_sender_id()
    if not roster.has(peer):
        return
    var now := Time.get_ticks_msec()
    if now - int(_chat_last_ms.get(peer, -100000)) < CHAT_MIN_INTERVAL_MS:
        return
    _chat_last_ms[peer] = now
    text = _clean_chat_text(text)
    if text == "":
        return
    var nick := _chat_nick(peer)
    chat_message.emit(peer, nick, text)
    _sync_chat.rpc(peer, nick, text)

@rpc("authority", "call_remote", "reliable")
func _sync_chat(peer: int, nick: String, text: String) -> void:
    if role == "client":
        chat_message.emit(peer, nick.left(32), _clean_chat_text(text))


## Что у меня в руках и целюсь ли я: хост рассылает всем, чтобы оружие было видно на модели.
func submit_battle_hold(weapon_id: String, aiming: bool, collimator: bool = false) -> void:
    if not battle_active:
        return
    if weapon_id != "" and not Weapons.has(weapon_id):
        weapon_id = ""
    if role == "client":
        _client_hold.rpc_id(1, weapon_id, aiming, collimator)
    else:
        battle_weapons[1] = weapon_id
        battle_aims[1] = aiming
        battle_attach[1] = collimator and Weapons.has_collimator(weapon_id)
        if role == "host":
            _sync_hold.rpc(1, weapon_id, aiming, battle_attach[1])

@rpc("any_peer", "call_remote", "reliable")
func _client_hold(weapon_id: String, aiming: bool, collimator: bool) -> void:
    if role != "host" or not battle_active:
        return
    var peer := multiplayer.get_remote_sender_id()
    if not roster.has(peer):
        return
    if weapon_id != "" and not Weapons.has(weapon_id):
        weapon_id = ""
    var was_sword: bool = str(battle_weapons.get(peer, "")) == "diamond_sword"
    var is_sword: bool = weapon_id == "diamond_sword"
    if was_sword != is_sword and battle_health.has(peer):
        battle_health[peer] = maxi(1, int(battle_health[peer]) + (340 if is_sword else -340))
        health_changed.emit(peer, int(battle_health[peer]))
        _health_snapshot.rpc(battle_health)
    battle_weapons[peer] = weapon_id
    battle_aims[peer] = aiming
    battle_attach[peer] = collimator and Weapons.has_collimator(weapon_id)
    _sync_hold.rpc(peer, weapon_id, aiming, battle_attach[peer])

@rpc("authority", "call_remote", "reliable")
func _sync_hold(peer: int, weapon_id: String, aiming: bool, collimator: bool) -> void:
    if role == "client" and battle_active:
        battle_weapons[peer] = weapon_id
        battle_aims[peer] = aiming
        battle_attach[peer] = collimator


@rpc("any_peer", "call_remote", "unreliable_ordered")
func _battle_move(pos: Vector3, facing_yaw: float, pitch: float = 0.0) -> void:
    if role != "host" or not battle_active:
        return
    var id := multiplayer.get_remote_sender_id()
    if not roster.has(id):
        return
    var old: Vector3 = battle_positions.get(id, Vector3.ZERO)
    # Бег как в CS2 (до ~6.4 м/с): допускаем потерю нескольких пакетов.
    if old.distance_to(pos) <= 5.0 and pos.y >= 1.0 and pos.y <= 4.0:
        battle_positions[id] = pos
        battle_yaws[id] = wrapf(facing_yaw, -PI, PI)
        battle_pitches[id] = clampf(pitch, -1.4, 1.4)


@rpc("authority", "call_remote", "unreliable_ordered")
func _battle_snapshot(positions: Dictionary, yaws: Dictionary, pitches: Dictionary = {}) -> void:
    if role != "client" or not battle_active:
        return
    battle_positions = positions.duplicate(true)
    for raw_id in positions.keys():
        var id := int(raw_id)
        if id >= BOT_ID_START and not bot_loot.has(id):
            bot_loot[id] = {"weapon": "ak47", "medkits": 0, "ammo": 1}
            battle_health[id] = 100
            battle_state[id] = ST_ALIVE
            battle_bleed[id] = BLEED_START
    battle_yaws = yaws.duplicate(true)
    battle_pitches = pitches.duplicate(true)
    battle_positions_changed.emit()


## Host owns world drops; clients request creation and pickup.
func request_world_drop(stack: Dictionary, pos: Vector3, facing: float) -> bool:
    if not battle_active or not GameState.ITEMS.has(str(stack.get("id", ""))):
        return false
    if peer_state(my_id()) != ST_ALIVE:
        return false
    if role == "client":
        _request_world_drop.rpc_id(1, stack, pos, facing)
    else:
        _host_create_world_drop(stack, pos, facing)
    return true

@rpc("any_peer", "call_remote", "reliable")
func _request_world_drop(stack: Dictionary, pos: Vector3, facing: float) -> void:
    if role != "host" or not battle_active:
        return
    var sender := multiplayer.get_remote_sender_id()
    if not battle_positions.has(sender) or pos.distance_to(battle_positions[sender]) > 4.0:
        return
    if peer_state(sender) != ST_ALIVE:
        return   # в нокауте и мёртвые не выбрасывают лут
    if not GameState.ITEMS.has(str(stack.get("id", ""))):
        return
    _host_create_world_drop(stack, pos, facing)

func _host_create_world_drop(stack: Dictionary, pos: Vector3, facing: float) -> void:
    var id := _next_world_item_id
    _next_world_item_id += 1
    world_items[id] = {"stack": stack.duplicate(true), "pos": pos, "facing": facing}
    world_item_added.emit(id, stack, pos, facing)
    if role == "host":
        _world_drop_created.rpc(id, stack, pos, facing)

@rpc("authority", "call_remote", "reliable")
func _world_drop_created(id: int, stack: Dictionary, pos: Vector3, facing: float) -> void:
    world_items[id] = {"stack": stack.duplicate(true), "pos": pos, "facing": facing}
    world_item_added.emit(id, stack, pos, facing)

func request_world_pickup(id: int) -> void:
    if role == "client":
        _request_world_pickup.rpc_id(1, id)
    else:
        _host_pickup_world_item(my_id(), id)

@rpc("any_peer", "call_remote", "reliable")
func _request_world_pickup(id: int) -> void:
    if role == "host":
        _host_pickup_world_item(multiplayer.get_remote_sender_id(), id)

func _host_pickup_world_item(peer: int, id: int) -> void:
    if not battle_active or not world_items.has(id) or not battle_positions.has(peer):
        return
    var record: Dictionary = world_items[id]
    if battle_positions[peer].distance_to(record["pos"]) > 3.5:
        return
    world_items.erase(id)
    world_item_removed.emit(id)
    if role == "host":
        _world_drop_removed.rpc(id)
    if peer == my_id():
        pickup_accepted.emit(record["stack"])
    else:
        _pickup_confirmed.rpc_id(peer, record["stack"])

@rpc("authority", "call_remote", "reliable")
func _world_drop_removed(id: int) -> void:
    world_items.erase(id)
    world_item_removed.emit(id)

@rpc("authority", "call_remote", "reliable")
func _pickup_confirmed(stack: Dictionary) -> void:
    pickup_accepted.emit(stack)

func sync_world_items_to(peer: int) -> void:
    if role != "host":
        return
    for id in world_items:
        var record: Dictionary = world_items[id]
        _world_drop_created.rpc_id(peer, id, record["stack"], record["pos"], record["facing"])

func end_battle() -> void:
    _survival_live_restored.clear()
    world_items.clear()
    world_items_reset.emit()
    battle_active = false
    battle_positions.clear()
    battle_crouches.clear()
    battle_yaws.clear()
    battle_pitches.clear()
    battle_weapons.clear()
    battle_aims.clear()
    battle_attach.clear()
    battle_health.clear()
    _reset_life_states()
    local_battle_left = false
    battle_leader_id = 1
    _last_shot_ms.clear()
    turrets.clear()
    turret_aims.clear()
    turret_ammo.clear()
    turret_hp.clear()
    _turret_state.clear()


func my_id() -> int:
    return multiplayer.get_unique_id() if role == "client" else 1


func is_busy() -> bool:
    return role == "client" or roster.size() >= MAX_PLAYERS or _joining_uid != ""


## Есть ли входящее приглашение, которое ещё не принято/отклонено (нужно, если окно открывается после смены сцены).
func has_incoming_invite() -> bool:
    return _incoming_uid != ""


func incoming_invite_nick() -> String:
    return _incoming_nick


func can_invite() -> bool:
    return online and role != "client" and roster.size() < MAX_PLAYERS and _pending_uid == ""


func friends_list() -> Array:
    var out: Array = []
    for key in friends.keys():
        var f: Dictionary = friends[key]
        out.append({"uid": str(key), "nick": f["nick"], "busy": f["busy"]})
    out.sort_custom(func(a, b): return str(a["nick"]).to_lower() < str(b["nick"]).to_lower())
    return out


func invite(friend_uid: String) -> void:
    if not friends.has(friend_uid):
        return
    if role == "client" or roster.size() >= MAX_PLAYERS:
        notice.emit("Вы не можете приглашать: лобби занято")
        return
    if _pending_uid != "":
        notice.emit("Приглашение уже отправлено")
        return
    var f: Dictionary = friends[friend_uid]
    if bool(f["busy"]):
        notice.emit("Игрок уже в лобби")
        return
    _pending_uid = friend_uid
    _pending_left = INVITE_TIMEOUT
    _send(str(f["ip"]), {"k": "invite", "u": uid, "n": GameState.nickname})
    notice.emit("Приглашение отправлено: %s" % str(f["nick"]))
    friends_changed.emit()


func accept_invite() -> void:
    if _incoming_uid == "":
        return
    var ip: String = _incoming_ip
    var host_uid: String = _incoming_uid
    _incoming_uid = ""
    invite_closed.emit()
    if role != "solo":
        _return_to_solo("")
    _joining_uid = host_uid
    _joining_left = JOIN_TIMEOUT
    _send(ip, {"k": "accept", "u": uid, "n": GameState.nickname})
    notice.emit("Подключение к лобби...")


func decline_invite() -> void:
    if _incoming_uid == "":
        return
    _send(_incoming_ip, {"k": "decline", "u": uid, "n": GameState.nickname})
    _incoming_uid = ""
    invite_closed.emit()


func leave_lobby() -> void:
    if role == "solo":
        return
    _return_to_solo("Вы вышли из лобби")


## Поворот своего персонажа (свайп по модели).
func add_my_yaw(d: float) -> void:
    my_yaw = wrapf(my_yaw + d, -PI, PI)
    if role == "client":
        _yaw_pending = true
    elif roster.has(1):
        var e: Dictionary = roster[1]
        e["yaw"] = my_yaw
        _dirty = true


# ======================================================================
#  Состояние лобби
# ======================================================================

func _own_entry(x: float) -> Dictionary:
    return {
        "nick": GameState.nickname,
        "money": GameState.money,
        "loadout": GameState.get_loadout(),
        "hand": GameState.get_hand_weapon(),
        "skin": GameState.skin,
        "x": x, "tx": x, "yaw": my_yaw,
    }


func _reset_solo_roster() -> void:
    roster = {1: _own_entry(0.0)}


func _set_role(r: String) -> void:
    role = r
    role_changed.emit()


func _roster_sig(r: Dictionary) -> String:
    var parts: Array = []
    for id in r.keys():
        var e: Dictionary = r[id]
        parts.append("%s:%s:%s" % [str(id), str(e.get("nick", "")), str(e.get("money", 0)) + "/" + str(e.get("skin", 0))])
    return "|".join(parts)


func _on_local_changed() -> void:
    if role == "client":
        _req_profile.rpc_id(1, GameState.nickname, GameState.money, GameState.get_loadout(), GameState.get_hand_weapon(), GameState.skin)
        return
    if not roster.has(1):
        return
    var e: Dictionary = roster[1]
    e["nick"] = GameState.nickname
    e["money"] = GameState.money
    e["loadout"] = GameState.get_loadout()
    e["hand"] = GameState.get_hand_weapon()
    e["skin"] = GameState.skin
    roster_changed.emit()
    if role == "host" and roster.size() > 1:
        _sync_roster.rpc(roster)


func _return_to_solo(message: String) -> void:
    if battle_active:
        end_battle()
        get_tree().call_deferred("change_scene_to_file", "res://main.tscn")
    var was_client := role == "client"
    _joining_uid = ""
    _host_wait_left = 0.0
    internet_mode = false
    if was_client:
        # Удаляем полученные байты из памяти; персональный фон не трогаем.
        lobby_background_data = _personal_background_data.duplicate()
        _personal_background_data.clear()
        lobby_background_changed.emit(lobby_background_data)
        lobby_music_data = _personal_music_data.duplicate()
        lobby_music_volume = _personal_music_volume
        _personal_music_data.clear()
        _music_receive.clear()
        _music_expected = 0
        lobby_music_changed.emit(lobby_music_data)
        lobby_music_volume_changed.emit(lobby_music_volume)
    if _enet != null:
        _enet.close()
        _enet = null
    multiplayer.multiplayer_peer = null
    _reset_solo_roster()
    battle_leader_id = 1
    local_battle_left = false
    _dirty = false
    _yaw_pending = false
    _set_role("solo")
    roster_changed.emit()
    friends_changed.emit()
    if message != "":
        notice.emit(message)


func _host_tick(delta: float) -> void:
    var finished_walk: bool = false
    for id in roster.keys():
        if int(id) == 1:
            continue
        var e: Dictionary = roster[id]
        var x: float = float(e["x"])
        var tx: float = float(e["tx"])
        if not is_equal_approx(x, tx):
            var nx: float = move_toward(x, tx, WALK_SPEED * delta)
            e["x"] = nx
            _dirty = true
            if is_equal_approx(nx, tx):
                finished_walk = true
    if roster.size() < MAX_PLAYERS and _host_wait_left > 0.0:
        _host_wait_left -= delta
        if _host_wait_left <= 0.0:
            if battle_active:
                _host_wait_left = 0.0   # идёт бой: не закрываем игру хозяину, если приглашённый не подключился
            else:
                _return_to_solo("Игрок не подключился")
                return
    if roster.size() > 1:
        if finished_walk:
            _sync_roster.rpc(roster)
        _full_timer += delta
        if _full_timer >= 1.0:
            _full_timer = 0.0
            _sync_roster.rpc(roster)   # страховка от потерянных unreliable-пакетов
        _sync_timer += delta
        if _dirty and _sync_timer >= 0.05:
            _sync_timer = 0.0
            _dirty = false
            var data: Dictionary = {}
            for id in roster.keys():
                var e2: Dictionary = roster[id]
                data[id] = Vector2(float(e2["x"]), float(e2["yaw"]))
            _sync_transforms.rpc(data)


# ======================================================================
#  ENet: события соединения
# ======================================================================

func _start_host() -> bool:
    if role == "host":
        return true
    _enet = ENetMultiplayerPeer.new()
    var err: int = _enet.create_server(GAME_PORT, MAX_PLAYERS - 1)
    if err != OK:
        _enet = null
        return false
    multiplayer.multiplayer_peer = _enet
    _host_wait_left = JOIN_TIMEOUT + 4.0
    internet_mode = false
    _set_role("host")
    return true


## Internet Host: listens on the chosen UDP port on all network interfaces.
## Public IPv4 and router UDP port forwarding are configured outside Godot.
func start_online_host(port: int = GAME_PORT) -> bool:
    if role != "solo" or _enet != null:
        notice.emit("Сначала выйдите из текущего лобби")
        return false
    if port < MIN_ONLINE_PORT or port > MAX_ONLINE_PORT:
        notice.emit("Неверный UDP-порт")
        return false
    _enet = ENetMultiplayerPeer.new()
    var err: int = _enet.create_server(port, MAX_PLAYERS - 1)
    if err != OK:
        _enet = null
        notice.emit("Не удалось открыть UDP-порт %d (ошибка %d)" % [port, err])
        return false
    multiplayer.multiplayer_peer = _enet
    internet_port = port
    internet_mode = true
    # Unlike the LAN invitation, wait until the host closes the room.
    _host_wait_left = 0.0
    _set_role("host")
    roster_changed.emit()
    notice.emit("Online Host запущен: UDP %d" % port)
    return true


func join_online_host(ip: String, port: int = GAME_PORT) -> bool:
    ip = ip.strip_edges()
    if role != "solo" or _enet != null:
        notice.emit("Сначала выйдите из текущего лобби")
        return false
    if not ip.is_valid_ip_address() or ip.contains(":"):
        notice.emit("Введите IPv4-адрес Host")
        return false
    if port < MIN_ONLINE_PORT or port > MAX_ONLINE_PORT:
        notice.emit("Неверный UDP-порт")
        return false
    _enet = ENetMultiplayerPeer.new()
    var err: int = _enet.create_client(ip, port)
    if err != OK:
        _enet = null
        notice.emit("Не удалось начать соединение (ошибка %d)" % err)
        return false
    internet_mode = true
    internet_port = port
    multiplayer.multiplayer_peer = _enet
    _joining_left = 15.0
    notice.emit("Подключение к %s:%d..." % [ip, port])
    return true


func _connect_to_host(ip: String) -> void:
    if _enet != null:
        return
    _enet = ENetMultiplayerPeer.new()
    var err: int = _enet.create_client(ip, GAME_PORT)
    if err != OK:
        _enet = null
        _joining_uid = ""
        notice.emit("Не удалось подключиться к лобби")
        return
    multiplayer.multiplayer_peer = _enet
    _joining_left = JOIN_TIMEOUT


func _on_connected_to_server() -> void:
    _joining_uid = ""
    roster = {}
    _last_sig = ""
    _personal_background_data = lobby_background_data.duplicate()
    _personal_music_data = lobby_music_data.duplicate()
    _personal_music_volume = lobby_music_volume
    _set_role("client")
    # Автоматически запрашиваем фон Host при подключении.
    request_lobby_background()
    request_lobby_music()
    _req_join.rpc_id(1, GameState.nickname, GameState.money, GameState.get_loadout(), GameState.get_hand_weapon(), GameState.skin)
    _yaw_pending = true
    notice.emit("Вы в лобби другого игрока")


func _on_connection_failed() -> void:
    _return_to_solo.call_deferred("Не удалось подключиться к лобби")


func _on_server_disconnected() -> void:
    # The battle scene may be destroyed immediately; preserve the latest local state first.
    if role == "client" and game_mode == MODE_SURVIVAL and battle_active:
        survival_client_save_local()
    _return_to_solo.call_deferred("Host закрыл лобби")


func _on_peer_disconnected(id: int) -> void:
    if _survival_pending_joins.has(id):
        _survival_pending_joins.erase(id)
        survival_join_request_closed.emit(id)
    if role != "host":
        return
    _survival_store_disconnected(id)
    _survival_identity_sent.erase(id)
    _survival_live_restored.erase(id)
    if game_mode == MODE_SURVIVAL:
        _team_disconnect(id)
    roster.erase(id)
    if battle_active and battle_state.has(id):
        _mark_left(id)
    if battle_leader_id == id:
        _elect_battle_leader()
    _dirty = true
    roster_changed.emit()
    friends_changed.emit()
    if not roster.has(1):
        _return_to_solo.call_deferred("Сеанс закрыт")


# ======================================================================
#  RPC
# ======================================================================

signal survival_join_announcement(message: String)

@rpc("authority", "call_remote", "reliable")
func _survival_join_announcement(message: String) -> void:
    survival_join_announcement.emit(message)

signal survival_join_request(peer_id: int, nickname: String)
signal survival_join_request_closed(peer_id: int)
var _survival_pending_joins: Dictionary = {}
var _survival_join_cooldowns: Dictionary = {}
const SURVIVAL_JOIN_COOLDOWN_MS: int = 120000

func answer_survival_join(peer_id: int, accept: bool) -> void:
    if role != "host" or not _survival_pending_joins.has(peer_id):
        return
    var profile: Dictionary = _survival_pending_joins[peer_id]
    _survival_pending_joins.erase(peer_id)
    survival_join_request_closed.emit(peer_id)
    if not accept:
        _survival_join_cooldowns[str(profile.get("nick", ""))] = Time.get_ticks_msec() + SURVIVAL_JOIN_COOLDOWN_MS
        _survival_join_answer.rpc_id(peer_id, false, 120)
        return
    _survival_join_answer.rpc_id(peer_id, true, 0)
    _admit_survival_peer(peer_id, profile)

@rpc("authority", "call_remote", "reliable")
func _survival_join_answer(accepted: bool, cooldown_seconds: int) -> void:
    if accepted:
        notice.emit("Host принял заявку на вход")
    else:
        notice.emit("Host отклонил заявку. Повторить можно через %d секунд" % cooldown_seconds)

func _survival_saved_state_for(peer: int) -> Dictionary:
    var key: String = str(survival_client_ids.get(peer, ""))
    if key.is_empty():
        return {}
    var state: Dictionary = survival_recovered_states.get(key, {})
    if state.is_empty():
        state = SurvivalSaves.client_snapshots.get(key, {})
    if str(state.get("save_id", "")) != survival_save_id:
        return {}
    return state.duplicate(true)

func _survival_apply_live_state(peer: int, state: Dictionary) -> void:
    var xyz: Array = state.get("pos", [])
    if xyz.size() == 3:
        battle_positions[peer] = Vector3(float(xyz[0]), float(xyz[1]), float(xyz[2]))
    battle_health[peer] = clampi(int(state.get("health", 100)), 0, 100)
    battle_yaws[peer] = float(state.get("yaw", 0.0))
    battle_pitches[peer] = float(state.get("pitch", 0.0))

@rpc("authority", "call_remote", "reliable")
func _survival_live_positions(positions: Dictionary, health: Dictionary) -> void:
    if role != "client" or not battle_active:
        return
    battle_positions = positions.duplicate(true)
    battle_health = health.duplicate(true)

func _admit_survival_peer(id: int, profile: Dictionary) -> void:
    if roster.has(id) or roster.size() >= MAX_PLAYERS:
        return
    roster[id] = {"nick": "Player", "money": 0, "loadout": [], "hand": "", "skin": 0,
        "x": CLIENT_SPAWN_X, "tx": CLIENT_SLOT_X, "yaw": 0.0}
    _apply_profile(id, str(profile.get("nick", "Player")), int(profile.get("money", 0)),
        profile.get("loadout", []), str(profile.get("hand", "")), int(profile.get("skin", 0)))
    _host_wait_left = 0.0
    _dirty = true
    roster_changed.emit()
    friends_changed.emit()
    _sync_roster.rpc(roster)
    _survival_sync_identity(id)
    _sync_friendly_fire.rpc_id(id, friendly_fire_enabled)
    _sync_bots_disabled.rpc_id(id, bots_disabled)
    _sync_bot_options.rpc_id(id, bot_count, bot_aggression_checked)
    if battle_active and game_mode == MODE_SURVIVAL:
        battle_positions[id] = Vector3(0.0, 1.0, 0.0)
        battle_health[id] = 100
        battle_yaws[id] = 0.0
        battle_pitches[id] = 0.0
        battle_state[id] = ST_ALIVE
        battle_bleed[id] = BLEED_START
        _receive_game_mode.rpc_id(id, game_mode)
        _battle_begin.rpc_id(id, battle_positions)
        _health_snapshot.rpc_id(id, battle_health)
        _survival_live_positions.rpc(battle_positions, battle_health)
    notice.emit("%s принят в мир" % str(roster[id]["nick"]))
    _survival_join_announcement.rpc("Игрок \"%s\" зашел на сервер" % str(roster[id]["nick"]))
    survival_join_announcement.emit("Игрок \"%s\" зашел на сервер" % str(roster[id]["nick"]))

## Client -> Host: вход в лобби.
@rpc("any_peer", "call_remote", "reliable")
func _req_join(nick: String, money: int, loadout: Array, hand: String, skin: int) -> void:
    if role != "host":
        return
    var id: int = multiplayer.get_remote_sender_id()
    var invited: bool = _survival_has_preapproval(nick)
    if roster.has(id) or roster.size() >= MAX_PLAYERS or (_host_wait_left <= 0.0 and not internet_mode and not invited):
        return
    if game_mode == MODE_SURVIVAL and battle_active:
        if invited and _survival_consume_preapproval(nick):
            _admit_survival_peer(id, {"nick": nick, "money": money, "loadout": loadout, "hand": hand, "skin": skin})
            return
        var key: String = GameState.clean_nick(nick)
        var left_ms: int = int(_survival_join_cooldowns.get(key, 0)) - Time.get_ticks_msec()
        if left_ms > 0:
            _survival_join_answer.rpc_id(id, false, ceili(float(left_ms) / 1000.0))
            return
        if not _survival_pending_joins.has(id):
            _survival_pending_joins[id] = {"nick": nick, "money": money, "loadout": loadout, "hand": hand, "skin": skin}
            survival_join_request.emit(id, nick)
        return
    roster[id] = {
        "nick": "Player", "money": 0, "loadout": [], "hand": "", "skin": 0,
        "x": CLIENT_SPAWN_X, "tx": CLIENT_SLOT_X, "yaw": 0.0,
    }
    _apply_profile(id, nick, money, loadout, hand, skin)
    _host_wait_left = 0.0
    _dirty = true
    roster_changed.emit()
    friends_changed.emit()
    _sync_roster.rpc(roster)
    _survival_sync_identity(id)
    _sync_friendly_fire.rpc_id(id, friendly_fire_enabled)
    _sync_bots_disabled.rpc_id(id, bots_disabled)
    _sync_bot_options.rpc_id(id, bot_count, bot_aggression_checked)
    notice.emit("%s присоединился к лобби" % str(roster[id]["nick"]))


## Client -> Host: смена ника / денег / снаряжения. Host принимает автоматически.
@rpc("any_peer", "call_remote", "reliable")
func _req_profile(nick: String, money: int, loadout: Array, hand: String, skin: int) -> void:
    if role != "host":
        return
    var id: int = multiplayer.get_remote_sender_id()
    if not roster.has(id) or id == 1:
        return
    _apply_profile(id, nick, money, loadout, hand, skin)
    roster_changed.emit()
    _sync_roster.rpc(roster)


## Client -> Host: поворот персонажа.
@rpc("any_peer", "call_remote", "unreliable_ordered")
func _req_yaw(yaw: float) -> void:
    if role != "host" or not is_finite(yaw):
        return
    var id: int = multiplayer.get_remote_sender_id()
    if not roster.has(id) or id == 1:
        return
    var e: Dictionary = roster[id]
    e["yaw"] = wrapf(yaw, -PI, PI)
    _dirty = true


func _apply_profile(id: int, nick: String, money: int, loadout: Array, hand: String = "", skin: int = 0) -> void:
    var e: Dictionary = roster[id]
    var clean: String = GameState.clean_nick(nick)
    if clean.length() >= GameState.MIN_NICK:
        e["nick"] = clean
    e["money"] = clampi(money, 0, GameState.MAX_MONEY)
    e["loadout"] = GameState.sanitize_loadout(loadout)
    # Оружие в руках — только косметика, но принимаем лишь известный автомат/пистолет из присланного снаряжения.
    var safe_hand := ""
    var hand_category: String = str(GameState.ITEMS.get(hand, {}).get("category", ""))
    if hand_category == "rifle" or hand_category == "pistol":
        for stack in e["loadout"]:
            if str((stack as Dictionary).get("id", "")) == hand:
                safe_hand = hand
                break
    e["hand"] = safe_hand
    e["skin"] = GameState.clamp_skin(skin)   # косметика: Host принимает только существующий номер скина


## Host -> все: полное состояние лобби.
@rpc("authority", "call_remote", "reliable")
func _sync_roster(data: Dictionary) -> void:
    if role != "client":
        return
    roster = data.duplicate(true)
    var sig: String = _roster_sig(roster)
    if sig != _last_sig:
        _last_sig = sig
        roster_changed.emit()


## Host -> все: позиции и повороты (часто, без гарантии доставки).
@rpc("authority", "call_remote", "unreliable_ordered")
func _sync_transforms(data: Dictionary) -> void:
    if role != "client":
        return
    for id in data.keys():
        if roster.has(id):
            var v: Vector2 = data[id]
            var e: Dictionary = roster[id]
            e["x"] = v.x
            e["yaw"] = v.y


# ======================================================================
#  Сеть Wi-Fi: статус и поиск игроков (UDP)
# ======================================================================

func _check_online() -> void:
    var now: bool = false
    for a in IP.get_local_addresses():
        var addr: String = a
        if addr.contains(":"):
            continue
        if addr.begins_with("127.") or addr.begins_with("169.254.") or addr.begins_with("0."):
            continue
        now = true
        break
    if now != online:
        online = now
        if not online:
            friends.clear()
            friends_changed.emit()
        online_changed.emit(online)


func _broadcast_targets() -> Array:
    var targets: Array = ["255.255.255.255"]
    for a in IP.get_local_addresses():
        var addr: String = a
        if addr.contains(":") or addr.begins_with("127.") or addr.begins_with("169.254."):
            continue
        var o: PackedStringArray = addr.split(".")
        if o.size() == 4:
            var t: String = "%s.%s.%s.255" % [o[0], o[1], o[2]]
            if not targets.has(t):
                targets.append(t)
    return targets


func _broadcast_hello() -> void:
    if not _udp_ok:
        return
    var data: PackedByteArray = JSON.stringify({
        "k": "hello", "u": uid, "n": GameState.nickname, "b": is_busy(),
    }).to_utf8_buffer()
    for t in _broadcast_targets():
        _udp.set_dest_address(str(t), DISCOVERY_PORT)
        _udp.put_packet(data)


func _send(ip: String, data: Dictionary) -> void:
    if not _udp_ok:
        return
    _udp.set_dest_address(ip, DISCOVERY_PORT)
    _udp.put_packet(JSON.stringify(data).to_utf8_buffer())


func _expire_friends() -> void:
    var now: int = Time.get_ticks_msec()
    var removed: bool = false
    for key in friends.keys():
        var f: Dictionary = friends[key]
        if now - int(f["seen"]) > PEER_TIMEOUT_MS:
            friends.erase(key)
            removed = true
    if removed:
        friends_changed.emit()


func _poll_udp() -> void:
    if not _udp_ok:
        return
    while _udp.get_available_packet_count() > 0:
        var raw: String = _udp.get_packet().get_string_from_utf8()
        var ip: String = _udp.get_packet_ip()   # ВАЖНО: после get_packet()
        var parsed = JSON.parse_string(raw)
        if typeof(parsed) != TYPE_DICTIONARY:
            continue
        var msg: Dictionary = parsed
        if str(msg.get("u", "")) == uid:
            continue   # собственный broadcast
        _handle_udp(ip, msg)


func _handle_udp(ip: String, msg: Dictionary) -> void:
    var kind: String = str(msg.get("k", ""))
    var from_uid: String = str(msg.get("u", ""))
    var nick: String = GameState.clean_nick(str(msg.get("n", "")))
    if from_uid == "" or nick == "":
        return
    match kind:
        "hello", "reply":
            var busy: bool = bool(msg.get("b", false))
            var is_new: bool = true
            if friends.has(from_uid):
                var old: Dictionary = friends[from_uid]
                is_new = old["nick"] != nick or old["ip"] != ip or old["busy"] != busy
            friends[from_uid] = {"nick": nick, "ip": ip, "busy": busy, "seen": Time.get_ticks_msec()}
            if is_new:
                friends_changed.emit()
            if kind == "hello":
                # unicast-ответ: обнаружение работает в обе стороны
                var now: int = Time.get_ticks_msec()
                if now - int(_last_reply.get(from_uid, 0)) > 1200:
                    _last_reply[from_uid] = now
                    _send(ip, {"k": "reply", "u": uid, "n": GameState.nickname, "b": is_busy()})
        "invite":
            if is_busy() or _incoming_uid != "":
                _send(ip, {"k": "fail", "u": uid, "n": GameState.nickname})
                return
            _incoming_uid = from_uid
            _incoming_ip = ip
            _incoming_nick = nick
            _incoming_left = INVITE_TIMEOUT
            invite_received.emit(nick)
        "decline":
            if from_uid == _pending_uid:
                _pending_uid = ""
                friends_changed.emit()
                notice.emit("Игрок %s отменил приглашение" % nick)
        "accept":
            if from_uid != _pending_uid:
                return
            _pending_uid = ""
            friends_changed.emit()
            if role == "client" or roster.size() >= MAX_PLAYERS or not _start_host():
                _send(ip, {"k": "fail", "u": uid, "n": GameState.nickname})
                return
            # Игрок сам принял приглашение: в идущую игру выживания он входит без повторного вопроса Host-у.
            _survival_preapprove_nick(nick)
            _send(ip, {"k": "ready", "u": uid, "n": GameState.nickname})
        "ready":
            if from_uid == _joining_uid:
                _connect_to_host(ip)
        "fail":
            if from_uid == _pending_uid:
                _pending_uid = ""
                friends_changed.emit()
                notice.emit("Игрок %s сейчас недоступен" % nick)
            elif from_uid == _joining_uid:
                _joining_uid = ""
                notice.emit("Лобби игрока %s недоступно" % nick)


func _tick_invites(delta: float) -> void:
    if _pending_uid != "":
        _pending_left -= delta
        if _pending_left <= 0.0:
            _pending_uid = ""
            friends_changed.emit()
    if _incoming_uid != "":
        _incoming_left -= delta
        if _incoming_left <= 0.0:
            _incoming_uid = ""
            invite_closed.emit()
    if _joining_uid != "":
        _joining_left -= delta
        if _joining_left <= 0.0:
            _return_to_solo("Не удалось подключиться к лобби")


## Host verifies the weapon, rate, origin, direction and hit; clients only request shots.
## directions содержит по одному лучу на дробину (у обычного оружия - один).
var downed_pistol_peers: Dictionary = {}

func register_downed_pistol_talent() -> void:
    if not battle_active:
        return
    if role == "client":
        _register_downed_pistol_talent.rpc_id(1, GameState.downed_pistol_talent)
    else:
        downed_pistol_peers[1] = GameState.downed_pistol_talent

@rpc("any_peer", "call_remote", "reliable")
func _register_downed_pistol_talent(owned: bool) -> void:
    if role != "host" or not battle_active:
        return
    downed_pistol_peers[multiplayer.get_remote_sender_id()] = owned

func request_shot(weapon_id: String, origin: Vector3, directions: PackedVector3Array) -> void:
    if not battle_active or not Weapons.has(weapon_id):
        return
    if role == "client":
        _request_shot.rpc_id(1, weapon_id, origin, directions)
    else:
        _resolve_shot(1, weapon_id, origin, directions)

## Совместимость со старым вызовом (только АК-47).
func request_ak_shot(origin: Vector3, direction: Vector3) -> void:
    request_shot("ak47", origin, PackedVector3Array([direction]))

@rpc("any_peer", "call_remote", "reliable")
func _request_shot(weapon_id: String, origin: Vector3, directions: PackedVector3Array) -> void:
    if role != "host" or not battle_active:
        return
    _resolve_shot(multiplayer.get_remote_sender_id(), weapon_id, origin, directions)

func _resolve_shot(shooter: int, weapon_id: String, origin: Vector3, directions: PackedVector3Array) -> void:
    if not Weapons.has(weapon_id) or Weapons.is_melee(weapon_id):
        return
    var downed_shot: bool = peer_state(shooter) == ST_DOWNED and bool(downed_pistol_peers.get(shooter, false)) and int(Weapons.get_def(weapon_id).get("slot", -1)) == 1
    if not battle_positions.has(shooter) or (peer_state(shooter) != ST_ALIVE and not downed_shot):
        return
    if peer_state(shooter) == ST_ALIVE and int(battle_health.get(shooter, 0)) <= 0:
        return
    if origin.distance_to(battle_positions[shooter] + Vector3(0, 0.7 if downed_shot else 1.45, 0)) > 2.0:
        return
    var def: Dictionary = Weapons.get_def(weapon_id)
    var now := Time.get_ticks_msec()
    # Допускаем небольшой запас на сетевой джиттер (85% от темпа оружия).
    var min_interval := int(float(def["rate"]) * 1000.0 * 0.85)
    if now - int(_last_shot_ms.get(shooter, -1000)) < min_interval:
        return
    _last_shot_ms[shooter] = now
    var pellets: int = clampi(int(def.get("pellets", 1)), 1, 16)
    var max_range: float = float(def["range"])
    var damage_each: int = int(def["damage"])
    var damage_by_victim: Dictionary = {}
    var damage_by_zombie: Dictionary = {}
    var shots_to_show: Array = []
    for i in mini(directions.size(), pellets):
        var dir := directions[i]
        if dir.length_squared() < 0.9:
            continue
        var ray := dir.normalized()
        var end := origin + ray * max_range
        var best := max_range
        if game_mode == MODE_ZOMBIES:
            # Stage103: стены, мебель и постройки останавливают пулю.
            best = TitanicMap.ray_distance(origin, ray, max_range)
            end = origin + ray * best
        var hit_id := -1
        var hit_multiplier := 0.0
        for id in battle_positions.keys():
            var peer := int(id)
            if peer == shooter or peer_state(peer) == ST_DEAD or peer_state(peer) == ST_LEFT:
                continue
            var hit := _hit_region(origin, ray, battle_positions[peer], best)
            if float(hit["mult"]) > 0.0 and float(hit["distance"]) < best:
                best = float(hit["distance"])
                hit_id = peer
                hit_multiplier = float(hit["mult"])
        var hit_zombie := -1
        if game_mode == MODE_ZOMBIES:
            for raw_zid in zombie_positions.keys():
                var zid := int(raw_zid)
                if not _zombie_targetable(zid):
                    continue
                var zhit := _zombie_hit_region(origin, ray, zombie_positions[zid], _zombie_kind_of(zid), best)
                if float(zhit["mult"]) > 0.0 and float(zhit["distance"]) < best:
                    best = float(zhit["distance"])
                    hit_zombie = zid
                    hit_id = -1
                    hit_multiplier = float(zhit["mult"])
        if hit_zombie >= 0:
            end = origin + ray * best
            damage_by_zombie[hit_zombie] = int(damage_by_zombie.get(hit_zombie, 0)) + maxi(1, roundi(damage_each * hit_multiplier))
        elif hit_id >= 0:
            end = origin + ray * best
            damage_by_victim[hit_id] = int(damage_by_victim.get(hit_id, 0)) + maxi(1, roundi(damage_each * hit_multiplier))
        shots_to_show.append(end)
    for victim in damage_by_victim.keys():
        _apply_damage(shooter, int(victim), int(damage_by_victim[victim]))
    for zombie_id in damage_by_zombie.keys():
        _damage_zombie(shooter, int(zombie_id), int(damage_by_zombie[zombie_id]))
    shot_fired.emit(shooter, weapon_id, origin)
    if role == "host":
        _shot_fired.rpc(shooter, weapon_id, origin)
    for end_point in shots_to_show:
        shot_visual.emit(origin, end_point, shooter)
        if role == "host":
            _shot_effect.rpc(origin, end_point, shooter)

# Сервер хранит время начала поднятия отдельно для каждого помощника.
var revive_started: Dictionary = {}
const REVIVE_DURATION_MS := 5000

func begin_revive(origin: Vector3, direction: Vector3) -> void:
    if role == "client":
        _begin_revive_remote.rpc_id(1, origin, direction)
    else:
        _begin_revive_host(my_id(), origin, direction)

@rpc("any_peer", "call_remote", "reliable")
func _begin_revive_remote(origin: Vector3, direction: Vector3) -> void:
    if role == "host":
        _begin_revive_host(multiplayer.get_remote_sender_id(), origin, direction)

func _begin_revive_host(helper: int, origin: Vector3, direction: Vector3) -> void:
    var target := _revive_target(helper, origin, direction)
    if target >= 0:
        revive_started[helper] = {"target": target, "time": Time.get_ticks_msec()}

func cancel_revive() -> void:
    if role == "client":
        _cancel_revive_remote.rpc_id(1)
    else:
        revive_started.erase(my_id())

@rpc("any_peer", "call_remote", "reliable")
func _cancel_revive_remote() -> void:
    if role == "host":
        revive_started.erase(multiplayer.get_remote_sender_id())

func _revive_target(helper: int, origin: Vector3, direction: Vector3) -> int:
    if not battle_active or peer_state(helper) != ST_ALIVE or not battle_positions.has(helper) or direction.length_squared() < 0.9:
        return -1
    if origin.distance_to(battle_positions[helper] + Vector3(0, 1.45, 0)) > 2.0:
        return -1
    var ray := direction.normalized()
    var best := 2.5
    var target := -1
    for id in battle_positions.keys():
        var peer := int(id)
        if peer == helper or peer_state(peer) != ST_DOWNED:
            continue
        var center: Vector3 = battle_positions[peer] + Vector3(0, 0.65, 0)
        var along := (center - origin).dot(ray)
        if along < 0.0 or along > best:
            continue
        if (origin + ray * along).distance_to(center) <= 0.75:
            best = along
            target = peer
    return target

## Поднятие нокаутированного игрока: сервер проверяет прицел и дистанцию.
func request_revive(origin: Vector3, direction: Vector3) -> bool:
    if not battle_active or direction.length_squared() < 0.9:
        return false
    if role == "client":
        _request_revive.rpc_id(1, origin, direction)
        return true
    return _resolve_revive(my_id(), origin, direction)

@rpc("any_peer", "call_remote", "reliable")
func _request_revive(origin: Vector3, direction: Vector3) -> void:
    if role == "host":
        _resolve_revive(multiplayer.get_remote_sender_id(), origin, direction)

func _resolve_revive(helper: int, origin: Vector3, direction: Vector3) -> bool:
    if not revive_started.has(helper):
        return false
    var session: Dictionary = revive_started[helper]
    if Time.get_ticks_msec() - int(session["time"]) < REVIVE_DURATION_MS:
        return false
    var target := _revive_target(helper, origin, direction)
    if target < 0 or target != int(session["target"]):
        revive_started.erase(helper)
        return false
    revive_started.erase(helper)
    battle_state[target] = ST_ALIVE
    battle_bleed[target] = 0
    battle_health[target] = 50
    health_changed.emit(target, 50)
    if role == "host":
        _health_snapshot.rpc(battle_health)
    _after_state_change()
    return true

## Вертикальные зоны попадания: ноги, туловище, голова; боковые зоны рук.
func _hit_region(origin: Vector3, ray: Vector3, base: Vector3, max_distance: float) -> Dictionary:
    var zones := [
        {"offset": Vector3(0, 1.68, 0), "radius": 0.24, "mult": 2.0},
        {"offset": Vector3(-0.53, 1.12, 0), "radius": 0.22, "mult": 1.2},
        {"offset": Vector3(0.53, 1.12, 0), "radius": 0.22, "mult": 1.2},
        {"offset": Vector3(0, 1.12, 0), "radius": 0.37, "mult": 1.0},
        {"offset": Vector3(-0.18, 0.43, 0), "radius": 0.23, "mult": 0.8},
        {"offset": Vector3(0.18, 0.43, 0), "radius": 0.23, "mult": 0.8}
    ]
    var nearest := max_distance
    var multiplier := 0.0
    for zone in zones:
        var center: Vector3 = base + zone["offset"]
        var along := (center - origin).dot(ray)
        if along < 0.0 or along >= nearest:
            continue
        var radius: float = zone["radius"]
        var perpendicular_sq := (origin + ray * along).distance_squared_to(center)
        if perpendicular_sq <= radius * radius:
            nearest = along - sqrt(radius * radius - perpendicular_sq)
            multiplier = float(zone["mult"])
    return {"distance": nearest, "mult": multiplier}

## Удар холодным оружием: хост проверяет дистанцию и конус перед стрелком.
func request_melee(weapon_id: String, origin: Vector3, direction: Vector3) -> void:
    if not battle_active or not Weapons.is_melee(weapon_id):
        return
    if role == "client":
        _request_melee.rpc_id(1, weapon_id, origin, direction)
    else:
        _resolve_melee(1, weapon_id, origin, direction)

@rpc("any_peer", "call_remote", "reliable")
func _request_melee(weapon_id: String, origin: Vector3, direction: Vector3) -> void:
    if role != "host" or not battle_active:
        return
    _resolve_melee(multiplayer.get_remote_sender_id(), weapon_id, origin, direction)

func _resolve_melee(shooter: int, weapon_id: String, origin: Vector3, direction: Vector3) -> void:
    if not Weapons.is_melee(weapon_id) or not battle_positions.has(shooter) or direction.length_squared() < 0.9:
        return
    if int(battle_health.get(shooter, 0)) <= 0 or peer_state(shooter) != ST_ALIVE:
        return
    if origin.distance_to(battle_positions[shooter] + Vector3(0, 1.45, 0)) > 2.0:
        return
    var def: Dictionary = Weapons.get_def(weapon_id)
    var now := Time.get_ticks_msec()
    if now - int(_last_shot_ms.get(shooter, -1000)) < int(float(def["rate"]) * 1000.0 * 0.85):
        return
    _last_shot_ms[shooter] = now
    var ray := direction.normalized()
    var reach: float = float(def["range"])
    var best := reach
    if game_mode == MODE_ZOMBIES:
        best = minf(best, TitanicMap.ray_distance(origin, ray, reach))   # Stage103: не бьём сквозь стены
    var hit_id := -1
    for id in battle_positions.keys():
        var peer := int(id)
        if peer == shooter or peer_state(peer) == ST_DEAD or peer_state(peer) == ST_LEFT:
            continue
        var center: Vector3 = battle_positions[peer] + Vector3(0, 1.0, 0)
        var along := (center - origin).dot(ray)
        # Цель должна быть впереди и в пределах досягаемости (+ радиус тела).
        if along < 0.0 or along > best + 0.5:
            continue
        var closest := origin + ray * along
        if closest.distance_to(center) <= 0.75 and center.distance_to(origin) <= reach + 0.6:
            best = along
            hit_id = peer
    var hit_zombie := -1
    if game_mode == MODE_ZOMBIES:
        for raw_zid in zombie_positions.keys():
            var zid := int(raw_zid)
            if not _zombie_targetable(zid):
                continue
            var scale_k := float(ZombieModel.KIND_SCALE[_zombie_kind_of(zid)])
            var zcenter: Vector3 = (zombie_positions[zid] as Vector3) + Vector3(0, 1.1 * scale_k, 0)
            var zalong := (zcenter - origin).dot(ray)
            if zalong < 0.0 or zalong > best + 0.5:
                continue
            if (origin + ray * zalong).distance_to(zcenter) <= 0.75 * scale_k and zcenter.distance_to(origin) <= reach + 0.6 * scale_k:
                best = zalong
                hit_zombie = zid
                hit_id = -1
    shot_fired.emit(shooter, weapon_id, origin)
    if role == "host":
        _shot_fired.rpc(shooter, weapon_id, origin)
    if hit_zombie >= 0:
        _damage_zombie(shooter, hit_zombie, int(def["damage"]))
    elif hit_id >= 0:
        _apply_damage(shooter, hit_id, int(def["damage"]))

## Общий расчёт урона: здоровье авторитетно на хосте.
func _apply_damage(shooter: int, victim: int, amount: int) -> void:
    if amount <= 0 or not battle_health.has(victim):
        return
    if shooter != victim and not friendly_fire_enabled:
        return
    if is_bot(victim) and not is_bot(shooter) and shooter != victim:
        bot_aggressive[victim] = true
    var state := peer_state(victim)
    if state == ST_DEAD or state == ST_LEFT:
        return
    if state == ST_DOWNED:
        var remaining := maxi(0, int(battle_bleed.get(victim, BLEED_START)) - amount)
        battle_bleed[victim] = remaining
        if shooter == my_id():
            shot_confirmed.emit(victim, amount)
        elif role == "host":
            _shot_hit_confirmed.rpc_id(shooter, victim, amount)
        if remaining <= 0:
            battle_state[victim] = ST_DEAD
            _after_state_change()
        else:
            _broadcast_states()
        return
    battle_health[victim] = maxi(0, int(battle_health[victim]) - amount)
    var knocked_out: bool = int(battle_health[victim]) <= 0 and state == ST_ALIVE
    if shooter == my_id():
        shot_confirmed.emit(victim, amount)
    elif role == "host":
        _shot_hit_confirmed.rpc_id(shooter, victim, amount)
    health_changed.emit(victim, battle_health[victim])
    if role == "host":
        _health_snapshot.rpc(battle_health)
    if knocked_out:
        _knock_out(victim)

@rpc("authority", "call_remote", "unreliable")
func _shot_fired(shooter: int, weapon_id: String, origin: Vector3) -> void:
    if role == "client" and Weapons.has(weapon_id):
        shot_fired.emit(shooter, weapon_id, origin)

@rpc("authority", "call_remote", "reliable")
func _shot_hit_confirmed(victim: int, damage: int) -> void:
    if role == "client":
        shot_confirmed.emit(victim, damage)

@rpc("authority", "call_remote", "unreliable")
func _shot_effect(origin: Vector3, target: Vector3, shooter: int) -> void:
    shot_visual.emit(origin, target, shooter)

@rpc("authority", "call_remote", "reliable")
func _health_snapshot(values: Dictionary) -> void:
    battle_health = values.duplicate(true)
    for id in battle_health.keys():
        health_changed.emit(int(id), int(battle_health[id]))



# ======================================================================
#  Нокаут, смерть, наблюдение (авторитетно на хосте / в solo)
# ======================================================================

func _reset_life_states() -> void:
    battle_state.clear()
    battle_bleed.clear()
    battle_over = false
    _bleed_clock = 0.0

func peer_state(peer: int) -> int:
    return int(battle_state.get(peer, ST_ALIVE))

## Сколько других игроков ещё сражаются (живы или в нокауте).
func others_in_battle(me: int) -> int:
    var count := 0
    for id in battle_state.keys():
        var st := int(battle_state[id])
        if int(id) != me and (st == ST_ALIVE or st == ST_DOWNED):
            count += 1
    return count

## За кем наблюдать мёртвому игроку: выживший (ST_ALIVE), иначе -1.
func spectate_target(me: int) -> int:
    for id in battle_state.keys():
        if int(id) != me and int(battle_state[id]) == ST_ALIVE:
            return int(id)
    return -1

func _alive_count() -> int:
    var count := 0
    for id in battle_state.keys():
        if int(battle_state[id]) == ST_ALIVE:
            count += 1
    return count

## 0 HP: если есть живой напарник — нокаут, иначе сразу смерть.
func _knock_out(victim: int) -> void:
    if role == "client" or not battle_state.has(victim) or peer_state(victim) != ST_ALIVE:
        return
    var others := 0
    for id in battle_state.keys():
        if int(id) != victim and int(battle_state[id]) == ST_ALIVE:
            others += 1
    if others > 0:
        battle_state[victim] = ST_DOWNED
        battle_bleed[victim] = BLEED_START
    else:
        battle_state[victim] = ST_DEAD
        battle_bleed[victim] = 0
    _after_state_change()

## Каждые 2 секунды отнимаем 1 HP нокаута у каждого лежащего игрока.
## Выполняется только на сервере/в одиночной игре, клиенты получают снимок состояния.
## Stage122: игрок коснулся воды (упал за борт «Титаника») — мгновенная смерть, без нокаута.
## Вещи при этом остаются в воде: мешок погибшего с ними не поднять.
func _tick_water_death() -> void:
    if role == "client" or not battle_active or battle_over or game_mode != MODE_ZOMBIES:
        return
    var drowned := false
    for id in battle_state.keys():
        var peer := int(id)
        var st := peer_state(peer)
        if st != ST_ALIVE and st != ST_DOWNED:
            continue
        var pos = battle_positions.get(peer, null)
        if pos is Vector3 and TitanicMap.touches_water(pos as Vector3):
            battle_health[peer] = 0
            battle_bleed[peer] = 0
            battle_state[peer] = ST_DEAD
            health_changed.emit(peer, 0)
            drowned = true
    if drowned:
        if role == "host":
            _health_snapshot.rpc(battle_health)
        _after_state_change()

func _tick_knockout_hp(delta: float) -> void:
    if not battle_active or battle_over or role == "client":
        return
    _bleed_clock += delta
    if _bleed_clock < 2.0:
        return
    var ticks := int(_bleed_clock / 2.0)
    _bleed_clock = fmod(_bleed_clock, 2.0)
    var changed := false
    var died := false
    for id in battle_state.keys():
        var peer := int(id)
        if peer_state(peer) != ST_DOWNED:
            continue
        var remaining := maxi(0, int(battle_bleed.get(peer, BLEED_START)) - ticks)
        battle_bleed[peer] = remaining
        changed = true
        if remaining == 0:
            battle_state[peer] = ST_DEAD
            died = true
    if died:
        _after_state_change()
    elif changed:
        _broadcast_states()

## Создать рюкзак погибшего бота один раз, на сервере.
func _create_dead_bot_bags() -> void:
    for raw_id in bot_loot.keys():
        var bot_id := int(raw_id)
        if peer_state(bot_id) != ST_DEAD or not battle_positions.has(bot_id) or _death_bag_created_owners.has(bot_id):
            continue
        var loot: Dictionary = bot_loot[bot_id]
        var items: Array = loot.get("inventory", []).duplicate(true)
        _host_death_bag(bot_id, items, battle_positions[bot_id])

## Пересчёт после любой смены состояния.
## Пересчёт после любой смены состояния. Нет живых — бой окончен для всех.
func _after_state_change(force_over: bool = false) -> void:
    if role == "client" or not battle_active:
        return
    if game_mode != MODE_DUEL and (force_over or _alive_count() == 0) and not battle_over:
        for id in battle_state.keys():
            if int(battle_state[id]) == ST_DOWNED:
                battle_state[id] = ST_DEAD
                battle_bleed[id] = 0
        battle_over = true
    _create_dead_bot_bags()
    _broadcast_states()
    for id in battle_state.keys():
        player_state_changed.emit(int(id), int(battle_state[id]))
    if battle_over:
        _on_battle_over()

func _broadcast_states() -> void:
    if role == "host":
        _state_snapshot.rpc(battle_state, battle_bleed, battle_over)

func _on_battle_over() -> void:
    battle_finished.emit()
    # Игрок уже в лобби (сцена боя закрыта) — завершаем бой для него сами.
    if local_battle_left and role == "client":
        end_battle()

@rpc("authority", "call_remote", "reliable")
func _state_snapshot(states: Dictionary, bleed: Dictionary, over: bool) -> void:
    if role != "client" or not battle_active:
        return
    battle_state = states.duplicate(true)
    battle_bleed = bleed.duplicate(true)
    for id in battle_state.keys():
        player_state_changed.emit(int(id), int(battle_state[id]))
    if over and not battle_over:
        battle_over = true
        _on_battle_over()

## Возвращение в лобби завершает бой только для этого участника.
## ENet authority остаётся у создателя сеанса; battle_leader_id — логический лидер боя.
# Stage120: only Host may authorize a fresh survival life.
func request_survival_respawn() -> void:
    if not battle_active or game_mode != MODE_SURVIVAL or peer_state(my_id()) != ST_DEAD:
        return
    if role == "client":
        _request_survival_respawn.rpc_id(1)
    else:
        _host_survival_respawn(my_id())

@rpc("any_peer", "call_remote", "reliable")
func _request_survival_respawn() -> void:
    if role == "host":
        _host_survival_respawn(multiplayer.get_remote_sender_id())

func _host_survival_respawn(peer: int) -> void:
    if role == "client" or not battle_active or game_mode != MODE_SURVIVAL:
        return
    if not roster.has(peer) or peer_state(peer) != ST_DEAD:
        return
    # Original world entry point, not the position where the player died.
    var spawn := Vector3(0, 1, 0)
    battle_positions[peer] = spawn
    battle_yaws[peer] = 0.0
    battle_pitches[peer] = 0.0
    battle_health[peer] = 100
    battle_bleed[peer] = BLEED_START
    battle_state[peer] = ST_ALIVE
    battle_over = false
    if role == "host":
        _survival_respawn_sync.rpc(peer, spawn)
        _health_snapshot.rpc(battle_health)
        _broadcast_states()
    _survival_respawn_sync(peer, spawn)
    player_state_changed.emit(peer, ST_ALIVE)
    health_changed.emit(peer, 100)

@rpc("authority", "call_remote", "reliable")
func _survival_respawn_sync(peer: int, spawn: Vector3) -> void:
    if role != "client" or not battle_active or game_mode != MODE_SURVIVAL:
        return
    battle_positions[peer] = spawn
    battle_health[peer] = 100
    battle_state[peer] = ST_ALIVE
    battle_bleed[peer] = BLEED_START
    battle_positions_changed.emit()
    player_state_changed.emit(peer, ST_ALIVE)
    health_changed.emit(peer, 100)

func leave_battle_as_dead() -> void:
    leave_battle_locally()

func leave_battle_locally() -> void:
    if not battle_active or local_battle_left:
        return
    local_battle_left = true
    if role == "client":
        _client_left_battle.rpc_id(1)
        # Stage88: игрок в лобби — для него бой закончен сразу, не ждём конца боя у остальных.
        # Небольшая задержка, чтобы сцена боя успела закрыться.
        get_tree().create_timer(0.4).timeout.connect(_finish_local_battle)
    else:
        # В одиночном режиме при выходе бой завершается полностью.
        # Нельзя оставлять battle_active=true из-за NPC или старого состояния.
        if role == "solo":
            end_battle()
            return
        _mark_left(my_id())
        # Stage89: хост ушёл в лобби. Лично для него бой закрыт, лидер боя переходит к другому игроку
        # (_mark_left -> _elect_battle_leader); симуляция у остальных идёт в фоне на этом устройстве.
        if role == "host" and battle_active:
            if others_in_battle(my_id()) > 0:
                notice.emit("Для вас бой закончен. У остальных игроков он продолжается")
            else:
                # Последний участник вышел: снимаем блокировку нового боя.
                end_battle()

## Клиент ушёл в лобби: локально завершаем бой (хост продолжает его для остальных).
func _finish_local_battle() -> void:
    if role != "client" or not local_battle_left:
        return
    if GameState.battle_active:
        GameState.lose_battle()
    if battle_active:
        end_battle()
    else:
        local_battle_left = false

@rpc("any_peer", "call_remote", "reliable")
func _client_left_battle() -> void:
    if role != "host" or not battle_active:
        return
    var peer := multiplayer.get_remote_sender_id()
    if roster.has(peer):
        _mark_left(peer)

func _elect_battle_leader() -> void:
    var chosen := -1
    for raw_id in battle_state.keys():
        var peer := int(raw_id)
        if not roster.has(peer):
            continue
        var st := int(battle_state[peer])
        if st == ST_ALIVE or st == ST_DOWNED:
            if chosen == -1 or peer < chosen:
                chosen = peer
    battle_leader_id = chosen if chosen != -1 else 1
    if role == "host":
        _sync_battle_leader.rpc(battle_leader_id)
    battle_leader_changed.emit(battle_leader_id)

@rpc("authority", "call_remote", "reliable")
func _sync_battle_leader(peer: int) -> void:
    battle_leader_id = peer
    battle_leader_changed.emit(peer)

func _mark_left(peer: int) -> void:
    if not battle_state.has(peer) or int(battle_state[peer]) == ST_LEFT:
        return
    battle_state[peer] = ST_LEFT
    battle_bleed[peer] = 0
    if battle_leader_id == peer:
        _elect_battle_leader()
    _after_state_change()

## Добровольная смерть в нокдауне, только с подтверждения игрока.
func request_end_life() -> void:
    if not battle_active or peer_state(my_id()) != ST_DOWNED:
        return
    if role == "client":
        _request_end_life.rpc_id(1)
    else:
        _finish_downed_life(my_id())

@rpc("any_peer", "call_remote", "reliable")
func _request_end_life() -> void:
    if role != "host" or not battle_active:
        return
    _finish_downed_life(multiplayer.get_remote_sender_id())

func _finish_downed_life(peer: int) -> void:
    if role == "client" or peer_state(peer) != ST_DOWNED or not battle_state.has(peer):
        return
    battle_state[peer] = ST_DEAD
    battle_bleed[peer] = 0
    _after_state_change()

## Последний боец выходит сам (другие уже мертвы/в лобби): бой заканчивается для всех, сеанс остаётся.
func request_finish_battle() -> void:
    if not battle_active:
        return
    if role == "client":
        _client_finish_battle.rpc_id(1)
    else:
        _after_state_change(true)

@rpc("any_peer", "call_remote", "reliable")
func _client_finish_battle() -> void:
    if role != "host" or not battle_active:
        return
    if roster.has(multiplayer.get_remote_sender_id()):
        _after_state_change(true)


## Health is authoritative on HOST. An approval consumes one local medkit.
## Inventory validation must be moved to HOST when server-side inventories are available.
func request_medkit_use() -> bool:
    if not battle_active:
        return false
    if role == "client":
        _request_medkit_use.rpc_id(1)
        return true
    _apply_medkit(my_id())
    return true

@rpc("any_peer", "call_remote", "reliable")
func _request_medkit_use() -> void:
    if role != "host" or not battle_active:
        return
    _apply_medkit(multiplayer.get_remote_sender_id())

func _apply_medkit(peer_id: int) -> void:
    if not battle_health.has(peer_id) or int(battle_health[peer_id]) <= 0:
        return
    battle_health[peer_id] = mini(100, int(battle_health[peer_id]) + 50)
    health_changed.emit(peer_id, int(battle_health[peer_id]))
    if role == "host":
        _health_snapshot.rpc(battle_health)
    if peer_id == my_id():
        medkit_approved.emit()
    elif role == "host":
        _medkit_use_approved.rpc_id(peer_id)

@rpc("authority", "call_remote", "reliable")
func _medkit_use_approved() -> void:
    if role == "client":
        medkit_approved.emit()


## Server-authoritative healing / self-revive. The client's item is consumed on approval.
func request_adrenaline_use() -> bool:
    if not battle_active or (peer_state(my_id()) != ST_ALIVE and peer_state(my_id()) != ST_DOWNED):
        return false
    if role == "client":
        _request_adrenaline_use.rpc_id(1)
    else:
        _apply_adrenaline(my_id())
    return true

@rpc("any_peer", "call_remote", "reliable")
func _request_adrenaline_use() -> void:
    if role == "host" and battle_active:
        _apply_adrenaline(multiplayer.get_remote_sender_id())

func _apply_adrenaline(peer_id: int) -> void:
    var state := peer_state(peer_id)
    if not battle_health.has(peer_id) or (state != ST_ALIVE and state != ST_DOWNED):
        return
    if state == ST_DOWNED:
        battle_state[peer_id] = ST_ALIVE
        battle_bleed[peer_id] = 0
        battle_health[peer_id] = 20
        _after_state_change()
    else:
        battle_health[peer_id] = mini(100, int(battle_health[peer_id]) + 20)
    health_changed.emit(peer_id, int(battle_health[peer_id]))
    if role == "host":
        _health_snapshot.rpc(battle_health)
    if peer_id == my_id():
        adrenaline_approved.emit()
    elif role == "host":
        _adrenaline_use_approved.rpc_id(peer_id)

@rpc("authority", "call_remote", "reliable")
func _adrenaline_use_approved() -> void:
    if role == "client":
        adrenaline_approved.emit()

# Stage80: навигация строится из данных карты «Титаник» (titanic_map.gd), без физики.
var zombie_nav: AStarGrid2D
var zombie_heights: Dictionary = {}
var zombie_nav_origin := Vector2.ZERO
var zombie_nav_cell_size := 2.0
var zombie_paths: Dictionary = {}
var zombie_path_clock := 0.0
var zombie_speed_mul := 1.0

const ZOMBIE_SPEED := [2.2, 4.0, 1.8]       # ходок, бегун, громила (м/с)
const ZOMBIE_DAMAGE := [40, 25, 70]
const ZOMBIE_COOLDOWN := [1.5, 1.0, 2.0]
const ZOMBIE_HP := [100, 70, 400]           # ходок, бегун, громила
const ZOMBIE_REACH_Y := 1.6                 # Stage122: зомби не достаёт игрока, стоящего на высоком штабеле ящиков
const ZOMBIE_LINGER := 4.2                  # сколько секунд виден труп
const ZOMBIE_RISE_HOLD := 1.4               # столько секунд зомби вылезает и не двигается

func _reset_zombie_state() -> void:
    zombie_wave_no = 1
    zombie_phase = PHASE_FIGHT
    zombie_heli_left = 0.0
    zombie_time_left = WAVE_FIRST_TIME
    battle_evacuated.clear()
    zombie_meta.clear()
    zombie_attack_age.clear()
    zombie_attack_hit.clear()
    zombie_rise_left.clear()
    zombie_yaws.clear()
    zombie_net_clock = 0.0
    zombie_serial = 0
    zombie_paths.clear()
    zombie_health.clear()
    zombie_dead_age.clear()
    zombie_kills = 0
    turrets.clear()
    turret_aims.clear()
    turret_ammo.clear()
    turret_hp.clear()
    _turret_state.clear()
    _turret_serial = 0

func configure_zombie_navigation(grid: AStarGrid2D, heights: Dictionary, origin: Vector2, cell_size: float) -> void:
    zombie_nav = grid
    zombie_heights = heights
    zombie_nav_origin = origin
    zombie_nav_cell_size = cell_size
    zombie_paths.clear()

func _ensure_zombie_navigation() -> void:
    if zombie_nav != null:
        return
    var data := TitanicMap.build_navigation()
    configure_zombie_navigation(data["grid"], data["heights"], Vector2(TitanicMap.NAV_LEFT, TitanicMap.NAV_TOP), TitanicMap.NAV_CELL)

func _zombie_cell(pos: Vector3) -> Vector2i:
    return Vector2i(roundi((pos.x - zombie_nav_origin.x) / zombie_nav_cell_size), roundi((pos.z - zombie_nav_origin.y) / zombie_nav_cell_size))

func _zombie_world(cell: Vector2i) -> Vector3:
    return Vector3(zombie_nav_origin.x + cell.x * zombie_nav_cell_size, float(zombie_heights.get(cell, 0.0)), zombie_nav_origin.y + cell.y * zombie_nav_cell_size)

# Ближайшая проходимая ячейка: сначала быстрый поиск по кольцам вокруг ячейки.
func zombie_nearby_walkable(pos: Vector3) -> Vector3:
    if zombie_nav == null or zombie_heights.is_empty():
        return pos
    var center := _zombie_cell(pos)
    if zombie_heights.has(center):
        return _zombie_world(center)
    for ring in range(1, 10):
        var best_cell := Vector2i.ZERO
        var best := INF
        for dx in range(-ring, ring + 1):
            for dz in range(-ring, ring + 1):
                if maxi(absi(dx), absi(dz)) != ring:
                    continue
                var cell := center + Vector2i(dx, dz)
                if not zombie_heights.has(cell):
                    continue
                var distance := _zombie_world(cell).distance_squared_to(pos)
                if distance < best:
                    best = distance
                    best_cell = cell
        if best < INF:
            return _zombie_world(best_cell)
    return pos

func zombie_player_spawn() -> Vector3:
    return TitanicMap.player_spawn(0)

func _zombie_route(pos: Vector3, destination: Vector3) -> Array[Vector2i]:
    var route: Array[Vector2i] = []
    if zombie_nav == null:
        return route
    var start := _zombie_cell(zombie_nearby_walkable(pos))
    var finish := _zombie_cell(zombie_nearby_walkable(destination))
    if zombie_nav.is_in_boundsv(start) and zombie_nav.is_in_boundsv(finish) and not zombie_nav.is_point_solid(start) and not zombie_nav.is_point_solid(finish):
        route = zombie_nav.get_id_path(start, finish)
    return route

func _wave_duration() -> float:
    return WAVE_FIRST_TIME if zombie_wave_no <= 1 else WAVE_NEXT_TIME

## Уровень сложности: внутри волны растёт каждые 1/6 её длины (0..5), каждая следующая волна даёт +2 сразу.
func _zombie_wave() -> int:
    var duration := _wave_duration()
    var elapsed := duration - zombie_time_left
    var inner := clampi(int(elapsed / (duration / 6.0)), 0, 5)
    return clampi(inner + (zombie_wave_no - 1) * 2, 0, 9)

## Волна N даёт в N раз больше зомби (2-я волна — 2X, 3-я — 3X ...).
func _wave_count_mul() -> float:
    return float(maxi(1, zombie_wave_no))

## Здоровье зомби: +50% за каждую следующую волну.
func _wave_hp_mul() -> float:
    return 1.0 + 0.5 * float(maxi(0, zombie_wave_no - 1))

func _alive_human_positions() -> Array:
    var result: Array = []
    for raw_id in battle_positions.keys():
        var peer := int(raw_id)
        if is_bot(peer) or peer_state(peer) != ST_ALIVE:
            continue
        result.append(battle_positions[peer])
    return result

# Stage103: зомби появляются ТОЛЬКО из вентиляционных люков (TitanicMap.vent_points),
# но не ближе MIN_SPAWN_DISTANCE к живым игрокам.
func _pick_zombie_spawn(humans: Array) -> Vector3:
    var min_distance := 24.0
    var candidates: Array = TitanicMap.zombie_spawn_points()
    if candidates.is_empty():
        var cells := zombie_heights.keys()
        for _i in range(12):
            candidates.append(_zombie_world(cells[randi() % cells.size()]))
    candidates.shuffle()
    var farthest := Vector3.ZERO
    var farthest_distance := -1.0
    for raw in candidates:
        var point: Vector3 = raw
        var nearest := INF
        for human in humans:
            var h: Vector3 = human
            nearest = minf(nearest, Vector2(point.x - h.x, point.z - h.z).length())
        if nearest >= min_distance:
            return point
        if nearest > farthest_distance:
            farthest_distance = nearest
            farthest = point
    return farthest

func _spawn_zombie(humans: Array) -> void:
    var wave := _zombie_wave()
    var roll := randf()
    var zombie_kind := 0
    # Сильные зомби (громилы) со 2-й волны появляются заметно чаще.
    if wave >= 2 and roll < 0.06 + 0.02 * float(wave) + 0.05 * float(zombie_wave_no - 1):
        zombie_kind = 2
    elif wave >= 1 and roll < 0.30:
        zombie_kind = 1
    zombie_serial += 1
    var spawn := zombie_nearby_walkable(_pick_zombie_spawn(humans))
    zombie_positions[zombie_serial] = spawn
    zombie_yaws[zombie_serial] = randf() * TAU
    zombie_rise_left[zombie_serial] = ZOMBIE_RISE_HOLD
    zombie_health[zombie_serial] = int(round(float(ZOMBIE_HP[zombie_kind]) * _wave_hp_mul()))
    zombie_meta[zombie_serial] = Vector4(zombie_kind, zombie_yaws[zombie_serial], -1.0, -1.0)

## Stage87: смена фазы волны (только сервер/solo). Клиенты узнают фазу из снимка зомби.
func _set_zombie_phase(phase: int) -> void:
    zombie_phase = phase
    if phase == PHASE_HELI:
        zombie_heli_left = WAVE_HELI_TIME
    zombie_phase_changed.emit(zombie_phase, zombie_wave_no)

func _start_next_wave() -> void:
    zombie_wave_no += 1
    zombie_time_left = WAVE_NEXT_TIME
    zombie_heli_left = 0.0
    zombie_spawn_clock = 0.0
    _set_zombie_phase(PHASE_FIGHT)

## Живой игрок на площадке «ТОЧКА ПОЯВЛЕНИЯ» садится в вертолёт. Первый коснувшийся вызывает вертолёт (1:00).
func _check_evac_touch() -> void:
    for raw_id in battle_state.keys():
        var peer := int(raw_id)
        if is_bot(peer) or peer_state(peer) != ST_ALIVE or not battle_positions.has(peer):
            continue
        var p: Vector3 = battle_positions[peer]
        var flat := Vector2(p.x - TitanicMap.SPAWN_CENTER.x, p.z - TitanicMap.SPAWN_CENTER.z)
        if flat.length() > EVAC_TOUCH_RADIUS or absf(p.y - TitanicMap.GROUND_Y) > 3.0:
            continue
        if zombie_phase == PHASE_GO:
            _set_zombie_phase(PHASE_HELI)
        _host_evacuate(peer)
        if battle_over:
            return

func _host_evacuate(peer: int) -> void:
    if role == "client" or peer_state(peer) != ST_ALIVE:
        return
    battle_evacuated[peer] = zombie_wave_no
    battle_state[peer] = ST_DEAD
    battle_bleed[peer] = 0
    if role == "host":
        _evac_sync.rpc(battle_evacuated)     # раньше снимка состояний (оба reliable, порядок сохраняется)
    _after_state_change()

func is_evacuated(peer: int) -> bool:
    return battle_evacuated.has(peer)

@rpc("authority", "call_remote", "reliable")
func _evac_sync(evacuated: Dictionary) -> void:
    if role != "client":
        return
    battle_evacuated = evacuated.duplicate(true)

# Stage77/80/87: серверные волны зомби (эвакуация вертолётом после каждой волны).
func _tick_zombies(delta: float) -> void:
    if not battle_active or battle_over or role == "client":
        return
    # Stage87: фазы волны.
    match zombie_phase:
        PHASE_FIGHT:
            zombie_time_left = maxf(0.0, zombie_time_left - delta)
            if zombie_time_left <= 0.0:
                _set_zombie_phase(PHASE_HELI)   # сразу запускается отдельный таймер 1:00
        PHASE_GO:
            _check_evac_touch()
        PHASE_HELI:
            zombie_heli_left = maxf(0.0, zombie_heli_left - delta)
            _check_evac_touch()
            if not battle_over and zombie_heli_left <= 0.0:
                _start_next_wave()
    if battle_over:
        return
    _ensure_zombie_navigation()
    if zombie_heights.is_empty():
        return
    var humans := _alive_human_positions()
    var wave := _zombie_wave()
    # Волны: каждые 20 секунд спавн чаще, пачки крупнее, зомби больше.
    var count_mul := _wave_count_mul()
    var spawn_interval := maxf(0.9, 3.0 - 0.4 * float(wave))
    var batch := int(ceil(float(1 + wave / 2) * count_mul))
    var max_alive := mini(ZOMBIE_MAX_ALIVE, int(float(16 + wave * 4) * count_mul))
    _creator_sword_contact_kills()
    # Трупы: считаем время, через ZOMBIE_LINGER секунд убираем зомби совсем.
    for dead_key in zombie_dead_age.keys():
        var dead_age := float(zombie_dead_age[dead_key]) + delta
        if dead_age >= ZOMBIE_LINGER:
            for table in [zombie_positions, zombie_meta, zombie_health, zombie_yaws, zombie_attack_age, zombie_attack_hit, zombie_rise_left, zombie_paths, zombie_attack_cooldowns, zombie_dead_age]:
                (table as Dictionary).erase(dead_key)
        else:
            zombie_dead_age[dead_key] = dead_age
    var can_spawn := zombie_phase != PHASE_HELI     # пока вертолёт ждёт, новые зомби не появляются
    if can_spawn and zombie_serial == 0 and not humans.is_empty():
        for _i in range(5):
            _spawn_zombie(humans)
    zombie_path_clock += delta
    zombie_spawn_clock += delta
    if can_spawn and zombie_spawn_clock >= spawn_interval and not humans.is_empty():
        zombie_spawn_clock = 0.0
        for _i in range(batch):
            if zombie_positions.size() - zombie_dead_age.size() < max_alive:
                _spawn_zombie(humans)
    for key in zombie_positions.keys():
        var zid := int(key)
        if zombie_dead_age.has(zid):
            continue
        var pos: Vector3 = zombie_positions[zid]
        var meta: Vector4 = zombie_meta.get(zid, Vector4(0, 0, -1, -1))
        var zombie_kind := int(meta.x)
        # Фаза вылезания из люка.
        var rise := float(zombie_rise_left.get(zid, 0.0)) - delta
        if rise > 0.0:
            zombie_rise_left[zid] = rise
            continue
        zombie_rise_left.erase(zid)
        var target := -1
        var closest := INF
        for raw_id in battle_positions.keys():
            var peer := int(raw_id)
            if is_bot(peer) or peer_state(peer) != ST_ALIVE:
                continue
            var d := pos.distance_squared_to(battle_positions[peer])
            if d < closest:
                closest = d
                target = peer
        # Stage90: зомби бьёт ближайшую турель, если она рядом и ближе любого живого игрока.
        var turret_target := -1
        var turret_best := TURRET_AGGRO * TURRET_AGGRO
        for raw_tid in turrets.keys():
            var tpos: Vector3 = turrets[raw_tid]["pos"]
            var td := Vector2(pos.x - tpos.x, pos.z - tpos.z).length_squared()
            if td < turret_best:
                turret_best = td
                turret_target = int(raw_tid)
        var attack_turret := turret_target >= 0 and (target < 0 or turret_best < closest)
        if target < 0 and not attack_turret:
            continue
        var path_key := -1000000 - turret_target if attack_turret else target
        var target_pos: Vector3 = (turrets[turret_target]["pos"] as Vector3) if attack_turret else (battle_positions[target] as Vector3)
        var to_target: Vector3 = target_pos - pos
        to_target.y = 0.0
        var distance := to_target.length()
        var attacking := zombie_attack_age.has(zid)
        var move_dir := Vector3.ZERO
        if not attacking and distance > 1.5:
            # Путь пересчитывается не чаще раза в 0.6 с на зомби (со случайным сдвигом).
            var entry: Dictionary = zombie_paths.get(zid, {})
            var age := float(entry.get("age", randf() * 0.6)) + delta
            if entry.is_empty() or age >= 0.6 or int(entry.get("target", -1)) != path_key:
                entry = {"target": path_key, "cells": _zombie_route(pos, target_pos), "age": 0.0}
            else:
                entry["age"] = age
            zombie_paths[zid] = entry
            var path: Array = entry.get("cells", [])
            var waypoint := target_pos
            if path.size() > 2:
                waypoint = _zombie_world(path[1])
            var step := waypoint - pos
            step.y = 0.0
            if step.length() > 0.05:
                move_dir = step.normalized()
        # Лёгкое расталкивание, чтобы зомби не слипались в одну точку.
        var push := Vector3.ZERO
        for other_key in zombie_positions.keys():
            if int(other_key) == zid or zombie_dead_age.has(other_key):
                continue
            var away: Vector3 = pos - (zombie_positions[other_key] as Vector3)
            away.y = 0.0
            var away_length := away.length()
            if away_length > 0.001 and away_length < 1.0:
                push += away / away_length * (1.0 - away_length)
        if move_dir != Vector3.ZERO or push != Vector3.ZERO:
            var next_pos := pos + (move_dir * float(ZOMBIE_SPEED[zombie_kind]) * zombie_speed_mul + push * 1.5) * delta
            var snapped := zombie_nearby_walkable(next_pos)
            if absf(snapped.x - next_pos.x) < 1.6 and absf(snapped.z - next_pos.z) < 1.6:
                zombie_positions[zid] = Vector3(next_pos.x, snapped.y, next_pos.z)
        # Поворот лицом к цели или к направлению движения.
        var face := to_target if (attacking or distance <= 3.0) else move_dir
        if face.length() > 0.01:
            zombie_yaws[zid] = lerp_angle(float(zombie_yaws.get(zid, 0.0)), atan2(face.x, face.z), minf(1.0, delta * 8.0))
        # Атака: замах 0.35 с, затем урон, всего 0.8 с анимации.
        var cooldown := maxf(0.0, float(zombie_attack_cooldowns.get(zid, 0.0)) - delta)
        if attacking:
            var attack_time := float(zombie_attack_age[zid]) + delta
            if attack_time >= 0.4 and not zombie_attack_hit.has(zid):
                zombie_attack_hit[zid] = true
                if distance <= 2.7 and absf(target_pos.y - pos.y) <= ZOMBIE_REACH_Y and not TitanicMap.segment_blocked(pos + Vector3(0, 1.2, 0), target_pos + Vector3(0, 1.2, 0)):
                    if attack_turret:
                        _damage_turret(turret_target, int(ZOMBIE_DAMAGE[zombie_kind]))
                    else:
                        _apply_zombie_damage(target, int(ZOMBIE_DAMAGE[zombie_kind]))
            if attack_time >= 0.8:
                zombie_attack_age.erase(zid)
                zombie_attack_hit.erase(zid)
            else:
                zombie_attack_age[zid] = attack_time
        elif distance <= 2.1 and cooldown <= 0.0 and absf(target_pos.y - pos.y) <= ZOMBIE_REACH_Y and not TitanicMap.segment_blocked(pos + Vector3(0, 1.2, 0), target_pos + Vector3(0, 1.2, 0)):
            zombie_attack_age[zid] = 0.0
            zombie_attack_hit.erase(zid)
            cooldown = float(ZOMBIE_COOLDOWN[zombie_kind])
        zombie_attack_cooldowns[zid] = cooldown
    for key in zombie_positions.keys():
        var zid2 := int(key)
        var old_meta: Vector4 = zombie_meta.get(zid2, Vector4(0, 0, -1, -1))
        zombie_meta[zid2] = Vector4(old_meta.x, float(zombie_yaws.get(zid2, 0.0)), float(zombie_attack_age.get(zid2, -1.0)), float(zombie_dead_age.get(zid2, -1.0)))
    _tick_turrets(delta)
    # Снимок отправляем 20 раз в секунду, клиенты сглаживают движение.
    zombie_net_clock += delta
    if zombie_net_clock >= 0.05:
        zombie_net_clock = 0.0
        _zombie_snapshot.rpc(zombie_heli_left if zombie_phase == PHASE_HELI else zombie_time_left, zombie_positions, zombie_meta, zombie_kills, zombie_phase, zombie_wave_no)
        if not turret_aims.is_empty():
            _turret_snapshot.rpc(turret_aims, turret_ammo, turret_hp)
    zombie_updated.emit()

# ---------------------------------------------------------------- Stage84: турели

## Игрок нажал «Использовать» у турели. Положение и поворот выбирает боевая сцена.
func request_turret_place(pos: Vector3, yaw: float) -> bool:
    if not battle_active or game_mode != MODE_ZOMBIES:
        return false
    if role == "client":
        _request_turret_place.rpc_id(1, pos, yaw)
        return true
    return _host_place_turret(my_id(), pos, yaw)

@rpc("any_peer", "call_remote", "reliable")
func _request_turret_place(pos: Vector3, yaw: float) -> void:
    if role != "host" or not battle_active:
        return
    _host_place_turret(multiplayer.get_remote_sender_id(), pos, yaw)

func _turret_deny(peer: int, message: String) -> void:
    if peer == my_id():
        turret_notice.emit(message)
    elif role == "host":
        _turret_notice_rpc.rpc_id(peer, message)

@rpc("authority", "call_remote", "reliable")
func _turret_notice_rpc(message: String) -> void:
    if role == "client":
        turret_notice.emit(message)

func _host_place_turret(peer: int, pos: Vector3, yaw: float) -> bool:
    if battle_over:
        _turret_deny(peer, "Сейчас нельзя ставить турель")
        return false
    if peer_state(peer) != ST_ALIVE or not battle_positions.has(peer):
        _turret_deny(peer, "Турель может поставить только живой игрок")
        return false
    if not (is_finite(pos.x) and is_finite(pos.z) and is_finite(yaw)):
        return false
    var player_pos: Vector3 = battle_positions[peer]
    if Vector2(pos.x - player_pos.x, pos.z - player_pos.z).length() > TURRET_PLACE_REACH:
        _turret_deny(peer, "Слишком далеко от игрока")
        return false
    var own_count := 0
    for tid in turrets.keys():
        if int(turrets[tid]["owner"]) == peer:
            own_count += 1
    if own_count >= TURRET_MAX_PER_PLAYER:
        _turret_deny(peer, "Лимит: %d турели на игрока" % TURRET_MAX_PER_PLAYER)
        return false
    if turrets.size() >= TURRET_MAX_TOTAL:
        _turret_deny(peer, "На карте слишком много турелей")
        return false
    var spot := TitanicMap.resolve_player(Vector3(pos.x, TitanicMap.GROUND_Y, pos.z))
    if Vector2(spot.x - pos.x, spot.z - pos.z).length() > 1.2:
        _turret_deny(peer, "Здесь нельзя поставить турель")
        return false
    spot.y = TitanicMap.GROUND_Y
    for tid in turrets.keys():
        if (turrets[tid]["pos"] as Vector3).distance_to(spot) < 1.3:
            _turret_deny(peer, "Рядом уже стоит турель")
            return false
    _turret_serial += 1
    var new_id := _turret_serial
    turrets[new_id] = {"pos": spot, "owner": peer}
    _turret_state[new_id] = {"cd": 0.4, "yaw": yaw, "pitch": 0.0, "age": 9.0, "target": -1, "ammo": TURRET_AMMO}
    turret_ammo[new_id] = TURRET_AMMO
    turret_hp[new_id] = TURRET_HP
    turret_aims[new_id] = Vector4(yaw, 0.0, 9.0, -1.0)
    _turret_spawn.rpc(new_id, spot, peer)
    if peer == my_id():
        turret_place_approved.emit()
    else:
        _turret_place_approved_rpc.rpc_id(peer)
    return true

@rpc("authority", "call_remote", "reliable")
func _turret_place_approved_rpc() -> void:
    if role == "client":
        turret_place_approved.emit()

@rpc("authority", "call_remote", "reliable")
func _turret_spawn(id: int, pos: Vector3, owner_peer: int) -> void:
    if role != "client" or not battle_active:
        return
    turrets[id] = {"pos": pos, "owner": owner_peer}
    turret_aims[id] = Vector4(0.0, 0.0, 9.0, -1.0)
    turret_ammo[id] = TURRET_AMMO
    turret_hp[id] = TURRET_HP

@rpc("authority", "call_remote", "unreliable")
func _turret_snapshot(aims: Dictionary, ammo: Dictionary, hp: Dictionary) -> void:
    if role != "client" or not battle_active:
        return
    # Уничтоженные турели приходят отдельным reliable-вызовом; запоздавший снимок их не возвращает.
    turret_aims = aims.duplicate(true)
    turret_ammo = ammo.duplicate(true)
    turret_hp = hp.duplicate(true)

# ---------------------------------------------------------------- Stage90: урон по турелям и покупка патронов

## Зомби ударил турель (только хост).
func _damage_turret(tid: int, amount: int) -> void:
    if role == "client" or not turrets.has(tid):
        return
    turret_hp[tid] = int(turret_hp.get(tid, TURRET_HP)) - amount
    if int(turret_hp[tid]) <= 0:
        _remove_turret(tid)
        if role == "host":
            _turret_destroyed.rpc(tid)

func _remove_turret(tid: int) -> void:
    turrets.erase(tid)
    turret_aims.erase(tid)
    turret_ammo.erase(tid)
    turret_hp.erase(tid)
    _turret_state.erase(tid)

@rpc("authority", "call_remote", "reliable")
func _turret_destroyed(tid: int) -> void:
    if role == "client":
        _remove_turret(tid)

## Игрок навёл прицел на турель и нажал «Купить патроны». Деньги списываются после одобрения хоста.
func request_turret_refill(tid: int) -> bool:
    if not battle_active:
        return false
    if role == "client":
        _request_turret_refill.rpc_id(1, tid)
        return true
    return _host_refill_turret(my_id(), tid)

@rpc("any_peer", "call_remote", "reliable")
func _request_turret_refill(tid: int) -> void:
    if role != "host" or not battle_active:
        return
    _host_refill_turret(multiplayer.get_remote_sender_id(), tid)

func _host_refill_turret(peer: int, tid: int) -> bool:
    if battle_over:
        _turret_deny(peer, "Сейчас нельзя")
        return false
    if peer_state(peer) != ST_ALIVE or not battle_positions.has(peer):
        _turret_deny(peer, "Патроны может купить только живой игрок")
        return false
    if not turrets.has(tid) or not _turret_state.has(tid):
        _turret_deny(peer, "Турель уничтожена")
        return false
    var player_pos: Vector3 = battle_positions[peer]
    var turret_pos: Vector3 = turrets[tid]["pos"]
    if Vector2(player_pos.x - turret_pos.x, player_pos.z - turret_pos.z).length() > TURRET_REFILL_REACH:
        _turret_deny(peer, "Слишком далеко от турели")
        return false
    var st: Dictionary = _turret_state[tid]
    if int(st["ammo"]) + TURRET_REFILL_AMMO > TURRET_AMMO_MAX:
        _turret_deny(peer, "Турель уже заряжена (максимум %d)" % TURRET_AMMO_MAX)
        return false
    st["ammo"] = int(st["ammo"]) + TURRET_REFILL_AMMO
    turret_ammo[tid] = int(st["ammo"])
    if peer == my_id():
        turret_refill_approved.emit(tid)
    else:
        _turret_refill_approved_rpc.rpc_id(peer, tid)
    return true

@rpc("authority", "call_remote", "reliable")
func _turret_refill_approved_rpc(tid: int) -> void:
    if role == "client":
        turret_refill_approved.emit(tid)

# Хост: каждая турель берёт ближайшего живого зомби в радиусе, плавно наводится и стреляет.
func _tick_turrets(delta: float) -> void:
    if turrets.is_empty():
        return
    for tid in turrets.keys():
        var st: Dictionary = _turret_state.get(tid, {})
        if st.is_empty():
            continue
        var base: Vector3 = turrets[tid]["pos"]
        var muzzle := base + Vector3(0.0, 1.17, 0.0)
        st["cd"] = maxf(0.0, float(st["cd"]) - delta)
        st["age"] = minf(9.0, float(st["age"]) + delta)
        turret_ammo[tid] = int(st["ammo"])
        if int(st["ammo"]) <= 0:
            # Патроны кончились: турель молчит и не целится.
            turret_aims[tid] = Vector4(float(st["yaw"]), float(st["pitch"]), 9.0, -1.0)
            continue
        var best := -1
        var best_d := TURRET_RANGE * TURRET_RANGE
        var best_point := Vector3.ZERO
        for raw_zid in zombie_positions.keys():
            var zid := int(raw_zid)
            if not _zombie_targetable(zid):
                continue
            var zk := float(ZombieModel.KIND_SCALE[_zombie_kind_of(zid)])
            var point: Vector3 = (zombie_positions[zid] as Vector3) + Vector3(0.0, 1.15 * zk, 0.0)
            var d := muzzle.distance_squared_to(point)
            if d >= best_d:
                continue
            # Не стреляем сквозь стены: цель должна быть в прямой видимости.
            if TitanicMap.segment_blocked(muzzle, point):
                continue
            if d < best_d:
                best_d = d
                best = zid
                best_point = point
        if best >= 0:
            var dir := best_point - muzzle
            var want_yaw := atan2(dir.x, dir.z)
            var want_pitch := atan2(dir.y, Vector2(dir.x, dir.z).length())
            st["yaw"] = lerp_angle(float(st["yaw"]), want_yaw, minf(1.0, delta * 16.0))
            st["pitch"] = lerpf(float(st["pitch"]), want_pitch, minf(1.0, delta * 16.0))
            if float(st["cd"]) <= 0.0 and absf(angle_difference(float(st["yaw"]), want_yaw)) < 0.12:
                st["cd"] = TURRET_INTERVAL
                st["age"] = 0.0
                st["target"] = best
                st["ammo"] = int(st["ammo"]) - 1
                turret_ammo[tid] = int(st["ammo"])
                _turret_hit_zombie(best, TURRET_DAMAGE)
        var target_id := int(st["target"]) if float(st["age"]) < 0.15 else -1
        turret_aims[tid] = Vector4(float(st["yaw"]), float(st["pitch"]), float(st["age"]), float(target_id))

# Урон турели: без «подтверждения попадания» стрелку, чтобы не спамить маркером и RPC.
func _turret_hit_zombie(zid: int, amount: int) -> void:
    if not zombie_health.has(zid) or zombie_dead_age.has(zid):
        return
    zombie_health[zid] = int(zombie_health[zid]) - amount
    if int(zombie_health[zid]) <= 0:
        zombie_dead_age[zid] = 0.0
        zombie_attack_age.erase(zid)
        zombie_attack_hit.erase(zid)
        zombie_kills += 1

# Stage81: урон по зомби считает хост; смерть и убийства синхронизируются снимком.
# Stage100: server-authoritative contact buff for CREATOR sword.
# Only an alive player actively holding the sword can instantly kill a live zombie.
# Distance is measured from player body to zombie body, not from camera/weapon visuals.
func _creator_sword_contact_kills() -> void:
    if role == "client" or game_mode != MODE_ZOMBIES:
        return
    for raw_peer in battle_positions.keys():
        var peer := int(raw_peer)
        if peer_state(peer) != ST_ALIVE or str(battle_weapons.get(peer, "")) != "diamond_sword":
            continue
        var player_pos: Vector3 = battle_positions[peer]
        for raw_zid in zombie_positions.keys():
            var zid := int(raw_zid)
            if not _zombie_targetable(zid):
                continue
            var zombie_pos: Vector3 = zombie_positions[zid]
            var horizontal := Vector2(player_pos.x - zombie_pos.x, player_pos.z - zombie_pos.z)
            if horizontal.length_squared() <= 1.65 * 1.65 and absf(player_pos.y - zombie_pos.y) <= 2.1:
                _damage_zombie(peer, zid, maxi(1, int(zombie_health.get(zid, 1))))

func _damage_zombie(shooter: int, zid: int, amount: int) -> void:
    if amount <= 0 or not zombie_health.has(zid) or zombie_dead_age.has(zid):
        return
    zombie_health[zid] = int(zombie_health[zid]) - amount
    if shooter == my_id():
        shot_confirmed.emit(-1, amount)
    elif role == "host" and not is_bot(shooter):
        _shot_hit_confirmed.rpc_id(shooter, -1, amount)
    if int(zombie_health[zid]) <= 0:
        zombie_dead_age[zid] = 0.0
        zombie_attack_age.erase(zid)
        zombie_attack_hit.erase(zid)
        zombie_kills += 1
        if str(battle_weapons.get(shooter, "")) == "diamond_sword":
            var burn_position: Vector3 = zombie_positions.get(zid, Vector3.ZERO)
            creator_sword_zombie_burn.emit(zid, burn_position)
            if role == "host":
                _creator_sword_burn_rpc.rpc(zid, burn_position)

@rpc("authority", "call_remote", "reliable")
func _creator_sword_burn_rpc(zid: int, burn_position: Vector3) -> void:
    if role == "client" and battle_active and game_mode == MODE_ZOMBIES:
        creator_sword_zombie_burn.emit(zid, burn_position)

# Зомби можно ранить, только когда он уже вылез из люка и ещё жив.
func _zombie_targetable(zid: int) -> bool:
    return not zombie_dead_age.has(zid) and not zombie_rise_left.has(zid) and zombie_health.has(zid)

func _zombie_kind_of(zid: int) -> int:
    var meta: Vector4 = zombie_meta.get(zid, Vector4(0, 0, -1, -1))
    return clampi(int(meta.x), 0, 2)

## Зоны попадания по зомби: голова x2, туловище x1, ноги x0.8; размеры зависят от масштаба вида.
func _zombie_hit_region(origin: Vector3, ray: Vector3, base: Vector3, kind: int, max_distance: float) -> Dictionary:
    var k := float(ZombieModel.KIND_SCALE[kind])
    var zones := [
        {"offset": Vector3(0, 1.74 * k, 0.04 * k), "radius": 0.21 * k, "mult": 2.0},
        {"offset": Vector3(0, 1.30 * k, 0), "radius": 0.38 * k, "mult": 1.0},
        {"offset": Vector3(0, 0.90 * k, 0), "radius": 0.30 * k, "mult": 1.0},
        {"offset": Vector3(-0.15 * k, 0.45 * k, 0), "radius": 0.24 * k, "mult": 0.8},
        {"offset": Vector3(0.15 * k, 0.45 * k, 0), "radius": 0.24 * k, "mult": 0.8}
    ]
    var nearest := max_distance
    var multiplier := 0.0
    for zone in zones:
        var center: Vector3 = base + zone["offset"]
        var along := (center - origin).dot(ray)
        if along < 0.0 or along >= nearest:
            continue
        var radius: float = zone["radius"]
        var perpendicular_sq := (origin + ray * along).distance_squared_to(center)
        if perpendicular_sq <= radius * radius:
            nearest = along - sqrt(radius * radius - perpendicular_sq)
            multiplier = float(zone["mult"])
    return {"distance": nearest, "mult": multiplier}

func _apply_zombie_damage(victim: int, amount: int) -> void:
    if peer_state(victim) != ST_ALIVE:
        return
    battle_health[victim] = maxi(0, int(battle_health.get(victim, 100)) - amount)
    health_changed.emit(victim, int(battle_health[victim]))
    if role == "host":
        _health_snapshot.rpc(battle_health)
    if int(battle_health[victim]) <= 0:
        _knock_out(victim)

@rpc("authority", "call_remote", "unreliable")
func _zombie_snapshot(seconds: float, positions: Dictionary, meta: Dictionary, kills: int, phase: int, wave: int) -> void:
    if role != "client" or not battle_active:
        return
    if phase == PHASE_HELI:
        zombie_heli_left = seconds
    else:
        zombie_time_left = seconds
    if phase != zombie_phase or wave != zombie_wave_no:
        zombie_phase = phase
        zombie_wave_no = wave
        zombie_phase_changed.emit(phase, wave)
    zombie_positions = positions.duplicate(true)
    zombie_meta = meta.duplicate(true)
    zombie_kills = kills
    zombie_updated.emit()

@rpc("authority", "call_remote", "reliable")
func _zombie_victory_sync() -> void:
    if role != "client" or not battle_active:
        return
    zombie_win = true
    battle_over = true
    zombie_victory.emit()
    _on_battle_over()


# Stage121: Host-authoritative survival teams.
signal teams_changed
signal team_invitation(leader: int, title: String)
var survival_teams: Dictionary = {} # leader peer ID -> {name, members}
var pending_team_invites: Dictionary = {} # target -> leader
var survival_team_offline: Dictionary = {} # stable identity -> {name, team}

func _team_identity(peer: int) -> String:
    if peer == 1:
        return "host"
    return str(survival_client_ids.get(peer, "peer:" + str(peer)))

func _team_export_saved() -> Array:
    var result: Array = []
    for leader in survival_teams.keys():
        var team: Dictionary = survival_teams[leader]
        var members: Array = []
        for member in team.get("members", []):
            var id := int(member)
            members.append({"id": _team_identity(id), "nick": str(roster.get(id, {}).get("nick", "Игрок")), "leader": id == int(leader)})
        for identity in survival_team_offline.keys():
            var info: Dictionary = survival_team_offline[identity]
            if int(info.get("team", 0)) == int(leader):
                members.append({"id": identity, "nick": str(info.get("nick", "Игрок")), "leader": bool(info.get("leader", false))})
        result.append({"name": str(team.get("name", "Команда")), "members": members})
    return result

func _team_import_saved(saved: Variant) -> void:
    if not (saved is Array):
        return
    for item in saved:
        if not (item is Dictionary):
            continue
        var members: Array = item.get("members", [])
        var leader_id := 0
        for entry in members:
            if entry is Dictionary and str(entry.get("id", "")) == "host":
                leader_id = 1
                break
        if leader_id == 0:
            # Reserve a negative key for an offline leader.
            leader_id = -1
            while survival_teams.has(leader_id):
                leader_id -= 1
        survival_teams[leader_id] = {"name": str(item.get("name", "Команда")), "members": []}
        for entry in members:
            if not (entry is Dictionary):
                continue
            var identity := str(entry.get("id", ""))
            if identity == "host":
                (survival_teams[leader_id]["members"] as Array).append(1)
            elif not identity.is_empty():
                survival_team_offline[identity] = {"team": leader_id, "nick": str(entry.get("nick", "Игрок")), "leader": bool(entry.get("leader", false))}
    teams_changed.emit()

func _team_disconnect(peer: int) -> void:
    var leader := team_leader(peer)
    if leader == 0:
        return
    var identity := _team_identity(peer)
    survival_team_offline[identity] = {"team": leader, "nick": str(roster.get(peer, {}).get("nick", "Игрок")), "leader": leader == peer}
    (survival_teams[leader]["members"] as Array).erase(peer)
    _team_broadcast()

func _team_reconnect(peer: int, identity: String) -> void:
    if not survival_team_offline.has(identity):
        return
    var info: Dictionary = survival_team_offline[identity]
    var leader := int(info.get("team", 0))
    if not survival_teams.has(leader):
        return
    if bool(info.get("leader", false)) and leader != 1:
        survival_teams[peer] = survival_teams[leader]
        survival_teams.erase(leader)
        for other in survival_team_offline.keys():
            if int(survival_team_offline[other].get("team", 0)) == leader:
                survival_team_offline[other]["team"] = peer
        leader = peer
    (survival_teams[leader]["members"] as Array).append(peer)
    survival_team_offline.erase(identity)
    _team_broadcast()


func team_leader(peer: int) -> int:
    for leader in survival_teams.keys():
        if peer in (survival_teams[leader] as Dictionary).get("members", []):
            return int(leader)
    return 0

func same_team(a: int, b: int) -> bool:
    return team_leader(a) != 0 and team_leader(a) == team_leader(b)

func create_survival_team(title: String) -> void:
    if role == "client":
        _team_create_request.rpc_id(1, title)
    else:
        _team_host_create(my_id(), title)

@rpc("any_peer", "call_remote", "reliable")
func _team_create_request(title: String) -> void:
    if role == "host":
        _team_host_create(multiplayer.get_remote_sender_id(), title)

func _team_host_create(peer: int, title: String) -> void:
    title = title.strip_edges().substr(0, 24)
    if game_mode != MODE_SURVIVAL or not battle_active or title.is_empty() or team_leader(peer) != 0 or not roster.has(peer):
        return
    survival_teams[peer] = {"name": title, "members": [peer]}
    _team_broadcast()

func invite_survival_team(target: int) -> void:
    if role == "client":
        _team_invite_request.rpc_id(1, target)
    else:
        _team_host_invite(my_id(), target)

@rpc("any_peer", "call_remote", "reliable")
func _team_invite_request(target: int) -> void:
    if role == "host":
        _team_host_invite(multiplayer.get_remote_sender_id(), target)

func _team_host_invite(sender: int, target: int) -> void:
    if not battle_active or game_mode != MODE_SURVIVAL or team_leader(sender) != sender or team_leader(target) != 0 or sender == target:
        return
    if not battle_positions.has(sender) or not battle_positions.has(target) or battle_positions[sender].distance_to(battle_positions[target]) > 1.5:
        return
    pending_team_invites[target] = sender
    var title: String = str(survival_teams[sender].get("name", "Команда"))
    if target == my_id():
        team_invitation.emit(sender, title)
    else:
        _team_invitation_rpc.rpc_id(target, sender, title)

@rpc("authority", "call_remote", "reliable")
func _team_invitation_rpc(sender: int, title: String) -> void:
    team_invitation.emit(sender, title)

func answer_survival_team(accept: bool) -> void:
    if role == "client":
        _team_answer_request.rpc_id(1, accept)
    else:
        _team_host_answer(my_id(), accept)

@rpc("any_peer", "call_remote", "reliable")
func _team_answer_request(accept: bool) -> void:
    if role == "host":
        _team_host_answer(multiplayer.get_remote_sender_id(), accept)

func _team_host_answer(peer: int, accept: bool) -> void:
    if not pending_team_invites.has(peer):
        return
    var leader: int = int(pending_team_invites[peer])
    pending_team_invites.erase(peer)
    if accept and survival_teams.has(leader) and team_leader(peer) == 0 and roster.has(peer):
        var members: Array = survival_teams[leader]["members"]
        members.append(peer)
        _team_broadcast()

func leave_survival_team() -> void:
    if role == "client":
        _team_leave_request.rpc_id(1)
    else:
        _team_host_leave(my_id())

@rpc("any_peer", "call_remote", "reliable")
func _team_leave_request() -> void:
    if role == "host":
        _team_host_leave(multiplayer.get_remote_sender_id())

func _team_host_leave(peer: int) -> void:
    var leader := team_leader(peer)
    if leader == 0:
        return
    if leader == peer:
        survival_teams.erase(leader)
        for identity in survival_team_offline.keys():
            if int(survival_team_offline[identity].get("team", 0)) == leader:
                survival_team_offline.erase(identity)
    else:
        (survival_teams[leader]["members"] as Array).erase(peer)
    _team_broadcast()

func _team_broadcast() -> void:
    teams_changed.emit()
    if role == "host":
        if not survival_save_name.is_empty() and game_mode == MODE_SURVIVAL:
            SurvivalSaves.saved_teams = _team_export_saved()
            SurvivalSaves.save_slot(survival_save_name, survival_host_position, survival_host_hp, survival_host_yaw, survival_host_pitch)
        _team_snapshot.rpc(survival_teams, survival_team_offline)

@rpc("authority", "call_remote", "reliable")
func _team_snapshot(teams: Dictionary, offline: Dictionary) -> void:
    survival_teams = teams.duplicate(true)
    survival_team_offline = offline.duplicate(true)
    teams_changed.emit()
