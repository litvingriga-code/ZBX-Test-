extends Control

const UiGray = preload("res://scripts/ui_gray.gd")
const AK47_ICON: Texture2D = preload("res://assets/hud/weapons/rifle.png")
# Иконки остальных предметов подгружаются по пути (load() кэширует ресурсы).
const ICON_PATHS := {
    "m4a1": "res://assets/hud/weapons/m4a1.png",
    "shotgun": "res://assets/hud/weapons/shotgun.png",
    "svd": "res://assets/hud/weapons/svd.png",
    "pm": "res://assets/hud/weapons/pm.png",
    "revolver": "res://assets/hud/weapons/revolver.png",
    "knife": "res://assets/hud/weapons/knife.png",
    "machete": "res://assets/hud/weapons/machete.png",
    "diamond_sword": "res://assets/hud/weapons/diamond_sword.png",
    "ammo_556": "res://assets/shop/ammo_556.png",
    "ammo_9mm": "res://assets/shop/ammo_9mm.png",
    "ammo_12": "res://assets/shop/ammo_12.png",
    "ammo_44": "res://assets/shop/ammo_44.png",
    "collimator": "res://assets/shop/collimator.png",
    "turret": "res://assets/shop/turret.png",
}
## Кэш иконок со СТРОГИМИ ссылками. Раньше текстура грузилась через load() прямо в _draw():
## ссылка исчезала сразу после вызова, ресурс освобождался, а команда отрисовки
## оставалась с удалённой текстурой — Godot рисует её белой. В бою иконки держали
## кнопки панели оружия, а в лобби их не держал никто, поэтому PNG становились белыми.
static var _icon_cache: Dictionary = {}


static func icon_texture(path: String) -> Texture2D:
    if _icon_cache.has(path):
        return _icon_cache[path]
    if not ResourceLoader.exists(path):
        return null
    var tex := load(path) as Texture2D
    if tex != null:
        _icon_cache[path] = tex
    return tex


signal selected(container: String, slot_index: int)
## Ячейка инвентаря. Предмет можно перетащить пальцем или курсором в любую
## другую ячейку любого инвентаря. Двойной тап - быстро переложить в другой инвентарь.

var container_id: String = "inv"   # "inv" (инвентарь) или "gear" (снаряжение)
var index: int = 0
var item: Dictionary = {}
var is_preview: bool = false
var highlight: bool = false
var is_selected: bool = false


func _init() -> void:
    custom_minimum_size = Vector2(84, 84)
    mouse_filter = Control.MOUSE_FILTER_STOP


func set_item(new_item: Dictionary) -> void:
    item = new_item
    if item.is_empty():
        tooltip_text = ""
    else:
        tooltip_text = str(GameState.ITEMS[str(item["id"])]["name"])
    queue_redraw()


# ---------- drag & drop ----------

func _get_drag_data(_at_position: Vector2) -> Variant:
    if is_preview or item.is_empty():
        return null
    var holder := Control.new()
    var ghost = get_script().new()
    ghost.is_preview = true
    ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ghost.modulate = Color(1, 1, 1, 0.85)
    ghost.size = size
    ghost.position = -size * 0.5
    holder.add_child(ghost)
    ghost.set_item(item.duplicate())
    set_drag_preview(holder)
    return {"container": container_id, "index": index}


func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
    var ok: bool = not is_preview and typeof(data) == TYPE_DICTIONARY \
            and data.has("container") and data.has("index")
    if highlight != ok:
        highlight = ok
        queue_redraw()
    if ok:
        var source: Array = GameState.get_slots(str(data["container"]))
        var source_idx: int = int(data["index"])
        if source_idx < 0 or source_idx >= source.size():
            return false
        ok = GameState.can_place(container_id, index, source[source_idx])
        ok = ok and GameState.can_place(str(data["container"]), source_idx, item)
    return ok


func _drop_data(_at_position: Vector2, data: Variant) -> void:
    highlight = false
    queue_redraw()
    GameState.move_item(str(data["container"]), int(data["index"]), container_id, index)


func _notification(what: int) -> void:
    if what == NOTIFICATION_MOUSE_EXIT or what == NOTIFICATION_DRAG_END:
        if highlight:
            highlight = false
            queue_redraw()


func _gui_input(event: InputEvent) -> void:
    if is_preview:
        return
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        selected.emit(container_id, index)
    if event is InputEventScreenTouch and event.pressed:
        selected.emit(container_id, index)
    if event is InputEventMouseButton and event.pressed \
            and event.button_index == MOUSE_BUTTON_LEFT and event.double_click:
        if not item.is_empty():
            GameState.quick_move(container_id, index)
        accept_event()


# ---------- рисование ----------

func _draw() -> void:
    var r := Rect2(Vector2.ZERO, size)
    draw_rect(r, Color(0.11, 0.11, 0.12, 0.95))
    var border: Color = UiGray.EDGE_STRONG if is_selected else (Color(0.62, 0.62, 0.66) if highlight else UiGray.EDGE_SOFT)
    draw_rect(r, border, false, 3.0 if highlight else 2.0)
    if item.is_empty():
        return
    var id: String = str(item["id"])
    var def: Dictionary = GameState.ITEMS[id]
    var area := Rect2(10, 8, size.x - 20, size.y - 32)
    draw_rect(area, (def["color"] as Color).darkened(0.55))
    _draw_icon(id, area)
    var font: Font = get_theme_default_font()
    draw_string(font, Vector2(0, size.y - 8), str(def["name"]),
            HORIZONTAL_ALIGNMENT_CENTER, size.x, 11, UiGray.TEXT)
    var count: int = int(item["count"])
    if count > 1:
        draw_string(font, Vector2(0, 21), "×%d" % count,
                HORIZONTAL_ALIGNMENT_RIGHT, size.x - 8, 15, UiGray.ACCENT)


func _draw_icon(id: String, a: Rect2) -> void:
    match id:
        "ak47":
            # Единая PNG-иконка для ячеек боевого и лобби-инвентаря.
            # Сохраняем пропорции и центрируем изображение в ячейке.
            _draw_texture_fit(AK47_ICON, a)
        "adrenaline", "medkit":
            var c: Vector2 = a.get_center()
            var u: float = minf(a.size.x, a.size.y) * 0.5
            draw_rect(Rect2(c.x - u * 0.85, c.y - u * 0.65, u * 1.7, u * 1.3), Color(0.92, 0.93, 0.95))
            draw_rect(Rect2(c.x - u * 0.45, c.y - u * 0.14, u * 0.9, u * 0.28), Color(0.85, 0.12, 0.12))
            draw_rect(Rect2(c.x - u * 0.14, c.y - u * 0.45, u * 0.28, u * 0.9), Color(0.85, 0.12, 0.12))
        "ammo_762":
            for i in 3:
                var bx: float = a.position.x + a.size.x * (0.14 + i * 0.28)
                var bw: float = a.size.x * 0.2
                var top: float = a.position.y + a.size.y * 0.38
                draw_rect(Rect2(bx, top, bw, a.size.y * 0.52), Color(0.85, 0.65, 0.25))
                draw_colored_polygon(PackedVector2Array([
                    Vector2(bx, top), Vector2(bx + bw, top), Vector2(bx + bw * 0.5, top - a.size.y * 0.24)]),
                    Color(0.75, 0.40, 0.18))
        _:
            if ICON_PATHS.has(id):
                _draw_texture_fit(icon_texture(str(ICON_PATHS[id])), a)


func _draw_texture_fit(texture: Texture2D, a: Rect2) -> void:
    if texture == null:
        return
    var image_size: Vector2 = texture.get_size()
    if image_size.x > 0.0 and image_size.y > 0.0:
        var ratio: float = minf(a.size.x / image_size.x, a.size.y / image_size.y)
        var draw_size: Vector2 = image_size * ratio
        draw_texture_rect(texture, Rect2(a.get_center() - draw_size * 0.5, draw_size), false)
