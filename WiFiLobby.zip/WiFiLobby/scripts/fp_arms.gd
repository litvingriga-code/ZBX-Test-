extends RefCounted
## Руки от первого лица (этап 53): перчатки и рукава держат оружие в «вьюмодели».
## Руки — дети оружия, поэтому двигаются вместе с ним: подъём к глазу, отдача, бег.
## Хваты берутся из Weapons.GRIPS (r — основная рука, l — вторая; нет l — одна рука).
## Каждая рука: ладонь + пальцы + большой палец на хвате и рукав, уходящий назад и вниз
## за край экрана.

const Kit = preload("res://scripts/model_kit.gd")
const GLOVE := Color(0.11, 0.11, 0.12)
const GLOVE_DARK := Color(0.06, 0.06, 0.07)
const STRAP := Color(0.05, 0.05, 0.06)


static func build(parent: Node3D, grips: Dictionary, sleeve: Color) -> Node3D:
    var root := Kit.group(parent, Vector3.ZERO, "FirstPersonArms")
    if grips.has("r"):
        _arm(root, grips["r"], Vector3(0.40, -0.52, 0.76), sleeve, false)
    if grips.has("l"):
        _arm(root, grips["l"], Vector3(-0.58, -0.40, 0.70), sleeve, true)
    return root


## hand — точка хвата в координатах оружия, dir — куда от кисти уходит рука (к локтю).
static func _arm(root: Node3D, hand: Vector3, dir: Vector3, sleeve: Color, left: bool) -> void:
    var node := Node3D.new()
    node.name = "ArmL" if left else "ArmR"
    root.add_child(node)
    # локальная ось -Z руки смотрит от локтя к кисти, рукав тянется в +Z
    node.transform = Transform3D(Basis.looking_at(-dir.normalized(), Vector3.UP), hand)
    var side := 1.0 if left else -1.0
    var k = Kit.new()
    k.box(Vector3(0.088, 0.062, 0.105), Vector3(0, 0, -0.012), GLOVE, Vector3.ZERO, 0.0, 0.85)
    k.box(Vector3(0.092, 0.02, 0.045), Vector3(0, 0.03, -0.04), GLOVE_DARK, Vector3.ZERO, 0.0, 0.8)
    k.box(Vector3(0.086, 0.042, 0.052), Vector3(0, -0.012, -0.078), GLOVE, Vector3.ZERO, 0.0, 0.85)
    k.box(Vector3(0.026, 0.032, 0.075), Vector3(side * 0.052, 0.018, -0.034), GLOVE, Vector3(0, side * 12.0, 0), 0.0, 0.85)
    k.cyl_z(0.052, 0.052, 0.04, Vector3(0, 0, 0.088), STRAP, 12, 0.0, 0.8)
    k.cyl_z(0.045, 0.057, 0.62, Vector3(0, 0, 0.42), sleeve, 12, 0.0, 0.9)
    k.commit(node)
