extends Node
## Stage124: голосовой чат (микрофон слышен всем игрокам сеанса).
##
## Схема: клиент -> Host (unreliable RPC) -> Host пересылает всем остальным, кто слушает.
## Host сам ничего не микширует: каждый приём играет в своём AudioStreamPlayer
## (по одному на говорящего), поэтому голоса нескольких игроков складываются естественно.
## Звук глобальный (не позиционный): слышно всех в бою одинаково.
##
## Формат пакета: моно, 16 кГц, signed 16 bit, 20 мс = 320 сэмплов = 640 байт.
##
## Управление (из меню паузы -> Настройки):
##   VoiceChat.set_mic(true/false)       — включить/выключить свой микрофон
##   VoiceChat.set_listening(true/false) — слышать / не слышать микрофоны других

signal mic_changed(enabled: bool)
signal listen_changed(enabled: bool)
signal mic_permission_denied
signal voice_activity(peer_id: int)   # кто-то говорит прямо сейчас (для индикатора в бою)

const CAPTURE_BUS := "VoiceCapture"
const VOICE_FADE_START := 90.0
const VOICE_MAX_DISTANCE := 110.0
const VOICE_RATE := 16000
const CHUNK_SAMPLES := 320            # 20 мс
const MAX_PACKET_BYTES := 4096        # защита Host-а от мусорных пакетов
const GATE_PEAK := 0.012              # тише этого порога — тишина (экономит трафик, режет шум)
const GATE_HANG_SEC := 0.35           # после речи шлём ещё 0.35 с, чтобы не обрезать концы слов
const PLAYBACK_BUFFER_SEC := 0.5      # размер буфера AudioStreamGenerator
const MAX_LATENCY_SEC := 0.35         # если накопилось больше — отбрасываем пакеты
const PREFILL_FRAMES := 640           # 40 мс тишины перед началом реплики (антидрожание)

var mic_enabled: bool = false
var listen_enabled: bool = true

var _bus_idx: int = -1
var _capture: AudioEffectCapture
var _mic_player: AudioStreamPlayer
var _pending := PackedFloat32Array()  # уже сжатый до 16 кГц моно звук, ждёт отправки
var _acc: float = 0.0
var _acc_n: int = 0
var _phase: float = 0.0
var _hang_left: float = 0.0
var _speakers: Dictionary = {}        # peer_id -> {"player": AudioStreamPlayer, "pb": AudioStreamGeneratorPlayback}
var _listeners: Dictionary = {}       # (только Host) peer_id -> слышит ли он других
var _listen_resend: float = 0.0
var _permission_wait: bool = false


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS   # голос не должен замолкать от паузы дерева
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    get_tree().on_request_permissions_result.connect(_on_permission_result)
    if Net.has_signal("role_changed"):
        Net.role_changed.connect(_on_role_changed)


# ----------------------------------------------------------------------
#  Публичный интерфейс
# ----------------------------------------------------------------------

func set_mic(enabled: bool) -> void:
    if enabled == mic_enabled:
        return
    if not enabled:
        _stop_mic()
        return
    if not _has_mic_permission():
        if not _permission_wait:
            _permission_wait = true
            OS.request_permission("RECORD_AUDIO")
        return
    _start_mic()


func toggle_mic() -> void:
    set_mic(not mic_enabled)


func set_listening(enabled: bool) -> void:
    if enabled == listen_enabled:
        return
    listen_enabled = enabled
    if not enabled:
        _free_speakers()
    _tell_host_listening()
    listen_changed.emit(enabled)


# ----------------------------------------------------------------------
#  Микрофон
# ----------------------------------------------------------------------

func _has_mic_permission() -> bool:
    if OS.get_name() != "Android":
        return true
    for permission in OS.get_granted_permissions():
        if str(permission).ends_with("RECORD_AUDIO"):
            return true
    return false


func _on_permission_result(permission: String, granted: bool) -> void:
    if not permission.ends_with("RECORD_AUDIO"):
        return
    _permission_wait = false
    if granted:
        if not mic_enabled:
            _start_mic()
    else:
        mic_permission_denied.emit()


func _ensure_capture() -> void:
    if _bus_idx != -1:
        return
    # Отдельная заглушённая шина: микрофон пишется в Capture, но в динамики не идёт
    # (иначе игрок слышал бы сам себя с задержкой).
    AudioServer.add_bus()
    _bus_idx = AudioServer.bus_count - 1
    AudioServer.set_bus_name(_bus_idx, CAPTURE_BUS)
    AudioServer.set_bus_mute(_bus_idx, true)
    _capture = AudioEffectCapture.new()
    _capture.buffer_length = 0.25
    AudioServer.add_bus_effect(_bus_idx, _capture)
    _mic_player = AudioStreamPlayer.new()
    _mic_player.stream = AudioStreamMicrophone.new()
    _mic_player.bus = CAPTURE_BUS
    add_child(_mic_player)


func _start_mic() -> void:
    _ensure_capture()
    _pending.clear()
    _acc = 0.0
    _acc_n = 0
    _phase = 0.0
    _hang_left = 0.0
    _capture.clear_buffer()
    _mic_player.play()
    mic_enabled = true
    _tell_host_listening()
    mic_changed.emit(true)


func _stop_mic() -> void:
    mic_enabled = false
    if _mic_player != null:
        _mic_player.stop()
    if _capture != null:
        _capture.clear_buffer()
    _pending.clear()
    mic_changed.emit(false)


func _process(delta: float) -> void:
    _listen_resend += delta
    if _listen_resend >= 2.0:
        _listen_resend = 0.0
        _tell_host_listening()   # страховка: Host мог не получить первое сообщение
    _update_spatial_voice()
    if not mic_enabled or _capture == null:
        return
    var available := _capture.get_frames_available()
    if available <= 0:
        return
    var frames := _capture.get_buffer(available)
    if not _can_send():
        return   # соло или нет соединения — просто сливаем буфер
    _downsample(frames)
    while _pending.size() >= CHUNK_SAMPLES:
        var chunk := _pending.slice(0, CHUNK_SAMPLES)
        _pending = _pending.slice(CHUNK_SAMPLES)
        _send_chunk(chunk)


## Простое усреднение (box-фильтр) из частоты микшера в 16 кГц и стерео -> моно.
func _downsample(frames: PackedVector2Array) -> void:
    var step := AudioServer.get_mix_rate() / float(VOICE_RATE)
    for frame in frames:
        _acc += (frame.x + frame.y) * 0.5
        _acc_n += 1
        _phase += 1.0
        if _phase >= step:
            _phase -= step
            _pending.append(_acc / float(_acc_n))
            _acc = 0.0
            _acc_n = 0


func _send_chunk(chunk: PackedFloat32Array) -> void:
    var peak := 0.0
    for sample in chunk:
        peak = maxf(peak, absf(sample))
    var chunk_sec := float(CHUNK_SAMPLES) / float(VOICE_RATE)
    if peak >= GATE_PEAK:
        _hang_left = GATE_HANG_SEC
    elif _hang_left > 0.0:
        _hang_left -= chunk_sec
    else:
        return   # тишина — ничего не отправляем
    var bytes := PackedByteArray()
    bytes.resize(chunk.size() * 2)
    for i in chunk.size():
        bytes.encode_s16(i * 2, int(clampf(chunk[i], -1.0, 1.0) * 32767.0))
    voice_activity.emit(Net.my_id())
    if Net.role == "client":
        _voice_up.rpc_id(1, bytes)
    else:
        _relay(1, bytes)


func _can_send() -> bool:
    if Net.role != "host" and Net.role != "client":
        return false
    var peer := multiplayer.multiplayer_peer
    return peer != null and peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED


# ----------------------------------------------------------------------
#  Сеть
# ----------------------------------------------------------------------

## Клиент -> Host. Идентификатор говорящего берём из соединения, а не из пакета (нельзя подделать).
@rpc("any_peer", "call_remote", "unreliable")
func _voice_up(pcm: PackedByteArray) -> void:
    if Net.role != "host":
        return
    var sender := multiplayer.get_remote_sender_id()
    if not Net.roster.has(sender):
        return
    if pcm.is_empty() or pcm.size() > MAX_PACKET_BYTES or pcm.size() % 2 != 0:
        return
    _relay(sender, pcm)


## Host -> все остальные.
@rpc("authority", "call_remote", "unreliable")
func _voice_down(speaker: int, pcm: PackedByteArray) -> void:
    if pcm.is_empty() or pcm.size() > MAX_PACKET_BYTES or pcm.size() % 2 != 0:
        return
    _play(speaker, pcm)


## Клиент сообщает Host-у, нужно ли ему слать чужой голос (экономит трафик).
@rpc("any_peer", "call_remote", "reliable")
func _voice_listen(enabled: bool) -> void:
    if Net.role != "host":
        return
    _listeners[multiplayer.get_remote_sender_id()] = enabled


func _relay(speaker: int, pcm: PackedByteArray) -> void:
    for peer in multiplayer.get_peers():
        if not _in_voice_range(speaker, peer):
            continue
        if peer == speaker:
            continue
        if bool(_listeners.get(peer, true)):
            _voice_down.rpc_id(peer, speaker, pcm)
    if speaker != 1 and _in_voice_range(speaker, 1):
        _play(speaker, pcm)   # сам Host тоже слушает (если не отключил)


func _tell_host_listening() -> void:
    if Net.role == "client" and _can_send():
        _voice_listen.rpc_id(1, listen_enabled)


# ----------------------------------------------------------------------
#  Воспроизведение
# ----------------------------------------------------------------------



# Host фильтрует сетевые пакеты по расстоянию; клиент дополнительно
# рассчитывает громкость по синхронизированным координатам игроков.
func _in_voice_range(a: int, b: int) -> bool:
    if not Net.battle_positions.has(a) or not Net.battle_positions.has(b):
        return false
    var pa: Vector3 = Net.battle_positions[a]
    var pb: Vector3 = Net.battle_positions[b]
    return pa.distance_to(pb) < VOICE_MAX_DISTANCE


func is_peer_audible(peer_id: int) -> bool:
    return listen_enabled and _voice_gain(peer_id, Net.my_id()) > 0.0


func _voice_gain(a: int, b: int) -> float:
    if not Net.battle_positions.has(a) or not Net.battle_positions.has(b):
        return 0.0
    var pa: Vector3 = Net.battle_positions[a]
    var pb: Vector3 = Net.battle_positions[b]
    var distance := pa.distance_to(pb)
    if distance >= VOICE_MAX_DISTANCE:
        return 0.0
    if distance <= VOICE_FADE_START:
        return clampf(1.0 / (1.0 + distance / 22.0), 0.08, 1.0)
    var edge := (VOICE_MAX_DISTANCE - distance) / (VOICE_MAX_DISTANCE - VOICE_FADE_START)
    return 0.08 * edge * edge


func _update_spatial_voice() -> void:
    for peer_id in _speakers.keys():
        var entry: Dictionary = _speakers[peer_id]
        var player: AudioStreamPlayer = entry["player"]
        if is_instance_valid(player):
            var gain := _voice_gain(int(peer_id), Net.my_id())
            player.volume_linear = gain


func _make_echo_bus(peer_id: int) -> String:
    var bus_name := "VoiceEcho_%d" % peer_id
    var index := AudioServer.get_bus_index(bus_name)
    if index < 0:
        AudioServer.add_bus()
        index = AudioServer.bus_count - 1
        AudioServer.set_bus_name(index, bus_name)
        AudioServer.set_bus_send(index, "Master")
        var delay := AudioEffectDelay.new()
        delay.dry = 1.0
        delay.tap1_active = true
        delay.tap1_delay_ms = 170.0
        delay.tap1_level_db = -19.0
        delay.tap2_active = false
        delay.feedback_active = false
        AudioServer.add_bus_effect(index, delay)
    return bus_name

func _speaker_for(peer_id: int) -> Dictionary:
    if _speakers.has(peer_id) and is_instance_valid(_speakers[peer_id]["player"]):
        return _speakers[peer_id]
    var generator := AudioStreamGenerator.new()
    generator.mix_rate = VOICE_RATE
    generator.buffer_length = PLAYBACK_BUFFER_SEC
    var player := AudioStreamPlayer.new()
    player.stream = generator
    player.bus = _make_echo_bus(peer_id)
    add_child(player)
    player.play()
    var entry := {"player": player, "pb": player.get_stream_playback()}
    _speakers[peer_id] = entry
    return entry


func _play(peer_id: int, pcm: PackedByteArray) -> void:
    if not listen_enabled or peer_id == Net.my_id():
        return
    if _voice_gain(peer_id, Net.my_id()) <= 0.0:
        return
    voice_activity.emit(peer_id)
    var entry := _speaker_for(peer_id)
    var pb: AudioStreamGeneratorPlayback = entry["pb"]
    if pb == null:
        return
    var capacity := int(PLAYBACK_BUFFER_SEC * VOICE_RATE)
    var buffered := capacity - pb.get_frames_available()
    if buffered > int(MAX_LATENCY_SEC * VOICE_RATE):
        return   # задержка накопилась — пропускаем пакет, догоняем реальное время
    var count := pcm.size() / 2
    var frames := PackedVector2Array()
    if buffered <= 0:
        frames.resize(PREFILL_FRAMES)   # нули: небольшой запас против «заикания»
    var start := frames.size()
    frames.resize(start + count)
    for i in count:
        var value := float(pcm.decode_s16(i * 2)) / 32768.0
        frames[start + i] = Vector2(value, value)
    if pb.can_push_buffer(frames.size()):
        pb.push_buffer(frames)


func _free_speakers() -> void:
    for entry in _speakers.values():
        if is_instance_valid(entry["player"]):
            entry["player"].queue_free()
    _speakers.clear()


func _on_peer_disconnected(peer_id: int) -> void:
    _listeners.erase(peer_id)
    if _speakers.has(peer_id):
        if is_instance_valid(_speakers[peer_id]["player"]):
            _speakers[peer_id]["player"].queue_free()
        _speakers.erase(peer_id)


func _on_role_changed() -> void:
    _listeners.clear()
    _free_speakers()
    if Net.role == "client":
        _tell_host_listening()
