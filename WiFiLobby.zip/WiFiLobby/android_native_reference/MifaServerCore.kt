package org.mifa.server

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/** Standalone UDP/JSON proof of concept. NOT wire-compatible with Godot ENet/RPC. */
class MifaServerCore(private val context: Context, private val onCount: (Int) -> Unit) {
    private val running = AtomicBoolean(false)
    private val sessions = ConcurrentHashMap<String, Long>()
    private val players = ConcurrentHashMap<String, JSONObject>()
    private val world = JSONObject()
    private val saveFile = File(context.filesDir, "mifa_server/world_v1.json")
    private var socket: DatagramSocket? = null
    private var worker: Thread? = null
    private var lastSave = 0L

    @Synchronized fun start() {
        if (running.get()) return
        load()
        running.set(true)
        worker = Thread({ loop() }, "MifaNativeServer").apply { start() }
    }

    private fun loop() {
        try {
            DatagramSocket(7778).use { udp ->
                socket = udp
                udp.soTimeout = 200
                val buf = ByteArray(8192)
                lastSave = System.currentTimeMillis()
                while (running.get()) {
                    try {
                        val packet = DatagramPacket(buf, buf.size)
                        udp.receive(packet)
                        val request = JSONObject(String(packet.data, packet.offset, packet.length, Charsets.UTF_8))
                        val response = handle(request, "${packet.address.hostAddress}:${packet.port}")
                        val bytes = response.toString().toByteArray(Charsets.UTF_8)
                        udp.send(DatagramPacket(bytes, bytes.size, packet.address, packet.port))
                    } catch (_: SocketTimeoutException) {
                    } catch (_: org.json.JSONException) {
                    } catch (_: java.io.IOException) {
                        if (!running.get()) break
                    }
                    val now = System.currentTimeMillis()
                    sessions.entries.removeIf { now - it.value > 30000L }
                    onCount(sessions.size)
                    if (now - lastSave >= 60000L) {
                        save()
                        lastSave = now
                    }
                }
            }
        } catch (_: java.net.BindException) {
            running.set(false)
        } finally {
            socket = null
            save()
            onCount(0)
        }
    }

    @Synchronized private fun handle(req: JSONObject, endpoint: String): JSONObject {
        val action = req.optString("action")
        if (action == "register") {
            val id = UUID.randomUUID().toString()
            val token = UUID.randomUUID().toString() + UUID.randomUUID().toString()
            players[id] = JSONObject().put("id", id).put("token", token)
                .put("nickname", req.optString("nickname").take(24))
                .put("hp", 100).put("armor", 0)
                .put("position", JSONArray().put(0).put(0).put(0))
                .put("inventory", JSONObject())
            save()
            return JSONObject().put("ok", true).put("player_id", id).put("token", token)
        }
        val id = req.optString("player_id")
        val p = players[id]
        if (p == null || p.optString("token") != req.optString("token"))
            return JSONObject().put("ok", false).put("error", "unauthorized")
        sessions[id] = System.currentTimeMillis()
        if (action == "heartbeat") return JSONObject().put("ok", true).put("online", sessions.size)
        if (action == "get_state") return JSONObject().put("ok", true)
            .put("player", publicPlayer(p)).put("world", JSONObject(world.toString()))
        // Movement, damage, inventory and shooting must be implemented as validated server rules.
        return JSONObject().put("ok", false).put("error", "unsupported_action")
    }

    private fun publicPlayer(p: JSONObject): JSONObject = JSONObject(p.toString()).apply { remove("token") }

    @Synchronized fun save() {
        val snapshot = JSONObject().put("schema", 1).put("saved_at", System.currentTimeMillis())
            .put("players", JSONObject().apply { players.forEach { (id, p) -> put(id, p) } })
            .put("world", world)
        saveFile.parentFile?.mkdirs()
        val tmp = File(saveFile.parentFile, saveFile.name + ".tmp")
        tmp.writeText(snapshot.toString())
        if (!tmp.renameTo(saveFile)) {
            tmp.copyTo(saveFile, overwrite = true)
            tmp.delete()
        }
    }

    @Synchronized private fun load() {
        if (!saveFile.exists()) return
        try {
            val data = JSONObject(saveFile.readText())
            if (data.optInt("schema") != 1) return
            val savedPlayers = data.optJSONObject("players") ?: JSONObject()
            players.clear()
            val keys = savedPlayers.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                players[id] = savedPlayers.getJSONObject(id)
            }
            val savedWorld = data.optJSONObject("world") ?: JSONObject()
            val keysWorld = savedWorld.keys()
            while (keysWorld.hasNext()) {
                val key = keysWorld.next()
                world.put(key, savedWorld.get(key))
            }
        } catch (_: Exception) { /* preserve corrupt file for recovery */ }
    }

    @Synchronized fun stop() {
        running.set(false)
        socket?.close()
        worker?.join(3000)
        save()
    }
}
