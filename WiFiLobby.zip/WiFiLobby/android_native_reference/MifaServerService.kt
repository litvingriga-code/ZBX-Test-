package org.mifa.server

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Requires AndroidX Core and a correctly configured foreground-service manifest. */
class MifaServerService : Service() {
    companion object {
        const val STOP = "org.mifa.server.STOP"
        const val RESTART = "org.mifa.server.RESTART"
        const val CHANNEL = "mifa_server"
        const val ID = 7777
    }
    private var core: MifaServerCore? = null
    private var count = 0
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "MIFAOGAMES Server", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) {
            core?.stop(); core = null
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            return START_NOT_STICKY
        }
        // Start foreground promptly before opening sockets / restoring state.
        startForeground(ID, notification())
        if (intent?.action == RESTART) {
            core?.stop(); core = null; count = 0
        }
        if (core == null) core = MifaServerCore(this) { newCount ->
            if (newCount != count) {
                count = newCount
                getSystemService(NotificationManager::class.java).notify(ID, notification())
            }
        }.also { it.start() }
        return START_STICKY
    }
    private fun notification(): Notification {
        fun pending(action: String, request: Int): PendingIntent = PendingIntent.getService(
            this, request, Intent(this, MifaServerService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("MIFAOGAMES SERVER")
            .setContentText("Игроков онлайн: $count / 8 · UDP 7778")
            .setOngoing(true)
            .addAction(0, "Остановить", pending(STOP, 1))
            .addAction(0, "Перезагрузить", pending(RESTART, 2))
            .build()
    }
    override fun onDestroy() {
        core?.stop(); core = null
        super.onDestroy()
    }
}
