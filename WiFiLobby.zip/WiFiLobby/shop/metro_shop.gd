extends PanelContainer
## Магазин по схеме пользователя: 15 предпросмотр, 20 полоса прокрутки, каталог справа, 1–4 категории,
## 35 обычная покупка, 25 покупка с количеством 1–999.
signal purchase_message(message: String)
const UiGray = preload("res://scripts/ui_gray.gd")
const BG := Color(0.10, 0.10, 0.11, 0.98)
const PANEL := Color(0.16, 0.16, 0.17)
const GOLD := Color(0.86, 0.86, 0.89)   # акцент теперь светло-серый
const TEXT := Color(0.93, 0.93, 0.94)
var selected_item: String = "ak47"
var current_filter: String = "Все"
var catalog: VBoxContainer
var items_scroll: ScrollContainer
var catalog_scrollbar: VScrollBar
var preview_title: Label
var preview_info: Label
var preview_art: Label
var balance_label: Label
var purchase_button: Button
var quantity_popup: PanelContainer
var quantity_slider: HSlider
var quantity_label: Label
var quantity_total: Label
var category_buttons: Dictionary = {}
const Weapons = preload("res://scripts/weapons.gd")
const ITEM_IMAGES := {
    "ak47": "res://assets/hud/weapons/rifle.png",
    "m4a1": "res://assets/hud/weapons/m4a1.png",
    "shotgun": "res://assets/hud/weapons/shotgun.png",
    "svd": "res://assets/hud/weapons/svd.png",
    "pm": "res://assets/hud/weapons/pm.png",
    "revolver": "res://assets/hud/weapons/revolver.png",
    "knife": "res://assets/hud/weapons/knife.png",
    "machete": "res://assets/hud/weapons/machete.png",
    "ammo_762": "res://assets/shop/ammo_762.png",
    "ammo_556": "res://assets/shop/ammo_556.png",
    "ammo_9mm": "res://assets/shop/ammo_9mm.png",
    "ammo_12": "res://assets/shop/ammo_12.png",
    "ammo_44": "res://assets/shop/ammo_44.png",
    "medkit": "res://assets/shop/medkit.png",
    "adrenaline": "res://assets/shop/adrenaline.png",
    "collimator": "res://assets/shop/collimator.png"
}
var preview_texture: TextureRect
var item_cards: Dictionary = {}

func _item_image(item_id: String) -> Texture2D:
    var path: String = str(ITEM_IMAGES.get(item_id, ""))
    if path != "" and ResourceLoader.exists(path):
        return load(path) as Texture2D
    return null

func _catalog_card(item_id: String) -> Button:
    var card := Button.new()
    card.name = "ShopItem_" + item_id
    card.text = ""
    card.custom_minimum_size.y = 156
    card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    card.add_theme_stylebox_override("normal", _style(Color(0.13, 0.13, 0.14)))
    card.add_theme_stylebox_override("hover", _style(Color(0.20, 0.20, 0.22), GOLD))
    card.add_theme_stylebox_override("pressed", _style(Color(0.26, 0.26, 0.28), GOLD))
    card.pressed.connect(_select_item.bind(item_id))
    var contents := VBoxContainer.new()
    contents.mouse_filter = Control.MOUSE_FILTER_IGNORE
    contents.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    contents.offset_left = 7
    contents.offset_top = 5
    contents.offset_right = -7
    contents.offset_bottom = -5
    contents.add_theme_constant_override("separation", 2)
    card.add_child(contents)
    var picture := TextureRect.new()
    picture.mouse_filter = Control.MOUSE_FILTER_IGNORE
    picture.texture = _item_image(item_id)
    picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    picture.custom_minimum_size.y = 95
    picture.size_flags_vertical = Control.SIZE_EXPAND_FILL
    contents.add_child(picture)
    var title := _label(str(GameState.ITEMS[item_id]["name"]), 15)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.mouse_filter = Control.MOUSE_FILTER_IGNORE
    contents.add_child(title)
    var cost := _label("%s $" % GameState.format_money(int(GameState.SHOP[item_id]["price"])), 14, GOLD)
    cost.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    cost.mouse_filter = Control.MOUSE_FILTER_IGNORE
    contents.add_child(cost)
    return card


func _style(color: Color, border: Color = Color.TRANSPARENT) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = color
    sb.border_color = border
    sb.set_border_width_all(1 if border.a > 0.0 else 0)
    sb.set_corner_radius_all(5)
    sb.content_margin_left = 6
    sb.content_margin_right = 6
    sb.content_margin_top = 6
    sb.content_margin_bottom = 6
    return sb

func _label(value: String, size_px: int = 17, color: Color = TEXT) -> Label:
    var label := Label.new()
    label.text = value
    label.add_theme_font_size_override("font_size", size_px)
    label.add_theme_color_override("font_color", color)
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    return label

func _button(value: String) -> Button:
    var button := Button.new()
    button.text = value
    button.add_theme_stylebox_override("normal", _style(PANEL))
    button.add_theme_stylebox_override("hover", _style(Color(0.25, 0.25, 0.27), GOLD))
    button.add_theme_stylebox_override("pressed", _style(Color(0.32, 0.32, 0.34), GOLD))
    button.add_theme_color_override("font_color", TEXT)
    button.add_theme_font_size_override("font_size", 16)
    return button

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    clip_contents = true
    add_theme_stylebox_override("panel", _style(BG, GOLD))
    # Все области в процентах, поэтому в landscape они не выходят за экран.
    var frame := Control.new()
    frame.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(frame)
    var top := HBoxContainer.new()
    _place(top, 0.02, 0.02, 0.98, 0.105)
    frame.add_child(top)
    var heading := _label("METRO / МАГАЗИН", 21, GOLD)
    heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(heading)
    balance_label = _label("", 15, GOLD)
    top.add_child(balance_label)
    # Независимая кнопка закрытия: не зависит от ширины заголовка и баланса.
    # Создаётся последней в _ready(), чтобы быть поверх остальных панелей.

    # Слева 15: изображение и сведения, снизу 35 и 25.
    var preview := PanelContainer.new()
    _place(preview, 0.02, 0.13, 0.415, 0.98)
    preview.add_theme_stylebox_override("panel", _style(PANEL))
    frame.add_child(preview)
    var preview_frame := Control.new()
    preview.add_child(preview_frame)
    var preview_scroll := ScrollContainer.new()
    _place(preview_scroll, 0.03, 0.025, 0.97, 0.77)
    preview_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    preview_frame.add_child(preview_scroll)
    var preview_stack := VBoxContainer.new()
    preview_stack.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    preview_stack.add_theme_constant_override("separation", 10)
    preview_scroll.add_child(preview_stack)
    preview_texture = TextureRect.new()
    preview_texture.custom_minimum_size.y = 150
    preview_texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    preview_texture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    preview_stack.add_child(preview_texture)
    preview_art = _label("", 36, GOLD)
    preview_art.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    preview_art.custom_minimum_size.y = 105
    preview_stack.add_child(preview_art)
    preview_title = _label("", 23, GOLD)
    preview_stack.add_child(preview_title)
    preview_info = _label("", 16)
    preview_stack.add_child(preview_info)
    var buy := _button("КУПИТЬ")
    _place(buy, 0.03, 0.80, 0.49, 0.965)
    buy.add_theme_stylebox_override("normal", _style(Color(0.36, 0.36, 0.39), GOLD))
    buy.pressed.connect(_buy_one)
    preview_frame.add_child(buy)
    purchase_button = buy
    var many := _button("КОЛИЧЕСТВО")
    _place(many, 0.51, 0.80, 0.97, 0.965)
    many.pressed.connect(_open_quantity)
    preview_frame.add_child(many)

    # Область 20 — отдельная вертикальная полоса прокрутки.
    var scroll_panel := PanelContainer.new()
    _place(scroll_panel, 0.425, 0.13, 0.485, 0.98)
    scroll_panel.add_theme_stylebox_override("panel", _style(PANEL))
    frame.add_child(scroll_panel)
    catalog_scrollbar = VScrollBar.new()
    catalog_scrollbar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    catalog_scrollbar.size_flags_vertical = Control.SIZE_EXPAND_FILL
    catalog_scrollbar.value_changed.connect(_on_catalog_scrollbar_changed)
    scroll_panel.add_child(catalog_scrollbar)

    # Список товаров находится СПРАВА от области 20.
    var items_panel := PanelContainer.new()
    _place(items_panel, 0.495, 0.13, 0.89, 0.98)
    items_panel.add_theme_stylebox_override("panel", _style(PANEL))
    frame.add_child(items_panel)
    items_scroll = ScrollContainer.new()
    items_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    items_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    items_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    items_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
    items_scroll.get_v_scroll_bar().changed.connect(_sync_catalog_scrollbar)
    items_scroll.get_v_scroll_bar().value_changed.connect(_on_catalog_scrolled)
    items_panel.add_child(items_scroll)
    catalog = VBoxContainer.new()
    catalog.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    catalog.add_theme_constant_override("separation", 7)
    items_scroll.add_child(catalog)

    # Справа 1–4: категории.
    var filters := VBoxContainer.new()
    _place(filters, 0.90, 0.13, 0.985, 0.98)
    filters.add_theme_constant_override("separation", 7)
    frame.add_child(filters)
    for category in ["Все", "Оружие", "Обвес", "Патроны", "Аптечки"]:
        var b := _button(category)
        b.size_flags_vertical = Control.SIZE_EXPAND_FILL
        b.add_theme_font_size_override("font_size", 12)
        b.pressed.connect(_set_filter.bind(category))
        filters.add_child(b)
        category_buttons[category] = b

    # Окно количества появляется поверх магазина, не растягивая разметку.
    quantity_popup = PanelContainer.new()
    _place(quantity_popup, 0.23, 0.27, 0.77, 0.73)
    quantity_popup.add_theme_stylebox_override("panel", _style(Color(0.11, 0.11, 0.12), GOLD))
    quantity_popup.visible = false
    frame.add_child(quantity_popup)
    var popup_stack := VBoxContainer.new()
    popup_stack.add_theme_constant_override("separation", 10)
    quantity_popup.add_child(popup_stack)
    quantity_label = _label("Количество: 1", 19, GOLD)
    popup_stack.add_child(quantity_label)
    quantity_slider = HSlider.new()
    quantity_slider.min_value = 1
    quantity_slider.max_value = 999
    quantity_slider.step = 1
    quantity_slider.value = 1
    quantity_slider.custom_minimum_size.y = 45
    quantity_slider.value_changed.connect(_quantity_changed)
    popup_stack.add_child(quantity_slider)
    quantity_total = _label("", 15)
    popup_stack.add_child(quantity_total)
    var popup_actions := HBoxContainer.new()
    popup_stack.add_child(popup_actions)
    var cancel := _button("ОТМЕНА")
    cancel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    cancel.pressed.connect(func() -> void: quantity_popup.hide())
    popup_actions.add_child(cancel)
    var confirm := _button("КУПИТЬ")
    confirm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    confirm.pressed.connect(_buy_many)
    popup_actions.add_child(confirm)
    GameState.changed.connect(_refresh)
    _set_filter("Все")

    # Верхний правый угол магазина. Кнопка всегда внутри экрана.
    var close_button := _button("×")
    close_button.name = "CloseShopButton"
    close_button.tooltip_text = "Выйти из магазина"
    close_button.focus_mode = Control.FOCUS_NONE
    close_button.anchor_left = 1.0
    close_button.anchor_right = 1.0
    close_button.anchor_top = 0.0
    close_button.anchor_bottom = 0.0
    close_button.offset_left = -64.0
    close_button.offset_right = -8.0
    close_button.offset_top = 8.0
    close_button.offset_bottom = 62.0
    close_button.add_theme_font_size_override("font_size", 30)
    close_button.add_theme_stylebox_override("normal", _style(Color(0.26, 0.26, 0.28), GOLD))
    close_button.pressed.connect(_close_shop)
    frame.add_child(close_button)

func _close_shop() -> void:
    if quantity_popup != null:
        quantity_popup.hide()
    hide()


func _place(node: Control, left: float, top: float, right: float, bottom: float) -> void:
    node.anchor_left = left
    node.anchor_top = top
    node.anchor_right = right
    node.anchor_bottom = bottom
    node.offset_left = 0
    node.offset_top = 0
    node.offset_right = 0
    node.offset_bottom = 0

func _set_filter(category: String) -> void:
    current_filter = category
    for key in category_buttons:
        var button: Button = category_buttons[key]
        button.add_theme_color_override("font_color", GOLD if key == category else TEXT)
    item_cards.clear()
    for child in catalog.get_children():
        catalog.remove_child(child)
        child.queue_free()
    var ids: Array[String] = []
    for item_id in GameState.SHOP.keys():
        var kind := "Оружие" if Weapons.has(str(item_id)) else ("Аптечки" if item_id == "medkit" or item_id == "adrenaline" else ("Обвес" if item_id == "collimator" else "Патроны"))
        if category == "Все" or category == kind:
            ids.append(str(item_id))
    for item_id in ids:
        var card := _catalog_card(item_id)
        catalog.add_child(card)
        item_cards[item_id] = card
    if not ids.has(selected_item) and not ids.is_empty():
        selected_item = ids[0]
    _select_item(selected_item)
    call_deferred("_sync_catalog_scrollbar")

func _on_catalog_scrollbar_changed(value: float) -> void:
    if items_scroll != null:
        items_scroll.scroll_vertical = int(value)

func _on_catalog_scrolled(value: float) -> void:
    if catalog_scrollbar != null and not is_equal_approx(catalog_scrollbar.value, value):
        catalog_scrollbar.set_value_no_signal(value)

func _sync_catalog_scrollbar() -> void:
    if items_scroll == null or catalog_scrollbar == null:
        return
    var internal_bar: VScrollBar = items_scroll.get_v_scroll_bar()
    catalog_scrollbar.min_value = internal_bar.min_value
    catalog_scrollbar.max_value = internal_bar.max_value
    catalog_scrollbar.page = internal_bar.page
    catalog_scrollbar.step = 1.0
    catalog_scrollbar.set_value_no_signal(internal_bar.value)

func _select_item(item_id: String) -> void:
    if not GameState.SHOP.has(item_id):
        return
    selected_item = item_id
    var desc := {
        "ammo_762": "Патроны 7.62 мм\nПодходят для АК-47 и СВД\nВ одном лоте: 120 патронов",
        "ammo_556": "Патроны 5.56 мм\nПодходят для M4A1\nВ одном лоте: 120 патронов",
        "ammo_9mm": "Патроны 9 мм\nПодходят для пистолета ПМ\nВ одном лоте: 120 патронов",
        "ammo_12": "Патроны 12 калибра (картечь)\nПодходят для дробовика МР-133\nВ одном лоте: 24 патрона",
        "ammo_44": "Патроны .44 Magnum\nПодходят для револьвера\nВ одном лоте: 36 патронов",
        "adrenaline": "Адреналин\n+20 HP или самостоятельное поднятие из нокдауна",
        "medkit": "Аптечка\nВосстанавливает до 50 HP\nМожно использовать при 100 HP",
        "collimator": "Коллиматорный прицел\nОбвес для АК-47 и M4A1: положите в ячейку «Обвес»,\nи он появится на автомате.\nПри прицеливании — красная точка."
    }
    if Weapons.has(item_id):
        desc[item_id] = _weapon_text(item_id)
    preview_texture.texture = _item_image(item_id)
    preview_art.text = "" if preview_texture.texture != null else str(GameState.ITEMS[item_id]["name"])
    for card_id in item_cards:
        var card: Button = item_cards[card_id]
        card.add_theme_stylebox_override("normal", _style(Color(0.22, 0.22, 0.24), GOLD) if card_id == item_id else _style(Color(0.13, 0.13, 0.14)))
    preview_title.text = str(GameState.ITEMS[item_id]["name"])
    preview_info.text = "%s\n\nЦена: %s $" % [str(desc.get(item_id, "")), GameState.format_money(int(GameState.SHOP[item_id]["price"]))]
    if quantity_popup.visible:
        quantity_popup.hide()
    _refresh()

func _refresh() -> void:
    if balance_label == null or purchase_button == null:
        return
    balance_label.text = "Баланс: %s $" % GameState.format_money(GameState.money)
    purchase_button.disabled = GameState.money < int(GameState.SHOP[selected_item]["price"])
    if quantity_slider != null:
        _quantity_changed(quantity_slider.value)

func _buy_one() -> void:
    purchase_message.emit(GameState.buy_item_quantity(selected_item, 1))
    _refresh()

func _open_quantity() -> void:
    quantity_slider.value = 1
    _quantity_changed(1)
    quantity_popup.show()
    quantity_popup.move_to_front()

func _quantity_changed(value: float) -> void:
    if quantity_label == null or quantity_total == null:
        return
    var count: int = int(value)
    quantity_label.text = "Количество: %d" % count
    var total: int = int(GameState.SHOP[selected_item]["price"]) * count
    quantity_total.text = "Итого: %s $" % GameState.format_money(total)

func _buy_many() -> void:
    var result: String = GameState.buy_item_quantity(selected_item, int(quantity_slider.value))
    purchase_message.emit(result)
    quantity_popup.hide()
    _refresh()


func _weapon_text(item_id: String) -> String:
    var def: Dictionary = Weapons.get_def(item_id)
    var lines := PackedStringArray([str(def.get("name", item_id))])
    if bool(def.get("melee", false)):
        lines.append("Тип: холодное оружие")
        lines.append("Урон: %d HP" % int(def["damage"]))
        lines.append("Дальность: %.1f м" % float(def["range"]))
        lines.append("Скорость удара: %.1f в секунду" % (1.0 / float(def["rate"])))
        return "\n".join(lines)
    var pellets: int = int(def.get("pellets", 1))
    if pellets > 1:
        lines.append("Урон: %d HP × %d дробин" % [int(def["damage"]), pellets])
    else:
        lines.append("Урон: %d HP" % int(def["damage"]))
    lines.append("Патроны: %s" % str(Weapons.AMMO_NAMES.get(str(def["ammo"]), "")))
    lines.append("Магазин: %d" % int(def["mag"]))
    lines.append("Темп: %s" % ("автоматический" if bool(def["auto"]) else "одиночный"))
    lines.append("Дальность: %d м" % int(float(def["range"])))
    if bool(def.get("scope", false)):
        lines.append("Оптический прицел")
    return "\n".join(lines)
