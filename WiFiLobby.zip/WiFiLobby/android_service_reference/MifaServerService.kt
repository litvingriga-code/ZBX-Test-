package org.mifa.server

import android.app.*
import android.content.*
import android.os.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicInteger

/** Reference Android component, NOT a drop-in Godot plugin or ENet server. */
class MifaServerService : Service() {
    companion object {
        const val CHANNEL = "mifa_server"
        const val ACTION_STOP = "org.mifa.server.STOP"
        const val ACTION_RESTART = "org.mifa.server.RESTART"
        const val NOTIFICATION_ID = 7777
    }
    private val players = AtomicInteger(0)
    private var running = false
    private val binder = LocalBinder()
    inner class LocalBinder : Binder() {
        fun service(): MifaServerService = this@MifaServerService
    }
    override fun onBind(intent: Intent?): IBinder = binder
    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "MIFAOGAMES Server", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopServerSafely(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            ACTION_RESTART -> { stopServerSafely(); startServer(); }
            else -> if (!running) startServer()
        }
        startForeground(NOTIFICATION_ID, notification())
        return START_STICKY
    }
    fun updatePlayerCount(value: Int) {
        players.set(value.coerceAtLeast(0))
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification())
    }
    private fun startServer() {
        // TODO: start independent authoritative simulation + compatible ENet protocol here.
        // This example intentionally does not claim to host Godot clients.
        running = true
    }
    private fun stopServerSafely() {
        // TODO: synchronously commit ALL player/world state and stop network worker.
        running = false
        players.set(0)
    }
    private fun notification(): Notification {
        fun actionIntent(action: String, code: Int): PendingIntent {
            val i = Intent(this, MifaServerService::class.java).setAction(action)
            return PendingIntent.getService(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("MIFAOGAMES SERVER")
            .setContentText("Игроков онлайн: ${players.get()} / 8")
            .setOngoing(true)
            .addAction(0, "Остановить", actionIntent(ACTION_STOP, 1))
            .addAction(0, "Перезагрузить", actionIntent(ACTION_RESTART, 2))
            .build()
    }
}
