MIFAOGAMES: Android Foreground Service reference source (НЕ ГОТОВЫЙ СЕРВЕР)

Содержит пример Kotlin службы с уведомлением и двумя action-кнопками.
Это НЕ скомпилированный AAR, НЕ готовый Android plugin и НЕ сервер ENet.
Для интеграции нужны Android Gradle project, AndroidX Core, корректные
foregroundServiceType/permissions для целевой Android версии и запуск службы
из пользовательского действия с соблюдением ограничений Android.

КРИТИЧЕСКОЕ ОГРАНИЧЕНИЕ:
Godot Net.gd использует ENet. Независимая Kotlin служба не может просто
принять Godot ENet клиентов через DatagramSocket. Нужен совместимый ENet
сервер и перенос authoritative simulation, inventory, physics, damage,
world-state, player identity, persistence из Godot в сервис (либо отдельный
headless Godot процесс при наличии поддерживаемой Android реализации).

В примере startServer() и stopServerSafely() являются TODO.
Значение игроков передается через updatePlayerCount; реальные сетевые
подключения в примере отсутствуют. Не используйте для production.

Для полного решения требуется:
1. Выделить протокол и симуляцию в независимый серверный процесс.
2. Авторитетная обработка действий и безопасная идентификация игроков.
3. Снимки мира/игроков с atomic write и миграциями схемы.
4. IPC с Godot клиентом и реальная ENet совместимость.
5. Manifest + Gradle plugin, foreground type and OS testing.
6. Тесты: свернуть, заблокировать экран, force-stop, reboot, client reconnect.

Android не гарантирует вечную работу foreground service, особенно при
force-stop, энергосбережении и ограничениях запуска фоновых служб.
