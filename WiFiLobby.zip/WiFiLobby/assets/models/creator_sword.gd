extends Node3D
# Original CSG sword reconstructed from the scene provided by the creator.
func mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    return m

func capsule() -> CapsuleMesh:
    var m := CapsuleMesh.new()
    m.radial_segments = 4
    m.rings = 1
    return m

func part(parent: Node3D, label: String, mesh: Mesh, material: Material, pos: Vector3, size: Vector3, subtract: bool = false) -> CSGMesh3D:
    var n := CSGMesh3D.new()
    n.name = label
    n.mesh = mesh
    n.material = material
    n.position = pos
    n.scale = size
    if subtract:
        n.operation = CSGShape3D.OPERATION_SUBTRACTION
    parent.add_child(n)
    return n

func _ready() -> void:
    var model := Node3D.new()
    model.name = "model"
    add_child(model)
    var grip := mat(Color(0.46145672, 0, 0, 1))
    var blade := mat(Color(5.3174357, 0.9839405, 0.58453995, 1))
    var cut_a := mat(Color(0.5836357, 0.09792257, 0, 1))
    var cut_b := mat(Color(0.63807267, 0.12746197, 0, 1))
    var cross_mat := mat(Color(0.40953135, 0, 0, 1))
    part(model, "mesh", capsule(), grip, Vector3(0, 0.06469935, 0), Vector3(0.33140293, 0.6111089, 0.22856143))
    var blade_node := part(model, "mesh2", capsule(), blade, Vector3(0, 1.4257835, 0), Vector3(0.36979184, 1.6028413, 0.19237943))
    part(blade_node, "mesh4", BoxMesh.new(), cut_a, Vector3(0, 0, -0.84220797), Vector3(1, 1.9989486, 1), true)
    part(blade_node, "mesh5", BoxMesh.new(), cut_b, Vector3(0, 0, 0.8602548), Vector3(1, 1.9989486, 1), true)
    var cross := part(model, "mesh3", capsule(), cross_mat, Vector3(0, 0.45202816, 0), Vector3(1.0428828, 0.16145654, 0.30014104))
    part(cross, "mesh5", BoxMesh.new(), cross_mat, Vector3(0, 0, -0.7835206), Vector3(1, 4.3388486, 1), true)
    part(cross, "mesh6", BoxMesh.new(), cross_mat, Vector3(0, 0, 0.783854), Vector3(1, 4.3388476, 1), true)
    var orb := part(self, "Void", SphereMesh.new(), mat(Color(1.8859891, 0.5828516, 0, 1)), Vector3(0, 3.286563, -0.0034438372), Vector3(0.25, 0.25, 0.25))
    part(orb, "Void2", TorusMesh.new(), mat(Color(18.058388, 18.058388, 18.058386, 1)), Vector3.ZERO, Vector3(1.0376518, 0.04896086, 1))
