extends RefCounted
## Persistent player identities, separate from transient ENet peer IDs.
## Server-issued bearer secrets must be kept private; this is a prototype, not an account service.
const FILE := "user://server_saves/identities.json"
var records: Dictionary = {}
var sessions: Dictionary = {}

func load_records() -> void:
    if not FileAccess.file_exists(FILE):
        return
    var value = JSON.parse_string(FileAccess.get_file_as_string(FILE))
    if value is Dictionary and int(value.get("schema", 0)) == 1:
        records = value.get("records", {})

func save_records() -> bool:
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://server_saves"))
    var temp := FILE + ".tmp"
    var f := FileAccess.open(temp, FileAccess.WRITE)
    if f == null:
        return false
    f.store_string(JSON.stringify({"schema": 1, "records": records}))
    f.flush()
    f.close()
    return DirAccess.rename_absolute(ProjectSettings.globalize_path(temp), ProjectSettings.globalize_path(FILE)) == OK

func register_player() -> Dictionary:
    var player_id := _random_hex(16)
    var secret := _random_hex(32)
    records[player_id] = {"secret": secret, "state": {"hp": 100, "armor": 0, "position": [0, 1, 0], "inventory": {}}}
    save_records()
    return {"player_id": player_id, "secret": secret}

func authenticate(peer_id: int, player_id: String, secret: String) -> bool:
    if peer_id <= 1 or not records.has(player_id):
        return false
    if str(records[player_id].get("secret", "")) != secret or secret.length() != 64:
        return false
    for connected in sessions.keys():
        if sessions[connected] == player_id:
            return false
    sessions[peer_id] = player_id
    return true

func uid_for_peer(peer_id: int) -> String:
    return str(sessions.get(peer_id, ""))

func store_state(peer_id: int, state: Dictionary) -> bool:
    var uid := uid_for_peer(peer_id)
    if uid.is_empty() or not records.has(uid):
        return false
    records[uid]["state"] = state.duplicate(true)
    return save_records()

func disconnect(peer_id: int) -> void:
    sessions.erase(peer_id)

func _random_hex(byte_count: int) -> String:
    var crypto := Crypto.new()
    return crypto.generate_random_bytes(byte_count).hex_encode()
