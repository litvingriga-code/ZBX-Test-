extends RefCounted
## Deterministic server-owned state; no scene/viewport dependencies.
const MAX_SPEED := 8.0
const MAX_HEALTH := 100
const MAX_ARMOR := 100
var players: Dictionary = {}
var elapsed := 0.0

func tick(delta: float) -> void:
    elapsed += delta
    for uid in players:
        var s: Dictionary = players[uid]
        var velocity: Vector3 = s.get("velocity", Vector3.ZERO)
        if velocity.length() > MAX_SPEED:
            velocity = velocity.normalized() * MAX_SPEED
        s["position"] = s.get("position", Vector3.ZERO) + velocity * delta
        players[uid] = s

func add_player(uid: String, stored: Dictionary) -> void:
    var p: Array = stored.get("position", [0, 1, 0])
    if p.size() != 3:
        p = [0, 1, 0]
    players[uid] = {"position": Vector3(float(p[0]), float(p[1]), float(p[2])), "velocity": Vector3.ZERO, "hp": clampi(int(stored.get("hp", 100)), 0, MAX_HEALTH), "armor": clampi(int(stored.get("armor", 0)), 0, MAX_ARMOR), "inventory": stored.get("inventory", {}).duplicate(true)}

func set_movement(uid: String, requested: Vector3) -> bool:
    if not players.has(uid) or not requested.is_finite():
        return false
    var state: Dictionary = players[uid]
    state["velocity"] = requested.limit_length(MAX_SPEED)
    players[uid] = state
    return true

func apply_damage(uid: String, amount: int) -> bool:
    if not players.has(uid) or amount <= 0 or amount > 1000:
        return false
    var state: Dictionary = players[uid]
    var absorbed: int = mini(int(state["armor"]), amount)
    state["armor"] = int(state["armor"]) - absorbed
    state["hp"] = maxi(0, int(state["hp"]) - (amount - absorbed))
    players[uid] = state
    return true

func add_item(uid: String, item_key: String, amount: int) -> bool:
    if not players.has(uid) or amount <= 0 or amount > 999 or not item_key.is_valid_identifier():
        return false
    var state: Dictionary = players[uid]
    var inv: Dictionary = state["inventory"]
    inv[item_key] = mini(99999, int(inv.get(item_key, 0)) + amount)
    return true

func consume_item(uid: String, item_key: String, amount: int) -> bool:
    if not players.has(uid) or amount <= 0:
        return false
    var inv: Dictionary = players[uid]["inventory"]
    if int(inv.get(item_key, 0)) < amount:
        return false
    inv[item_key] = int(inv[item_key]) - amount
    if inv[item_key] == 0:
        inv.erase(item_key)
    return true

func snapshot(uid: String) -> Dictionary:
    if not players.has(uid):
        return {}
    var s: Dictionary = players[uid]
    var pos: Vector3 = s["position"]
    return {"position": [pos.x, pos.y, pos.z], "hp": s["hp"], "armor": s["armor"], "inventory": s["inventory"].duplicate(true)}
