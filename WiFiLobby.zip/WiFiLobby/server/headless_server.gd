extends Node
## Headless dedicated host using the SAME Godot Net autoload/RPC definitions as the client.
## Start with: godot --headless --path . --scene res://server/headless_server.tscn
## This is a desktop/headless compatibility test, NOT an Android background service.

var _port: int = Net.GAME_PORT
var _save_timer: float = 0.0
var _simulation = preload("res://server/simulation_core.gd").new()
var _identities = preload("res://server/persistent_players.gd").new()
var _fixed_accumulator: float = 0.0

func _ready() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--port="):
            _port = int(arg.trim_prefix("--port="))
    if _port < 1024 or _port > 65535:
        push_error("Invalid UDP port")
        get_tree().quit(2)
        return
    _identities.load_records()
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    if not Net.start_online_host(_port):
        push_error("Could not start compatible ENet host")
        get_tree().quit(3)
        return
    print("MIFA headless ENet host listening UDP ", _port)
    print("RPC compatibility uses original Net autoload; server still has gameplay limitations")

func _process(delta: float) -> void:
    _fixed_accumulator = minf(_fixed_accumulator + delta, 0.25)
    while _fixed_accumulator >= 0.05:
        _simulation.tick(0.05)
        _fixed_accumulator -= 0.05
    _save_timer += delta
    if _save_timer >= 60.0:
        _save_timer = 0.0
        _save_active_players()
        if not ServerPersistence.save_snapshot():
            push_warning("Server snapshot failed")

func _exit_tree() -> void:
    if Net.role == "host":
        _save_active_players()
        ServerPersistence.save_snapshot()

func _save_active_players() -> void:
    for peer_id in _identities.sessions.keys():
        var uid: String = _identities.uid_for_peer(peer_id)
        if _simulation.players.has(uid):
            _identities.store_state(peer_id, _simulation.snapshot(uid))
    _identities.save_records()

func _on_peer_disconnected(peer_id: int) -> void:
    var uid: String = _identities.uid_for_peer(peer_id)
    if _simulation.players.has(uid):
        _identities.store_state(peer_id, _simulation.snapshot(uid))
        _simulation.players.erase(uid)
    _identities.disconnect(peer_id)
